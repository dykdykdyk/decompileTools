package android.support.v13.app;

import android.app.Fragment;

class FragmentCompatICSMR1
{
  public static void setUserVisibleHint(Fragment paramFragment, boolean paramBoolean)
  {
    paramFragment.setUserVisibleHint(paramBoolean);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     android.support.v13.app.FragmentCompatICSMR1
 * JD-Core Version:    0.6.2
 */