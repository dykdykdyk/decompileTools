package android.support.v13.app;

import android.app.Fragment;

class FragmentCompatICS
{
  public static void setMenuVisibility(Fragment paramFragment, boolean paramBoolean)
  {
    paramFragment.setMenuVisibility(paramBoolean);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     android.support.v13.app.FragmentCompatICS
 * JD-Core Version:    0.6.2
 */