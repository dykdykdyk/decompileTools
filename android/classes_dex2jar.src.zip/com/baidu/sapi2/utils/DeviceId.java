package com.baidu.sapi2.utils;

import android.content.Context;
import android.os.Environment;
import android.provider.Settings.Secure;
import android.provider.Settings.System;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.baidu.sapi2.security.Md5;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.UUID;

public final class DeviceId
{
  private static final String AES_KEY = "30212102dicudiab";
  private static final boolean DEBUG = false;
  private static final String EXT_FILE = "baidu/.cuid";
  private static final String KEY_DEVICE_ID = "com.baidu.deviceid";
  private static final String KEY_IMEI = "bd_setting_i";
  private static final String TAG = "DeviceId";

  private static void checkPermission(Context paramContext, String paramString)
  {
    if (paramContext.checkCallingOrSelfPermission(paramString) == 0);
    for (int i = 1; i == 0; i = 0)
      throw new SecurityException("Permission Denial: requires permission " + paramString);
  }

  public static String getAndroidId(Context paramContext)
  {
    String str = Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
    if (TextUtils.isEmpty(str))
      str = "";
    return str;
  }

  public static String getDeviceID(Context paramContext)
  {
    checkPermission(paramContext, "android.permission.WRITE_SETTINGS");
    checkPermission(paramContext, "android.permission.READ_PHONE_STATE");
    checkPermission(paramContext, "android.permission.WRITE_EXTERNAL_STORAGE");
    int i = 0;
    String str1 = "";
    try
    {
      str1 = Settings.System.getString(paramContext.getContentResolver(), "bd_setting_i");
      if (str1 == null)
        str1 = getIMEI(paramContext);
      Settings.System.putString(paramContext.getContentResolver(), "bd_setting_i", str1);
      str2 = getAndroidId(paramContext);
      if (i != 0)
        return Md5.toMd5(("com.baidu" + str2).getBytes(), true);
    }
    catch (Exception localException)
    {
      String str2;
      while (true)
        i = 1;
      String str3 = Settings.System.getString(paramContext.getContentResolver(), "com.baidu.deviceid");
      boolean bool = TextUtils.isEmpty(str3);
      String str4 = null;
      if (bool)
      {
        str4 = Md5.toMd5(("com.baidu" + str1 + str2).getBytes(), true);
        str3 = Settings.System.getString(paramContext.getContentResolver(), str4);
        if (!TextUtils.isEmpty(str3))
        {
          Settings.System.putString(paramContext.getContentResolver(), "com.baidu.deviceid", str3);
          setExternalDeviceId(str1, str3);
        }
      }
      if (TextUtils.isEmpty(str3))
      {
        str3 = getExternalDeviceId(str1);
        if (!TextUtils.isEmpty(str3))
        {
          Settings.System.putString(paramContext.getContentResolver(), str4, str3);
          Settings.System.putString(paramContext.getContentResolver(), "com.baidu.deviceid", str3);
        }
      }
      if (TextUtils.isEmpty(str3))
      {
        String str5 = UUID.randomUUID().toString();
        str3 = Md5.toMd5((str1 + str2 + str5).getBytes(), true);
        Settings.System.putString(paramContext.getContentResolver(), str4, str3);
        Settings.System.putString(paramContext.getContentResolver(), "com.baidu.deviceid", str3);
        setExternalDeviceId(str1, str3);
      }
      return str3;
    }
  }

  private static String getExternalDeviceId(String paramString)
  {
    String str1;
    if (TextUtils.isEmpty(paramString))
      str1 = "";
    while (true)
    {
      return str1;
      str1 = "";
      File localFile = new File(Environment.getExternalStorageDirectory(), "baidu/.cuid");
      try
      {
        BufferedReader localBufferedReader = new BufferedReader(new FileReader(localFile));
        StringBuilder localStringBuilder = new StringBuilder();
        while (true)
        {
          String str2 = localBufferedReader.readLine();
          if (str2 == null)
            break;
          localStringBuilder.append(str2);
          localStringBuilder.append("\r\n");
        }
        localBufferedReader.close();
        String[] arrayOfString = new String(AESUtil.decrypt("30212102dicudiab", "30212102dicudiab", Base64.decode(localStringBuilder.toString().getBytes()))).split("=");
        if ((arrayOfString != null) && (arrayOfString.length == 2) && (paramString.equals(arrayOfString[0])))
        {
          String str3 = arrayOfString[1];
          return str3;
        }
      }
      catch (Exception localException)
      {
        return str1;
      }
      catch (IOException localIOException)
      {
        return str1;
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
      }
    }
    return str1;
  }

  public static String getIMEI(Context paramContext)
  {
    String str = "";
    TelephonyManager localTelephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
    if (localTelephonyManager != null)
    {
      str = localTelephonyManager.getDeviceId();
      if (TextUtils.isEmpty(str))
        str = "";
    }
    return str;
  }

  private static void setExternalDeviceId(String paramString1, String paramString2)
  {
    if (TextUtils.isEmpty(paramString1))
      return;
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(paramString1);
    localStringBuilder.append("=");
    localStringBuilder.append(paramString2);
    File localFile = new File(Environment.getExternalStorageDirectory(), "baidu/.cuid");
    try
    {
      new File(localFile.getParent()).mkdirs();
      FileWriter localFileWriter = new FileWriter(localFile, false);
      localFileWriter.write(Base64.encode(AESUtil.encrypt("30212102dicudiab", "30212102dicudiab", localStringBuilder.toString().getBytes()), "utf-8"));
      localFileWriter.flush();
      localFileWriter.close();
      return;
    }
    catch (IOException localIOException)
    {
    }
    catch (Exception localException)
    {
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.utils.DeviceId
 * JD-Core Version:    0.6.2
 */