package com.baidu.sapi2.utils;

import java.io.UnsupportedEncodingException;

public final class Base64
{
  private static final byte[] MAP = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };

  public static byte[] decode(byte[] paramArrayOfByte)
  {
    return decode(paramArrayOfByte, paramArrayOfByte.length);
  }

  public static byte[] decode(byte[] paramArrayOfByte, int paramInt)
  {
    int i = 3 * (paramInt / 4);
    if (i == 0)
      return new byte[0];
    byte[] arrayOfByte1 = new byte[i];
    int j = 0;
    int k = paramArrayOfByte[(paramInt - 1)];
    int n;
    int i1;
    int i2;
    label75: int i5;
    int i7;
    label136: int i6;
    if ((k != 10) && (k != 13) && (k != 32) && (k != 9))
      if (k != 61)
      {
        int m = 0;
        n = 0;
        i1 = 0;
        i2 = 0;
        if (i1 >= paramInt)
          break label309;
        i5 = paramArrayOfByte[i1];
        if ((i5 == 10) || (i5 == 13) || (i5 == 32) || (i5 == 9))
          break label398;
        if ((i5 < 65) || (i5 > 90))
          break label232;
        i7 = i5 - 65;
        n = n << 6 | (byte)i7;
        if (m % 4 != 3)
          break label391;
        int i8 = i2 + 1;
        arrayOfByte1[i2] = ((byte)((0xFF0000 & n) >> 16));
        int i9 = i8 + 1;
        arrayOfByte1[i8] = ((byte)((0xFF00 & n) >> 8));
        i6 = i9 + 1;
        arrayOfByte1[i9] = ((byte)(n & 0xFF));
        label210: m++;
      }
    while (true)
    {
      i1++;
      i2 = i6;
      break label75;
      j++;
      paramInt--;
      break;
      label232: if ((i5 >= 97) && (i5 <= 122))
      {
        i7 = i5 - 71;
        break label136;
      }
      if ((i5 >= 48) && (i5 <= 57))
      {
        i7 = i5 + 4;
        break label136;
      }
      if (i5 == 43)
      {
        i7 = 62;
        break label136;
      }
      if (i5 == 47)
      {
        i7 = 63;
        break label136;
      }
      return null;
      label309: int i3;
      if (j > 0)
      {
        int i4 = n << j * 6;
        i3 = i2 + 1;
        arrayOfByte1[i2] = ((byte)((0xFF0000 & i4) >> 16));
        if (j == 1)
        {
          i2 = i3 + 1;
          arrayOfByte1[i3] = ((byte)((0xFF00 & i4) >> 8));
        }
      }
      else
      {
        i3 = i2;
      }
      byte[] arrayOfByte2 = new byte[i3];
      System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i3);
      return arrayOfByte2;
      label391: i6 = i2;
      break label210;
      label398: i6 = i2;
    }
  }

  public static String encode(byte[] paramArrayOfByte, String paramString)
    throws UnsupportedEncodingException
  {
    int i = 4 * paramArrayOfByte.length / 3;
    byte[] arrayOfByte = new byte[i + (3 + i / 76)];
    int j = 0;
    int k = paramArrayOfByte.length - paramArrayOfByte.length % 3;
    int m = 0;
    int n = 0;
    int i12;
    int i13;
    if (m < k)
    {
      int i9 = n + 1;
      arrayOfByte[n] = MAP[((0xFF & paramArrayOfByte[m]) >> 2)];
      int i10 = i9 + 1;
      arrayOfByte[i9] = MAP[((0x3 & paramArrayOfByte[m]) << 4 | (0xFF & paramArrayOfByte[(m + 1)]) >> 4)];
      int i11 = i10 + 1;
      arrayOfByte[i10] = MAP[((0xF & paramArrayOfByte[(m + 1)]) << 2 | (0xFF & paramArrayOfByte[(m + 2)]) >> 6)];
      i12 = i11 + 1;
      arrayOfByte[i11] = MAP[(0x3F & paramArrayOfByte[(m + 2)])];
      if (((i12 - j) % 76 != 0) || (i12 == 0))
        break label425;
      i13 = i12 + 1;
      arrayOfByte[i12] = 10;
      j++;
    }
    while (true)
    {
      m += 3;
      n = i13;
      break;
      switch (paramArrayOfByte.length % 3)
      {
      default:
      case 1:
      case 2:
      }
      while (true)
      {
        int i8;
        for (int i4 = n; ; i4 = i8)
        {
          return new String(arrayOfByte, 0, i4, paramString);
          int i5 = n + 1;
          arrayOfByte[n] = MAP[((0xFF & paramArrayOfByte[k]) >> 2)];
          int i6 = i5 + 1;
          arrayOfByte[i5] = MAP[((0x3 & paramArrayOfByte[k]) << 4)];
          int i7 = i6 + 1;
          arrayOfByte[i6] = 61;
          i8 = i7 + 1;
          arrayOfByte[i7] = 61;
        }
        int i1 = n + 1;
        arrayOfByte[n] = MAP[((0xFF & paramArrayOfByte[k]) >> 2)];
        int i2 = i1 + 1;
        arrayOfByte[i1] = MAP[((0x3 & paramArrayOfByte[k]) << 4 | (0xFF & paramArrayOfByte[(k + 1)]) >> 4)];
        int i3 = i2 + 1;
        arrayOfByte[i2] = MAP[((0xF & paramArrayOfByte[(k + 1)]) << 2)];
        n = i3 + 1;
        arrayOfByte[i3] = 61;
      }
      label425: i13 = i12;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.utils.Base64
 * JD-Core Version:    0.6.2
 */