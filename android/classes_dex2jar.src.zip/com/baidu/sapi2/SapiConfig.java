package com.baidu.sapi2;

import android.text.TextUtils;
import com.baidu.sapi2.social.config.BindType;
import com.baidu.sapi2.social.config.Display;
import com.baidu.sapi2.social.config.Domain;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;

public class SapiConfig
{
  public static final int SSL_AES = 6;
  private Display DISPLAY = Display.NATIVE;
  private String deviceInfo = "";
  private String devicePackageSign = "";
  private boolean enableYi = true;
  private boolean isDebuggable = false;
  private boolean isShare = true;
  private boolean isShowDevice = false;
  private String mAppId;
  private BindType mBindType = BindType.IMPLICIT;
  private String mClientId;
  private String mClientIp;
  private CppUtils mCppUtils;
  private Domain mDomain = Domain.DOMAIN_ONLINE;
  private String mSignKey;
  private String mTpl;

  public SapiConfig(String paramString1, String paramString2, String paramString3, Domain paramDomain)
  {
    this(paramString1, paramString2, paramString3, paramDomain, BindType.IMPLICIT, true, true);
  }

  public SapiConfig(String paramString1, String paramString2, String paramString3, Domain paramDomain, BindType paramBindType)
  {
    this(paramString1, paramString2, paramString3, paramDomain, paramBindType, true, true);
  }

  public SapiConfig(String paramString1, String paramString2, String paramString3, Domain paramDomain, BindType paramBindType, boolean paramBoolean)
  {
    this(paramString1, paramString2, paramString3, paramDomain, paramBindType, paramBoolean, true);
  }

  public SapiConfig(String paramString1, String paramString2, String paramString3, Domain paramDomain, BindType paramBindType, boolean paramBoolean1, boolean paramBoolean2)
  {
    this.mTpl = paramString1;
    this.mAppId = paramString2;
    this.mSignKey = paramString3;
    this.mClientIp = getLocalIpAddress();
    this.mDomain = paramDomain;
    this.mBindType = paramBindType;
    this.mCppUtils = new CppUtils();
    this.isShare = paramBoolean1;
    this.enableYi = paramBoolean2;
    if (!paramDomain.getURL().equals(Domain.DOMAIN_ONLINE.getURL()))
      this.isDebuggable = true;
    this.deviceInfo = Utils.createDeviceInfo();
  }

  private String getLocalIpAddress()
  {
    try
    {
      InetAddress localInetAddress;
      do
      {
        Enumeration localEnumeration1 = NetworkInterface.getNetworkInterfaces();
        Enumeration localEnumeration2;
        while (!localEnumeration2.hasMoreElements())
        {
          if (!localEnumeration1.hasMoreElements())
            break;
          localEnumeration2 = ((NetworkInterface)localEnumeration1.nextElement()).getInetAddresses();
        }
        localInetAddress = (InetAddress)localEnumeration2.nextElement();
      }
      while (localInetAddress.isLoopbackAddress());
      String str = localInetAddress.getHostAddress().toString();
      return str;
    }
    catch (SocketException localSocketException)
    {
    }
    return null;
  }

  public String getAppId()
  {
    return this.mAppId;
  }

  public String getApplyregcode()
  {
    return getDomain().getURL() + this.mCppUtils.nativeConfigApplyregcode();
  }

  public String getAskDynamicPwd()
  {
    return getDomain().getURL() + this.mCppUtils.nativeAskDynamicPwd();
  }

  public BindType getBindType()
  {
    return this.mBindType;
  }

  public String getClientId()
  {
    if (Utils.isValid(this.mClientId))
      return this.mClientId;
    return "123456789";
  }

  public String getClientIp()
  {
    return this.mClientIp;
  }

  public int getCryptType()
  {
    return 6;
  }

  public String getDeviceCheck()
  {
    return getDomain().getDeviceUrl() + this.mCppUtils.nativeGetDeviceCheck();
  }

  public String getDeviceForceReg()
  {
    return getDomain().getDeviceUrl() + this.mCppUtils.nativeGetDeviceForceReg();
  }

  public String getDeviceInfo()
  {
    return this.deviceInfo;
  }

  public String getDeviceLogin()
  {
    return getDomain().getDeviceUrl() + this.mCppUtils.nativeGetDeviceLogin();
  }

  public String getDevicePackageSign()
  {
    return this.devicePackageSign;
  }

  public String getDeviceReg()
  {
    return getDomain().getDeviceUrl() + this.mCppUtils.nativeGetDeviceReg();
  }

  public Display getDisplay()
  {
    return this.DISPLAY;
  }

  public Domain getDomain()
  {
    return this.mDomain;
  }

  public String getDomainSSOFinish()
  {
    if ((getDomain().getURL().startsWith("http://")) && (!this.isDebuggable))
      return getDomain().getURL().replace("http://", "https://") + this.mCppUtils.nativeGetSSOFinish();
    return getDomain().getURL() + this.mCppUtils.nativeGetSSOFinish();
  }

  public String getDomainSSOStart()
  {
    if ((getDomain().getURL().startsWith("http://")) && (!this.isDebuggable))
      return getDomain().getURL().replace("http://", "https://") + this.mCppUtils.nativeGetSSOStart();
    return getDomain().getURL() + this.mCppUtils.nativeGetSSOStart();
  }

  public String getDomanAfterAuth()
  {
    return getDomain().getURL() + this.mCppUtils.nativeGetSocialAfterAuth();
  }

  public String getDomanFillFinish()
  {
    return getDomain().getWap() + this.mCppUtils.nativeGetFillFinish();
  }

  public String getDomanFillStart()
  {
    return getDomain().getWap() + this.mCppUtils.nativeGetFillStart();
  }

  public String getDomanFinishBind()
  {
    return getDomain().getURL() + this.mCppUtils.nativeGetSocialFinishAuth();
  }

  public String getDomanStart()
  {
    return getDomain().getURL() + this.mCppUtils.nativeGetSocialStart();
  }

  public String getDownloadLogin()
  {
    return getDomain().getURL() + this.mCppUtils.nativeGetDownloadLogin();
  }

  public String getFastReg()
  {
    return getDomain().getURL() + this.mCppUtils.nativeGetFastReg();
  }

  public String getFilluname()
  {
    return getDomain().getURL() + "/v2/sapi/center/filluname";
  }

  public String getGenimage()
  {
    return getDomain().getURL() + "/cgi-bin/genimage?";
  }

  public String getLastCert()
  {
    return "http://passport.baidu.com/sslcrypt/get_last_cert";
  }

  public String getLogin()
  {
    return getDomain().getURL() + this.mCppUtils.nativeConfigLogin();
  }

  public String getLogout()
  {
    return getDomain().getURL() + this.mCppUtils.nativeConfigLogout();
  }

  public PassportDomanGetter getPassportDomanGetter()
  {
    if ((!TextUtils.isEmpty(this.mDomain.getURL())) && (this.mDomain.getURL().equals(Domain.DOMAIN_ONLINE.getURL())))
    {
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(this.mCppUtils.nativeConfigPassDoman1());
      localArrayList.add(this.mCppUtils.nativeConfigPassDoman2());
      localArrayList.add(this.mCppUtils.nativeConfigPassDoman3());
      return new PassportDomanGetter(localArrayList, 3);
    }
    return null;
  }

  public String getPhoneregverify()
  {
    return getDomain().getURL() + this.mCppUtils.nativeConfigPhoneregverify();
  }

  public String getQRAppLogin()
  {
    return getDomain().getURL() + this.mCppUtils.nativeGetQrAppLogin();
  }

  public String getQrPCLogin()
  {
    return getDomain().getURL() + this.mCppUtils.nativeGetQrPCLogin();
  }

  public String getRegdatacheck()
  {
    return getDomain().getURL() + this.mCppUtils.nativeConfigRegdatacheck();
  }

  public String getSignkey()
  {
    return this.mSignKey;
  }

  public String getTpl()
  {
    return this.mTpl;
  }

  public boolean isClientIpValid()
  {
    return (this.mClientIp != null) && (this.mClientIp.length() > 0);
  }

  public boolean isDebuggable()
  {
    return this.isDebuggable;
  }

  public boolean isEnableYi()
  {
    return this.enableYi;
  }

  public boolean isShare()
  {
    return this.isShare;
  }

  public boolean isShowDevice()
  {
    return this.isShowDevice;
  }

  public void setClientId(String paramString)
  {
    this.mClientId = paramString;
  }

  public void setDevicePackageSign(String paramString)
  {
    this.devicePackageSign = paramString;
  }

  public void setDomain(Domain paramDomain)
  {
    this.mDomain = paramDomain;
  }

  public void setEnableYi(boolean paramBoolean)
  {
    this.enableYi = paramBoolean;
  }

  public void setShowDevice(boolean paramBoolean)
  {
    this.isShowDevice = paramBoolean;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.SapiConfig
 * JD-Core Version:    0.6.2
 */