package com.baidu.sapi2;

public abstract interface IFirstInstallLoginShareListener
{
  public abstract void onSuccess();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.IFirstInstallLoginShareListener
 * JD-Core Version:    0.6.2
 */