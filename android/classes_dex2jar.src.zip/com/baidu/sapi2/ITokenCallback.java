package com.baidu.sapi2;

public abstract interface ITokenCallback
{
  public abstract void onResult(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.ITokenCallback
 * JD-Core Version:    0.6.2
 */