package com.baidu.sapi2.model;

public class FillUnameResponse
{
  public String mBduss;
  public String mDisplayname;
  public String mPtoken;
  public String mStoken;
  public String mUid;
  public String mUserName;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.model.FillUnameResponse
 * JD-Core Version:    0.6.2
 */