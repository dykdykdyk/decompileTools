package com.baidu.sapi2.model;

import com.baidu.sapi2.loginshare.LoginShareEvent;
import com.baidu.sapi2.loginshare.Token;

public class LoginResponse
{
  public String city;
  public String mAuth = null;
  public String mBduss = null;
  public String mDisplayname = null;
  public String mEmail = null;
  public boolean mNeedVerifyCode = false;
  public String mPtoken = null;
  public String mStoken = null;
  public String mUid = null;
  public String mUsername = null;
  public String mVcodeStr = null;
  public int mWeakPass = 0;
  public String province;

  public Token toToken()
  {
    Token localToken = new Token();
    localToken.mEvent = LoginShareEvent.VALID;
    localToken.mDisplayname = this.mDisplayname;
    localToken.mBduss = this.mBduss;
    localToken.mUsername = this.mUsername;
    localToken.mEmail = this.mEmail;
    localToken.mPtoken = this.mPtoken;
    return localToken;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.model.LoginResponse
 * JD-Core Version:    0.6.2
 */