package com.baidu.sapi2.model;

public class QrPcLoginResponse
{
  public String mCity;
  public String mProvince;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.model.QrPcLoginResponse
 * JD-Core Version:    0.6.2
 */