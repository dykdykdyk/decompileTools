package com.baidu.sapi2.model;

public class PhoneRegResponse
{
  public String mBduss = null;
  public String mDisplayname = null;
  public String mPtoken = null;
  public String mStoken = null;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.model.PhoneRegResponse
 * JD-Core Version:    0.6.2
 */