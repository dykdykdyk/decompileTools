package com.baidu.sapi2.model;

public class LogoutResponse
{
  public String mBduss;
  public String mPtoken;
  public String mUid;
  public String mUsername;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.model.LogoutResponse
 * JD-Core Version:    0.6.2
 */