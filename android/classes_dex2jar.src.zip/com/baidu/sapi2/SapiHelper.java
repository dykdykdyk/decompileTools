package com.baidu.sapi2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import com.baidu.sapi2.account.DisplayAccount;
import com.baidu.sapi2.log.Logger;
import com.baidu.sapi2.loginshare.ILoginShareListener;
import com.baidu.sapi2.loginshare.LoginShareAssistant;
import com.baidu.sapi2.loginshare.LoginShareEvent;
import com.baidu.sapi2.loginshare.Token;
import com.baidu.sapi2.social.config.Domain;
import com.baidu.sapi2.social.config.SocialType;
import com.baidu.sapi2.social.model.FillUProfileResponse;
import com.baidu.sapi2.social.model.SocialResponse;
import com.baidu.sapi2.social.utils.SocialHelper;
import org.json.JSONException;
import org.json.JSONObject;

public class SapiHelper
{
  private static SapiHelper mInstance = null;
  private boolean isEnableUserShare = true;
  private IFirstInstallLoginShareListener mFirstInstallLoginShareListener = null;
  private LoginShareAssistant mLoginShareAssistant = new LoginShareAssistant();
  private LoginShareListener mLoginShareListener = new LoginShareListener(null);
  private SapiClient mSapiClient = new SapiClient();
  private SocialHelper mSocialHelper = new SocialHelper();
  private Token mToken;
  private SapiConfig sapiConfig = null;

  private boolean deviceCheck()
  {
    return this.mSapiClient.deviceCheck();
  }

  public static SapiHelper getInstance()
  {
    try
    {
      if (mInstance == null)
        mInstance = new SapiHelper();
      SapiHelper localSapiHelper = mInstance;
      return localSapiHelper;
    }
    finally
    {
    }
  }

  private void setTokenCallBack(ITokenCallback paramITokenCallback)
  {
    this.mSapiClient.setTokenCallBack(paramITokenCallback);
  }

  public SocialResponse authResult(String paramString, SocialType paramSocialType)
  {
    return this.mSocialHelper.authResult(paramString, paramSocialType);
  }

  public String blockingGetAuthToken()
  {
    if (this.mToken == null)
      return null;
    return this.mToken.mBduss;
  }

  public boolean cancelRequest()
  {
    if (this.mSapiClient != null)
    {
      this.mSapiClient.cancelRequest();
      return true;
    }
    return false;
  }

  public void destroy()
  {
    if (this.mSapiClient != null)
      this.mSapiClient.destory();
    if (this.mLoginShareAssistant != null)
      this.mLoginShareAssistant.destroy();
  }

  public boolean deviceLoginAndReg(SapiCallBack paramSapiCallBack)
  {
    if (!this.sapiConfig.isShowDevice());
    while (this.mLoginShareAssistant == null)
      return false;
    String str = this.mLoginShareAssistant.getDeviceToken();
    if ((TextUtils.isEmpty(str)) || ("null".equalsIgnoreCase(str)))
      return this.mSapiClient.deviceRegister(paramSapiCallBack);
    return this.mSapiClient.deviceLogin(paramSapiCallBack, str);
  }

  public void disableUserShare()
  {
    this.isEnableUserShare = false;
  }

  public boolean downloadLogin(SapiCallBack paramSapiCallBack, String paramString)
  {
    return this.mSapiClient.downloadLogin(paramSapiCallBack, paramString);
  }

  public void enableUserShare()
  {
    this.isEnableUserShare = true;
  }

  public FillUProfileResponse fillUProfileResult(String paramString)
  {
    return this.mSocialHelper.fillUProfileResult(paramString);
  }

  public boolean fillUname(SapiCallBack paramSapiCallBack, String paramString1, String paramString2, String paramString3)
  {
    return this.mSapiClient.fillUname(paramSapiCallBack, paramString1, paramString2, paramString3);
  }

  public boolean getAskDynamicPass(SapiCallBack paramSapiCallBack, String paramString)
  {
    return this.mSapiClient.askDynamicPass(paramSapiCallBack, paramString);
  }

  void getAuthTokenAsync(ITokenCallback paramITokenCallback)
  {
    getAuthTokenAsync(paramITokenCallback, null, null);
  }

  void getAuthTokenAsync(ITokenCallback paramITokenCallback, Activity paramActivity, Class paramClass)
  {
    getAuthTokenAsync(paramITokenCallback, paramActivity, paramClass, -1);
  }

  void getAuthTokenAsync(ITokenCallback paramITokenCallback, Activity paramActivity, Class paramClass, int paramInt)
  {
    onLoginShareActivityCreate();
    setTokenCallBack(paramITokenCallback);
    if ((paramActivity != null) && (paramClass != null))
      paramActivity.startActivityForResult(new Intent(paramActivity, paramClass), paramInt);
  }

  public String getBDUSSCookieString(String paramString)
  {
    if (!isLogin())
      return null;
    return "BDUSS=" + paramString + ";domain=baidu.com;path=/";
  }

  public boolean getFastReg(SapiCallBack paramSapiCallBack, String paramString)
  {
    return this.mSapiClient.fastReg(paramSapiCallBack, paramString);
  }

  public boolean getIsUserShare()
  {
    return this.isEnableUserShare;
  }

  public String getPtokenCookieString(String paramString)
  {
    if (!isLogin())
      return null;
    return "PTOKEN=" + paramString + ";domain=" + this.sapiConfig.getDomain().getWap().replace("http://", "") + ";path=/";
  }

  public boolean getQrAppLogin(SapiCallBack paramSapiCallBack, String paramString1, String paramString2)
  {
    return this.mSapiClient.qrAppLogin(paramSapiCallBack, paramString1, paramString2);
  }

  public boolean getQrPCLogin(SapiCallBack paramSapiCallBack, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    return this.mSapiClient.qrPCLogin(paramSapiCallBack, paramString1, paramString2, paramString3, paramString4, paramString5);
  }

  public boolean getSmsCode(SapiCallBack paramSapiCallBack, String paramString)
  {
    return this.mSapiClient.getSmsCode(paramSapiCallBack, paramString, null, null);
  }

  public boolean getSmsCode(SapiCallBack paramSapiCallBack, String paramString1, String paramString2, String paramString3)
  {
    return this.mSapiClient.getSmsCode(paramSapiCallBack, paramString1, paramString2, paramString3);
  }

  public String getSocialAfterAuthUrl()
  {
    return this.mSocialHelper.getUrlAfterAuth();
  }

  public String getSocialBindUrl(SocialType paramSocialType)
  {
    return this.mSocialHelper.getUrlBind(paramSocialType);
  }

  public String getSocialBindUrl(SocialType paramSocialType, String paramString1, String paramString2)
  {
    return this.mSocialHelper.getUrlBind(paramSocialType, paramString1, paramString2);
  }

  public String getSocialFillFinishUrl()
  {
    return this.mSocialHelper.getUrlFillFinish();
  }

  public String getSocialFillStartUrl()
  {
    return this.mSocialHelper.getUrlFillStart();
  }

  public String getSocialFinishBindUrl()
  {
    return this.mSocialHelper.getUrlFinishBind();
  }

  public String getSocialSSOFinishUrl()
  {
    return this.mSocialHelper.getUrlSSOFinish();
  }

  public Token getToken()
  {
    return this.mToken;
  }

  public String getUserData(String paramString)
  {
    Object localObject = "";
    if (this.mToken == null)
      return null;
    if (paramString.equals("username"))
      return this.mToken.mUsername;
    if (paramString.equals("device_token"))
      return this.mToken.deviceToken;
    if ((paramString.equals("ptoken")) && (!TextUtils.isEmpty(this.mToken.mPtoken)))
      return this.mToken.mPtoken;
    if (paramString.equals("displayname"))
    {
      if (!TextUtils.isEmpty(this.mToken.mDisplayname))
        return this.mToken.mDisplayname;
      if (!TextUtils.isEmpty(this.mToken.mUsername))
        return this.mToken.mUsername;
      if (!TextUtils.isEmpty(this.mToken.mEmail))
        return this.mToken.mEmail;
      if (!TextUtils.isEmpty(this.mToken.mPhoneNumber))
        return this.mToken.mPhoneNumber;
    }
    if (this.mToken.mJson != null);
    try
    {
      String str = new JSONObject(this.mToken.mJson).optString(paramString);
      localObject = str;
      return localObject;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        Logger.w(localJSONException);
    }
  }

  public boolean getVerifyImg(SapiCallBack paramSapiCallBack, String paramString)
  {
    return this.mSapiClient.getVerifyImg(paramSapiCallBack, paramString);
  }

  boolean initial(Context paramContext, SapiConfig paramSapiConfig)
  {
    this.mSapiClient.initial(paramContext, paramSapiConfig);
    this.mLoginShareAssistant.initial(paramContext, paramSapiConfig.getTpl(), paramSapiConfig.getAppId());
    this.mSocialHelper.initial(paramContext, paramSapiConfig);
    if (!TextUtils.isEmpty(paramSapiConfig.getDevicePackageSign()))
      deviceCheck();
    if ((this.mLoginShareAssistant.getLastToken() != null) && (this.mLoginShareAssistant.getLastToken().mEvent == LoginShareEvent.VALID))
      this.mToken = this.mLoginShareAssistant.getLastToken();
    setLoginShareListener(this.mLoginShareListener);
    this.sapiConfig = paramSapiConfig;
    return true;
  }

  public void invalid(boolean paramBoolean)
  {
    if ((this.isEnableUserShare) && (paramBoolean))
      this.mLoginShareAssistant.invalid(this.mToken);
    invalidToken();
  }

  void invalidToken()
  {
    setToken(new Token());
  }

  public void invalidateAuthToken()
  {
    this.mLoginShareAssistant.invalid(this.mToken);
  }

  public boolean isDebuggable()
  {
    if (this.sapiConfig != null)
      return this.sapiConfig.isDebuggable();
    return false;
  }

  public boolean isLogin()
  {
    return (this.mToken != null) && (!TextUtils.isEmpty(this.mToken.mBduss));
  }

  public boolean isShare()
  {
    if (this.sapiConfig != null)
      return this.sapiConfig.isShare();
    return true;
  }

  public boolean isShowDevice()
  {
    if (this.sapiConfig != null)
      return this.sapiConfig.isShowDevice();
    return false;
  }

  public boolean login(SapiCallBack paramSapiCallBack, boolean paramBoolean1, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean2)
  {
    return this.mSapiClient.login(paramSapiCallBack, paramBoolean1, paramString1, paramString2, paramString3, paramString4, paramBoolean2);
  }

  public boolean login(SapiCallBack paramSapiCallBack, boolean paramBoolean1, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean2, DisplayAccount paramDisplayAccount)
  {
    return this.mSapiClient.login(paramSapiCallBack, paramBoolean1, paramString1, paramString2, paramString3, paramString4, paramBoolean2, paramDisplayAccount);
  }

  public boolean login(SapiCallBack paramSapiCallBack, boolean paramBoolean1, String paramString1, String paramString2, boolean paramBoolean2)
  {
    return this.mSapiClient.login(paramSapiCallBack, paramBoolean1, paramString1, paramString2, null, null, paramBoolean2);
  }

  public boolean logout()
  {
    Token localToken = this.mToken;
    boolean bool1 = false;
    if (localToken != null)
    {
      if (this.mToken.isSocialAccount)
        break label38;
      bool1 = this.mSapiClient.logout(this.mToken.mBduss);
    }
    label38: boolean bool3;
    do
    {
      boolean bool2;
      do
      {
        return bool1;
        bool2 = this.mSapiClient.logout(this.mToken.mBduss);
        bool1 = false;
      }
      while (!bool2);
      bool3 = this.mSapiClient.logout(this.mLoginShareAssistant.getOtherBduss());
      bool1 = false;
    }
    while (!bool3);
    return true;
  }

  public void onLoginShareActivityCreate()
  {
    this.mLoginShareAssistant.onActivityCreate();
  }

  public boolean phoneReg(SapiCallBack paramSapiCallBack, String paramString1, String paramString2, String paramString3, String paramString4)
  {
    return this.mSapiClient.phoneReg(paramSapiCallBack, paramString1, paramString2, paramString3, paramString4);
  }

  public boolean regDataCheck(SapiCallBack paramSapiCallBack, String paramString1, String paramString2, String paramString3)
  {
    return this.mSapiClient.regDataCheck(paramSapiCallBack, paramString1, paramString2, paramString3);
  }

  void setFirstInstallLoginShareListener(IFirstInstallLoginShareListener paramIFirstInstallLoginShareListener)
  {
    this.mFirstInstallLoginShareListener = paramIFirstInstallLoginShareListener;
  }

  public void setLoginShareListener(ILoginShareListener paramILoginShareListener)
  {
    if (!this.isEnableUserShare)
      return;
    this.mLoginShareAssistant.setLoginShareListener(paramILoginShareListener);
  }

  public void setShowDevice(boolean paramBoolean)
  {
    this.sapiConfig.setShowDevice(paramBoolean);
  }

  public void setToken(Token paramToken)
  {
    this.mToken = paramToken;
  }

  void startFillNameActivity(Activity paramActivity, Class paramClass, int paramInt)
  {
    if ((paramActivity != null) && (paramClass != null))
      paramActivity.startActivityForResult(new Intent(paramActivity, paramClass), paramInt);
  }

  public void valid()
  {
    if (this.isEnableUserShare)
      this.mLoginShareAssistant.valid(this.mToken);
  }

  private class LoginShareListener
    implements ILoginShareListener
  {
    private LoginShareListener()
    {
    }

    public void onLoginShareEvent(Token paramToken)
    {
      Logger.d("hahahah:" + paramToken.mEvent);
      if (paramToken.mEvent == LoginShareEvent.VALID)
      {
        SapiHelper.access$102(SapiHelper.this, paramToken);
        if (SapiHelper.this.mFirstInstallLoginShareListener != null)
          SapiHelper.this.mFirstInstallLoginShareListener.onSuccess();
      }
      while (paramToken.mEvent != LoginShareEvent.INVALID)
        return;
      SapiHelper.this.invalidToken();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.SapiHelper
 * JD-Core Version:    0.6.2
 */