package com.baidu.sapi2.security;

import java.security.NoSuchAlgorithmException;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AES
{
  private static final String ENCODING = "UTF-8";

  private static String bytesToHex(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte == null)
    {
      str = null;
      return str;
    }
    int i = paramArrayOfByte.length;
    String str = "";
    int j = 0;
    label16: if (j < i)
      if ((0xFF & paramArrayOfByte[j]) >= 16)
        break label72;
    label72: for (str = str + "0" + Integer.toHexString(0xFF & paramArrayOfByte[j]); ; str = str + Integer.toHexString(0xFF & paramArrayOfByte[j]))
    {
      j++;
      break label16;
      break;
    }
  }

  public static byte[] decrypt(byte[] paramArrayOfByte, String paramString1, String paramString2)
    throws Exception
  {
    if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0))
      throw new Exception("Empty string");
    try
    {
      IvParameterSpec localIvParameterSpec = new IvParameterSpec(paramString1.getBytes("UTF-8"));
      SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramString2.getBytes(), "AES");
      Cipher localCipher = Cipher.getInstance("AES/CBC/NoPadding");
      localCipher.init(2, localSecretKeySpec, localIvParameterSpec);
      byte[] arrayOfByte = localCipher.doFinal(paramArrayOfByte);
      return arrayOfByte;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      localNoSuchAlgorithmException.printStackTrace();
      return null;
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      localNoSuchPaddingException.printStackTrace();
    }
    return null;
  }

  public static byte[] encrypt(String paramString1, String paramString2, String paramString3)
    throws Exception
  {
    if ((paramString1 == null) || (paramString1.length() == 0))
      throw new Exception("Empty string");
    try
    {
      IvParameterSpec localIvParameterSpec = new IvParameterSpec(paramString2.getBytes("UTF-8"));
      SecretKeySpec localSecretKeySpec = new SecretKeySpec(paramString3.getBytes(), "AES");
      Cipher localCipher = Cipher.getInstance("AES/CBC/NoPadding");
      localCipher.init(1, localSecretKeySpec, localIvParameterSpec);
      byte[] arrayOfByte = localCipher.doFinal(padString(paramString1).getBytes());
      return arrayOfByte;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      localNoSuchAlgorithmException.printStackTrace();
      return null;
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      localNoSuchPaddingException.printStackTrace();
    }
    return null;
  }

  private static byte[] hexToBytes(String paramString)
  {
    byte[] arrayOfByte = null;
    if (paramString == null);
    while (true)
    {
      return arrayOfByte;
      int i = paramString.length();
      arrayOfByte = null;
      if (i >= 2)
      {
        int j = paramString.length() / 2;
        arrayOfByte = new byte[j];
        for (int k = 0; k < j; k++)
          arrayOfByte[k] = ((byte)Integer.parseInt(paramString.substring(k * 2, 2 + k * 2), 16));
      }
    }
  }

  private static String padString(String paramString)
  {
    int i = 16 - paramString.length() % 16;
    for (int j = 0; j < i; j++)
      paramString = paramString + ' ';
    return paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.security.AES
 * JD-Core Version:    0.6.2
 */