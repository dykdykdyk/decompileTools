package com.baidu.sapi2.security;

import com.baidu.sapi2.log.Logger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Md5
{
  public String str;

  public static String md5s(String paramString)
  {
    String str1 = "";
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(paramString.getBytes());
      byte[] arrayOfByte = localMessageDigest.digest();
      StringBuffer localStringBuffer = new StringBuffer("");
      for (int i = 0; i < arrayOfByte.length; i++)
      {
        int j = arrayOfByte[i];
        if (j < 0)
          j += 256;
        if (j < 16)
          localStringBuffer.append("0");
        localStringBuffer.append(Integer.toHexString(j));
      }
      str1 = localStringBuffer.toString();
      String str2 = localStringBuffer.toString();
      return str2;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      Logger.w(localNoSuchAlgorithmException);
    }
    return str1;
  }

  public static String toHexString(byte[] paramArrayOfByte, String paramString, boolean paramBoolean)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = paramArrayOfByte.length;
    for (int j = 0; j < i; j++)
    {
      String str1 = Integer.toHexString(0xFF & paramArrayOfByte[j]);
      if (paramBoolean)
        str1 = str1.toUpperCase();
      if (str1.length() == 1)
        localStringBuilder.append("0");
      localStringBuilder.append(str1).append(paramString);
    }
    return localStringBuilder.toString();
  }

  public static String toMd5(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.reset();
      localMessageDigest.update(paramArrayOfByte);
      String str1 = toHexString(localMessageDigest.digest(), "", paramBoolean);
      return str1;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      throw new RuntimeException(localNoSuchAlgorithmException);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.security.Md5
 * JD-Core Version:    0.6.2
 */