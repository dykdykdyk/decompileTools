package com.baidu.sapi2.security;

import android.text.TextUtils;
import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.Random;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.security.cert.CertificateException;
import javax.security.cert.X509Certificate;
import org.json.JSONArray;

public class EncryptHelper
{
  private String mKey = "kf1t9tsczk16vc8z";

  private String createAESKey()
  {
    Random localRandom = new Random();
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < 16; i++)
      localStringBuffer.append("abcdefghijklmnopqrstuvwxyz0123456789".charAt(localRandom.nextInt("abcdefghijklmnopqrstuvwxyz0123456789".length())));
    return localStringBuffer.toString();
  }

  private byte[] encrypt(Key paramKey, byte[] paramArrayOfByte)
    throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException
  {
    Cipher localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    localCipher.init(1, paramKey);
    return localCipher.doFinal(paramArrayOfByte);
  }

  public String decrypt(String paramString)
    throws Exception
  {
    return new String(AES.decrypt(Base64.decode(paramString), new StringBuffer(this.mKey).reverse().toString(), this.mKey), "UTF-8");
  }

  public String encrypt(String paramString1, String paramString2)
    throws CertificateException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException
  {
    if ((TextUtils.isEmpty(paramString1)) || (TextUtils.isEmpty(paramString2)))
      return null;
    PublicKey localPublicKey = X509Certificate.getInstance(new ByteArrayInputStream(paramString1.getBytes())).getPublicKey();
    JSONArray localJSONArray = new JSONArray();
    byte[] arrayOfByte1 = paramString2.getBytes("UTF-8");
    int i;
    int j;
    if (arrayOfByte1.length % 116 == 0)
    {
      i = arrayOfByte1.length / 116;
      j = 0;
      label71: if (j >= i)
        break label219;
      if (1 != i)
        break label119;
      localJSONArray.put(Base64.encode(encrypt(localPublicKey, arrayOfByte1)));
    }
    while (true)
    {
      j++;
      break label71;
      i = 1 + arrayOfByte1.length / 116;
      break;
      label119: if (j != i - 1)
      {
        byte[] arrayOfByte3 = new byte[116];
        System.arraycopy(arrayOfByte1, j * 116, arrayOfByte3, 0, 116);
        localJSONArray.put(Base64.encode(encrypt(localPublicKey, arrayOfByte3)));
      }
      else
      {
        int k = arrayOfByte1.length - j * 116;
        byte[] arrayOfByte2 = new byte[k];
        System.arraycopy(arrayOfByte1, j * 116, arrayOfByte2, 0, k);
        localJSONArray.put(Base64.encode(encrypt(localPublicKey, arrayOfByte2)));
      }
    }
    label219: return Base64.encode(localJSONArray.toString().getBytes("UTF-8"));
  }

  public String getAESKey()
  {
    return this.mKey;
  }

  public void setAESKey(String paramString)
  {
    this.mKey = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.security.EncryptHelper
 * JD-Core Version:    0.6.2
 */