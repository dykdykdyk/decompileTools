package com.baidu.sapi2.security;

import com.baidu.sapi2.log.Logger;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class Base64
{
  static String[] sBaseSting = { "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/" };

  public static int decode(char paramChar, int paramInt)
  {
    char[] arrayOfChar = sBaseSting[paramInt].toCharArray();
    if (paramChar == '=')
    {
      i = 0;
      return i;
    }
    for (int i = 0; ; i++)
    {
      if (i >= 64)
        break label40;
      if (arrayOfChar[i] == paramChar)
        break;
    }
    label40: throw new RuntimeException("unexpected code: " + paramChar);
  }

  public static void decode(String paramString, ByteArrayOutputStream paramByteArrayOutputStream)
  {
    int i = paramString.length();
    int j = paramString.length() % 4;
    if (j > 0);
    int k;
    for (j = 4 - j; ; j--)
    {
      k = 0;
      if (j <= 0)
        break;
      paramString = paramString + '=';
    }
    while (true)
      if ((k < i) && (paramString.charAt(k) <= ' '))
      {
        k++;
      }
      else
      {
        if (k == i);
        int m;
        do
        {
          do
          {
            return;
            m = (decode(paramString.charAt(k), 0) << 18) + (decode(paramString.charAt(k + 1), 0) << 12) + (decode(paramString.charAt(k + 2), 0) << 6) + decode(paramString.charAt(k + 3), 0);
            paramByteArrayOutputStream.write(0xFF & m >> 16);
          }
          while (paramString.charAt(k + 2) == '=');
          paramByteArrayOutputStream.write(0xFF & m >> 8);
        }
        while (paramString.charAt(k + 3) == '=');
        paramByteArrayOutputStream.write(m & 0xFF);
        k += 4;
      }
  }

  public static byte[] decode(String paramString)
  {
    byte[] arrayOfByte = null;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    if (paramString == null)
      return null;
    try
    {
      decode(paramString, localByteArrayOutputStream);
      arrayOfByte = localByteArrayOutputStream.toByteArray();
      localByteArrayOutputStream.close();
      try
      {
        localByteArrayOutputStream.close();
        return arrayOfByte;
      }
      catch (IOException localIOException3)
      {
        while (true)
          Logger.w(localIOException3);
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        localException = localException;
        Logger.w(localException);
        try
        {
          localByteArrayOutputStream.close();
        }
        catch (IOException localIOException2)
        {
          Logger.w(localIOException2);
        }
      }
    }
    finally
    {
    }
    try
    {
      localByteArrayOutputStream.close();
      throw localObject;
    }
    catch (IOException localIOException1)
    {
      while (true)
        Logger.w(localIOException1);
    }
  }

  public static String encode(byte[] paramArrayOfByte)
  {
    return encode(paramArrayOfByte, 0, paramArrayOfByte.length, null).toString();
  }

  public static StringBuffer encode(byte[] paramArrayOfByte, int paramInt1, int paramInt2, StringBuffer paramStringBuffer)
  {
    char[] arrayOfChar = sBaseSting[0].toCharArray();
    if (paramStringBuffer == null)
      paramStringBuffer = new StringBuffer(3 * paramArrayOfByte.length / 2);
    int i = paramInt2 - 3;
    for (int j = paramInt1; j <= i; j += 3)
    {
      int n = (0xFF & paramArrayOfByte[j]) << 16 | (0xFF & paramArrayOfByte[(j + 1)]) << 8 | 0xFF & paramArrayOfByte[(j + 2)];
      paramStringBuffer.append(arrayOfChar[(0x3F & n >> 18)]);
      paramStringBuffer.append(arrayOfChar[(0x3F & n >> 12)]);
      paramStringBuffer.append(arrayOfChar[(0x3F & n >> 6)]);
      paramStringBuffer.append(arrayOfChar[(n & 0x3F)]);
    }
    if (j == -2 + (paramInt1 + paramInt2))
    {
      m = (0xFF & paramArrayOfByte[j]) << 16 | (0xFF & paramArrayOfByte[(j + 1)]) << 8;
      paramStringBuffer.append(arrayOfChar[(0x3F & m >> 18)]);
      paramStringBuffer.append(arrayOfChar[(0x3F & m >> 12)]);
      paramStringBuffer.append(arrayOfChar[(0x3F & m >> 6)]);
    }
    while (j != -1 + (paramInt1 + paramInt2))
    {
      int m;
      return paramStringBuffer;
    }
    int k = (0xFF & paramArrayOfByte[j]) << 16;
    paramStringBuffer.append(arrayOfChar[(0x3F & k >> 18)]);
    paramStringBuffer.append(arrayOfChar[(0x3F & k >> 12)]);
    return paramStringBuffer;
  }

  public static boolean needBase64(String paramString)
  {
    int i = 0;
    if (i < paramString.length())
    {
      if (paramString.charAt(i) == '-');
      label128: label132: 
      while (true)
      {
        i++;
        break;
        int j;
        int k;
        label60: int m;
        if (paramString.charAt(i) <= 'z')
        {
          if (paramString.charAt(i) >= 'a')
            break label112;
          j = 1;
          if (paramString.charAt(i) <= 'Z')
            break label117;
          k = 1;
          if ((j & k) == 0)
          {
            if (paramString.charAt(i) >= 'A')
              break label122;
            m = 1;
            label79: if (paramString.charAt(i) <= '9')
              break label128;
          }
        }
        for (int n = 1; ; n = 0)
        {
          if (((m & n) == 0) && (paramString.charAt(i) >= '0'))
            break label132;
          return true;
          label112: j = 0;
          break;
          label117: k = 0;
          break label60;
          label122: m = 0;
          break label79;
        }
      }
    }
    return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.security.Base64
 * JD-Core Version:    0.6.2
 */