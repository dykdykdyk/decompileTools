package com.baidu.sapi2;

public class Constants
{
  public static final String SAPI_ACTION_FILLNAME = "com.baidu.account.FILL_NAME";
  public static final String SAPI_ACTION_LOGIN = "com.baidu.account.LOGIN";
  public static final String SAPI_SO = "sapi_so_1";
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.Constants
 * JD-Core Version:    0.6.2
 */