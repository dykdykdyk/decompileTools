package com.baidu.sapi2.share;

import java.util.HashMap;

public class ShareModel
{
  public String mAction;
  public HashMap<String, String> mData = new HashMap();
  public String mFrom;
  public long mTimestamp;

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("action:");
    localStringBuffer.append(this.mAction);
    localStringBuffer.append("\n");
    localStringBuffer.append("from:");
    localStringBuffer.append(this.mFrom);
    localStringBuffer.append("\n");
    localStringBuffer.append("timestamp:");
    localStringBuffer.append(this.mTimestamp);
    localStringBuffer.append("\n");
    localStringBuffer.append("data:");
    localStringBuffer.append(this.mData);
    localStringBuffer.append("\n");
    return localStringBuffer.toString();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.share.ShareModel
 * JD-Core Version:    0.6.2
 */