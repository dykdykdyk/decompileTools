package com.baidu.sapi2.share;

import java.util.ArrayList;

public class ListenerHelper
{
  private ArrayList<IShareListener> mListeners = new ArrayList();

  void destroy()
  {
    synchronized (this.mListeners)
    {
      this.mListeners.clear();
      return;
    }
  }

  void onShareEvent(ShareModel paramShareModel)
  {
    if ((paramShareModel != null) && (this.mListeners != null))
      synchronized (this.mListeners)
      {
        int i = this.mListeners.size();
        for (int j = 0; j < i; j++)
          ((IShareListener)this.mListeners.get(j)).onShareEvent(paramShareModel);
        return;
      }
  }

  boolean registListener(IShareListener paramIShareListener)
  {
    if (paramIShareListener == null)
      return false;
    synchronized (this.mListeners)
    {
      if (!this.mListeners.contains(paramIShareListener))
      {
        boolean bool = this.mListeners.add(paramIShareListener);
        return bool;
      }
    }
    return false;
  }

  boolean unRegistListener(IShareListener paramIShareListener)
  {
    if (paramIShareListener == null)
      return false;
    synchronized (this.mListeners)
    {
      boolean bool = this.mListeners.remove(paramIShareListener);
      return bool;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.share.ListenerHelper
 * JD-Core Version:    0.6.2
 */