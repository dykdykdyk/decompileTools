package com.baidu.sapi2.share;

public abstract interface IShareListener
{
  public abstract void onShareEvent(ShareModel paramShareModel);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.share.IShareListener
 * JD-Core Version:    0.6.2
 */