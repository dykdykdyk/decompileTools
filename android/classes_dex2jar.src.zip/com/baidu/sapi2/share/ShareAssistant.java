package com.baidu.sapi2.share;

import android.content.Context;
import java.util.ArrayList;

public class ShareAssistant
{
  private static ShareAssistant mInstance = null;
  private ListenerHelper mListenerHelper = new ListenerHelper();
  private ShareSender mSender = null;

  private ShareAssistant(Context paramContext)
  {
    if (paramContext == null)
      throw new IllegalArgumentException("context cannot be null");
    this.mSender = new ShareSender(paramContext);
  }

  public static ShareAssistant getInstance(Context paramContext)
  {
    try
    {
      if (mInstance == null)
        mInstance = new ShareAssistant(paramContext);
      ShareAssistant localShareAssistant = mInstance;
      return localShareAssistant;
    }
    finally
    {
    }
  }

  public void destroy()
  {
    if (this.mListenerHelper != null)
      this.mListenerHelper.destroy();
    if (this.mSender != null)
      this.mSender.destroy();
    try
    {
      NativeCrypto.destroy();
      label31: mInstance = null;
      return;
    }
    catch (Throwable localThrowable)
    {
      break label31;
    }
  }

  void onShareEvent(ShareModel paramShareModel)
  {
    this.mListenerHelper.onShareEvent(paramShareModel);
  }

  public boolean registListener(IShareListener paramIShareListener)
  {
    return this.mListenerHelper.registListener(paramIShareListener);
  }

  public boolean share(ShareModel paramShareModel)
  {
    return this.mSender.share(paramShareModel);
  }

  public boolean share(ShareModel paramShareModel, ArrayList<String> paramArrayList)
  {
    return this.mSender.share(paramShareModel, paramArrayList);
  }

  public boolean unRegistListener(IShareListener paramIShareListener)
  {
    return this.mListenerHelper.unRegistListener(paramIShareListener);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.share.ShareAssistant
 * JD-Core Version:    0.6.2
 */