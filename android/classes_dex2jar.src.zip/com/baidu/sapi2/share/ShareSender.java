package com.baidu.sapi2.share;

import android.content.Context;
import android.content.Intent;
import com.baidu.sapi2.SapiHelper;
import com.baidu.sapi2.log.Logger;
import com.baidu.sapi2.loginshare.Token;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.JSONObject;

public class ShareSender
{
  private Context mContext = null;

  ShareSender(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private static boolean isValidModel(ShareModel paramShareModel)
  {
    if (paramShareModel == null);
    while ((paramShareModel.mAction == null) || (paramShareModel.mAction.equals("")) || ((paramShareModel.mData != null) && (paramShareModel.mData.get(Keystore.getAction()) != null)))
      return false;
    return true;
  }

  private static boolean sendBroadcast(Context paramContext, Intent paramIntent, String paramString1, String paramString2, String paramString3, long paramLong, HashMap<String, String> paramHashMap)
  {
    try
    {
      paramIntent.putExtra(Keystore.getAction(), NativeCrypto.encrypt(paramContext, paramString1));
      paramIntent.putExtra(Keystore.getFrom(), NativeCrypto.encrypt(paramContext, paramString2));
      paramIntent.putExtra(Keystore.getTimestamp(), NativeCrypto.encrypt(paramContext, paramLong + ""));
      paramIntent.putExtra(Keystore.getReceiver(), NativeCrypto.encrypt(paramContext, paramString3));
      String str = null;
      if (paramHashMap != null)
      {
        int i = paramHashMap.size();
        str = null;
        if (i > 0)
          str = new JSONObject(paramHashMap).toString();
      }
      paramIntent.putExtra(Keystore.getData(), NativeCrypto.encrypt(paramContext, str));
      paramIntent.addFlags(32);
      paramContext.sendBroadcast(paramIntent, Keystore.getPermission());
      return true;
    }
    catch (Throwable localThrowable)
    {
    }
    return false;
  }

  void destroy()
  {
    this.mContext = null;
  }

  boolean share(ShareModel paramShareModel)
  {
    return share(paramShareModel, null);
  }

  boolean share(ShareModel paramShareModel, ArrayList<String> paramArrayList)
  {
    if (!isValidModel(paramShareModel))
      return false;
    String str1 = paramShareModel.mAction;
    String str2 = this.mContext.getPackageName();
    long l = System.currentTimeMillis();
    String str3 = null;
    if (paramArrayList != null)
    {
      str3 = new String();
      int i = paramArrayList.size();
      for (int j = 0; j < i; j++)
        str3 = str3 + ((String)paramArrayList.get(j)).replace(Keystore.getSplit(), "") + Keystore.getSplit();
      if (str3.length() > 0)
        str3 = str3.substring(0, -1 + str3.length());
    }
    boolean bool1 = true;
    boolean bool2 = true;
    if (str1.equals(com.baidu.sapi2.loginshare.Keystore.getSyncAction()))
    {
      bool1 = sendBroadcast(this.mContext, new Intent(Keystore.getIntentAction()), str1, str2, str3, l, paramShareModel.mData);
      bool2 = sendBroadcast(this.mContext, new Intent(Keystore.getNewIntentAction()), str1, str2, str3, l, paramShareModel.mData);
      Logger.d("Send old and new broadcast!" + str1);
    }
    while ((bool1) && (bool2))
    {
      return true;
      if (str1.equals(com.baidu.sapi2.loginshare.Keystore.getLogoutAction()))
      {
        if (SapiHelper.getInstance().getToken().isSocialAccount)
        {
          bool1 = sendBroadcast(this.mContext, new Intent(Keystore.getIntentAction()), str1, str2, str3, l, paramShareModel.mData);
          bool2 = sendBroadcast(this.mContext, new Intent(Keystore.getNewIntentAction()), str1, str2, str3, l, paramShareModel.mData);
          Logger.d("Send old and new broadcast!" + str1);
        }
        else
        {
          bool1 = sendBroadcast(this.mContext, new Intent(Keystore.getIntentAction()), str1, str2, str3, l, paramShareModel.mData);
          Logger.d("Send old broadcast!" + str1);
        }
      }
      else if (SapiHelper.getInstance().getToken().isSocialAccount)
      {
        bool2 = sendBroadcast(this.mContext, new Intent(Keystore.getNewIntentAction()), str1, str2, str3, l, paramShareModel.mData);
        Logger.d("Send new broadcast!" + str1);
      }
      else
      {
        bool1 = sendBroadcast(this.mContext, new Intent(Keystore.getIntentAction()), str1, str2, str3, l, paramShareModel.mData);
        Logger.d("Send old broadcast!" + str1);
      }
    }
    return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.share.ShareSender
 * JD-Core Version:    0.6.2
 */