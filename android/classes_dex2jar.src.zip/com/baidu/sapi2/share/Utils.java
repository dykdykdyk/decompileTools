package com.baidu.sapi2.share;

public class Utils
{
  static boolean isValid(String paramString)
  {
    return (paramString != null) && (paramString.length() > 0);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.share.Utils
 * JD-Core Version:    0.6.2
 */