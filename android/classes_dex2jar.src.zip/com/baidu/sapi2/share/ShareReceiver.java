package com.baidu.sapi2.share;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.baidu.sapi2.SapiHelper;
import com.baidu.sapi2.log.Logger;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import org.json.JSONObject;

public class ShareReceiver extends BroadcastReceiver
{
  static String buildTimeString(ArrayList<String> paramArrayList)
  {
    int i = paramArrayList.size();
    String str = new String();
    for (int j = 0; j < i; j++)
      str = str + (String)paramArrayList.get(j) + Keystore.getSplit();
    if (str.length() > 0)
      str = str.substring(0, -1 + str.length());
    return str;
  }

  private static boolean checkValid(Context paramContext, long paramLong)
  {
    File localFile1 = paramContext.getFilesDir();
    if ((localFile1 == null) || (!localFile1.exists()) || (!localFile1.isDirectory()))
      return true;
    String str1 = paramLong + "";
    File localFile2 = new File(localFile1.getAbsolutePath() + "/" + Keystore.getFileName());
    while (true)
    {
      try
      {
        ArrayList localArrayList = new ArrayList();
        if (localFile2.exists())
        {
          byte[] arrayOfByte = new byte[(int)localFile2.length()];
          String str2 = new String(arrayOfByte);
          String str3 = new JSONObject(str2).optString(Keystore.getTimestamp());
          if (Utils.isValid(str3))
          {
            String[] arrayOfString = str3.split(Keystore.getSplit());
            if (arrayOfString.length > 0)
            {
              int i = arrayOfString.length;
              int j = 0;
              if (j < i)
              {
                localArrayList.add(arrayOfString[j]);
                if (!str1.equals(arrayOfString[j]))
                  break label325;
                localArrayList.clear();
                return false;
              }
              int k = Keystore.getCacheSize() - i;
              JSONObject localJSONObject;
              FileWriter localFileWriter;
              if (k <= 0)
              {
                Collections.sort(localArrayList);
                int m = 0;
                if (m < 1 + -k)
                {
                  localArrayList.remove(0);
                  m++;
                  continue;
                }
              }
            }
          }
          localFile2.deleteOnExit();
        }
        else
        {
          localArrayList.add(str1);
          localJSONObject = new JSONObject();
          localJSONObject.put(Keystore.getTimestamp(), buildTimeString(localArrayList));
          localFileWriter = new FileWriter(localFile2);
          localFileWriter.write(localJSONObject.toString());
          localFileWriter.flush();
          localFileWriter.close();
          return true;
        }
      }
      catch (Exception localException)
      {
        return true;
      }
      label325: j++;
    }
  }

  // ERROR //
  private void handleReceiver(Context paramContext, Bundle paramBundle)
    throws Throwable
  {
    // Byte code:
    //   0: aload_2
    //   1: invokestatic 164	com/baidu/sapi2/share/Keystore:getAction	()Ljava/lang/String;
    //   4: invokevirtual 169	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   7: astore_3
    //   8: aload_3
    //   9: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   12: ifne +4 -> 16
    //   15: return
    //   16: aload_1
    //   17: aload_3
    //   18: invokestatic 175	com/baidu/sapi2/share/NativeCrypto:decrypt	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   21: astore 4
    //   23: aload 4
    //   25: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   28: ifeq -13 -> 15
    //   31: aload_2
    //   32: invokestatic 178	com/baidu/sapi2/share/Keystore:getFrom	()Ljava/lang/String;
    //   35: invokevirtual 169	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   38: astore 5
    //   40: aload 5
    //   42: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   45: ifeq -30 -> 15
    //   48: aload_1
    //   49: invokevirtual 181	android/content/Context:getPackageName	()Ljava/lang/String;
    //   52: astore 6
    //   54: aload_1
    //   55: aload 5
    //   57: invokestatic 175	com/baidu/sapi2/share/NativeCrypto:decrypt	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   60: astore 7
    //   62: aload 7
    //   64: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   67: ifeq -52 -> 15
    //   70: aload 6
    //   72: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   75: ifeq +13 -> 88
    //   78: aload 6
    //   80: aload 7
    //   82: invokevirtual 115	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   85: ifne -70 -> 15
    //   88: aload_2
    //   89: invokestatic 184	com/baidu/sapi2/share/Keystore:getReceiver	()Ljava/lang/String;
    //   92: invokevirtual 169	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   95: astore 8
    //   97: aload 8
    //   99: ifnull +73 -> 172
    //   102: aload_1
    //   103: aload 8
    //   105: invokestatic 175	com/baidu/sapi2/share/NativeCrypto:decrypt	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   108: astore 22
    //   110: aload 22
    //   112: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   115: ifeq -100 -> 15
    //   118: aload 22
    //   120: invokestatic 36	com/baidu/sapi2/share/Keystore:getSplit	()Ljava/lang/String;
    //   123: invokevirtual 108	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   126: astore 23
    //   128: aload 23
    //   130: ifnull +42 -> 172
    //   133: aload 23
    //   135: arraylength
    //   136: istore 24
    //   138: iconst_0
    //   139: istore 25
    //   141: iconst_0
    //   142: istore 26
    //   144: iload 25
    //   146: iload 24
    //   148: if_icmpge +19 -> 167
    //   151: aload 6
    //   153: aload 23
    //   155: iload 25
    //   157: aaload
    //   158: invokevirtual 115	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   161: ifeq +202 -> 363
    //   164: iconst_1
    //   165: istore 26
    //   167: iload 26
    //   169: ifeq -154 -> 15
    //   172: aload_2
    //   173: invokestatic 94	com/baidu/sapi2/share/Keystore:getTimestamp	()Ljava/lang/String;
    //   176: invokevirtual 169	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   179: astore 9
    //   181: aload 9
    //   183: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   186: ifeq -171 -> 15
    //   189: aload_1
    //   190: aload 9
    //   192: invokestatic 175	com/baidu/sapi2/share/NativeCrypto:decrypt	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   195: invokestatic 190	java/lang/Long:parseLong	(Ljava/lang/String;)J
    //   198: lstore 11
    //   200: aload_1
    //   201: lload 11
    //   203: invokestatic 192	com/baidu/sapi2/share/ShareReceiver:checkValid	(Landroid/content/Context;J)Z
    //   206: ifeq -191 -> 15
    //   209: aload_2
    //   210: invokestatic 195	com/baidu/sapi2/share/Keystore:getData	()Ljava/lang/String;
    //   213: invokevirtual 169	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   216: astore 13
    //   218: new 197	java/util/HashMap
    //   221: dup
    //   222: invokespecial 198	java/util/HashMap:<init>	()V
    //   225: astore 14
    //   227: aload 13
    //   229: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   232: ifeq +84 -> 316
    //   235: aload_1
    //   236: aload 13
    //   238: invokestatic 175	com/baidu/sapi2/share/NativeCrypto:decrypt	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   241: astore 16
    //   243: aload 16
    //   245: invokestatic 104	com/baidu/sapi2/share/Utils:isValid	(Ljava/lang/String;)Z
    //   248: ifeq +68 -> 316
    //   251: new 90	org/json/JSONObject
    //   254: dup
    //   255: aload 16
    //   257: invokespecial 91	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   260: astore 17
    //   262: aload 17
    //   264: invokevirtual 202	org/json/JSONObject:keys	()Ljava/util/Iterator;
    //   267: astore 19
    //   269: aload 19
    //   271: invokeinterface 207 1 0
    //   276: ifeq +40 -> 316
    //   279: aload 19
    //   281: invokeinterface 211 1 0
    //   286: checkcast 18	java/lang/String
    //   289: astore 20
    //   291: aload 14
    //   293: aload 20
    //   295: aload 17
    //   297: aload 20
    //   299: invokevirtual 212	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   302: invokevirtual 215	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   305: pop
    //   306: goto -37 -> 269
    //   309: astore 18
    //   311: aload 18
    //   313: invokestatic 221	com/baidu/sapi2/log/Logger:w	(Ljava/lang/Throwable;)V
    //   316: new 223	com/baidu/sapi2/share/ShareModel
    //   319: dup
    //   320: invokespecial 224	com/baidu/sapi2/share/ShareModel:<init>	()V
    //   323: astore 15
    //   325: aload 15
    //   327: aload 4
    //   329: putfield 228	com/baidu/sapi2/share/ShareModel:mAction	Ljava/lang/String;
    //   332: aload 15
    //   334: aload 7
    //   336: putfield 231	com/baidu/sapi2/share/ShareModel:mFrom	Ljava/lang/String;
    //   339: aload 15
    //   341: lload 11
    //   343: putfield 235	com/baidu/sapi2/share/ShareModel:mTimestamp	J
    //   346: aload 15
    //   348: aload 14
    //   350: putfield 239	com/baidu/sapi2/share/ShareModel:mData	Ljava/util/HashMap;
    //   353: aload_1
    //   354: invokestatic 245	com/baidu/sapi2/share/ShareAssistant:getInstance	(Landroid/content/Context;)Lcom/baidu/sapi2/share/ShareAssistant;
    //   357: aload 15
    //   359: invokevirtual 249	com/baidu/sapi2/share/ShareAssistant:onShareEvent	(Lcom/baidu/sapi2/share/ShareModel;)V
    //   362: return
    //   363: iinc 25 1
    //   366: goto -225 -> 141
    //   369: astore 10
    //   371: return
    //   372: astore 18
    //   374: goto -63 -> 311
    //
    // Exception table:
    //   from	to	target	type
    //   262	269	309	org/json/JSONException
    //   269	306	309	org/json/JSONException
    //   189	200	369	java/lang/Exception
    //   251	262	372	org/json/JSONException
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    try
    {
      String str = paramIntent.getAction();
      if ((str != null) && (Keystore.getIntentAction() != null) && (!str.equals(Keystore.getIntentAction())) && (!str.equals(Keystore.getNewIntentAction())))
        return;
      Bundle localBundle = paramIntent.getExtras();
      if ((localBundle != null) && (SapiHelper.getInstance().isShare()))
      {
        handleReceiver(paramContext, localBundle);
        return;
      }
    }
    catch (Throwable localThrowable)
    {
      Logger.w(localThrowable);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.share.ShareReceiver
 * JD-Core Version:    0.6.2
 */