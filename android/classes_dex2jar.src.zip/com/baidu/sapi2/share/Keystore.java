package com.baidu.sapi2.share;

public class Keystore
{
  static String getAction()
  {
    return "action";
  }

  static int getCacheSize()
  {
    return 15;
  }

  static String getData()
  {
    return "data";
  }

  static String getFileName()
  {
    return "share.json";
  }

  static String getFrom()
  {
    return "from";
  }

  static String getIntentAction()
  {
    return "baidu.intent.action.SHARE";
  }

  static String getNewIntentAction()
  {
    return "baidu.intent.action.NEWSHARE";
  }

  static String getPermission()
  {
    return "com.baidu.permission.SHARE";
  }

  static String getReceiver()
  {
    return "receiver";
  }

  static String getSplit()
  {
    return ";";
  }

  static String getTimestamp()
  {
    return "timestamp";
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.share.Keystore
 * JD-Core Version:    0.6.2
 */