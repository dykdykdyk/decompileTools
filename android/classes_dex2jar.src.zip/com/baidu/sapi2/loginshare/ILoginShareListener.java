package com.baidu.sapi2.loginshare;

public abstract interface ILoginShareListener
{
  public abstract void onLoginShareEvent(Token paramToken);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.ILoginShareListener
 * JD-Core Version:    0.6.2
 */