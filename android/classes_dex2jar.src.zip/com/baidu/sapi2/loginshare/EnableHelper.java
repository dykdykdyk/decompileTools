package com.baidu.sapi2.loginshare;

public class EnableHelper
{
  private long mCheckTime = 0L;
  private volatile boolean mEnable = true;

  long getCheckTime()
  {
    return this.mCheckTime;
  }

  boolean isEnable()
  {
    return this.mEnable;
  }

  void setCheckTime(long paramLong)
  {
    this.mCheckTime = paramLong;
  }

  void setEnable(boolean paramBoolean)
  {
    this.mEnable = paramBoolean;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.EnableHelper
 * JD-Core Version:    0.6.2
 */