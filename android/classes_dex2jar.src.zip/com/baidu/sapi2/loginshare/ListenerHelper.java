package com.baidu.sapi2.loginshare;

public class ListenerHelper
{
  private ILoginShareListener mListener = null;

  void destroy()
  {
    try
    {
      this.mListener = null;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  void onLoginShareEvent(Token paramToken)
  {
    try
    {
      if (this.mListener != null)
        this.mListener.onLoginShareEvent(paramToken);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  void setLoginShareListener(ILoginShareListener paramILoginShareListener)
  {
    try
    {
      this.mListener = paramILoginShareListener;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.ListenerHelper
 * JD-Core Version:    0.6.2
 */