package com.baidu.sapi2.loginshare;

import org.json.JSONArray;

public abstract interface IDataStorage
{
  public abstract void close();

  public abstract boolean commit();

  public abstract JSONArray getJSONArray(String paramString);

  public abstract String getString(String paramString);

  public abstract void put(String paramString1, String paramString2);

  public abstract void put(String paramString, JSONArray paramJSONArray);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.IDataStorage
 * JD-Core Version:    0.6.2
 */