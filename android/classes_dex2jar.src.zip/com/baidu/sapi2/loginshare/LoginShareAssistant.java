package com.baidu.sapi2.loginshare;

import android.content.Context;

public class LoginShareAssistant
{
  private Sharer mSharer = null;

  public void destroy()
  {
    if (this.mSharer != null)
      this.mSharer.destroy();
    this.mSharer = null;
  }

  public String getDeviceToken()
  {
    if (this.mSharer != null)
      return this.mSharer.getDeviceToken();
    return null;
  }

  public Token getLastToken()
  {
    if (this.mSharer != null)
      return this.mSharer.getLastToken();
    return null;
  }

  public String getOtherBduss()
  {
    try
    {
      String str = this.mSharer.getOtherBduss();
      return str;
    }
    catch (Throwable localThrowable)
    {
    }
    return null;
  }

  public void initial(Context paramContext, String paramString1, String paramString2)
  {
    try
    {
      this.mSharer.initial(paramContext, paramString1, paramString2);
      return;
    }
    catch (Throwable localThrowable)
    {
    }
  }

  public boolean invalid(Token paramToken)
  {
    try
    {
      boolean bool = this.mSharer.invalid(paramToken);
      return bool;
    }
    catch (Throwable localThrowable)
    {
    }
    return false;
  }

  public void onActivityCreate()
  {
    if (this.mSharer != null)
      this.mSharer.onActivityCreate();
  }

  public void setLoginShareListener(ILoginShareListener paramILoginShareListener)
  {
    try
    {
      this.mSharer.setLoginShareListener(paramILoginShareListener);
      return;
    }
    catch (Throwable localThrowable)
    {
    }
  }

  public boolean valid(Token paramToken)
  {
    try
    {
      boolean bool = this.mSharer.valid(paramToken);
      return bool;
    }
    catch (Throwable localThrowable)
    {
    }
    return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.LoginShareAssistant
 * JD-Core Version:    0.6.2
 */