package com.baidu.sapi2.loginshare;

import android.content.Context;
import com.baidu.sapi2.share.NativeCrypto;

public class LoginShareCrypto
{
  static String decrypt(Context paramContext, String paramString)
  {
    try
    {
      String str = NativeCrypto.decrypt(paramContext, paramString);
      return str;
    }
    catch (Throwable localThrowable)
    {
    }
    return null;
  }

  static String encrypt(Context paramContext, String paramString)
  {
    try
    {
      String str = NativeCrypto.encrypt(paramContext, paramString);
      return str;
    }
    catch (Throwable localThrowable)
    {
    }
    return null;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.LoginShareCrypto
 * JD-Core Version:    0.6.2
 */