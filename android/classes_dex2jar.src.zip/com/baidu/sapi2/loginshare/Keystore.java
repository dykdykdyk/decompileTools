package com.baidu.sapi2.loginshare;

public class Keystore
{
  static String getBduss()
  {
    return "bduss";
  }

  static String getCheckTime()
  {
    return "checkTime";
  }

  static String getDeviceToken()
  {
    return "device_token";
  }

  static String getDisplayname()
  {
    return "displayname";
  }

  static String getEmail()
  {
    return "email";
  }

  static String getEngyptFileName()
  {
    return "android_sapi_loginshare";
  }

  static String getExtra()
  {
    return "extra";
  }

  static String getFileName()
  {
    return "loginshare.json";
  }

  static String getIsEnable()
  {
    return "isEnable";
  }

  static String getIsFirstBoot()
  {
    return "isValid";
  }

  static String getIsSocialAccount()
  {
    return "isSocialAccount";
  }

  static String getIsValid()
  {
    return "isValid";
  }

  static String getJson()
  {
    return "json";
  }

  static String getLoginAction()
  {
    return "baidu.share.action.ACTION_LOGIN";
  }

  public static String getLogoutAction()
  {
    return "baidu.share.action.ACTION_LOGOUT";
  }

  static String getOtherBduss()
  {
    return "otherBduss";
  }

  static String getPhoneNumber()
  {
    return "phoneNumber";
  }

  static String getPtoken()
  {
    return "ptoken";
  }

  static String getSocialAccounts()
  {
    return "socialAccounts";
  }

  static String getStatisticsAppUrl()
  {
    return "http://passport.baidu.com/v2/intercomm/statistic";
  }

  static String getStatisticsUserUrl()
  {
    return "http://passport.baidu.com/v2/intercomm/statistic";
  }

  public static String getSyncAction()
  {
    return "baidu.share.action.ACTION_LOGIN_SYNC";
  }

  static String getSyncReplyAction()
  {
    return "baidu.share.action.ACTION_LOGIN_SYNC_REPLY";
  }

  static String getUrl()
  {
    return "http://passport.baidu.com/v2/intercomm/switch";
  }

  static String getUsername()
  {
    return "username";
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.Keystore
 * JD-Core Version:    0.6.2
 */