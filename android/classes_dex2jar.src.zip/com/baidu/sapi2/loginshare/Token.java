package com.baidu.sapi2.loginshare;

import com.baidu.sapi2.social.config.SocialType;
import com.baidu.sapi2.social.model.SocialToken;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Token
{
  public String deviceToken;
  public boolean isSocialAccount;
  public String mBduss;
  public String mDisplayname;
  public String mEmail;
  public LoginShareEvent mEvent = LoginShareEvent.INVALID;
  public HashMap<String, String> mExtras = new HashMap();
  public String mJson = "{}";
  public String mPhoneNumber;
  public String mPtoken;
  public String mUsername;
  public HashMap<SocialType, SocialToken> socialTokenMap = new LinkedHashMap();

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("mDisplayname:");
    localStringBuffer.append(this.mDisplayname);
    localStringBuffer.append("\n");
    localStringBuffer.append("mUsername:");
    localStringBuffer.append(this.mUsername);
    localStringBuffer.append("\n");
    localStringBuffer.append("mEmail:");
    localStringBuffer.append(this.mEmail);
    localStringBuffer.append("\n");
    localStringBuffer.append("mPhoneNumber:");
    localStringBuffer.append(this.mPhoneNumber);
    localStringBuffer.append("\n");
    localStringBuffer.append("mBduss:");
    localStringBuffer.append(this.mBduss);
    localStringBuffer.append("\n");
    localStringBuffer.append("mPtoken:");
    localStringBuffer.append(this.mPtoken);
    localStringBuffer.append("\n");
    localStringBuffer.append("mExtras:");
    localStringBuffer.append(this.mExtras);
    localStringBuffer.append("\n");
    localStringBuffer.append("mJson:");
    localStringBuffer.append(this.mJson);
    localStringBuffer.append("\n");
    return localStringBuffer.toString();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.Token
 * JD-Core Version:    0.6.2
 */