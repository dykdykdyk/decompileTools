package com.baidu.sapi2.loginshare;

public enum LoginShareEvent
{
  static
  {
    INVALID = new LoginShareEvent("INVALID", 1);
    LoginShareEvent[] arrayOfLoginShareEvent = new LoginShareEvent[2];
    arrayOfLoginShareEvent[0] = VALID;
    arrayOfLoginShareEvent[1] = INVALID;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.LoginShareEvent
 * JD-Core Version:    0.6.2
 */