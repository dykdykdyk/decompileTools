package com.baidu.sapi2.loginshare;

import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

public class StatisticsHelper
{
  static final int ACTION_APP = 2;
  static final int ACTION_USER = 1;
  private static final String SNAME_APP = "ServiceAppCount";
  private static final String SNAME_USER = "EffectUserCount";
  private String mAppId = null;
  private boolean mEnable = false;
  private String mTpl = null;

  StatisticsHelper(String paramString1, String paramString2)
  {
    this.mTpl = paramString1;
    this.mAppId = paramString2;
  }

  void destroy()
  {
    this.mTpl = null;
    this.mAppId = null;
    this.mEnable = false;
  }

  void doUpload(int paramInt, String paramString)
  {
    if (!this.mEnable);
    while (true)
    {
      return;
      if (Utils.isValid(paramString))
      {
        Object localObject = null;
        switch (paramInt)
        {
        default:
        case 1:
        case 2:
        }
        while (localObject != null)
        {
          new Thread((Runnable)localObject).start();
          return;
          localObject = new UploadTask(Keystore.getStatisticsUserUrl(), paramString, "EffectUserCount");
          continue;
          localObject = new UploadTask(Keystore.getStatisticsAppUrl(), paramString, "ServiceAppCount");
        }
      }
    }
  }

  void onActivityCreate()
  {
    this.mEnable = true;
  }

  private class UploadTask
    implements Runnable
  {
    private static final String ENCODING = "utf-8";
    private static final String KEY_APPID = "appid";
    private static final String KEY_BDUSS = "bduss";
    private static final String KEY_SNAME = "sName";
    private static final String KEY_TPL = "tpl";
    private static final int TIME_OUT = 15000;
    private String mBduss = null;
    private HttpClient mHttpClient = null;
    private HttpParams mHttpParams = null;
    private String mSname = null;
    private String mUrl = null;

    UploadTask(String paramString1, String paramString2, String arg4)
    {
      this.mUrl = paramString1;
      this.mBduss = paramString2;
      Object localObject;
      this.mSname = localObject;
      this.mHttpParams = new BasicHttpParams();
      HttpConnectionParams.setConnectionTimeout(this.mHttpParams, 15000);
      HttpConnectionParams.setSoTimeout(this.mHttpParams, 15000);
      this.mHttpClient = new DefaultHttpClient(this.mHttpParams);
    }

    public void run()
    {
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(new BasicNameValuePair("appid", StatisticsHelper.this.mAppId));
      localArrayList.add(new BasicNameValuePair("bduss", this.mBduss));
      localArrayList.add(new BasicNameValuePair("tpl", StatisticsHelper.this.mTpl));
      localArrayList.add(new BasicNameValuePair("sName", this.mSname));
      try
      {
        HttpPost localHttpPost = new HttpPost(this.mUrl);
        localHttpPost.setEntity(new UrlEncodedFormEntity(localArrayList, "utf-8"));
        this.mHttpClient.execute(localHttpPost);
        return;
      }
      catch (Exception localException)
      {
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.StatisticsHelper
 * JD-Core Version:    0.6.2
 */