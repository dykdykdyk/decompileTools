package com.baidu.sapi2.loginshare;

import android.content.Context;
import android.text.TextUtils;
import com.baidu.sapi2.SapiHelper;
import com.baidu.sapi2.log.Logger;
import com.baidu.sapi2.share.IShareListener;
import com.baidu.sapi2.share.ShareAssistant;
import com.baidu.sapi2.share.ShareModel;
import com.baidu.sapi2.social.config.SocialType;
import com.baidu.sapi2.social.model.SocialToken;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Sharer
{
  private static final int DELAYED_TIME = 100;
  private Context mContext = null;
  private FileStorage mDataStorage = null;
  private String mEnableFalse = "0";
  private EnableHelper mEnableHelper = new EnableHelper();
  private String mEnableTrue = "1";
  private volatile boolean mIsInit = false;
  private volatile boolean mIsNetChecking = false;
  private String mIsSocialFalse = "0";
  private String mIsSocialTrue = "1";
  private ListenerHelper mListenerHelper = new ListenerHelper();
  private NetCheckHelper mNetCheckHelper = null;
  private ShareAssistant mShareAssistant = null;
  private IShareListener mShareListener = new IShareListener()
  {
    public void onShareEvent(ShareModel paramAnonymousShareModel)
    {
      String str = paramAnonymousShareModel.mAction;
      if (!Utils.isValid(str));
      do
      {
        return;
        if (Keystore.getLoginAction().equals(str))
        {
          Sharer.this.handleLogin(paramAnonymousShareModel);
          return;
        }
        if (Keystore.getLogoutAction().equals(str))
        {
          Sharer.this.handleLogout(paramAnonymousShareModel);
          return;
        }
        if (Keystore.getSyncAction().equals(str))
        {
          Sharer.this.handleSync(paramAnonymousShareModel);
          return;
        }
      }
      while (!Keystore.getSyncReplyAction().equals(str));
      Sharer.this.handleSyncReply(paramAnonymousShareModel);
    }
  };
  private StatisticsHelper mStatisticsHelper = null;
  private Token mToken = null;
  private String mValidFalse = "0";
  private String mValidTrue = "1";
  private ArrayList<ShareModel> mWaitingList = new ArrayList();

  private boolean check(ShareModel paramShareModel, boolean paramBoolean, String paramString)
  {
    boolean bool;
    if (!SapiHelper.getInstance().isShare())
      bool = true;
    while (true)
    {
      return bool;
      if (!hasCheckToday())
        break;
      if (this.mEnableHelper.isEnable());
      for (bool = this.mShareAssistant.share(paramShareModel); (bool) && (paramBoolean); bool = false)
      {
        this.mStatisticsHelper.doUpload(1, paramString);
        return bool;
      }
    }
    synchronized (this.mWaitingList)
    {
      this.mWaitingList.add(paramShareModel);
      if (!this.mIsNetChecking)
      {
        this.mNetCheckHelper = new NetCheckHelper(paramBoolean, paramString);
        new Thread(this.mNetCheckHelper).start();
      }
      return true;
    }
  }

  // ERROR //
  private HashMap<SocialType, SocialToken> getSocialAccount(String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic 190	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   4: istore_2
    //   5: aconst_null
    //   6: astore_3
    //   7: iload_2
    //   8: ifeq +5 -> 13
    //   11: aload_3
    //   12: areturn
    //   13: new 192	org/json/JSONArray
    //   16: dup
    //   17: aload_1
    //   18: invokespecial 195	org/json/JSONArray:<init>	(Ljava/lang/String;)V
    //   21: astore 4
    //   23: aconst_null
    //   24: astore_3
    //   25: aload 4
    //   27: ifnull -16 -> 11
    //   30: aload 4
    //   32: invokevirtual 199	org/json/JSONArray:length	()I
    //   35: istore 5
    //   37: aconst_null
    //   38: astore_3
    //   39: iload 5
    //   41: ifeq -30 -> 11
    //   44: new 201	java/util/LinkedHashMap
    //   47: dup
    //   48: invokespecial 202	java/util/LinkedHashMap:<init>	()V
    //   51: astore_3
    //   52: iconst_0
    //   53: istore 6
    //   55: iload 6
    //   57: aload 4
    //   59: invokevirtual 199	org/json/JSONArray:length	()I
    //   62: if_icmpge -51 -> 11
    //   65: new 204	org/json/JSONObject
    //   68: dup
    //   69: aload 4
    //   71: iload 6
    //   73: invokevirtual 208	org/json/JSONArray:optString	(I)Ljava/lang/String;
    //   76: invokespecial 209	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   79: astore 7
    //   81: new 211	com/baidu/sapi2/social/model/SocialToken
    //   84: dup
    //   85: invokespecial 212	com/baidu/sapi2/social/model/SocialToken:<init>	()V
    //   88: astore 8
    //   90: aload 8
    //   92: aload 7
    //   94: ldc 214
    //   96: invokevirtual 218	org/json/JSONObject:optBoolean	(Ljava/lang/String;)Z
    //   99: putfield 220	com/baidu/sapi2/social/model/SocialToken:isBinded	Z
    //   102: aload 8
    //   104: aload 7
    //   106: ldc 222
    //   108: invokevirtual 225	org/json/JSONObject:optString	(Ljava/lang/String;)Ljava/lang/String;
    //   111: putfield 227	com/baidu/sapi2/social/model/SocialToken:username	Ljava/lang/String;
    //   114: aload 8
    //   116: aload 7
    //   118: ldc 229
    //   120: invokevirtual 233	org/json/JSONObject:optInt	(Ljava/lang/String;)I
    //   123: invokestatic 239	com/baidu/sapi2/social/config/Sex:getSex	(I)Lcom/baidu/sapi2/social/config/Sex;
    //   126: putfield 242	com/baidu/sapi2/social/model/SocialToken:sex	Lcom/baidu/sapi2/social/config/Sex;
    //   129: aload 8
    //   131: aload 7
    //   133: ldc 244
    //   135: invokevirtual 225	org/json/JSONObject:optString	(Ljava/lang/String;)Ljava/lang/String;
    //   138: putfield 246	com/baidu/sapi2/social/model/SocialToken:headURL	Ljava/lang/String;
    //   141: aload 8
    //   143: aload 7
    //   145: ldc 248
    //   147: invokevirtual 233	org/json/JSONObject:optInt	(Ljava/lang/String;)I
    //   150: invokestatic 254	com/baidu/sapi2/social/config/SocialType:getSocialType	(I)Lcom/baidu/sapi2/social/config/SocialType;
    //   153: putfield 257	com/baidu/sapi2/social/model/SocialToken:type	Lcom/baidu/sapi2/social/config/SocialType;
    //   156: aload_3
    //   157: aload 8
    //   159: getfield 257	com/baidu/sapi2/social/model/SocialToken:type	Lcom/baidu/sapi2/social/config/SocialType;
    //   162: aload 8
    //   164: invokevirtual 263	java/util/HashMap:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   167: pop
    //   168: iinc 6 1
    //   171: goto -116 -> 55
    //   174: astore 11
    //   176: aconst_null
    //   177: areturn
    //   178: astore 10
    //   180: goto -12 -> 168
    //
    // Exception table:
    //   from	to	target	type
    //   13	23	174	org/json/JSONException
    //   65	81	178	org/json/JSONException
  }

  private JSONArray getSocialAccount(HashMap<SocialType, SocialToken> paramHashMap)
  {
    if ((paramHashMap == null) || (paramHashMap.size() == 0))
    {
      localJSONArray = new JSONArray();
      return localJSONArray;
    }
    JSONArray localJSONArray = new JSONArray();
    Iterator localIterator = paramHashMap.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      JSONObject localJSONObject = new JSONObject();
      try
      {
        localJSONObject.put("isBinded", ((SocialToken)localEntry.getValue()).isBinded);
        localJSONObject.put("username", ((SocialToken)localEntry.getValue()).username);
        localJSONObject.put("sex", ((SocialToken)localEntry.getValue()).sex);
        localJSONObject.put("headURL", ((SocialToken)localEntry.getValue()).headURL);
        localJSONObject.put("type", ((SocialToken)localEntry.getValue()).type.getType());
        localJSONArray.put(localJSONObject);
      }
      catch (JSONException localJSONException)
      {
        while (true)
          Logger.w(localJSONException);
      }
    }
  }

  private void handleLogin(ShareModel paramShareModel)
  {
    HashMap localHashMap = paramShareModel.mData;
    Token localToken = new Token();
    Iterator localIterator = localHashMap.keySet().iterator();
    while (true)
      if (localIterator.hasNext())
      {
        str1 = (String)localIterator.next();
        if (Keystore.getUsername().equals(str1))
        {
          str13 = (String)localHashMap.get(str1);
          localToken.mUsername = LoginShareCrypto.decrypt(this.mContext, str13);
        }
        else if (Keystore.getEmail().equals(str1))
        {
          str12 = (String)localHashMap.get(str1);
          localToken.mEmail = LoginShareCrypto.decrypt(this.mContext, str12);
        }
        else if (Keystore.getPhoneNumber().equals(str1))
        {
          str11 = (String)localHashMap.get(str1);
          localToken.mPhoneNumber = LoginShareCrypto.decrypt(this.mContext, str11);
        }
        else if (Keystore.getBduss().equals(str1))
        {
          str10 = (String)localHashMap.get(str1);
          if (Utils.isValid(str10))
            break;
        }
      }
    while (!isValid(localToken))
    {
      String str1;
      String str13;
      String str12;
      String str11;
      String str10;
      return;
      localToken.mBduss = LoginShareCrypto.decrypt(this.mContext, str10);
      break;
      if (Keystore.getPtoken().equals(str1))
      {
        String str9 = (String)localHashMap.get(str1);
        localToken.mPtoken = LoginShareCrypto.decrypt(this.mContext, str9);
        break;
      }
      if (Keystore.getJson().equals(str1))
      {
        String str8 = (String)localHashMap.get(str1);
        localToken.mJson = LoginShareCrypto.decrypt(this.mContext, str8);
        break;
      }
      if (Keystore.getDisplayname().equals(str1))
      {
        String str7 = (String)localHashMap.get(str1);
        localToken.mDisplayname = LoginShareCrypto.decrypt(this.mContext, str7);
        break;
      }
      if (Keystore.getIsSocialAccount().equals(str1))
      {
        String str6 = (String)localHashMap.get(str1);
        localToken.isSocialAccount = this.mIsSocialTrue.equals(LoginShareCrypto.decrypt(this.mContext, str6));
        break;
      }
      if (Keystore.getSocialAccounts().equals(str1))
      {
        String str5 = (String)localHashMap.get(str1);
        localToken.socialTokenMap = getSocialAccount(LoginShareCrypto.decrypt(this.mContext, str5));
        break;
      }
      if (Keystore.getDeviceToken().equals(str1))
      {
        String str4 = (String)localHashMap.get(str1);
        if (TextUtils.isEmpty(str4))
          break;
        localToken.deviceToken = LoginShareCrypto.decrypt(this.mContext, str4);
        break;
      }
      String str2 = (String)localHashMap.get(str1);
      String str3 = LoginShareCrypto.decrypt(this.mContext, str2);
      localToken.mExtras.put(str1, str3);
      break;
    }
    if ((SapiHelper.getInstance().isLogin()) && (SapiHelper.getInstance().getToken().isSocialAccount) && (!localToken.isSocialAccount))
    {
      syncStorage(localToken.mBduss);
      return;
    }
    syncStorage(true, localToken.mDisplayname, localToken.mUsername, localToken.mEmail, localToken.mPhoneNumber, localToken.mBduss, localToken.mPtoken, localToken.mExtras, localToken.mJson, localToken.isSocialAccount, localToken.socialTokenMap, localToken.deviceToken);
    localToken.mEvent = LoginShareEvent.VALID;
    this.mToken = localToken;
    this.mStatisticsHelper.doUpload(2, localToken.mBduss);
    this.mListenerHelper.onLoginShareEvent(localToken);
  }

  private void handleLogout(ShareModel paramShareModel)
  {
    HashMap localHashMap1 = paramShareModel.mData;
    Token localToken = new Token();
    HashMap localHashMap2 = new HashMap();
    Iterator localIterator = localHashMap1.keySet().iterator();
    while (true)
      if (localIterator.hasNext())
      {
        str1 = (String)localIterator.next();
        if (Keystore.getUsername().equals(str1))
        {
          str11 = (String)localHashMap1.get(str1);
          localToken.mUsername = LoginShareCrypto.decrypt(this.mContext, str11);
        }
        else if (Keystore.getEmail().equals(str1))
        {
          str10 = (String)localHashMap1.get(str1);
          localToken.mEmail = LoginShareCrypto.decrypt(this.mContext, str10);
        }
        else if (Keystore.getPhoneNumber().equals(str1))
        {
          str9 = (String)localHashMap1.get(str1);
          localToken.mPhoneNumber = LoginShareCrypto.decrypt(this.mContext, str9);
        }
        else if (Keystore.getBduss().equals(str1))
        {
          str8 = (String)localHashMap1.get(str1);
          if (Utils.isValid(str8))
            break;
        }
      }
    while (!isValid(localToken))
    {
      String str1;
      String str11;
      String str10;
      String str9;
      String str8;
      return;
      localToken.mBduss = LoginShareCrypto.decrypt(this.mContext, str8);
      break;
      if (Keystore.getPtoken().equals(str1))
      {
        String str7 = (String)localHashMap1.get(str1);
        localToken.mPtoken = LoginShareCrypto.decrypt(this.mContext, str7);
        break;
      }
      if (Keystore.getDisplayname().equals(str1))
      {
        String str6 = (String)localHashMap1.get(str1);
        localToken.mDisplayname = LoginShareCrypto.decrypt(this.mContext, str6);
        break;
      }
      if (Keystore.getIsSocialAccount().equals(str1))
      {
        String str5 = (String)localHashMap1.get(str1);
        localToken.isSocialAccount = this.mIsSocialTrue.equals(LoginShareCrypto.decrypt(this.mContext, str5));
        break;
      }
      if (Keystore.getSocialAccounts().equals(str1))
      {
        String str4 = (String)localHashMap1.get(str1);
        localToken.socialTokenMap = getSocialAccount(LoginShareCrypto.decrypt(this.mContext, str4));
        break;
      }
      if (Keystore.getDeviceToken().equals(str1))
      {
        String str3 = (String)localHashMap1.get(str1);
        if (TextUtils.isEmpty(str3))
          break;
        localToken.deviceToken = LoginShareCrypto.decrypt(this.mContext, str3);
        break;
      }
      String str2 = (String)localHashMap1.get(str1);
      localHashMap2.put(str1, str2);
      localToken.mExtras.put(str1, LoginShareCrypto.decrypt(this.mContext, str2));
      break;
    }
    if ((SapiHelper.getInstance().isLogin()) && (SapiHelper.getInstance().getToken().isSocialAccount) && (!localToken.isSocialAccount))
    {
      syncStorage(localToken.mBduss);
      return;
    }
    localToken.mEvent = LoginShareEvent.INVALID;
    syncStorage(false, localToken.mDisplayname, localToken.mUsername, localToken.mEmail, localToken.mPhoneNumber, localToken.mBduss, localToken.mPtoken, localToken.mExtras, localToken.mJson, localToken.isSocialAccount, localToken.socialTokenMap, localToken.deviceToken);
    this.mToken = localToken;
    this.mListenerHelper.onLoginShareEvent(localToken);
  }

  private void handleSync(ShareModel paramShareModel)
  {
    String str1 = paramShareModel.mFrom;
    if (!Utils.isValid(this.mDataStorage.getString(Keystore.getIsValid())));
    String str2;
    do
    {
      return;
      str2 = LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getBduss()));
    }
    while (!Utils.isValid(str2));
    ShareModel localShareModel = new ShareModel();
    localShareModel.mAction = Keystore.getSyncReplyAction();
    localShareModel.mData.put(Keystore.getIsValid(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getIsValid())));
    localShareModel.mData.put(Keystore.getUsername(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getUsername())));
    localShareModel.mData.put(Keystore.getEmail(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getEmail())));
    localShareModel.mData.put(Keystore.getPhoneNumber(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getPhoneNumber())));
    localShareModel.mData.put(Keystore.getBduss(), str2);
    localShareModel.mData.put(Keystore.getPtoken(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getPtoken())));
    localShareModel.mData.put(Keystore.getExtra(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getExtra())));
    localShareModel.mData.put(Keystore.getDisplayname(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getDisplayname())));
    localShareModel.mData.put(Keystore.getIsSocialAccount(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getIsSocialAccount())));
    localShareModel.mData.put(Keystore.getSocialAccounts(), this.mDataStorage.getString(Keystore.getSocialAccounts()));
    localShareModel.mData.put(Keystore.getDeviceToken(), LoginShareCrypto.encrypt(this.mContext, this.mDataStorage.getString(Keystore.getDeviceToken())));
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(str1);
    this.mShareAssistant.share(localShareModel, localArrayList);
  }

  private void handleSyncReply(ShareModel paramShareModel)
  {
    HashMap localHashMap1 = paramShareModel.mData;
    String str1 = (String)localHashMap1.get(Keystore.getIsValid());
    String str2 = (String)localHashMap1.get(Keystore.getUsername());
    String str3 = (String)localHashMap1.get(Keystore.getEmail());
    String str4 = (String)localHashMap1.get(Keystore.getPhoneNumber());
    String str5 = (String)localHashMap1.get(Keystore.getBduss());
    String str6 = (String)localHashMap1.get(Keystore.getPtoken());
    String str7 = (String)localHashMap1.get(Keystore.getExtra());
    String str8 = (String)localHashMap1.get(Keystore.getDisplayname());
    String str9 = (String)localHashMap1.get(Keystore.getIsSocialAccount());
    String str10 = (String)localHashMap1.get(Keystore.getSocialAccounts());
    String str11 = (String)localHashMap1.get(Keystore.getDeviceToken());
    Token localToken = new Token();
    String str12 = LoginShareCrypto.decrypt(this.mContext, str1);
    String str13 = LoginShareCrypto.decrypt(this.mContext, str2);
    String str14 = LoginShareCrypto.decrypt(this.mContext, str3);
    String str15 = LoginShareCrypto.decrypt(this.mContext, str4);
    String str16 = LoginShareCrypto.decrypt(this.mContext, str5);
    String str17 = LoginShareCrypto.decrypt(this.mContext, str6);
    String str18 = LoginShareCrypto.decrypt(this.mContext, str7);
    String str19 = LoginShareCrypto.decrypt(this.mContext, str8);
    String str20 = LoginShareCrypto.decrypt(this.mContext, str9);
    String str21 = LoginShareCrypto.decrypt(this.mContext, str10);
    String str22 = LoginShareCrypto.decrypt(this.mContext, str11);
    if ((!Utils.isValid(str12)) || (!Utils.isValid(str16)));
    while (true)
    {
      return;
      HashMap localHashMap2;
      if (Utils.isValid(str18))
        localHashMap2 = new HashMap();
      try
      {
        JSONObject localJSONObject = new JSONObject(str18);
        try
        {
          Iterator localIterator = localJSONObject.keys();
          while (localIterator.hasNext())
          {
            String str23 = (String)localIterator.next();
            localHashMap2.put(str23, localJSONObject.optString(str23));
          }
        }
        catch (JSONException localJSONException1)
        {
        }
        label359: Logger.w(localJSONException1);
        return;
        localToken.mExtras = localHashMap2;
        if (this.mValidTrue.equals(str12));
        for (LoginShareEvent localLoginShareEvent = LoginShareEvent.VALID; ; localLoginShareEvent = LoginShareEvent.INVALID)
        {
          localToken.mEvent = localLoginShareEvent;
          localToken.mUsername = str13;
          localToken.mEmail = str14;
          localToken.mPhoneNumber = str15;
          localToken.mBduss = str16;
          localToken.mPtoken = str17;
          localToken.mDisplayname = str19;
          localToken.isSocialAccount = this.mIsSocialTrue.equals(str20);
          localToken.socialTokenMap = getSocialAccount(str21);
          if (!TextUtils.isEmpty(str22))
            localToken.deviceToken = str22;
          if ((!SapiHelper.getInstance().isLogin()) || (!SapiHelper.getInstance().getToken().isSocialAccount) || (localToken.isSocialAccount))
            break;
          syncStorage(localToken.mBduss);
          return;
        }
        if (!syncStorage(this.mValidTrue.equals(str12), str19, str13, str14, str15, str16, str17, str18, localToken.isSocialAccount, localToken.socialTokenMap, localToken.deviceToken))
          continue;
        this.mToken = localToken;
        this.mListenerHelper.onLoginShareEvent(localToken);
        return;
      }
      catch (JSONException localJSONException2)
      {
        break label359;
      }
    }
  }

  private boolean hasCheckToday()
  {
    long l1 = this.mEnableHelper.getCheckTime();
    Date localDate = new Date(System.currentTimeMillis());
    long l2 = new Date(localDate.getYear(), localDate.getMonth(), localDate.getDate()).getTime();
    return (l1 < l2 + 86400000L) && (l1 >= l2);
  }

  private static boolean isValid(Token paramToken)
  {
    return (paramToken != null) && (paramToken.mExtras != null) && (Utils.isValid(paramToken.mBduss)) && (Utils.isValid(paramToken.mPtoken));
  }

  private boolean syncStorage(String paramString)
  {
    if ((this.mDataStorage != null) && (this.mToken.isSocialAccount))
    {
      this.mDataStorage.put(Keystore.getOtherBduss(), paramString);
      return this.mDataStorage.commit();
    }
    return false;
  }

  private boolean syncStorage(boolean paramBoolean1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, boolean paramBoolean2, HashMap<SocialType, SocialToken> paramHashMap, String paramString8)
  {
    if (this.mDataStorage != null)
    {
      FileStorage localFileStorage1 = this.mDataStorage;
      String str1 = Keystore.getIsValid();
      String str2;
      FileStorage localFileStorage2;
      String str3;
      if (paramBoolean1)
      {
        str2 = "1";
        localFileStorage1.put(str1, str2);
        this.mDataStorage.put(Keystore.getUsername(), paramString2);
        this.mDataStorage.put(Keystore.getEmail(), paramString3);
        this.mDataStorage.put(Keystore.getPhoneNumber(), paramString4);
        this.mDataStorage.put(Keystore.getBduss(), paramString5);
        this.mDataStorage.put(Keystore.getPtoken(), paramString6);
        if (Utils.isValid(paramString7))
          this.mDataStorage.put(Keystore.getExtra(), paramString7);
        this.mDataStorage.put(Keystore.getDisplayname(), paramString1);
        localFileStorage2 = this.mDataStorage;
        str3 = Keystore.getIsSocialAccount();
        if (!paramBoolean2)
          break label207;
      }
      label207: for (String str4 = this.mIsSocialTrue; ; str4 = this.mIsSocialFalse)
      {
        localFileStorage2.put(str3, str4);
        this.mDataStorage.put(Keystore.getSocialAccounts(), getSocialAccount(paramHashMap));
        if (!TextUtils.isEmpty(paramString8))
          this.mDataStorage.put(Keystore.getDeviceToken(), paramString8);
        return this.mDataStorage.commit();
        str2 = "0";
        break;
      }
    }
    return false;
  }

  private boolean syncStorage(boolean paramBoolean1, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, HashMap<String, String> paramHashMap, String paramString7, boolean paramBoolean2, HashMap<SocialType, SocialToken> paramHashMap1, String paramString8)
  {
    if (this.mDataStorage != null)
    {
      FileStorage localFileStorage1 = this.mDataStorage;
      String str1 = Keystore.getIsValid();
      String str2;
      FileStorage localFileStorage2;
      String str3;
      if (paramBoolean1)
      {
        str2 = "1";
        localFileStorage1.put(str1, str2);
        this.mDataStorage.put(Keystore.getUsername(), paramString2);
        this.mDataStorage.put(Keystore.getEmail(), paramString3);
        this.mDataStorage.put(Keystore.getPhoneNumber(), paramString4);
        this.mDataStorage.put(Keystore.getBduss(), paramString5);
        this.mDataStorage.put(Keystore.getPtoken(), paramString6);
        this.mDataStorage.put(Keystore.getJson(), paramString7);
        if (paramHashMap != null)
        {
          JSONObject localJSONObject = new JSONObject(paramHashMap);
          this.mDataStorage.put(Keystore.getExtra(), localJSONObject.toString());
        }
        this.mDataStorage.put(Keystore.getDisplayname(), paramString1);
        localFileStorage2 = this.mDataStorage;
        str3 = Keystore.getIsSocialAccount();
        if (!paramBoolean2)
          break label230;
      }
      label230: for (String str4 = this.mIsSocialTrue; ; str4 = this.mIsSocialFalse)
      {
        localFileStorage2.put(str3, str4);
        this.mDataStorage.put(Keystore.getSocialAccounts(), getSocialAccount(paramHashMap1));
        if (!TextUtils.isEmpty(paramString8))
          this.mDataStorage.put(Keystore.getDeviceToken(), paramString8);
        return this.mDataStorage.commit();
        str2 = "0";
        break;
      }
    }
    return false;
  }

  void destroy()
  {
    if ((this.mShareAssistant != null) && (this.mShareListener != null))
    {
      this.mShareAssistant.unRegistListener(this.mShareListener);
      this.mShareAssistant = null;
    }
    this.mStatisticsHelper = null;
    this.mContext = null;
    this.mIsInit = false;
  }

  String getDeviceToken()
  {
    if (this.mDataStorage == null)
      return "";
    return this.mDataStorage.getString("device_token");
  }

  Token getLastToken()
  {
    return this.mToken;
  }

  public String getOtherBduss()
  {
    if (this.mDataStorage != null)
      return this.mDataStorage.getString(Keystore.getOtherBduss());
    return null;
  }

  void initial(Context paramContext, String paramString1, String paramString2)
  {
    if (this.mIsInit)
      return;
    if ((paramContext == null) || (!Utils.isValid(paramString1)) || (!Utils.isValid(paramString2)))
      throw new IllegalArgumentException("params cannot be null");
    this.mContext = paramContext;
    StatisticsHelper localStatisticsHelper = new StatisticsHelper(paramString1, paramString2);
    this.mStatisticsHelper = localStatisticsHelper;
    this.mShareAssistant = ShareAssistant.getInstance(this.mContext);
    this.mShareAssistant.registListener(this.mShareListener);
    this.mDataStorage = new FileStorage(this.mContext);
    String str1 = this.mDataStorage.getString(Keystore.getIsValid());
    if (!Utils.isValid(str1))
    {
      this.mDataStorage.put(Keystore.getIsValid(), this.mValidFalse);
      this.mDataStorage.put(Keystore.getIsEnable(), this.mEnableTrue);
      this.mDataStorage.commit();
      this.mEnableHelper.setEnable(true);
      Thread local2 = new Thread()
      {
        public void run()
        {
          try
          {
            sleep(100L);
            if ((Sharer.this.mToken == null) && (Sharer.this.mContext != null))
            {
              ShareModel localShareModel = new ShareModel();
              localShareModel.mAction = Keystore.getSyncAction();
              ShareAssistant.getInstance(Sharer.this.mContext).share(localShareModel);
            }
            return;
          }
          catch (InterruptedException localInterruptedException)
          {
            Logger.w(localInterruptedException);
          }
        }
      };
      local2.start();
      this.mIsInit = true;
      return;
    }
    String str2 = this.mDataStorage.getString(Keystore.getIsEnable());
    String str3 = this.mDataStorage.getString(Keystore.getCheckTime());
    this.mEnableHelper.setEnable(this.mEnableTrue.equals(str2));
    try
    {
      this.mEnableHelper.setCheckTime(Long.parseLong(str3));
      label234: String str4 = this.mDataStorage.getString(Keystore.getUsername());
      String str5 = this.mDataStorage.getString(Keystore.getEmail());
      String str6 = this.mDataStorage.getString(Keystore.getPhoneNumber());
      String str7 = this.mDataStorage.getString(Keystore.getBduss());
      String str8 = this.mDataStorage.getString(Keystore.getPtoken());
      String str9 = this.mDataStorage.getString(Keystore.getExtra());
      String str10 = this.mDataStorage.getString(Keystore.getJson());
      String str11 = this.mDataStorage.getString(Keystore.getDisplayname());
      boolean bool = this.mIsSocialTrue.equals(this.mDataStorage.getString(Keystore.getIsSocialAccount()));
      String str12 = this.mDataStorage.getString(Keystore.getSocialAccounts());
      String str13 = this.mDataStorage.getString(Keystore.getDeviceToken());
      HashMap localHashMap = new HashMap();
      if (Utils.isValid(str9))
        try
        {
          JSONObject localJSONObject = new JSONObject(str9);
          Iterator localIterator = localJSONObject.keys();
          while (localIterator.hasNext())
          {
            String str14 = (String)localIterator.next();
            localHashMap.put(str14, localJSONObject.optString(str14));
          }
        }
        catch (JSONException localJSONException)
        {
          Logger.w(localJSONException);
        }
      this.mToken = new Token();
      Token localToken = this.mToken;
      if (this.mValidTrue.equals(str1));
      for (LoginShareEvent localLoginShareEvent = LoginShareEvent.VALID; ; localLoginShareEvent = LoginShareEvent.INVALID)
      {
        localToken.mEvent = localLoginShareEvent;
        this.mToken.mUsername = str4;
        this.mToken.mEmail = str5;
        this.mToken.mPhoneNumber = str6;
        this.mToken.mBduss = str7;
        this.mToken.mPtoken = str8;
        this.mToken.mExtras = localHashMap;
        this.mToken.mJson = str10;
        this.mToken.mDisplayname = str11;
        this.mToken.isSocialAccount = bool;
        this.mToken.socialTokenMap = getSocialAccount(str12);
        this.mToken.deviceToken = str13;
        this.mIsInit = true;
        return;
      }
    }
    catch (Exception localException)
    {
      break label234;
    }
  }

  boolean invalid(Token paramToken)
  {
    if (!this.mIsInit)
      return false;
    if (!isValid(paramToken))
      return false;
    String str1 = paramToken.mUsername;
    String str2 = paramToken.mEmail;
    String str3 = paramToken.mPhoneNumber;
    String str4 = paramToken.mBduss;
    String str5 = paramToken.mPtoken;
    String str6 = paramToken.mJson;
    String str7 = paramToken.mDisplayname;
    if (paramToken.isSocialAccount);
    ShareModel localShareModel;
    for (String str8 = this.mIsSocialTrue; ; str8 = this.mIsSocialFalse)
    {
      String str9 = getSocialAccount(paramToken.socialTokenMap).toString();
      String str10 = paramToken.deviceToken;
      String str11 = LoginShareCrypto.encrypt(this.mContext, str1);
      String str12 = LoginShareCrypto.encrypt(this.mContext, str2);
      String str13 = LoginShareCrypto.encrypt(this.mContext, str3);
      String str14 = LoginShareCrypto.encrypt(this.mContext, str4);
      String str15 = LoginShareCrypto.encrypt(this.mContext, str5);
      String str16 = LoginShareCrypto.encrypt(this.mContext, str6);
      HashMap localHashMap = new HashMap();
      String str17 = LoginShareCrypto.encrypt(this.mContext, str7);
      String str18 = LoginShareCrypto.encrypt(this.mContext, str8);
      String str19 = LoginShareCrypto.encrypt(this.mContext, str9);
      String str20 = LoginShareCrypto.encrypt(this.mContext, str10);
      localShareModel = new ShareModel();
      localShareModel.mAction = Keystore.getLogoutAction();
      localShareModel.mData.put(Keystore.getUsername(), str11);
      localShareModel.mData.put(Keystore.getEmail(), str12);
      localShareModel.mData.put(Keystore.getPhoneNumber(), str13);
      localShareModel.mData.put(Keystore.getBduss(), str14);
      localShareModel.mData.put(Keystore.getPtoken(), str15);
      localShareModel.mData.put(Keystore.getJson(), str16);
      localShareModel.mData.put(Keystore.getDisplayname(), str17);
      localShareModel.mData.put(Keystore.getIsSocialAccount(), str18);
      localShareModel.mData.put(Keystore.getSocialAccounts(), str19);
      localShareModel.mData.put(Keystore.getDeviceToken(), str20);
      Iterator localIterator = paramToken.mExtras.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str21 = (String)localIterator.next();
        String str22 = LoginShareCrypto.encrypt(this.mContext, (String)paramToken.mExtras.get(str21));
        localHashMap.put(str21, str22);
        localShareModel.mData.put(str21, str22);
      }
    }
    syncStorage(false, str7, str1, str2, str3, str4, str5, paramToken.mExtras, paramToken.mJson, paramToken.isSocialAccount, paramToken.socialTokenMap, paramToken.deviceToken);
    syncStorage("");
    paramToken.mEvent = LoginShareEvent.INVALID;
    this.mToken = paramToken;
    return check(localShareModel, false, str4);
  }

  void onActivityCreate()
  {
    if (this.mStatisticsHelper != null)
      this.mStatisticsHelper.onActivityCreate();
  }

  void setLoginShareListener(ILoginShareListener paramILoginShareListener)
  {
    this.mListenerHelper.setLoginShareListener(paramILoginShareListener);
  }

  boolean valid(Token paramToken)
  {
    if (!this.mIsInit)
      return false;
    if (!isValid(paramToken))
      return false;
    String str1 = paramToken.mUsername;
    String str2 = paramToken.mEmail;
    String str3 = paramToken.mPhoneNumber;
    String str4 = paramToken.mBduss;
    String str5 = paramToken.mPtoken;
    String str6 = paramToken.mJson;
    String str7 = paramToken.mDisplayname;
    if (paramToken.isSocialAccount);
    ShareModel localShareModel;
    for (String str8 = this.mIsSocialTrue; ; str8 = this.mIsSocialFalse)
    {
      String str9 = getSocialAccount(paramToken.socialTokenMap).toString();
      String str10 = paramToken.deviceToken;
      String str11 = LoginShareCrypto.encrypt(this.mContext, str1);
      String str12 = LoginShareCrypto.encrypt(this.mContext, str2);
      String str13 = LoginShareCrypto.encrypt(this.mContext, str3);
      String str14 = LoginShareCrypto.encrypt(this.mContext, str4);
      String str15 = LoginShareCrypto.encrypt(this.mContext, str5);
      String str16 = LoginShareCrypto.encrypt(this.mContext, str6);
      HashMap localHashMap = new HashMap();
      String str17 = LoginShareCrypto.encrypt(this.mContext, str7);
      String str18 = LoginShareCrypto.encrypt(this.mContext, str8);
      String str19 = LoginShareCrypto.encrypt(this.mContext, str9);
      String str20 = LoginShareCrypto.encrypt(this.mContext, str10);
      localShareModel = new ShareModel();
      localShareModel.mAction = Keystore.getLoginAction();
      localShareModel.mData.put(Keystore.getUsername(), str11);
      localShareModel.mData.put(Keystore.getEmail(), str12);
      localShareModel.mData.put(Keystore.getPhoneNumber(), str13);
      localShareModel.mData.put(Keystore.getBduss(), str14);
      localShareModel.mData.put(Keystore.getPtoken(), str15);
      localShareModel.mData.put(Keystore.getJson(), str16);
      localShareModel.mData.put(Keystore.getDisplayname(), str17);
      localShareModel.mData.put(Keystore.getIsSocialAccount(), str18);
      localShareModel.mData.put(Keystore.getSocialAccounts(), str19);
      localShareModel.mData.put(Keystore.getDeviceToken(), str20);
      Iterator localIterator = paramToken.mExtras.keySet().iterator();
      while (localIterator.hasNext())
      {
        String str21 = (String)localIterator.next();
        String str22 = LoginShareCrypto.encrypt(this.mContext, (String)paramToken.mExtras.get(str21));
        localHashMap.put(str21, str22);
        localShareModel.mData.put(str21, str22);
      }
    }
    syncStorage(true, str7, str1, str2, str3, str4, str5, paramToken.mExtras, paramToken.mJson, paramToken.isSocialAccount, paramToken.socialTokenMap, paramToken.deviceToken);
    paramToken.mEvent = LoginShareEvent.VALID;
    this.mToken = paramToken;
    return check(localShareModel, true, str4);
  }

  private class NetCheckHelper
    implements Runnable
  {
    private static final String KEY_APPCOMMUNICATE = "appcommunicate";
    private static final int TIME_OUT = 5000;
    private String mBduss = null;
    private boolean mIsValid = true;

    NetCheckHelper(boolean paramString, String arg3)
    {
      this.mIsValid = paramString;
      Object localObject;
      this.mBduss = localObject;
    }

    private Boolean asyncConnect()
    {
      HttpURLConnection localHttpURLConnection = null;
      try
      {
        localHttpURLConnection = (HttpURLConnection)new URL(Keystore.getUrl()).openConnection();
        localHttpURLConnection.setDoInput(false);
        localHttpURLConnection.setDoOutput(true);
        localHttpURLConnection.setUseCaches(false);
        localHttpURLConnection.setReadTimeout(5000);
        localHttpURLConnection.setConnectTimeout(5000);
        localHttpURLConnection.setRequestMethod("GET");
        localHttpURLConnection.connect();
        if (localHttpURLConnection.getResponseCode() != 200)
        {
          Boolean localBoolean4 = Boolean.valueOf(true);
          localObject2 = localBoolean4;
          return localObject2;
        }
        InputStream localInputStream = localHttpURLConnection.getInputStream();
        byte[] arrayOfByte = new byte[localInputStream.available()];
        localInputStream.read(arrayOfByte);
        localInputStream.close();
        localHttpURLConnection.disconnect();
        Boolean localBoolean3;
        if ("0".equals(new JSONObject(new String(arrayOfByte)).getString("appcommunicate")))
          localBoolean3 = Boolean.valueOf(false);
        Boolean localBoolean2;
        for (localObject2 = localBoolean3; ; localObject2 = localBoolean2)
        {
          return localObject2;
          localBoolean2 = Boolean.valueOf(true);
        }
      }
      catch (Exception localException)
      {
        Boolean localBoolean1 = Boolean.valueOf(true);
        Object localObject2 = localBoolean1;
        return localObject2;
      }
      finally
      {
        if (localHttpURLConnection != null)
          localHttpURLConnection.disconnect();
      }
    }

    private void onFinish(Boolean paramBoolean)
    {
      boolean bool = paramBoolean.booleanValue();
      long l = System.currentTimeMillis();
      Sharer.this.mEnableHelper.setEnable(bool);
      Sharer.this.mEnableHelper.setCheckTime(l);
      Sharer.this.mDataStorage.put(Keystore.getCheckTime(), l + "");
      FileStorage localFileStorage = Sharer.this.mDataStorage;
      String str1 = Keystore.getIsEnable();
      String str2;
      if (bool)
        str2 = Sharer.this.mEnableTrue;
      while (true)
      {
        localFileStorage.put(str1, str2);
        Sharer.this.mDataStorage.commit();
        synchronized (Sharer.this.mWaitingList)
        {
          int i = Sharer.this.mWaitingList.size();
          ShareModel localShareModel = null;
          if (i > 0)
          {
            localShareModel = (ShareModel)Sharer.this.mWaitingList.get(i - 1);
            Sharer.this.mWaitingList.clear();
          }
          if ((localShareModel != null) && (Sharer.this.mShareAssistant != null) && (Sharer.this.mShareAssistant.share(localShareModel)) && (this.mIsValid))
            Sharer.this.mStatisticsHelper.doUpload(1, this.mBduss);
          return;
          str2 = Sharer.this.mEnableFalse;
        }
      }
    }

    public void run()
    {
      Sharer.access$602(Sharer.this, true);
      onFinish(asyncConnect());
      Sharer.access$602(Sharer.this, false);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.Sharer
 * JD-Core Version:    0.6.2
 */