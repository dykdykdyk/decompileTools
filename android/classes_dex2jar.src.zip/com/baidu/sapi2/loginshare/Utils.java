package com.baidu.sapi2.loginshare;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;

public class Utils
{
  public static final int DEFAULT_PROXY_PORT = 80;
  public static final String NET = "net";
  public static final String PROXY_IP = "10.0.0.172";
  public static final int TYPE_NET = 2;
  public static final int TYPE_UNKNOWN = 3;
  public static final int TYPE_WAP = 1;
  public static final String WAP = "wap";
  public static final String http = "http://";
  public static final String https = "https://";

  public static Proxy getProxy(Context paramContext)
  {
    if (!((WifiManager)paramContext.getSystemService("wifi")).isWifiEnabled())
    {
      Proxy localProxy;
      try
      {
        Uri localUri = Uri.parse("content://telephony/carriers/preferapn");
        Cursor localCursor = null;
        try
        {
          localCursor = paramContext.getContentResolver().query(localUri, null, null, null, null);
          if ((localCursor != null) && (localCursor.moveToNext()))
          {
            String str = localCursor.getString(localCursor.getColumnIndex("proxy"));
            if ((str != null) && (str.trim().length() > 0))
            {
              localProxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(str, 80));
              return localProxy;
            }
          }
        }
        finally
        {
          if ((localCursor != null) && (!localCursor.isClosed()))
            localCursor.close();
        }
      }
      catch (Exception localException)
      {
      }
      return localProxy;
    }
    return null;
  }

  public static boolean hasActiveNetwork(Context paramContext)
  {
    if (paramContext == null);
    ConnectivityManager localConnectivityManager;
    do
    {
      return false;
      localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    }
    while ((localConnectivityManager == null) || (localConnectivityManager.getActiveNetworkInfo() == null));
    return true;
  }

  static boolean isValid(String paramString)
  {
    return (paramString != null) && (paramString.length() > 0);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.loginshare.Utils
 * JD-Core Version:    0.6.2
 */