package com.baidu.sapi2.View;

import android.view.View;

public abstract interface ItemView
{
  public abstract void clear();

  public abstract View getItemView();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.View.ItemView
 * JD-Core Version:    0.6.2
 */