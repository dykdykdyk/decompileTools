package com.baidu.sapi2.View;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.baidu.wearable.ble.util.LogUtil;

public class PageIndexView extends LinearLayout
{
  private static final String TAG = "PageIndexView";
  private Context mContext;
  private int mCurrentPage = 0;
  private int mHidePosition = -1;
  private int mIndexNormalBackgroundResId;
  private int mIndexSelectedBackgroundResId;
  private int mPaddingBottomDip;
  private int mPageNum;

  public PageIndexView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
    setIndexSelectedBackground(2130837846);
    setIndexNormalBackground(2130837845);
  }

  private int dip2px(Context paramContext, float paramFloat)
  {
    if (paramContext == null)
      return (int)paramFloat;
    return (int)(0.5F + paramFloat * paramContext.getResources().getDisplayMetrics().density);
  }

  private int getIndexNormalBackground()
  {
    return this.mIndexNormalBackgroundResId;
  }

  private int getIndexSelectedBackground()
  {
    return this.mIndexSelectedBackgroundResId;
  }

  public int getPagerCount()
  {
    return this.mPageNum;
  }

  public void initIndexView(int paramInt)
  {
    if (getChildCount() != 0)
      removeAllViews();
    this.mPageNum = paramInt;
    for (int i = 0; ; i++)
    {
      if (i >= this.mPageNum)
      {
        if (paramInt > 0)
          getChildAt(this.mCurrentPage).setBackgroundResource(getIndexSelectedBackground());
        return;
      }
      ImageView localImageView = new ImageView(this.mContext);
      localImageView.setBackgroundResource(getIndexNormalBackground());
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -2);
      int j = dip2px(getContext(), 2.0F);
      localLayoutParams.setMargins(j, 0, j, 0);
      localImageView.setLayoutParams(localLayoutParams);
      addView(localImageView);
    }
  }

  public void selectedIndexView(int paramInt)
  {
    if (paramInt >= this.mPageNum)
    {
      LogUtil.d("PageIndexView", "selectedIndexView currentView out of range!");
      return;
    }
    if (paramInt == this.mHidePosition)
      setVisibility(8);
    for (int i = 0; ; i++)
    {
      if (i >= this.mPageNum)
      {
        getChildAt(paramInt).setBackgroundResource(getIndexSelectedBackground());
        return;
        setVisibility(0);
        break;
      }
      getChildAt(i).setBackgroundResource(getIndexNormalBackground());
    }
  }

  public void setHidePostition(int paramInt)
  {
    this.mHidePosition = paramInt;
  }

  public int setIndexNormalBackground(int paramInt)
  {
    this.mIndexNormalBackgroundResId = paramInt;
    return paramInt;
  }

  public int setIndexSelectedBackground(int paramInt)
  {
    this.mIndexSelectedBackgroundResId = paramInt;
    return paramInt;
  }

  public void setPaddingBottom(int paramInt)
  {
    this.mPaddingBottomDip = paramInt;
  }

  public void showNext()
  {
    for (int i = 0; ; i++)
    {
      if (i >= this.mPageNum)
      {
        int j = 1 + this.mCurrentPage;
        this.mCurrentPage = j;
        int k = j % this.mPageNum;
        getChildAt(k).setBackgroundResource(getIndexSelectedBackground());
        if (k != this.mHidePosition)
          break;
        setVisibility(8);
        return;
      }
      getChildAt(i).setBackgroundResource(getIndexNormalBackground());
    }
    setVisibility(0);
  }

  public void showPre()
  {
    for (int i = 0; ; i++)
    {
      if (i >= this.mPageNum)
      {
        int j = -1 + this.mCurrentPage;
        this.mCurrentPage = j;
        int k = j % this.mPageNum;
        getChildAt((k + this.mPageNum) % this.mPageNum).setBackgroundResource(getIndexSelectedBackground());
        if ((k + this.mPageNum) % this.mPageNum != this.mHidePosition)
          break;
        setVisibility(8);
        return;
      }
      getChildAt(i).setBackgroundResource(getIndexNormalBackground());
    }
    setVisibility(0);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.View.PageIndexView
 * JD-Core Version:    0.6.2
 */