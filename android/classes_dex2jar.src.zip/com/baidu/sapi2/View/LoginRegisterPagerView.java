package com.baidu.sapi2.View;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import com.baidu.sapi2.activity.RegisterViewManager;

public class LoginRegisterPagerView extends FrameLayout
{
  private static final String TAG = "LoginRegisterPagerView";
  private View mLoginView;
  private LoginViewManager mLoginViewManager;
  private View mRegisterView;
  private RegisterViewManager mRegisterViewManager;
  private OnLoginRegisterViewSwitchOverListenner mSwichListenner;

  public LoginRegisterPagerView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public LoginRegisterPagerView(Context paramContext, LoginViewManager paramLoginViewManager, RegisterViewManager paramRegisterViewManager)
  {
    super(paramContext);
    this.mLoginViewManager = paramLoginViewManager;
    this.mRegisterViewManager = paramRegisterViewManager;
    this.mLoginView = paramLoginViewManager.getRootView();
    this.mRegisterView = paramRegisterViewManager.getRootView();
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-1, -1);
    this.mLoginView.setLayoutParams(localLayoutParams);
    this.mRegisterView.setLayoutParams(localLayoutParams);
    addView(this.mLoginView);
    addView(this.mRegisterView);
    this.mRegisterView.setVisibility(8);
    paramLoginViewManager.initView();
    paramLoginViewManager.setOnRightBtnClickListener(new Change2RegisterClick(null));
    paramRegisterViewManager.initView();
    paramRegisterViewManager.setOnLeftBtnClickListener(new Change2LoginClick(null));
    paramRegisterViewManager.setOnRightBtnClickListener(new Change2LoginClick(null));
  }

  private void hideRegisterAnimation()
  {
    Animation localAnimation = AnimationUtils.loadAnimation(getContext(), 2130968578);
    this.mRegisterView.startAnimation(localAnimation);
  }

  private void showRegisterAnimation()
  {
    Animation localAnimation = AnimationUtils.loadAnimation(getContext(), 2130968577);
    this.mRegisterView.startAnimation(localAnimation);
  }

  public void hideSoftKeyboard()
  {
    if (isRegisterViewShow())
    {
      this.mRegisterViewManager.hideSoftKeyboard();
      return;
    }
    this.mLoginViewManager.hideSoftKeyboard();
  }

  public boolean isLoginViewShow()
  {
    return this.mLoginView.getVisibility() == 0;
  }

  public boolean isRegisterViewShow()
  {
    return this.mRegisterView.getVisibility() == 0;
  }

  public void setOnBackClickListenner(View.OnClickListener paramOnClickListener)
  {
    this.mLoginViewManager.setOnLeftBtnClickListener(paramOnClickListener);
  }

  public void setOnSwichListenner(OnLoginRegisterViewSwitchOverListenner paramOnLoginRegisterViewSwitchOverListenner)
  {
    this.mSwichListenner = paramOnLoginRegisterViewSwitchOverListenner;
  }

  public void showLoginView()
  {
    if (!isRegisterViewShow());
    do
    {
      return;
      hideSoftKeyboard();
      this.mRegisterView.setVisibility(8);
      hideRegisterAnimation();
    }
    while (this.mSwichListenner == null);
    this.mSwichListenner.LoginRegisterViewSwich(true);
  }

  public void showRegisterView()
  {
    if (isRegisterViewShow());
    do
    {
      return;
      hideSoftKeyboard();
      this.mRegisterView.setVisibility(0);
      showRegisterAnimation();
    }
    while (this.mSwichListenner == null);
    this.mSwichListenner.LoginRegisterViewSwich(false);
  }

  private class Change2LoginClick
    implements View.OnClickListener
  {
    private Change2LoginClick()
    {
    }

    public void onClick(View paramView)
    {
      LoginRegisterPagerView.this.showLoginView();
    }
  }

  private class Change2RegisterClick
    implements View.OnClickListener
  {
    private Change2RegisterClick()
    {
    }

    public void onClick(View paramView)
    {
      LoginRegisterPagerView.this.showRegisterView();
    }
  }

  public static abstract interface OnLoginRegisterViewSwitchOverListenner
  {
    public abstract void LoginRegisterViewSwich(boolean paramBoolean);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.View.LoginRegisterPagerView
 * JD-Core Version:    0.6.2
 */