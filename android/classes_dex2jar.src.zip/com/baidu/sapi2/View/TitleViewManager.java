package com.baidu.sapi2.View;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public abstract class TitleViewManager
  implements View.OnClickListener
{
  private Activity mActivity;
  protected Button mLeftBtn;
  protected Button mRightBtn;
  private View mRootView;
  protected TextView mTitle;
  private LayoutInflater mViewInflater;
  protected AlertDialog progressingDialog;
  protected View progressingView;
  protected Dialog tipsDialog;

  public TitleViewManager(Activity paramActivity)
  {
    this.mActivity = paramActivity;
    this.mViewInflater = LayoutInflater.from(paramActivity);
    if (this.mViewInflater != null)
      this.mRootView = this.mViewInflater.inflate(getLayoutId(), null);
  }

  protected View findViewById(int paramInt)
  {
    if (this.mRootView == null)
      return null;
    return this.mRootView.findViewById(paramInt);
  }

  protected abstract int getLayoutId();

  public View getRootView()
  {
    return this.mRootView;
  }

  protected Button getTipsDialogLeftButton()
  {
    return (Button)this.tipsDialog.findViewById(2131231087);
  }

  protected Button getTipsDialogRightButton()
  {
    return (Button)this.tipsDialog.findViewById(2131231088);
  }

  public void initView()
  {
    if (this.mViewInflater == null);
  }

  public void onClick(View paramView)
  {
    if (paramView == this.mLeftBtn)
      onLeftBtnClick();
    while (paramView != this.mRightBtn)
      return;
    onRightBtnClick();
  }

  protected void onLeftBtnClick()
  {
  }

  protected void onRightBtnClick()
  {
  }

  public void setBtnText(int paramInt1, int paramInt2)
  {
    if (this.mLeftBtn != null)
      this.mLeftBtn.setText(paramInt1);
    if (this.mRightBtn != null)
      this.mRightBtn.setText(paramInt2);
  }

  public void setBtnVisibility(int paramInt1, int paramInt2)
  {
    if (this.mLeftBtn != null)
      this.mLeftBtn.setVisibility(paramInt1);
    if (this.mRightBtn != null)
      this.mRightBtn.setVisibility(paramInt2);
  }

  public void setOnLeftBtnClickListener(View.OnClickListener paramOnClickListener)
  {
    if (this.mLeftBtn != null)
      this.mLeftBtn.setOnClickListener(paramOnClickListener);
  }

  public void setOnRightBtnClickListener(View.OnClickListener paramOnClickListener)
  {
    if (this.mRightBtn != null)
      this.mRightBtn.setOnClickListener(paramOnClickListener);
  }

  protected void setProgressingDialogText(int paramInt)
  {
    ((TextView)this.progressingView.findViewById(2131231084)).setText(paramInt);
  }

  protected void setProgressingDialogText(String paramString)
  {
    ((TextView)this.progressingView.findViewById(2131231084)).setText(paramString);
  }

  protected void setTipsDialogMessage(String paramString)
  {
    ((TextView)this.tipsDialog.findViewById(2131231086)).setText(paramString);
  }

  protected void setTipsDialogTMessage(int paramInt)
  {
    ((TextView)this.tipsDialog.findViewById(2131231086)).setText(paramInt);
  }

  protected void setTipsDialogTitle(int paramInt)
  {
    ((TextView)this.tipsDialog.findViewById(2131231085)).setText(paramInt);
  }

  protected void setTipsDialogTitle(String paramString)
  {
    ((TextView)this.tipsDialog.findViewById(2131231085)).setText(paramString);
  }

  public void setTitleText(int paramInt)
  {
    if (this.mTitle != null)
      this.mTitle.setText(paramInt);
  }

  public void setTitleText(String paramString)
  {
    if (this.mTitle != null)
      this.mTitle.setText(paramString);
  }

  protected void setupViews()
  {
    this.mTitle = ((TextView)this.mRootView.findViewById(2131230967));
    this.mLeftBtn = ((Button)this.mRootView.findViewById(2131231226));
    this.mRightBtn = ((Button)this.mRootView.findViewById(2131231227));
    this.mLeftBtn.setOnClickListener(this);
    this.mRightBtn.setOnClickListener(this);
    this.progressingView = this.mViewInflater.inflate(2130903087, null);
    this.progressingDialog = new AlertDialog.Builder(this.mActivity).setCancelable(false).setView(this.progressingView).create();
    this.tipsDialog = new Dialog(this.mActivity, 2131361793);
    this.tipsDialog.setContentView(2130903088);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.View.TitleViewManager
 * JD-Core Version:    0.6.2
 */