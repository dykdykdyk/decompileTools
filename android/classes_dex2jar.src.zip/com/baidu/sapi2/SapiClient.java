package com.baidu.sapi2;

import android.content.Context;
import android.text.TextUtils;
import com.baidu.sapi2.account.AccountAPI;
import com.baidu.sapi2.account.AccountType;
import com.baidu.sapi2.account.DisplayAccount;
import com.baidu.sapi2.http.AsyncHttpClient;
import com.baidu.sapi2.http.AsyncHttpResponseHandler;
import com.baidu.sapi2.http.BinaryHttpResponseHandler;
import com.baidu.sapi2.http.RequestParams;
import com.baidu.sapi2.log.Logger;
import com.baidu.sapi2.loginshare.Token;
import com.baidu.sapi2.model.FillUnameResponse;
import com.baidu.sapi2.model.LoginResponse;
import com.baidu.sapi2.model.PhoneRegResponse;
import com.baidu.sapi2.model.QrPcLoginResponse;
import com.baidu.sapi2.security.EncryptHelper;
import com.baidu.sapi2.security.Md5;
import com.baidu.sapi2.social.config.Domain;
import com.baidu.sapi2.utils.DeviceId;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.security.cert.CertificateException;
import org.json.JSONException;
import org.json.JSONObject;

public class SapiClient
{
  private static SapiConfig mSapiConfig = null;
  private static final String version = "5.3";
  String encryptInfo = "";
  private AsyncHttpClient mAsyncHttpClient;
  private Context mContext;
  private ITokenCallback mTokenCallback;

  private int getErrorCode(String paramString)
  {
    try
    {
      int i = new JSONObject(paramString).getInt("errno");
      return i;
    }
    catch (Exception localException)
    {
      Logger.w(localException);
    }
    return -100;
  }

  private int getErrorCodeForReg(String paramString)
  {
    int i = getErrorCode(paramString);
    if (i == 110000)
      i = 0;
    return i;
  }

  private String getPassportSig(HashMap<String, String> paramHashMap, String paramString)
  {
    Iterator localIterator1 = paramHashMap.keySet().iterator();
    ArrayList localArrayList = new ArrayList();
    while (localIterator1.hasNext())
      localArrayList.add(localIterator1.next());
    Collections.sort(localArrayList);
    StringBuffer localStringBuffer = new StringBuffer();
    Iterator localIterator2 = localArrayList.iterator();
    while (true)
      if (localIterator2.hasNext())
      {
        String str1 = (String)localIterator2.next();
        localStringBuffer.append(str1);
        localStringBuffer.append("=");
        try
        {
          String str2 = (String)paramHashMap.get(str1);
          if (!TextUtils.isEmpty(str2))
            localStringBuffer.append(URLEncoder.encode(str2, "UTF-8"));
          localStringBuffer.append("&");
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException)
        {
          while (true)
            Logger.w(localUnsupportedEncodingException);
        }
      }
    localStringBuffer.append("sign_key=" + paramString);
    return Md5.md5s(localStringBuffer.toString());
  }

  private String getUaInfo()
  {
    return "tpl:" + mSapiConfig.getTpl() + ";android_sapi_v" + getVersion();
  }

  public static String getVersion()
  {
    return "5.3";
  }

  private void handleAskDynamicPass(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    try
    {
      paramSapiCallBack.onEvent(Integer.parseInt(new JSONObject(paramString).optString("errno")), null);
      return;
    }
    catch (Exception localException)
    {
      paramSapiCallBack.onEvent(-100, null);
    }
  }

  private void handleDeviceForcedResult(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    LoginResponse localLoginResponse;
    if (paramString != null)
      localLoginResponse = new LoginResponse();
    do
    {
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        localLoginResponse.mDisplayname = localJSONObject.optString("displayname");
        localLoginResponse.mUid = localJSONObject.optString("uid");
        localLoginResponse.mBduss = localJSONObject.optString("bduss");
        localLoginResponse.mPtoken = localJSONObject.optString("ptoken");
        if ((!localJSONObject.has("error_code")) && (!localJSONObject.has("error_msg")))
        {
          Token localToken = new Token();
          localToken.mDisplayname = localLoginResponse.mDisplayname;
          localToken.mBduss = localLoginResponse.mBduss;
          localToken.mPtoken = localLoginResponse.mPtoken;
          localToken.isSocialAccount = true;
          if (localJSONObject.has("device_token"))
            localToken.deviceToken = localJSONObject.optString("device_token");
          localToken.mJson = paramString;
          mSapiConfig.setShowDevice(true);
          SapiHelper.getInstance().setShowDevice(true);
          SapiHelper.getInstance().setToken(localToken);
          SapiHelper.getInstance().valid();
        }
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(localJSONObject.optInt("error_code"), localLoginResponse);
        if (this.mTokenCallback != null)
          this.mTokenCallback.onResult(localLoginResponse.mBduss);
        return;
      }
      catch (Exception localException)
      {
        do
          if (paramSapiCallBack != null)
            paramSapiCallBack.onEvent(-100, null);
        while (this.mTokenCallback == null);
        this.mTokenCallback.onResult(null);
        return;
      }
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(paramInt, null);
    }
    while (this.mTokenCallback == null);
    this.mTokenCallback.onResult(null);
  }

  private void handleDeviceResult(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    if (paramString != null)
    {
      LoginResponse localLoginResponse = new LoginResponse();
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        localLoginResponse.mDisplayname = localJSONObject.optString("displayname");
        localLoginResponse.mUid = localJSONObject.optString("uid");
        localLoginResponse.mBduss = localJSONObject.optString("bduss");
        localLoginResponse.mPtoken = localJSONObject.optString("ptoken");
        if (localJSONObject.optInt("error_code") == 104)
        {
          deviceForcedRegister(paramSapiCallBack, localJSONObject.optString("force_reg_token"));
          return;
        }
        if ((!localJSONObject.has("error_code")) && (!localJSONObject.has("error_msg")))
        {
          Token localToken = new Token();
          localToken.mDisplayname = localLoginResponse.mDisplayname;
          localToken.mBduss = localLoginResponse.mBduss;
          localToken.mPtoken = localLoginResponse.mPtoken;
          localToken.isSocialAccount = true;
          if (localJSONObject.has("device_token"))
            localToken.deviceToken = localJSONObject.optString("device_token");
          localToken.mJson = paramString;
          mSapiConfig.setShowDevice(true);
          SapiHelper.getInstance().setShowDevice(true);
          SapiHelper.getInstance().setToken(localToken);
          SapiHelper.getInstance().valid();
        }
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(localJSONObject.optInt("error_code"), localLoginResponse);
        if (this.mTokenCallback == null)
          return;
        this.mTokenCallback.onResult(localLoginResponse.mBduss);
        return;
      }
      catch (Exception localException)
      {
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(-100, null);
        if (this.mTokenCallback == null)
          return;
      }
      this.mTokenCallback.onResult(null);
    }
    else
    {
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(paramInt, null);
      if (this.mTokenCallback != null)
        this.mTokenCallback.onResult(null);
    }
  }

  private void handleDownloadLogin(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    LoginResponse localLoginResponse;
    if (paramString != null)
      localLoginResponse = new LoginResponse();
    do
    {
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        localLoginResponse.mDisplayname = localJSONObject.optString("displayname");
        localLoginResponse.mUid = localJSONObject.optString("uid");
        localLoginResponse.mBduss = localJSONObject.optString("bduss");
        localLoginResponse.mPtoken = localJSONObject.optString("ptoken");
        if ((!TextUtils.isEmpty(localJSONObject.optString("errno"))) && (localJSONObject.optString("errno").equals("0")))
        {
          Token localToken = new Token();
          localToken.mDisplayname = localLoginResponse.mDisplayname;
          localToken.mBduss = localLoginResponse.mBduss;
          localToken.mPtoken = localLoginResponse.mPtoken;
          localToken.isSocialAccount = true;
          localToken.mJson = paramString;
          mSapiConfig.setShowDevice(true);
          SapiHelper.getInstance().setShowDevice(true);
          SapiHelper.getInstance().setToken(localToken);
          SapiHelper.getInstance().valid();
        }
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(localJSONObject.optInt("errno"), localLoginResponse);
        if (this.mTokenCallback != null)
          this.mTokenCallback.onResult(localLoginResponse.mBduss);
        return;
      }
      catch (Exception localException)
      {
        do
          if (paramSapiCallBack != null)
            paramSapiCallBack.onEvent(-100, null);
        while (this.mTokenCallback == null);
        this.mTokenCallback.onResult(null);
        return;
      }
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(paramInt, null);
    }
    while (this.mTokenCallback == null);
    this.mTokenCallback.onResult(null);
  }

  private void handleFastReg(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    LoginResponse localLoginResponse;
    if (paramString != null)
      localLoginResponse = new LoginResponse();
    do
    {
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        localLoginResponse.mDisplayname = localJSONObject.optString("displayname");
        localLoginResponse.mUid = localJSONObject.optString("uid");
        localLoginResponse.mBduss = localJSONObject.optString("bduss");
        localLoginResponse.mPtoken = localJSONObject.optString("ptoken");
        if ((!TextUtils.isEmpty(localJSONObject.optString("errno"))) && (localJSONObject.optString("errno").equals("0")))
        {
          Token localToken = new Token();
          localToken.mDisplayname = localLoginResponse.mDisplayname;
          localToken.mBduss = localLoginResponse.mBduss;
          localToken.mPtoken = localLoginResponse.mPtoken;
          localToken.isSocialAccount = true;
          localToken.mJson = paramString;
          mSapiConfig.setShowDevice(true);
          SapiHelper.getInstance().setShowDevice(true);
          SapiHelper.getInstance().setToken(localToken);
          SapiHelper.getInstance().valid();
        }
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(localJSONObject.optInt("errno"), localLoginResponse);
        if (this.mTokenCallback != null)
          this.mTokenCallback.onResult(localLoginResponse.mBduss);
        return;
      }
      catch (Exception localException)
      {
        do
          if (paramSapiCallBack != null)
            paramSapiCallBack.onEvent(-100, null);
        while (this.mTokenCallback == null);
        this.mTokenCallback.onResult(null);
        return;
      }
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(paramInt, null);
    }
    while (this.mTokenCallback == null);
    this.mTokenCallback.onResult(null);
  }

  private void handleFillUname(int paramInt, SapiCallBack paramSapiCallBack, String paramString1, String paramString2, EncryptHelper paramEncryptHelper)
  {
    if (paramString1 != null)
    {
      FillUnameResponse localFillUnameResponse = new FillUnameResponse();
      try
      {
        String str = new JSONObject(paramString1).optString("userinfo");
        if (!TextUtils.isEmpty(str))
        {
          JSONObject localJSONObject = new JSONObject(paramEncryptHelper.decrypt(str));
          localFillUnameResponse.mBduss = localJSONObject.optString("bduss");
          localFillUnameResponse.mPtoken = localJSONObject.optString("ptoken");
          localFillUnameResponse.mStoken = localJSONObject.optString("stoken");
          localFillUnameResponse.mDisplayname = localJSONObject.optString("displayname");
          localFillUnameResponse.mUid = localJSONObject.optString("uid");
          localFillUnameResponse.mUserName = localJSONObject.optString("uname");
          if (paramInt == 0)
          {
            Token localToken = new Token();
            localToken.mDisplayname = localFillUnameResponse.mDisplayname;
            localToken.mBduss = localFillUnameResponse.mBduss;
            localToken.mPtoken = localFillUnameResponse.mPtoken;
            localToken.mUsername = localFillUnameResponse.mUserName;
            localToken.mJson = localJSONObject.toString();
            SapiHelper.getInstance().setToken(localToken);
            SapiHelper.getInstance().valid();
          }
        }
        paramSapiCallBack.onEvent(paramInt, localFillUnameResponse);
        return;
      }
      catch (Exception localException)
      {
        paramSapiCallBack.onEvent(-100, null);
        return;
      }
    }
    paramSapiCallBack.onEvent(paramInt, null);
  }

  private void handleLogin(int paramInt, SapiCallBack paramSapiCallBack, String paramString, EncryptHelper paramEncryptHelper)
  {
    int i = 1;
    LoginResponse localLoginResponse;
    if (paramString != null)
      localLoginResponse = new LoginResponse();
    label336: 
    do
    {
      try
      {
        String str = new JSONObject(paramString).optString("userinfo");
        JSONObject localJSONObject;
        if (!TextUtils.isEmpty(str))
        {
          localJSONObject = new JSONObject(paramEncryptHelper.decrypt(str));
          if (localJSONObject.optInt("needvcode") != i)
            break label336;
        }
        while (true)
        {
          localLoginResponse.mNeedVerifyCode = i;
          if (localLoginResponse.mNeedVerifyCode)
            localLoginResponse.mVcodeStr = localJSONObject.optString("vcodestr");
          localLoginResponse.mDisplayname = localJSONObject.optString("displayname");
          localLoginResponse.mUsername = localJSONObject.optString("uname");
          localLoginResponse.mUid = localJSONObject.optString("uid");
          localLoginResponse.mEmail = localJSONObject.optString("email");
          localLoginResponse.mWeakPass = localJSONObject.optInt("weakpass");
          localLoginResponse.mBduss = localJSONObject.optString("bduss");
          localLoginResponse.mPtoken = localJSONObject.optString("ptoken");
          localLoginResponse.mStoken = localJSONObject.optString("stoken");
          localLoginResponse.mAuth = localJSONObject.optString("auth");
          if (paramInt == 0)
          {
            Token localToken = new Token();
            localToken.mDisplayname = localLoginResponse.mDisplayname;
            localToken.mBduss = localLoginResponse.mBduss;
            localToken.mUsername = localLoginResponse.mUsername;
            localToken.mEmail = localLoginResponse.mEmail;
            localToken.mPtoken = localLoginResponse.mPtoken;
            localToken.mJson = localJSONObject.toString();
            SapiHelper.getInstance().setToken(localToken);
            SapiHelper.getInstance().valid();
          }
          if (paramSapiCallBack != null)
            paramSapiCallBack.onEvent(paramInt, localLoginResponse);
          if (this.mTokenCallback != null)
            this.mTokenCallback.onResult(localLoginResponse.mBduss);
          return;
          i = 0;
        }
      }
      catch (Exception localException)
      {
        do
          if (paramSapiCallBack != null)
            paramSapiCallBack.onEvent(-100, null);
        while (this.mTokenCallback == null);
        this.mTokenCallback.onResult(null);
        return;
      }
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(paramInt, null);
    }
    while (this.mTokenCallback == null);
    this.mTokenCallback.onResult(null);
  }

  private void handlePhoneReg(int paramInt, SapiCallBack paramSapiCallBack, String paramString, EncryptHelper paramEncryptHelper)
  {
    PhoneRegResponse localPhoneRegResponse;
    if (paramString != null)
      localPhoneRegResponse = new PhoneRegResponse();
    do
    {
      try
      {
        String str = new JSONObject(paramString).optString("userinfo");
        if (!TextUtils.isEmpty(str))
        {
          JSONObject localJSONObject = new JSONObject(paramEncryptHelper.decrypt(str));
          localPhoneRegResponse.mBduss = localJSONObject.optString("bduss");
          localPhoneRegResponse.mPtoken = localJSONObject.optString("ptoken");
          localPhoneRegResponse.mStoken = localJSONObject.optString("stoken");
          localPhoneRegResponse.mDisplayname = localJSONObject.optString("displayname");
          if (paramInt == 0)
          {
            Token localToken = new Token();
            localToken.mDisplayname = localPhoneRegResponse.mDisplayname;
            localToken.mBduss = localPhoneRegResponse.mBduss;
            localToken.mPtoken = localPhoneRegResponse.mPtoken;
            localToken.mJson = localJSONObject.toString();
            SapiHelper.getInstance().setToken(localToken);
            SapiHelper.getInstance().valid();
          }
        }
        paramSapiCallBack.onEvent(paramInt, localPhoneRegResponse);
        if (this.mTokenCallback != null)
          this.mTokenCallback.onResult(localPhoneRegResponse.mBduss);
        return;
      }
      catch (Exception localException)
      {
        do
          paramSapiCallBack.onEvent(-100, null);
        while (this.mTokenCallback == null);
        this.mTokenCallback.onResult(localPhoneRegResponse.mBduss);
        return;
      }
      paramSapiCallBack.onEvent(paramInt, null);
    }
    while (this.mTokenCallback == null);
    this.mTokenCallback.onResult(null);
  }

  private void handleQrAppLogin(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    LoginResponse localLoginResponse;
    if (paramString != null)
      localLoginResponse = new LoginResponse();
    do
    {
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        localLoginResponse.mDisplayname = localJSONObject.optString("displayname");
        localLoginResponse.mUid = localJSONObject.optString("uid");
        localLoginResponse.mBduss = localJSONObject.optString("bduss");
        localLoginResponse.mPtoken = localJSONObject.optString("ptoken");
        if ((!TextUtils.isEmpty(localJSONObject.optString("errno"))) && (localJSONObject.optString("errno").equals("0")))
        {
          Token localToken = new Token();
          localToken.mDisplayname = localLoginResponse.mDisplayname;
          localToken.mBduss = localLoginResponse.mBduss;
          localToken.mPtoken = localLoginResponse.mPtoken;
          localToken.isSocialAccount = true;
          localToken.mJson = paramString;
          mSapiConfig.setShowDevice(true);
          SapiHelper.getInstance().setShowDevice(true);
          SapiHelper.getInstance().setToken(localToken);
          SapiHelper.getInstance().valid();
        }
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(localJSONObject.optInt("errno"), localLoginResponse);
        if (this.mTokenCallback != null)
          this.mTokenCallback.onResult(localLoginResponse.mBduss);
        return;
      }
      catch (Exception localException)
      {
        do
          if (paramSapiCallBack != null)
            paramSapiCallBack.onEvent(-100, null);
        while (this.mTokenCallback == null);
        this.mTokenCallback.onResult(null);
        return;
      }
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(paramInt, null);
    }
    while (this.mTokenCallback == null);
    this.mTokenCallback.onResult(null);
  }

  private void handleQrPCLogin(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    try
    {
      JSONObject localJSONObject1 = new JSONObject(paramString);
      int i = Integer.parseInt(localJSONObject1.optString("errno"));
      JSONObject localJSONObject2 = localJSONObject1.optJSONObject("local");
      if (localJSONObject2 == null)
      {
        paramSapiCallBack.onEvent(i, null);
        return;
      }
      QrPcLoginResponse localQrPcLoginResponse = new QrPcLoginResponse();
      localQrPcLoginResponse.mProvince = localJSONObject2.optString("provice");
      localQrPcLoginResponse.mCity = localJSONObject2.optString("city");
      paramSapiCallBack.onEvent(i, localQrPcLoginResponse);
      return;
    }
    catch (Exception localException)
    {
      paramSapiCallBack.onEvent(-100, null);
    }
  }

  private void handleRegDataCheckCallBack(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    paramSapiCallBack.onEvent(paramInt, paramString);
  }

  private void handleSmsCode(int paramInt, SapiCallBack paramSapiCallBack, String paramString)
  {
    if ((paramInt == 257) || (paramInt == 110031))
      try
      {
        paramSapiCallBack.onEvent(paramInt, new JSONObject(paramString).optString("vcodestr"));
        return;
      }
      catch (Exception localException)
      {
        paramSapiCallBack.onEvent(-100, null);
        return;
      }
    paramSapiCallBack.onEvent(paramInt, paramString);
  }

  private void handleVerifyCodeImgCallBack(int paramInt, SapiCallBack paramSapiCallBack, byte[] paramArrayOfByte)
  {
    if (paramInt == 0)
    {
      if (paramArrayOfByte != null)
      {
        paramSapiCallBack.onEvent(paramInt, paramArrayOfByte);
        return;
      }
      paramSapiCallBack.onEvent(-200, null);
      return;
    }
    paramSapiCallBack.onEvent(paramInt, null);
  }

  private boolean realFillUname(final SapiCallBack paramSapiCallBack, String paramString1, String paramString2, final String paramString3, String paramString4, String paramString5, final EncryptHelper paramEncryptHelper)
    throws JSONException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, CertificateException
  {
    if (mSapiConfig == null)
      return false;
    this.mAsyncHttpClient = new AsyncHttpClient();
    HashMap localHashMap = new HashMap();
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("cert_id", paramString5);
    localHashMap.put("crypttype", mSapiConfig.getCryptType() + "");
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("bduss", paramString1);
    localJSONObject.put("clientid", mSapiConfig.getClientId());
    if (mSapiConfig.isClientIpValid())
      localJSONObject.put("clientip", mSapiConfig.getClientIp());
    localJSONObject.put("ptoken", paramString2);
    localJSONObject.put("username", paramString3);
    localJSONObject.put("key", paramEncryptHelper.getAESKey());
    localHashMap.put("userinfo", paramEncryptHelper.encrypt(paramString4, localJSONObject.toString()));
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getFilluname(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        SapiClient.this.handleFillUname(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString, paramString3, paramEncryptHelper);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        SapiClient.this.handleFillUname(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString, paramString3, paramEncryptHelper);
      }
    });
    return true;
  }

  private boolean realGetSmsCode(final SapiCallBack paramSapiCallBack, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, EncryptHelper paramEncryptHelper)
    throws JSONException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, CertificateException
  {
    this.mAsyncHttpClient = new AsyncHttpClient();
    HashMap localHashMap = new HashMap();
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("crypttype", mSapiConfig.getCryptType() + "");
    localHashMap.put("cert_id", paramString5);
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("phonenum", paramString1);
    localJSONObject.put("clientid", mSapiConfig.getClientId());
    localJSONObject.put("key", paramEncryptHelper.getAESKey());
    if (mSapiConfig.isClientIpValid())
      localJSONObject.put("clientip", mSapiConfig.getClientIp());
    if ((!TextUtils.isEmpty(paramString3)) && (!TextUtils.isEmpty(paramString2)))
    {
      localJSONObject.put("verifycode", paramString3);
      localJSONObject.put("vcodestr", paramString2);
    }
    localHashMap.put("userinfo", paramEncryptHelper.encrypt(paramString4, localJSONObject.toString()));
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getApplyregcode(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        SapiClient.this.handleSmsCode(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        SapiClient.this.handleSmsCode(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
      }
    });
    return true;
  }

  private boolean realLogin(final SapiCallBack paramSapiCallBack, String paramString1, String paramString2, final boolean paramBoolean1, final String paramString3, final String paramString4, final String paramString5, final String paramString6, final boolean paramBoolean2, DisplayAccount paramDisplayAccount, final EncryptHelper paramEncryptHelper)
    throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, CertificateException, JSONException
  {
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    localHashMap.put("crypttype", mSapiConfig.getCryptType() + "");
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("cuid", DeviceId.getDeviceID(this.mContext));
    localHashMap.put("cert_id", paramString2);
    if (paramBoolean2)
      localHashMap.put("isdpass", "1");
    String str;
    if ((paramDisplayAccount == null) || (!paramString4.equals(paramDisplayAccount.getDisplayPassword())) || (!paramString3.equals(paramDisplayAccount.getAccountName())))
    {
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put("username", paramString3);
      if (paramBoolean1)
      {
        str = "1";
        localJSONObject.put("isphone", str);
        localJSONObject.put("password", paramString4);
        localJSONObject.put("login_type", "3");
        localJSONObject.put("key", paramEncryptHelper.getAESKey());
        if ((!TextUtils.isEmpty(paramString6)) && (!TextUtils.isEmpty(paramString5)))
        {
          localJSONObject.put("verifycode", paramString6);
          localJSONObject.put("vcodestr", paramString5);
        }
        this.encryptInfo = paramEncryptHelper.encrypt(paramString1, localJSONObject.toString());
        localHashMap.put("userinfo", this.encryptInfo);
      }
    }
    while (true)
    {
      localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
      RequestParams localRequestParams = new RequestParams(localHashMap);
      this.mAsyncHttpClient.post(mSapiConfig.getLogin(), localRequestParams, new AsyncHttpResponseHandler()
      {
        public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
        {
          super.onFailure(paramAnonymousThrowable, paramAnonymousString);
          if (SapiClient.mSapiConfig.getPassportDomanGetter() != null)
          {
            String str = SapiClient.mSapiConfig.getPassportDomanGetter().getNextDoman();
            Domain localDomain = SapiClient.mSapiConfig.getDomain();
            localDomain.setURL(str);
            SapiClient.mSapiConfig.setDomain(localDomain);
            if ((SapiClient.mSapiConfig.getPassportDomanGetter() != null) && (SapiClient.mSapiConfig.getPassportDomanGetter().isMaxDomanUsed()))
            {
              SapiClient.this.handleLogin(SapiClient.access$200(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString, paramEncryptHelper);
              return;
            }
          }
          SapiClient.this.login(paramSapiCallBack, paramBoolean1, paramString3, paramString4, paramString5, paramString6, paramBoolean2);
        }

        public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
        {
          super.onSuccess(paramAnonymousInt, paramAnonymousString);
          DisplayAccount localDisplayAccount = new DisplayAccount();
          localDisplayAccount.setAccountName(paramString3);
          if (paramBoolean1);
          StringBuffer localStringBuffer;
          for (AccountType localAccountType = AccountType.PHONE; ; localAccountType = AccountType.NORMAL)
          {
            localDisplayAccount.setAccountType(localAccountType);
            localDisplayAccount.setDisplayName(paramString3);
            localStringBuffer = new StringBuffer();
            for (int i = 0; i < paramString4.length(); i++)
              localStringBuffer.append("~");
          }
          localDisplayAccount.setDisplayPassword(localStringBuffer.toString());
          localDisplayAccount.setEncryptPassword(SapiClient.this.encryptInfo);
          localDisplayAccount.setLastLoginTime(System.currentTimeMillis());
          localDisplayAccount.setKeyChain(paramEncryptHelper.getAESKey());
          if (SapiClient.this.getErrorCode(paramAnonymousString) == 4)
          {
            localDisplayAccount.setDisplayPassword("");
            localDisplayAccount.setEncryptPassword("");
            localDisplayAccount.setKeyChain("");
            AccountAPI.getInstance(SapiClient.this.mContext).blockAddAccount(localDisplayAccount);
            AccountAPI.getInstance(SapiClient.this.mContext).blockSaveAccount();
          }
          while (true)
          {
            SapiClient.this.encryptInfo = "";
            SapiClient.this.handleLogin(SapiClient.access$200(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString, paramEncryptHelper);
            return;
            if (SapiClient.this.getErrorCode(paramAnonymousString) == 0)
            {
              AccountAPI.getInstance(SapiClient.this.mContext).blockAddAccount(localDisplayAccount);
              AccountAPI.getInstance(SapiClient.this.mContext).blockSaveAccount();
            }
          }
        }
      });
      return true;
      str = "0";
      break;
      this.encryptInfo = paramDisplayAccount.getEncryptPassword();
      paramEncryptHelper.setAESKey(paramDisplayAccount.getKeyChain());
      localHashMap.put("userinfo", this.encryptInfo);
    }
  }

  private boolean realLogout(String paramString1, String paramString2, String paramString3, EncryptHelper paramEncryptHelper)
    throws JSONException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, CertificateException
  {
    if ((mSapiConfig == null) || (TextUtils.isEmpty(paramString1)))
      return false;
    this.mAsyncHttpClient = new AsyncHttpClient();
    HashMap localHashMap = new HashMap();
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("cert_id", paramString3);
    localHashMap.put("crypttype", mSapiConfig.getCryptType() + "");
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("bduss", paramString1);
    localJSONObject.put("clientid", mSapiConfig.getClientId());
    localJSONObject.put("key", paramEncryptHelper.getAESKey());
    if (mSapiConfig.isClientIpValid())
      localJSONObject.put("clientip", mSapiConfig.getClientIp());
    localJSONObject.put("bdstoken", Md5.md5s(paramString1 + mSapiConfig.getSignkey()));
    localHashMap.put("userinfo", paramEncryptHelper.encrypt(paramString2, localJSONObject.toString()));
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getLogout(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  private boolean realPhoneReg(final SapiCallBack paramSapiCallBack, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, final EncryptHelper paramEncryptHelper)
    throws JSONException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, CertificateException
  {
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("cert_id", paramString6);
    localHashMap.put("crypttype", mSapiConfig.getCryptType() + "");
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("phonenum", paramString1);
    localJSONObject.put("passwd", paramString4);
    localJSONObject.put("smscode", paramString2);
    localJSONObject.put("key", paramEncryptHelper.getAESKey());
    if (!TextUtils.isEmpty(paramString3))
      localJSONObject.put("fields", "{\"username\":\"" + paramString3 + "\"}");
    localJSONObject.put("clientid", mSapiConfig.getClientId());
    if (mSapiConfig.isClientIpValid())
      localJSONObject.put("clientip", mSapiConfig.getClientIp());
    localHashMap.put("userinfo", paramEncryptHelper.encrypt(paramString5, localJSONObject.toString()));
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getPhoneregverify(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        SapiClient.this.handlePhoneReg(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString, paramEncryptHelper);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        SapiClient.this.handlePhoneReg(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString, paramEncryptHelper);
      }
    });
    return true;
  }

  private boolean realRegDataCheck(final SapiCallBack paramSapiCallBack, final String paramString1, final String paramString2, final String paramString3, String paramString4, String paramString5, EncryptHelper paramEncryptHelper)
    throws JSONException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, CertificateException
  {
    this.mAsyncHttpClient = new AsyncHttpClient();
    HashMap localHashMap = new HashMap();
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("crypttype", mSapiConfig.getCryptType() + "");
    localHashMap.put("cert_id", paramString5);
    JSONObject localJSONObject1 = new JSONObject();
    localJSONObject1.put("checkall", "1");
    localJSONObject1.put("clientid", mSapiConfig.getClientId());
    localJSONObject1.put("key", paramEncryptHelper.getAESKey());
    if (mSapiConfig.isClientIpValid())
      localJSONObject1.put("clientip", mSapiConfig.getClientIp());
    JSONObject localJSONObject2 = new JSONObject();
    if (!TextUtils.isEmpty(paramString2))
      localJSONObject2.put("username", paramString2);
    if (!TextUtils.isEmpty(paramString3))
      localJSONObject2.put("password", paramString3);
    if (!TextUtils.isEmpty(paramString1))
      localJSONObject2.put("phonenum", paramString1);
    localJSONObject1.put("fields", localJSONObject2.toString());
    localHashMap.put("userinfo", paramEncryptHelper.encrypt(paramString4, localJSONObject1.toString()));
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getRegdatacheck(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        if (SapiClient.mSapiConfig.getPassportDomanGetter() != null)
        {
          String str = SapiClient.mSapiConfig.getPassportDomanGetter().getNextDoman();
          Domain localDomain = SapiClient.mSapiConfig.getDomain();
          localDomain.setURL(str);
          SapiClient.mSapiConfig.setDomain(localDomain);
          SapiClient.this.regDataCheck(paramSapiCallBack, paramString1, paramString2, paramString3);
          if ((SapiClient.mSapiConfig.getPassportDomanGetter() != null) && (SapiClient.mSapiConfig.getPassportDomanGetter().isMaxDomanUsed()))
            SapiClient.this.handleRegDataCheckCallBack(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        }
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        SapiClient.this.handleRegDataCheckCallBack(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
      }
    });
    return true;
  }

  private void setSapiConfig(SapiConfig paramSapiConfig)
  {
    mSapiConfig = paramSapiConfig;
  }

  public boolean askDynamicPass(final SapiCallBack paramSapiCallBack, String paramString)
  {
    if (this.mContext == null);
    do
    {
      do
      {
        do
        {
          return false;
          if (com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
            break;
        }
        while (paramSapiCallBack == null);
        paramSapiCallBack.onEvent(-200, null);
        return false;
        if (!TextUtils.isEmpty(paramString))
          break;
      }
      while (paramSapiCallBack == null);
      paramSapiCallBack.onEvent(-103, null);
      return false;
    }
    while (mSapiConfig == null);
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    localHashMap.put("username", paramString);
    localHashMap.put("clientid", DeviceId.getDeviceID(this.mContext));
    localHashMap.put("clientip", mSapiConfig.getClientIp());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getAskDynamicPwd(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.this.handleAskDynamicPass(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        SapiClient.this.handleAskDynamicPass(paramAnonymousInt, paramSapiCallBack, paramAnonymousString);
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  public void cancelRequest()
  {
    if (this.mAsyncHttpClient != null)
      this.mAsyncHttpClient.cancelRequests(this.mContext, true);
  }

  public void destory()
  {
  }

  public boolean deviceCheck()
  {
    if ((this.mContext == null) || (SapiHelper.getInstance().isLogin()) || (!com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext)) || (mSapiConfig == null))
      return false;
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    if ((SapiHelper.getInstance().getToken() != null) && (!TextUtils.isEmpty(SapiHelper.getInstance().getUserData("device_token"))))
    {
      localHashMap.put("device_id", Utils.createDeviceID(this.mContext));
      localHashMap.put("device_token", SapiHelper.getInstance().getUserData("device_token"));
    }
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.get(mSapiConfig.getDeviceCheck(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.mSapiConfig.setShowDevice(false);
        SapiHelper.getInstance().setShowDevice(false);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        if (paramAnonymousString != null);
        try
        {
          JSONObject localJSONObject = new JSONObject(paramAnonymousString);
          if ((!localJSONObject.has("error_code")) && (!localJSONObject.has("error_msg")) && (localJSONObject.optInt("fulfilbind") == 0) && ((localJSONObject.optInt("reg") == 1) || (localJSONObject.optInt("login") == 1)))
          {
            SapiClient.mSapiConfig.setShowDevice(true);
            SapiHelper.getInstance().setShowDevice(true);
          }
          super.onSuccess(paramAnonymousInt, paramAnonymousString);
          return;
        }
        catch (JSONException localJSONException)
        {
          while (true)
          {
            SapiClient.mSapiConfig.setShowDevice(false);
            SapiHelper.getInstance().setShowDevice(false);
          }
        }
      }
    });
    return true;
  }

  public boolean deviceForcedRegister(final SapiCallBack paramSapiCallBack, String paramString)
  {
    if ((this.mContext == null) || (SapiHelper.getInstance().isLogin()) || (mSapiConfig == null) || (TextUtils.isEmpty(mSapiConfig.getDevicePackageSign())) || (!mSapiConfig.isShowDevice()));
    do
    {
      return false;
      if (com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
        break;
    }
    while (paramSapiCallBack == null);
    paramSapiCallBack.onEvent(-200, null);
    return false;
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    String str = DeviceCrypto.encryptDeviceId(Utils.createDeviceID(this.mContext));
    localHashMap.put("ptpl", mSapiConfig.getTpl());
    localHashMap.put("device_id", str);
    localHashMap.put("device_info", mSapiConfig.getDeviceInfo());
    localHashMap.put("force_reg_token", paramString);
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getDeviceForceReg(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.mSapiConfig.setShowDevice(false);
        SapiHelper.getInstance().setShowDevice(false);
        SapiClient.this.handleDeviceForcedResult(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        SapiClient.this.handleDeviceForcedResult(paramAnonymousInt, paramSapiCallBack, paramAnonymousString);
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  public boolean deviceLogin(final SapiCallBack paramSapiCallBack, String paramString)
  {
    if ((this.mContext == null) || (SapiHelper.getInstance().isLogin()) || (mSapiConfig == null) || (TextUtils.isEmpty(mSapiConfig.getDevicePackageSign())) || (!mSapiConfig.isShowDevice()));
    do
    {
      return false;
      if (com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
        break;
    }
    while (paramSapiCallBack == null);
    paramSapiCallBack.onEvent(-200, null);
    return false;
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    String str = DeviceCrypto.encryptDeviceId(Utils.createDeviceID(this.mContext));
    localHashMap.put("ptpl", mSapiConfig.getTpl());
    localHashMap.put("device_id", str);
    localHashMap.put("device_token", paramString);
    localHashMap.put("package_sign", mSapiConfig.getDevicePackageSign());
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getDeviceLogin(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.mSapiConfig.setShowDevice(false);
        SapiHelper.getInstance().setShowDevice(false);
        SapiClient.this.handleDeviceResult(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        SapiClient.this.handleDeviceResult(paramAnonymousInt, paramSapiCallBack, paramAnonymousString);
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  public boolean deviceRegister(final SapiCallBack paramSapiCallBack)
  {
    if ((this.mContext == null) || (SapiHelper.getInstance().isLogin()) || (mSapiConfig == null) || (TextUtils.isEmpty(mSapiConfig.getDevicePackageSign())) || (!mSapiConfig.isShowDevice()));
    do
    {
      return false;
      if (com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
        break;
    }
    while (paramSapiCallBack == null);
    paramSapiCallBack.onEvent(-200, null);
    return false;
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    String str = DeviceCrypto.encryptDeviceId(Utils.createDeviceID(this.mContext));
    localHashMap.put("ptpl", mSapiConfig.getTpl());
    localHashMap.put("device_id", str);
    localHashMap.put("device_info", mSapiConfig.getDeviceInfo());
    localHashMap.put("package_sign", mSapiConfig.getDevicePackageSign());
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getDeviceReg(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.mSapiConfig.setShowDevice(false);
        SapiHelper.getInstance().setShowDevice(false);
        SapiClient.this.handleDeviceResult(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        SapiClient.this.handleDeviceResult(paramAnonymousInt, paramSapiCallBack, paramAnonymousString);
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  public boolean downloadLogin(final SapiCallBack paramSapiCallBack, String paramString)
  {
    if (this.mContext == null);
    do
    {
      do
      {
        return false;
        if (com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
          break;
      }
      while (paramSapiCallBack == null);
      paramSapiCallBack.onEvent(-200, null);
      return false;
    }
    while (mSapiConfig == null);
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    localHashMap.put("loginsign", paramString);
    localHashMap.put("clientid", DeviceId.getDeviceID(this.mContext));
    localHashMap.put("clientip", mSapiConfig.getClientIp());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getDownloadLogin(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.this.handleDownloadLogin(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        SapiClient.this.handleDownloadLogin(paramAnonymousInt, paramSapiCallBack, paramAnonymousString);
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  public boolean fastReg(final SapiCallBack paramSapiCallBack, String paramString)
  {
    if (this.mContext == null);
    do
    {
      do
      {
        do
        {
          return false;
          if (com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
            break;
        }
        while (paramSapiCallBack == null);
        paramSapiCallBack.onEvent(-200, null);
        return false;
        if (!TextUtils.isEmpty(paramString))
          break;
      }
      while (paramSapiCallBack == null);
      paramSapiCallBack.onEvent(-103, null);
      return false;
    }
    while (mSapiConfig == null);
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    localHashMap.put("sms", paramString);
    localHashMap.put("clientid", DeviceId.getDeviceID(this.mContext));
    localHashMap.put("clientip", mSapiConfig.getClientIp());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getFastReg(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.this.handleFastReg(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        SapiClient.this.handleFastReg(paramAnonymousInt, paramSapiCallBack, paramAnonymousString);
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  public boolean fillUname(final SapiCallBack paramSapiCallBack, final String paramString1, final String paramString2, final String paramString3)
  {
    if (this.mContext == null);
    while (mSapiConfig == null)
      return false;
    if (!com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
    {
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(-200, null);
      return true;
    }
    final EncryptHelper localEncryptHelper = new EncryptHelper();
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.get(mSapiConfig.getLastCert(), new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        JSONObject localJSONObject = new JSONObject();
        Object localObject = "";
        try
        {
          localJSONObject.put("failure_info", paramAnonymousString);
          String str = localJSONObject.toString();
          localObject = str;
          SapiClient.this.handleFillUname(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, (String)localObject, paramString3, localEncryptHelper);
          return;
        }
        catch (JSONException localJSONException)
        {
          while (true)
          {
            SapiClient.this.handleLogin(-100, paramSapiCallBack, (String)localObject, localEncryptHelper);
            Logger.w(localJSONException);
          }
        }
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        try
        {
          JSONObject localJSONObject = new JSONObject(paramAnonymousString);
          String str1 = localJSONObject.optString("cert");
          String str2 = localJSONObject.optString("cert_id");
          SapiClient.this.realFillUname(paramSapiCallBack, paramString1, paramString2, paramString3, str1, str2, localEncryptHelper);
          return;
        }
        catch (Exception localException)
        {
          SapiClient.this.handleFillUname(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString, paramString3, localEncryptHelper);
          localException.printStackTrace();
        }
      }
    });
    return true;
  }

  public boolean getSmsCode(final SapiCallBack paramSapiCallBack, final String paramString1, final String paramString2, final String paramString3)
  {
    if (this.mContext == null);
    do
    {
      return false;
      if (!com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
      {
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(-200, null);
        return true;
      }
    }
    while (mSapiConfig == null);
    final EncryptHelper localEncryptHelper = new EncryptHelper();
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.get(mSapiConfig.getLastCert(), new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        JSONObject localJSONObject = new JSONObject();
        Object localObject = "";
        try
        {
          localJSONObject.put("failure_info", paramAnonymousString);
          String str = localJSONObject.toString();
          localObject = str;
          SapiClient.this.handleSmsCode(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, (String)localObject);
          return;
        }
        catch (JSONException localJSONException)
        {
          while (true)
          {
            SapiClient.this.handleSmsCode(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, (String)localObject);
            Logger.w(localJSONException);
          }
        }
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        try
        {
          JSONObject localJSONObject = new JSONObject(paramAnonymousString);
          String str1 = localJSONObject.optString("cert");
          String str2 = localJSONObject.optString("cert_id");
          SapiClient.this.realGetSmsCode(paramSapiCallBack, paramString1, paramString2, paramString3, str1, str2, localEncryptHelper);
          return;
        }
        catch (Exception localException)
        {
          SapiClient.this.handleSmsCode(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
          localException.printStackTrace();
        }
      }
    });
    return true;
  }

  public boolean getVerifyImg(final SapiCallBack paramSapiCallBack, String paramString)
  {
    if (this.mContext == null);
    do
    {
      return false;
      if (!com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
      {
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(-200, null);
        return true;
      }
    }
    while (mSapiConfig == null);
    this.mAsyncHttpClient = new AsyncHttpClient();
    String[] arrayOfString = { "image/png", "image/jpeg", "image/jpg", "image/gif" };
    this.mAsyncHttpClient.get(mSapiConfig.getGenimage() + paramString, new BinaryHttpResponseHandler(arrayOfString)
    {
      public void onFailure(Throwable paramAnonymousThrowable)
      {
        SapiClient.this.handleVerifyCodeImgCallBack(-100, paramSapiCallBack, null);
      }

      public void onSuccess(byte[] paramAnonymousArrayOfByte)
      {
        SapiClient.this.handleVerifyCodeImgCallBack(0, paramSapiCallBack, paramAnonymousArrayOfByte);
      }
    });
    return true;
  }

  public boolean initial(Context paramContext, SapiConfig paramSapiConfig)
  {
    this.mContext = paramContext;
    setSapiConfig(paramSapiConfig);
    return true;
  }

  public boolean login(SapiCallBack paramSapiCallBack, boolean paramBoolean1, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean2)
  {
    return login(paramSapiCallBack, paramBoolean1, paramString1, paramString2, paramString3, paramString4, paramBoolean2, null);
  }

  public boolean login(final SapiCallBack paramSapiCallBack, final boolean paramBoolean1, final String paramString1, final String paramString2, final String paramString3, final String paramString4, final boolean paramBoolean2, final DisplayAccount paramDisplayAccount)
  {
    if (this.mContext == null)
      return false;
    if (!com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
    {
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(-200, null);
      return true;
    }
    if (mSapiConfig == null)
      return false;
    final EncryptHelper localEncryptHelper = new EncryptHelper();
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.get(mSapiConfig.getLastCert(), new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        JSONObject localJSONObject = new JSONObject();
        Object localObject = "";
        try
        {
          localJSONObject.put("failure_info", paramAnonymousString);
          String str = localJSONObject.toString();
          localObject = str;
          SapiClient.this.handleLogin(-100, paramSapiCallBack, (String)localObject, localEncryptHelper);
          return;
        }
        catch (JSONException localJSONException)
        {
          while (true)
          {
            SapiClient.this.handleLogin(-100, paramSapiCallBack, (String)localObject, localEncryptHelper);
            Logger.w(localJSONException);
          }
        }
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        try
        {
          JSONObject localJSONObject = new JSONObject(paramAnonymousString);
          String str1 = localJSONObject.optString("cert");
          String str2 = localJSONObject.optString("cert_id");
          SapiClient.this.realLogin(paramSapiCallBack, str1, str2, paramBoolean1, paramString1, paramString2, paramString3, paramString4, paramBoolean2, paramDisplayAccount, localEncryptHelper);
          return;
        }
        catch (Exception localException)
        {
          SapiClient.this.handleLogin(-100, paramSapiCallBack, paramAnonymousString, localEncryptHelper);
          localException.printStackTrace();
        }
      }
    });
    return true;
  }

  public boolean logout(final String paramString)
  {
    if ((mSapiConfig == null) || (TextUtils.isEmpty(paramString)))
      return false;
    this.mAsyncHttpClient = new AsyncHttpClient();
    final EncryptHelper localEncryptHelper = new EncryptHelper();
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.get(mSapiConfig.getLastCert(), new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        try
        {
          JSONObject localJSONObject = new JSONObject(paramAnonymousString);
          String str1 = localJSONObject.optString("cert");
          String str2 = localJSONObject.optString("cert_id");
          SapiClient.this.realLogout(paramString, str1, str2, localEncryptHelper);
          return;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    });
    return true;
  }

  public boolean phoneReg(final SapiCallBack paramSapiCallBack, final String paramString1, final String paramString2, final String paramString3, final String paramString4)
  {
    if (this.mContext == null)
      return false;
    if (!com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
    {
      if (paramSapiCallBack != null)
        paramSapiCallBack.onEvent(-200, null);
      return true;
    }
    if (mSapiConfig == null)
      return false;
    final EncryptHelper localEncryptHelper = new EncryptHelper();
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.get(mSapiConfig.getLastCert(), new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        JSONObject localJSONObject = new JSONObject();
        Object localObject = "";
        try
        {
          localJSONObject.put("failure_info", paramAnonymousString);
          String str = localJSONObject.toString();
          localObject = str;
          SapiClient.this.handlePhoneReg(-100, paramSapiCallBack, (String)localObject, localEncryptHelper);
          return;
        }
        catch (JSONException localJSONException)
        {
          while (true)
          {
            SapiClient.this.handlePhoneReg(-100, paramSapiCallBack, (String)localObject, localEncryptHelper);
            Logger.w(localJSONException);
          }
        }
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        try
        {
          JSONObject localJSONObject = new JSONObject(paramAnonymousString);
          String str1 = localJSONObject.optString("cert");
          String str2 = localJSONObject.optString("cert_id");
          SapiClient.this.realPhoneReg(paramSapiCallBack, paramString1, paramString2, paramString3, paramString4, str1, str2, localEncryptHelper);
          return;
        }
        catch (Exception localException)
        {
          SapiClient.this.handlePhoneReg(-100, paramSapiCallBack, paramAnonymousString, localEncryptHelper);
          localException.printStackTrace();
        }
      }
    });
    return true;
  }

  public boolean qrAppLogin(final SapiCallBack paramSapiCallBack, String paramString1, String paramString2)
  {
    if (this.mContext == null);
    do
    {
      do
      {
        do
        {
          return false;
          if (com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
            break;
        }
        while (paramSapiCallBack == null);
        paramSapiCallBack.onEvent(-200, null);
        return false;
        if ((!TextUtils.isEmpty(paramString1)) && (!TextUtils.isEmpty(paramString2)))
          break;
      }
      while (paramSapiCallBack == null);
      paramSapiCallBack.onEvent(-103, null);
      return false;
    }
    while (mSapiConfig == null);
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    localHashMap.put("sign", paramString1);
    localHashMap.put("cmd", paramString2);
    localHashMap.put("clientid", DeviceId.getDeviceID(this.mContext));
    localHashMap.put("clientip", mSapiConfig.getClientIp());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getQRAppLogin(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.this.handleQrAppLogin(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        SapiClient.this.handleQrAppLogin(paramAnonymousInt, paramSapiCallBack, paramAnonymousString);
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  public boolean qrPCLogin(final SapiCallBack paramSapiCallBack, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    if (this.mContext == null);
    do
    {
      do
      {
        do
        {
          do
          {
            return false;
            if (com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
              break;
          }
          while (paramSapiCallBack == null);
          paramSapiCallBack.onEvent(-200, null);
          return false;
          if ((!TextUtils.isEmpty(paramString1)) && (!TextUtils.isEmpty(paramString2)))
            break;
        }
        while (paramSapiCallBack == null);
        paramSapiCallBack.onEvent(-103, null);
        return false;
        if (!TextUtils.isEmpty(paramString3))
          break;
      }
      while (paramSapiCallBack == null);
      paramSapiCallBack.onEvent(160102, null);
      return false;
    }
    while (mSapiConfig == null);
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.setUserAgent(getUaInfo());
    HashMap localHashMap = new HashMap();
    localHashMap.put("sign", paramString1);
    localHashMap.put("cmd", paramString2);
    localHashMap.put("bduss", paramString3);
    localHashMap.put("stoken", paramString4);
    localHashMap.put("ptoken", paramString5);
    localHashMap.put("clientid", DeviceId.getDeviceID(this.mContext));
    localHashMap.put("clientip", mSapiConfig.getClientIp());
    localHashMap.put("tpl", mSapiConfig.getTpl());
    localHashMap.put("appid", mSapiConfig.getAppId());
    localHashMap.put("sig", getPassportSig(localHashMap, mSapiConfig.getSignkey()));
    RequestParams localRequestParams = new RequestParams(localHashMap);
    this.mAsyncHttpClient.post(mSapiConfig.getQrPCLogin(), localRequestParams, new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        SapiClient.this.handleQrPCLogin(SapiClient.access$700(SapiClient.this, paramAnonymousString), paramSapiCallBack, paramAnonymousString);
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        SapiClient.this.handleQrPCLogin(paramAnonymousInt, paramSapiCallBack, paramAnonymousString);
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
      }
    });
    return true;
  }

  public boolean regDataCheck(final SapiCallBack paramSapiCallBack, final String paramString1, final String paramString2, final String paramString3)
  {
    if (this.mContext == null);
    do
    {
      return false;
      if (!com.baidu.sapi2.loginshare.Utils.hasActiveNetwork(this.mContext))
      {
        if (paramSapiCallBack != null)
          paramSapiCallBack.onEvent(-200, null);
        return true;
      }
    }
    while (mSapiConfig == null);
    final EncryptHelper localEncryptHelper = new EncryptHelper();
    this.mAsyncHttpClient = new AsyncHttpClient();
    this.mAsyncHttpClient.get(mSapiConfig.getLastCert(), new AsyncHttpResponseHandler()
    {
      public void onFailure(Throwable paramAnonymousThrowable, String paramAnonymousString)
      {
        super.onFailure(paramAnonymousThrowable, paramAnonymousString);
        JSONObject localJSONObject = new JSONObject();
        try
        {
          localJSONObject.put("failure_info", paramAnonymousString);
          localJSONObject.toString();
          return;
        }
        catch (JSONException localJSONException)
        {
          Logger.w(localJSONException);
          SapiClient.this.handleRegDataCheckCallBack(-100, paramSapiCallBack, "");
        }
      }

      public void onSuccess(int paramAnonymousInt, String paramAnonymousString)
      {
        super.onSuccess(paramAnonymousInt, paramAnonymousString);
        try
        {
          JSONObject localJSONObject = new JSONObject(paramAnonymousString);
          String str1 = localJSONObject.optString("cert");
          String str2 = localJSONObject.optString("cert_id");
          SapiClient.this.realRegDataCheck(paramSapiCallBack, paramString1, paramString2, paramString3, str1, str2, localEncryptHelper);
          return;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
          SapiClient.this.handleRegDataCheckCallBack(-100, paramSapiCallBack, null);
        }
      }
    });
    return true;
  }

  void setTokenCallBack(ITokenCallback paramITokenCallback)
  {
    this.mTokenCallback = paramITokenCallback;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.SapiClient
 * JD-Core Version:    0.6.2
 */