package com.baidu.sapi2;

public class ErrorCode
{
  public static final int AdminDBCommunicateError = 100003;
  public static final int AntiCheatCommunicateError = 100008;
  public static final int AntiifCommunicateError = 100002;
  public static final int BdussIsEmpty = 160102;
  public static final int BugetBreak = 130016;
  public static final int CannotLogin = 16;
  public static final int Cer_idNotExist = -6;
  public static final int CertOverTime = -5;
  public static final int Cheat = 130001;
  public static final int DBGateCommunicationError = 100001;
  public static final int ErrorUnknown = -100;
  public static final int FillUnameCannotBeUse = 160105;
  public static final int FillUnameFormatError = 160110;
  public static final int FillUnameIsEmpty = 160100;
  public static final int FillUnameIsExist = 160111;
  public static final int ForceOfflineFailed = 160106;
  public static final int GetCertFail = -105;
  public static final int GettingCert = -104;
  public static final int InterfaceTooOld = 140008;
  public static final int InvalidArg = -103;
  public static final int IpAuthorityError = 140005;
  public static final int IpHasNoAuthority = -4;
  public static final int LogaSucceed = 110000;
  public static final int LoginFailOverLimit = 210001;
  public static final int LoginInterfaceParamError = -1;
  public static final int LoginSignatureError = -2;
  public static final int LoginTooMuch = 5;
  public static final int MultiLoginOverLimit = 20;
  public static final int NeedActivateEmail = 110024;
  public static final int NeedRequiredItems = 130025;
  public static final int Network_Failed = -200;
  public static final int NotInit = -102;
  public static final int OtherParamError = 210003;
  public static final int PasswordExpired = 3;
  public static final int PasswordFormatError = 120013;
  public static final int PasswordNull = 9;
  public static final int PasswordWrong = 4;
  public static final int PhoneFormatErr = 130019;
  public static final int PhoneNumBinded = 130020;
  public static final int PhoneNumNull = 130018;
  public static final int PlsGetSmsVerifyCode = 130022;
  public static final int PlsInputVerifyCode = 257;
  public static final int PwdEmpty = 130010;
  public static final int PwdFormatError = 110013;
  public static final int QRCodeBdussInvalid = 2;
  public static final int QRCodeInvalid = 1;
  public static final int QRCodeNormalizeInvalid = 3;
  public static final int ReLoginFailed = 160107;
  public static final int SMSFormatError = 1;
  public static final int SMSLoginTooMuch = 190016;
  public static final int SMSNotExisted = 2;
  public static final int SaveCertFail = -106;
  public static final int SentSucceed = -101;
  public static final int SessionCommunicateError = 100005;
  public static final int SignatureError = 140003;
  public static final int SmsCheat = 130017;
  public static final int SmsCommunicateError = 100014;
  public static final int SmsVerifyCodeExpired = 130004;
  public static final int SmsVerifyCodeNull = 130021;
  public static final int SmsVerifyCodeWrong = 130003;
  public static final int Succeed = 0;
  public static final int TokenCheckFail = 210002;
  public static final int TplAppidGroupNotFound = -3;
  public static final int TplNotPermit = 210000;
  public static final int TplOrAppidError = 140004;
  public static final int UserDoHaveName = 160104;
  public static final int UserIsNotOnline = 160103;
  public static final int UsernameCannotUse = 130007;
  public static final int UsernameEmpty = 130005;
  public static final int UsernameExist = 110003;
  public static final int UsernameFormatErrorLogin = 1;
  public static final int UsernameFormatErrorRegist = 110002;
  public static final int UsernameNotExist = 2;
  public static final int VerifyCodeInputErr = 110031;
  public static final int VerifyCodeNotMatch = 6;
  public static final int VersionTooOld = 140008;
  public static final int WeakPwd = 110012;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.ErrorCode
 * JD-Core Version:    0.6.2
 */