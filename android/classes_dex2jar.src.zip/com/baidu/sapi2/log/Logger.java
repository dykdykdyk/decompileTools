package com.baidu.sapi2.log;

import android.util.Log;
import com.baidu.sapi2.SapiHelper;

public class Logger
{
  protected static final String TAG = "Sapi";

  protected static String buildMessage(String paramString)
  {
    StackTraceElement localStackTraceElement = new Throwable().fillInStackTrace().getStackTrace()[2];
    return localStackTraceElement.getClassName() + "." + localStackTraceElement.getMethodName() + "(): " + paramString;
  }

  public static void d(String paramString)
  {
    if (getDebuggable())
      Log.d("Sapi", buildMessage(paramString));
  }

  public static void d(String paramString, Throwable paramThrowable)
  {
    if (getDebuggable())
      Log.d("Sapi", buildMessage(paramString), paramThrowable);
  }

  public static void e(String paramString)
  {
    if (getDebuggable())
      Log.e("Sapi", buildMessage(paramString));
  }

  public static void e(String paramString, Throwable paramThrowable)
  {
    if (getDebuggable())
      Log.e("Sapi", buildMessage(paramString), paramThrowable);
  }

  private static boolean getDebuggable()
  {
    return SapiHelper.getInstance().isDebuggable();
  }

  public static void i(String paramString)
  {
    if (getDebuggable())
      Log.i("Sapi", buildMessage(paramString));
  }

  public static void i(String paramString, Throwable paramThrowable)
  {
    if (getDebuggable())
      Log.i("Sapi", buildMessage(paramString), paramThrowable);
  }

  public static void v(String paramString)
  {
    if (getDebuggable())
      Log.v("Sapi", buildMessage(paramString));
  }

  public static void v(String paramString, Throwable paramThrowable)
  {
    if (getDebuggable())
      Log.v("Sapi", buildMessage(paramString), paramThrowable);
  }

  public static void w(String paramString)
  {
    if (getDebuggable())
      Log.w("Sapi", buildMessage(paramString));
  }

  public static void w(String paramString, Throwable paramThrowable)
  {
    if (getDebuggable())
      Log.w("Sapi", buildMessage(paramString), paramThrowable);
  }

  public static void w(Throwable paramThrowable)
  {
    if (getDebuggable())
      Log.w("Sapi", buildMessage(""), paramThrowable);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.log.Logger
 * JD-Core Version:    0.6.2
 */