package com.baidu.sapi2.common;

import android.os.Build.VERSION;
import com.baidu.wearable.ble.util.LogUtil;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

public abstract class PlatformSupportManager<T>
{
  private static final String TAG = PlatformSupportManager.class.getSimpleName();
  private final T defaultImplementation;
  private final SortedMap<Integer, String> implementations;
  private final Class<T> managedInterface;

  protected PlatformSupportManager(Class<T> paramClass, T paramT)
  {
    if (!paramClass.isInterface())
      throw new IllegalArgumentException();
    if (!paramClass.isInstance(paramT))
      throw new IllegalArgumentException();
    this.managedInterface = paramClass;
    this.defaultImplementation = paramT;
    this.implementations = new TreeMap(Collections.reverseOrder());
  }

  protected final void addImplementationClass(int paramInt, String paramString)
  {
    this.implementations.put(Integer.valueOf(paramInt), paramString);
  }

  public final T build()
  {
    Iterator localIterator = this.implementations.keySet().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        LogUtil.i(TAG, "Using default implementation " + this.defaultImplementation.getClass() + " of " + this.managedInterface);
        return this.defaultImplementation;
      }
      Integer localInteger = (Integer)localIterator.next();
      if (Build.VERSION.SDK_INT >= localInteger.intValue())
      {
        String str = (String)this.implementations.get(localInteger);
        try
        {
          Class localClass = Class.forName(str).asSubclass(this.managedInterface);
          LogUtil.i(TAG, "Using implementation " + localClass + " of " + this.managedInterface + " for SDK " + localInteger);
          Object localObject = localClass.getConstructor(new Class[0]).newInstance(new Object[0]);
          return localObject;
        }
        catch (ClassNotFoundException localClassNotFoundException)
        {
          LogUtil.w(TAG, "ClassNotFoundException", localClassNotFoundException);
        }
        catch (IllegalAccessException localIllegalAccessException)
        {
          LogUtil.w(TAG, "IllegalAccessException", localIllegalAccessException);
        }
        catch (InstantiationException localInstantiationException)
        {
          LogUtil.w(TAG, "InstantiationException", localInstantiationException);
        }
        catch (NoSuchMethodException localNoSuchMethodException)
        {
          LogUtil.w(TAG, "NoSuchMethodException", localNoSuchMethodException);
        }
        catch (InvocationTargetException localInvocationTargetException)
        {
          LogUtil.w(TAG, "InvocationTargetException", localInvocationTargetException);
        }
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.common.PlatformSupportManager
 * JD-Core Version:    0.6.2
 */