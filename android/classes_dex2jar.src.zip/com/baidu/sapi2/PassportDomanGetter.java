package com.baidu.sapi2;

import java.util.ArrayList;
import java.util.Random;

public class PassportDomanGetter
{
  private int mMaxDoman = 3;
  private ArrayList<String> mPassportDomans = new ArrayList();
  private ArrayList<String> mPassportIps = new ArrayList();
  private Random mRandom = new Random();
  private int usedDomans = 0;

  PassportDomanGetter(ArrayList<String> paramArrayList, int paramInt)
  {
    this.mPassportDomans = paramArrayList;
    fillDomans();
  }

  public void fillDomans()
  {
    this.usedDomans = 0;
    this.mPassportIps.clear();
    this.mPassportIps.addAll(this.mPassportDomans);
  }

  String getNextDoman()
  {
    if (this.mPassportIps.isEmpty())
      return null;
    int i = this.mPassportIps.size();
    int j = this.mRandom.nextInt(i);
    String str = (String)this.mPassportIps.remove(j);
    this.usedDomans = (1 + this.usedDomans);
    return str;
  }

  boolean isMaxDomanUsed()
  {
    return this.usedDomans >= this.mMaxDoman;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.PassportDomanGetter
 * JD-Core Version:    0.6.2
 */