package com.baidu.sapi2.http;

import com.baidu.sapi2.log.Logger;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Random;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.message.BasicHeader;

class SimpleMultipartEntity
  implements HttpEntity
{
  private static final char[] MULTIPART_CHARS = "-_1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
  private String boundary = null;
  boolean isSetFirst = false;
  boolean isSetLast = false;
  ByteArrayOutputStream out = new ByteArrayOutputStream();

  public SimpleMultipartEntity()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Random localRandom = new Random();
    for (int i = 0; i < 30; i++)
      localStringBuffer.append(MULTIPART_CHARS[localRandom.nextInt(MULTIPART_CHARS.length)]);
    this.boundary = localStringBuffer.toString();
  }

  public void addPart(String paramString, File paramFile, boolean paramBoolean)
  {
    try
    {
      addPart(paramString, paramFile.getName(), new FileInputStream(paramFile), paramBoolean);
      return;
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      Logger.w(localFileNotFoundException);
    }
  }

  public void addPart(String paramString1, String paramString2)
  {
    writeFirstBoundaryIfNeeds();
    try
    {
      this.out.write(("Content-Disposition: form-data; name=\"" + paramString1 + "\"\r\n\r\n").getBytes());
      this.out.write(paramString2.getBytes());
      this.out.write(("\r\n--" + this.boundary + "\r\n").getBytes());
      return;
    }
    catch (IOException localIOException)
    {
      Logger.w(localIOException);
    }
  }

  public void addPart(String paramString1, String paramString2, InputStream paramInputStream, String paramString3, boolean paramBoolean)
  {
    writeFirstBoundaryIfNeeds();
    try
    {
      String str = "Content-Type: " + paramString3 + "\r\n";
      this.out.write(("Content-Disposition: form-data; name=\"" + paramString1 + "\"; filename=\"" + paramString2 + "\"\r\n").getBytes());
      this.out.write(str.getBytes());
      this.out.write("Content-Transfer-Encoding: binary\r\n\r\n".getBytes());
      byte[] arrayOfByte = new byte[4096];
      while (true)
      {
        int i = paramInputStream.read(arrayOfByte);
        if (i == -1)
          break;
        this.out.write(arrayOfByte, 0, i);
      }
    }
    catch (IOException localIOException2)
    {
      localIOException2 = localIOException2;
      Logger.w(localIOException2);
      try
      {
        paramInputStream.close();
        return;
        if (!paramBoolean)
          this.out.write(("\r\n--" + this.boundary + "\r\n").getBytes());
        this.out.flush();
        try
        {
          paramInputStream.close();
          return;
        }
        catch (IOException localIOException4)
        {
          Logger.w(localIOException4);
          return;
        }
      }
      catch (IOException localIOException3)
      {
        Logger.w(localIOException3);
        return;
      }
    }
    finally
    {
    }
    try
    {
      paramInputStream.close();
      throw localObject;
    }
    catch (IOException localIOException1)
    {
      while (true)
        Logger.w(localIOException1);
    }
  }

  public void addPart(String paramString1, String paramString2, InputStream paramInputStream, boolean paramBoolean)
  {
    addPart(paramString1, paramString2, paramInputStream, "application/octet-stream", paramBoolean);
  }

  public void consumeContent()
    throws IOException, UnsupportedOperationException
  {
    if (isStreaming())
      throw new UnsupportedOperationException("Streaming entity does not implement #consumeContent()");
  }

  public InputStream getContent()
    throws IOException, UnsupportedOperationException
  {
    return new ByteArrayInputStream(this.out.toByteArray());
  }

  public Header getContentEncoding()
  {
    return null;
  }

  public long getContentLength()
  {
    writeLastBoundaryIfNeeds();
    return this.out.toByteArray().length;
  }

  public Header getContentType()
  {
    return new BasicHeader("Content-Type", "multipart/form-data; boundary=" + this.boundary);
  }

  public boolean isChunked()
  {
    return false;
  }

  public boolean isRepeatable()
  {
    return false;
  }

  public boolean isStreaming()
  {
    return false;
  }

  public void writeFirstBoundaryIfNeeds()
  {
    if (!this.isSetFirst);
    try
    {
      this.out.write(("--" + this.boundary + "\r\n").getBytes());
      this.isSetFirst = true;
      return;
    }
    catch (IOException localIOException)
    {
      while (true)
        Logger.w(localIOException);
    }
  }

  public void writeLastBoundaryIfNeeds()
  {
    if (this.isSetLast)
      return;
    try
    {
      this.out.write(("\r\n--" + this.boundary + "--\r\n").getBytes());
      this.isSetLast = true;
      return;
    }
    catch (IOException localIOException)
    {
      while (true)
        Logger.w(localIOException);
    }
  }

  public void writeTo(OutputStream paramOutputStream)
    throws IOException
  {
    paramOutputStream.write(this.out.toByteArray());
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.http.SimpleMultipartEntity
 * JD-Core Version:    0.6.2
 */