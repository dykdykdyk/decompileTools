package com.baidu.sapi2.http;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

public class AsyncHttpResponseHandler
{
  protected static final int FAILURE_MESSAGE = 1;
  protected static final int FINISH_MESSAGE = 3;
  protected static final int START_MESSAGE = 2;
  protected static final int SUCCESS_MESSAGE;
  private Handler handler;

  public AsyncHttpResponseHandler()
  {
    if (Looper.myLooper() != null)
      this.handler = new Handler()
      {
        public void handleMessage(Message paramAnonymousMessage)
        {
          AsyncHttpResponseHandler.this.handleMessage(paramAnonymousMessage);
        }
      };
  }

  protected void handleFailureMessage(Throwable paramThrowable, String paramString)
  {
    onFailure(paramThrowable, paramString);
  }

  protected void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      return;
    case 0:
      Object[] arrayOfObject2 = (Object[])paramMessage.obj;
      handleSuccessMessage(((Integer)arrayOfObject2[0]).intValue(), (String)arrayOfObject2[1]);
      return;
    case 1:
      Object[] arrayOfObject1 = (Object[])paramMessage.obj;
      handleFailureMessage((Throwable)arrayOfObject1[0], (String)arrayOfObject1[1]);
      return;
    case 2:
      onStart();
      return;
    case 3:
    }
    onFinish();
  }

  protected void handleSuccessMessage(int paramInt, String paramString)
  {
    if ((paramString != null) && (paramString.startsWith("﻿")))
      paramString = paramString.substring(1);
    onSuccess(paramInt, paramString);
  }

  protected Message obtainMessage(int paramInt, Object paramObject)
  {
    if (this.handler != null)
      return this.handler.obtainMessage(paramInt, paramObject);
    Message localMessage = Message.obtain();
    localMessage.what = paramInt;
    localMessage.obj = paramObject;
    return localMessage;
  }

  public void onFailure(Throwable paramThrowable)
  {
  }

  public void onFailure(Throwable paramThrowable, String paramString)
  {
    onFailure(paramThrowable);
  }

  public void onFinish()
  {
  }

  public void onStart()
  {
  }

  public void onSuccess(int paramInt, String paramString)
  {
    onSuccess(paramString);
  }

  public void onSuccess(String paramString)
  {
  }

  protected void sendFailureMessage(Throwable paramThrowable, String paramString)
  {
    sendMessage(obtainMessage(1, new Object[] { paramThrowable, paramString }));
  }

  protected void sendFailureMessage(Throwable paramThrowable, byte[] paramArrayOfByte)
  {
    sendMessage(obtainMessage(1, new Object[] { paramThrowable, paramArrayOfByte }));
  }

  protected void sendFinishMessage()
  {
    sendMessage(obtainMessage(3, null));
  }

  protected void sendMessage(Message paramMessage)
  {
    if (this.handler != null)
    {
      this.handler.sendMessage(paramMessage);
      return;
    }
    handleMessage(paramMessage);
  }

  // ERROR //
  void sendResponseMessage(org.apache.http.HttpResponse paramHttpResponse)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokeinterface 122 1 0
    //   6: astore_2
    //   7: aload_1
    //   8: invokeinterface 126 1 0
    //   13: astore 5
    //   15: aconst_null
    //   16: astore 4
    //   18: aload 5
    //   20: ifnull +27 -> 47
    //   23: new 128	org/apache/http/entity/BufferedHttpEntity
    //   26: dup
    //   27: aload 5
    //   29: invokespecial 131	org/apache/http/entity/BufferedHttpEntity:<init>	(Lorg/apache/http/HttpEntity;)V
    //   32: astore 6
    //   34: aload 6
    //   36: ldc 133
    //   38: invokestatic 139	org/apache/http/util/EntityUtils:toString	(Lorg/apache/http/HttpEntity;Ljava/lang/String;)Ljava/lang/String;
    //   41: astore 7
    //   43: aload 7
    //   45: astore 4
    //   47: aload_2
    //   48: invokeinterface 144 1 0
    //   53: sipush 300
    //   56: if_icmplt +45 -> 101
    //   59: aload_0
    //   60: new 146	org/apache/http/client/HttpResponseException
    //   63: dup
    //   64: aload_2
    //   65: invokeinterface 144 1 0
    //   70: aload_2
    //   71: invokeinterface 150 1 0
    //   76: invokespecial 152	org/apache/http/client/HttpResponseException:<init>	(ILjava/lang/String;)V
    //   79: aload 4
    //   81: invokevirtual 154	com/baidu/sapi2/http/AsyncHttpResponseHandler:sendFailureMessage	(Ljava/lang/Throwable;Ljava/lang/String;)V
    //   84: return
    //   85: astore_3
    //   86: aload_0
    //   87: aload_3
    //   88: aconst_null
    //   89: checkcast 57	java/lang/String
    //   92: invokevirtual 154	com/baidu/sapi2/http/AsyncHttpResponseHandler:sendFailureMessage	(Ljava/lang/Throwable;Ljava/lang/String;)V
    //   95: aconst_null
    //   96: astore 4
    //   98: goto -51 -> 47
    //   101: aload_0
    //   102: aload_2
    //   103: invokeinterface 144 1 0
    //   108: aload 4
    //   110: invokevirtual 157	com/baidu/sapi2/http/AsyncHttpResponseHandler:sendSuccessMessage	(ILjava/lang/String;)V
    //   113: return
    //   114: astore_3
    //   115: goto -29 -> 86
    //
    // Exception table:
    //   from	to	target	type
    //   7	15	85	java/io/IOException
    //   23	34	85	java/io/IOException
    //   34	43	114	java/io/IOException
  }

  protected void sendStartMessage()
  {
    sendMessage(obtainMessage(2, null));
  }

  protected void sendSuccessMessage(int paramInt, String paramString)
  {
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = Integer.valueOf(paramInt);
    arrayOfObject[1] = paramString;
    sendMessage(obtainMessage(0, arrayOfObject));
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.http.AsyncHttpResponseHandler
 * JD-Core Version:    0.6.2
 */