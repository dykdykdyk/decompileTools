package com.baidu.sapi2.http;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.protocol.HttpContext;

class AsyncHttpRequest
  implements Runnable
{
  private final AbstractHttpClient client;
  private final HttpContext context;
  private int executionCount;
  private boolean isBinaryRequest;
  private final HttpUriRequest request;
  private final AsyncHttpResponseHandler responseHandler;

  public AsyncHttpRequest(AbstractHttpClient paramAbstractHttpClient, HttpContext paramHttpContext, HttpUriRequest paramHttpUriRequest, AsyncHttpResponseHandler paramAsyncHttpResponseHandler)
  {
    this.client = paramAbstractHttpClient;
    this.context = paramHttpContext;
    this.request = paramHttpUriRequest;
    this.responseHandler = paramAsyncHttpResponseHandler;
    if ((paramAsyncHttpResponseHandler instanceof BinaryHttpResponseHandler))
      this.isBinaryRequest = true;
  }

  private void makeRequest()
    throws IOException
  {
    if (!Thread.currentThread().isInterrupted())
    {
      HttpResponse localHttpResponse = this.client.execute(this.request, this.context);
      if ((!Thread.currentThread().isInterrupted()) && (this.responseHandler != null))
        this.responseHandler.sendResponseMessage(localHttpResponse);
    }
  }

  private void makeRequestWithRetries()
    throws ConnectException
  {
    boolean bool = true;
    Object localObject = null;
    HttpRequestRetryHandler localHttpRequestRetryHandler = this.client.getHttpRequestRetryHandler();
    while (bool)
      try
      {
        makeRequest();
        return;
      }
      catch (UnknownHostException localUnknownHostException)
      {
        while (this.responseHandler == null);
        this.responseHandler.sendFailureMessage(localUnknownHostException, "can't resolve host");
        return;
      }
      catch (SocketException localSocketException)
      {
        while (this.responseHandler == null);
        this.responseHandler.sendFailureMessage(localSocketException, "can't resolve host");
        return;
      }
      catch (SocketTimeoutException localSocketTimeoutException)
      {
        while (this.responseHandler == null);
        this.responseHandler.sendFailureMessage(localSocketTimeoutException, "socket time out");
        return;
      }
      catch (ConnectTimeoutException localConnectTimeoutException)
      {
        while (this.responseHandler == null);
        this.responseHandler.sendFailureMessage(localConnectTimeoutException, "connect time out");
        return;
      }
      catch (IOException localIOException)
      {
        localObject = localIOException;
        int j = 1 + this.executionCount;
        this.executionCount = j;
        bool = localHttpRequestRetryHandler.retryRequest((IOException)localObject, j, this.context);
      }
      catch (NullPointerException localNullPointerException)
      {
        localObject = new IOException("NPE in HttpClient" + localNullPointerException.getMessage());
        int i = 1 + this.executionCount;
        this.executionCount = i;
        bool = localHttpRequestRetryHandler.retryRequest((IOException)localObject, i, this.context);
      }
    ConnectException localConnectException = new ConnectException();
    localConnectException.initCause((Throwable)localObject);
    throw localConnectException;
  }

  public void run()
  {
    try
    {
      if (this.responseHandler != null)
        this.responseHandler.sendStartMessage();
      makeRequestWithRetries();
      if (this.responseHandler != null)
        this.responseHandler.sendFinishMessage();
      return;
    }
    catch (IOException localIOException)
    {
      while (this.responseHandler == null);
      this.responseHandler.sendFinishMessage();
      if (this.isBinaryRequest)
      {
        this.responseHandler.sendFailureMessage(localIOException, (byte[])null);
        return;
      }
      this.responseHandler.sendFailureMessage(localIOException, (String)null);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.http.AsyncHttpRequest
 * JD-Core Version:    0.6.2
 */