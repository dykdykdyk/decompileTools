package com.baidu.sapi2.activity;

public enum LOGINTYPE
{
  static
  {
    LOGINTYPE[] arrayOfLOGINTYPE = new LOGINTYPE[2];
    arrayOfLOGINTYPE[0] = BAIDU_LOGIN;
    arrayOfLOGINTYPE[1] = THIRD_LOGIN;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.activity.LOGINTYPE
 * JD-Core Version:    0.6.2
 */