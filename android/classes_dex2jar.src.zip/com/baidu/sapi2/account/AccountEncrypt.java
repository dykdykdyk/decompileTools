package com.baidu.sapi2.account;

import android.content.Context;
import com.baidu.sapi2.CppUtils;
import com.baidu.sapi2.utils.Base64;
import com.baidu.sapi2.utils.DeviceId;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AccountEncrypt
{
  private static final String AES_ALGORITHM = "AES";
  private static final String DEFAULT_ENCODEING = "UTF-8";
  private static final int IVS_LENGTH = 16;
  private static final int KEY_LENGTH = 16;
  private static final String MD5_ALGORITHM = "MD5";

  public static String AES128Decrypt(String paramString1, String paramString2)
  {
    try
    {
      byte[] arrayOfByte = Base64.decode(paramString1.getBytes("UTF-8"));
      String str1 = getHexString(getMd5DigestFormStr(paramString2.trim()));
      String str2 = str1.substring(0, 16);
      String str3 = new StringBuffer(str1.substring(0, 16)).reverse().toString();
      Cipher localCipher = Cipher.getInstance(CppUtils.nativeGetDeviceAESMode());
      localCipher.init(2, new SecretKeySpec(str2.getBytes("UTF-8"), "AES"), new IvParameterSpec(str3.getBytes("UTF-8")));
      String str4 = new String(localCipher.doFinal(paddingBlock(arrayOfByte)));
      return str4;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  public static String AES128Encrypt(String paramString1, String paramString2)
  {
    try
    {
      String str1 = getHexString(getMd5DigestFormStr(paramString2.trim()));
      String str2 = str1.substring(0, 16);
      String str3 = new StringBuffer(str1.substring(0, 16)).reverse().toString();
      Cipher localCipher = Cipher.getInstance(CppUtils.nativeGetDeviceAESMode());
      localCipher.init(1, new SecretKeySpec(str2.getBytes("UTF-8"), "AES"), new IvParameterSpec(str3.getBytes("UTF-8")));
      String str4 = new String(Base64.encode(localCipher.doFinal(paddingBlock(paramString1.getBytes("UTF-8"))).toString().getBytes(), "UTF-8"));
      return str4;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  public static String decryptPassword(Context paramContext, String paramString)
  {
    return AES128Decrypt(paramString, DeviceId.getDeviceID(paramContext));
  }

  public static String encryptPassword(Context paramContext, String paramString)
  {
    return new String(AES128Encrypt(paramString, DeviceId.getDeviceID(paramContext)));
  }

  public static String getHexString(byte[] paramArrayOfByte)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = 0; i < paramArrayOfByte.length; i++)
      localStringBuilder.append(Integer.toString(256 + (0xFF & paramArrayOfByte[i]), 16).substring(1));
    return localStringBuilder.toString();
  }

  private static byte[] getMd5DigestFormStr(String paramString)
  {
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(paramString.getBytes());
      byte[] arrayOfByte = localMessageDigest.digest();
      return arrayOfByte;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
    }
    return null;
  }

  private static byte[] paddingBlock(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length % 16 != 0)
    {
      arrayOfByte = new byte[16 * (1 + paramArrayOfByte.length / 16)];
      for (int i = 0; i < paramArrayOfByte.length; i++)
        arrayOfByte[i] = paramArrayOfByte[i];
      for (int j = paramArrayOfByte.length; j < arrayOfByte.length; j++)
        arrayOfByte[j] = 0;
    }
    byte[] arrayOfByte = paramArrayOfByte;
    return arrayOfByte;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.AccountEncrypt
 * JD-Core Version:    0.6.2
 */