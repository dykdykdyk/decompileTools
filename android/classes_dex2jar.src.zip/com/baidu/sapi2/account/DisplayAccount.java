package com.baidu.sapi2.account;

import android.content.Context;
import android.text.TextUtils;
import com.baidu.sapi2.log.Logger;
import org.json.JSONException;
import org.json.JSONObject;

public class DisplayAccount
{
  private static final String DISPLAY_ACCOUNT_DISPLAYNAME = "displayname";
  private static final String DISPLAY_ACCOUNT_DISPLAYPWD = "displaypassword";
  private static final String DISPLAY_ACCOUNT_KEYCHAIN = "keychain";
  private static final String DISPLAY_ACCOUNT_LASTTIME = "lasttime";
  private static final String DISPLAY_ACCOUNT_NAME = "name";
  private static final String DISPLAY_ACCOUNT_PWD = "password";
  private static final String DISPLAY_ACCOUNT_TYPE = "type";
  private String accountName;
  private AccountType accountType;
  private String displayName;
  private String displayPassword;
  private String encryptPassword;
  private String keyChain;
  private long lastLoginTime;

  public static DisplayAccount toDisplayAccount(Context paramContext, JSONObject paramJSONObject)
  {
    DisplayAccount localDisplayAccount = new DisplayAccount();
    localDisplayAccount.setAccountName(paramJSONObject.optString("name"));
    localDisplayAccount.setAccountType(AccountType.getAccountType(paramJSONObject.optInt("type")));
    localDisplayAccount.setDisplayName(paramJSONObject.optString("displayname"));
    localDisplayAccount.setDisplayPassword(paramJSONObject.optString("displaypassword"));
    localDisplayAccount.setLastLoginTime(paramJSONObject.optLong("lasttime"));
    if (paramJSONObject.optString("password") == null);
    for (String str = null; ; str = AccountEncrypt.decryptPassword(paramContext, paramJSONObject.optString("password")))
    {
      localDisplayAccount.setEncryptPassword(str);
      localDisplayAccount.setKeyChain(paramJSONObject.optString("keychain"));
      if ((TextUtils.isEmpty(localDisplayAccount.getDisplayPassword())) || (TextUtils.isEmpty(localDisplayAccount.getEncryptPassword())) || (TextUtils.isEmpty(localDisplayAccount.getKeyChain())) || (System.currentTimeMillis() - localDisplayAccount.getLastLoginTime() > 604800000L))
      {
        localDisplayAccount.setDisplayPassword("");
        localDisplayAccount.setEncryptPassword("");
        localDisplayAccount.setKeyChain("");
      }
      return localDisplayAccount;
    }
  }

  public static JSONObject toJsonObject(Context paramContext, DisplayAccount paramDisplayAccount)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      if ((TextUtils.isEmpty(paramDisplayAccount.getDisplayPassword())) || (TextUtils.isEmpty(paramDisplayAccount.getEncryptPassword())) || (TextUtils.isEmpty(paramDisplayAccount.getKeyChain())) || (System.currentTimeMillis() - paramDisplayAccount.getLastLoginTime() > 604800000L))
      {
        paramDisplayAccount.setDisplayPassword("");
        paramDisplayAccount.setEncryptPassword("");
        paramDisplayAccount.setKeyChain("");
      }
      localJSONObject.put("name", paramDisplayAccount.getAccountName());
      localJSONObject.put("type", paramDisplayAccount.getAccountType().getTypeID());
      localJSONObject.put("displayname", paramDisplayAccount.getDisplayName());
      localJSONObject.put("displaypassword", paramDisplayAccount.getDisplayPassword());
      if (paramDisplayAccount.getEncryptPassword() == null);
      String str;
      for (Object localObject = null; ; localObject = str)
      {
        localJSONObject.put("password", localObject);
        localJSONObject.put("lasttime", paramDisplayAccount.getLastLoginTime());
        localJSONObject.put("keychain", paramDisplayAccount.getKeyChain());
        return localJSONObject;
        str = AccountEncrypt.encryptPassword(paramContext, paramDisplayAccount.getEncryptPassword());
      }
    }
    catch (JSONException localJSONException)
    {
      Logger.w(localJSONException);
    }
    return localJSONObject;
  }

  public String getAccountName()
  {
    return this.accountName;
  }

  public AccountType getAccountType()
  {
    return this.accountType;
  }

  public String getDisplayName()
  {
    return this.displayName;
  }

  public String getDisplayPassword()
  {
    return this.displayPassword;
  }

  public String getEncryptPassword()
  {
    return this.encryptPassword;
  }

  public String getKeyChain()
  {
    return this.keyChain;
  }

  public long getLastLoginTime()
  {
    return this.lastLoginTime;
  }

  public void setAccountName(String paramString)
  {
    this.accountName = paramString;
  }

  public void setAccountType(AccountType paramAccountType)
  {
    this.accountType = paramAccountType;
  }

  public void setDisplayName(String paramString)
  {
    this.displayName = paramString;
  }

  public void setDisplayPassword(String paramString)
  {
    this.displayPassword = paramString;
  }

  public void setEncryptPassword(String paramString)
  {
    this.encryptPassword = paramString;
  }

  public void setKeyChain(String paramString)
  {
    this.keyChain = paramString;
  }

  public void setLastLoginTime(long paramLong)
  {
    this.lastLoginTime = paramLong;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.DisplayAccount
 * JD-Core Version:    0.6.2
 */