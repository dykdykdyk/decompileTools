package com.baidu.sapi2.account;

import android.accounts.AccountsException;

public class AccountThread extends Thread
{
  private DisplayAccount account;
  private String accountName;
  private AccountType accountType;
  private AccountAgent agent;
  private LocalAccountsListener mListener;
  private RunType type;

  public AccountThread(AccountAgent paramAccountAgent, LocalAccountsListener paramLocalAccountsListener, RunType paramRunType)
  {
    this.agent = paramAccountAgent;
    this.type = paramRunType;
    this.mListener = paramLocalAccountsListener;
  }

  public AccountThread(AccountAgent paramAccountAgent, LocalAccountsListener paramLocalAccountsListener, RunType paramRunType, AccountType paramAccountType)
  {
    this.agent = paramAccountAgent;
    this.mListener = paramLocalAccountsListener;
    this.type = paramRunType;
    this.accountType = paramAccountType;
  }

  public AccountThread(AccountAgent paramAccountAgent, LocalAccountsListener paramLocalAccountsListener, RunType paramRunType, DisplayAccount paramDisplayAccount)
  {
    this.agent = paramAccountAgent;
    this.mListener = paramLocalAccountsListener;
    this.type = paramRunType;
    this.account = paramDisplayAccount;
  }

  public AccountThread(AccountAgent paramAccountAgent, LocalAccountsListener paramLocalAccountsListener, RunType paramRunType, String paramString, AccountType paramAccountType)
  {
    this.agent = paramAccountAgent;
    this.mListener = paramLocalAccountsListener;
    this.type = paramRunType;
    this.accountType = paramAccountType;
    this.accountName = paramString;
  }

  public void run()
  {
    if (this.type == RunType.ADD_ACCOUNT);
    while (true)
    {
      try
      {
        this.agent.blockAddAccount(this.account);
        super.run();
        return;
      }
      catch (AccountsException localAccountsException)
      {
        this.mListener.getResult(false);
        continue;
      }
      if (this.type == RunType.GET_ACCOUNT_BY_TYPE)
        this.mListener.getResult(this.agent.blockGetAccountMap(this.accountType));
      else if (this.type == RunType.SAVE_ACCOUNT)
        this.mListener.getResult(this.agent.blockSave());
      else if (this.type == RunType.DELETE_SINGLE_ITEM)
        this.mListener.getResult(this.agent.blockDelete(this.accountName, this.accountType));
      else if (this.type == RunType.DELETE_BY_TYPE)
        this.mListener.getResult(this.agent.blockDelete(this.accountType));
      else if (this.type == RunType.CLEAR_ACCOUNT)
        this.mListener.getResult(this.agent.blockClear());
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.AccountThread
 * JD-Core Version:    0.6.2
 */