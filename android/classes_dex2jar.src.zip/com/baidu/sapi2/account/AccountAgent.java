package com.baidu.sapi2.account;

import android.accounts.AccountsException;
import android.content.Context;
import android.text.TextUtils;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AccountAgent
{
  private static final int RETAIN_ACCOUNT_MAX = 5;
  private Context mContext;
  private HashMap<String, DisplayAccount> mobileAccountMap = new LinkedHashMap();
  private HashMap<String, DisplayAccount> normalAccountMap = new LinkedHashMap();

  public AccountAgent(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private HashMap<String, DisplayAccount> blockRetainLastAccount(HashMap<String, DisplayAccount> paramHashMap, int paramInt)
  {
    LinkedList localLinkedList = null;
    if (paramInt > 0)
    {
      Iterator localIterator2 = paramHashMap.keySet().iterator();
      while (localIterator2.hasNext())
      {
        DisplayAccount localDisplayAccount1 = (DisplayAccount)paramHashMap.get(localIterator2.next());
        if ((localLinkedList == null) || (localLinkedList.size() < paramInt))
        {
          localLinkedList = new LinkedList();
          localLinkedList.add(localDisplayAccount1);
        }
        else
        {
          DisplayAccount localDisplayAccount2 = localDisplayAccount1;
          for (int i = 0; i < localLinkedList.size(); i++)
            if ((localDisplayAccount2 == null) || (((DisplayAccount)localLinkedList.get(i)).getLastLoginTime() > localDisplayAccount2.getLastLoginTime()))
              localDisplayAccount2 = (DisplayAccount)localLinkedList.get(i);
          if (localDisplayAccount1 != localDisplayAccount2)
          {
            localLinkedList.remove(localDisplayAccount2);
            localLinkedList.add(localDisplayAccount1);
          }
        }
      }
    }
    if ((localLinkedList != null) && (localLinkedList.size() != 0))
    {
      Iterator localIterator1 = localLinkedList.iterator();
      while (localIterator1.hasNext())
        paramHashMap.remove(((DisplayAccount)localIterator1.next()).getAccountName());
    }
    return paramHashMap;
  }

  private List<DisplayAccount> createOrderedList(HashMap<String, DisplayAccount> paramHashMap)
  {
    LinkedList localLinkedList = new LinkedList();
    Iterator localIterator = paramHashMap.keySet().iterator();
    while (localIterator.hasNext())
      localLinkedList.add(paramHashMap.get(localIterator.next()));
    Collections.sort(localLinkedList, new Comparator()
    {
      public int compare(DisplayAccount paramAnonymousDisplayAccount1, DisplayAccount paramAnonymousDisplayAccount2)
      {
        return String.valueOf(paramAnonymousDisplayAccount2.getLastLoginTime()).compareTo(String.valueOf(paramAnonymousDisplayAccount1.getLastLoginTime()));
      }
    });
    return localLinkedList;
  }

  private void initAccountMap()
  {
    if (((this.normalAccountMap != null) && (this.normalAccountMap.size() != 0)) || ((this.mobileAccountMap != null) && (this.mobileAccountMap.size() != 0)))
      return;
    this.normalAccountMap = new LinkedHashMap();
    while (true)
    {
      int i;
      try
      {
        String str = AccountStorage.getInstance(this.mContext).blockReceive();
        if (TextUtils.isEmpty(str))
          break;
        JSONArray localJSONArray = new JSONArray(str);
        if (localJSONArray == null)
          break;
        i = 0;
        if (i >= localJSONArray.length())
          break;
        JSONObject localJSONObject = localJSONArray.getJSONObject(i);
        DisplayAccount localDisplayAccount = DisplayAccount.toDisplayAccount(this.mContext, localJSONObject);
        if (!TextUtils.isEmpty(localDisplayAccount.getAccountName()))
        {
          if ((TextUtils.isEmpty(localDisplayAccount.getDisplayPassword())) || (TextUtils.isEmpty(localDisplayAccount.getEncryptPassword())) || (TextUtils.isEmpty(localDisplayAccount.getKeyChain())) || (System.currentTimeMillis() - localDisplayAccount.getLastLoginTime() > 604800000L))
          {
            localDisplayAccount.setDisplayPassword("");
            localDisplayAccount.setEncryptPassword("");
            localDisplayAccount.setKeyChain("");
          }
          if (localDisplayAccount.getAccountType() == AccountType.NORMAL)
            this.normalAccountMap.put(localDisplayAccount.getAccountName(), localDisplayAccount);
          else if (localDisplayAccount.getAccountType() == AccountType.PHONE)
            this.mobileAccountMap.put(localDisplayAccount.getAccountName(), localDisplayAccount);
        }
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
        return;
      }
      i++;
    }
  }

  protected boolean blockAddAccount(DisplayAccount paramDisplayAccount)
    throws AccountsException
  {
    if ((paramDisplayAccount == null) || (TextUtils.isEmpty(paramDisplayAccount.getAccountName())))
      throw new AccountsException("Account format is illegal.");
    if ((TextUtils.isEmpty(paramDisplayAccount.getDisplayPassword())) || (TextUtils.isEmpty(paramDisplayAccount.getEncryptPassword())) || (TextUtils.isEmpty(paramDisplayAccount.getKeyChain())) || (System.currentTimeMillis() - paramDisplayAccount.getLastLoginTime() > 604800000L))
    {
      paramDisplayAccount.setDisplayPassword("");
      paramDisplayAccount.setEncryptPassword("");
      paramDisplayAccount.setKeyChain("");
    }
    initAccountMap();
    int i;
    if (!this.normalAccountMap.containsKey(paramDisplayAccount.getAccountName()))
    {
      i = 1 + (-5 + this.normalAccountMap.size());
      if (paramDisplayAccount.getAccountType() != AccountType.NORMAL)
        break label227;
      if ((this.normalAccountMap.size() >= 4) && ((!this.normalAccountMap.containsKey(paramDisplayAccount.getAccountName())) || (this.normalAccountMap.size() != 5)))
        break label198;
      this.normalAccountMap.put(paramDisplayAccount.getAccountName(), paramDisplayAccount);
    }
    while (true)
    {
      blockSave();
      return true;
      i = -5 + this.normalAccountMap.size();
      break;
      label198: this.normalAccountMap = blockRetainLastAccount(this.normalAccountMap, i);
      this.normalAccountMap.put(paramDisplayAccount.getAccountName(), paramDisplayAccount);
    }
    label227: if (paramDisplayAccount.getAccountType() == AccountType.PHONE)
    {
      if ((this.mobileAccountMap.size() < 4) || ((this.mobileAccountMap.containsKey(paramDisplayAccount.getAccountName())) && (this.mobileAccountMap.size() < 5)))
        this.mobileAccountMap.put(paramDisplayAccount.getAccountName(), paramDisplayAccount);
      while (true)
      {
        blockSave();
        return true;
        this.mobileAccountMap = blockRetainLastAccount(this.mobileAccountMap, i);
        this.mobileAccountMap.put(paramDisplayAccount.getAccountName(), paramDisplayAccount);
      }
    }
    return false;
  }

  protected boolean blockClear()
  {
    this.normalAccountMap = new LinkedHashMap();
    this.mobileAccountMap = new LinkedHashMap();
    return AccountStorage.getInstance(this.mContext).blockClear();
  }

  protected boolean blockDelete(AccountType paramAccountType)
  {
    if ((paramAccountType == AccountType.NORMAL) && (this.normalAccountMap.size() > 0))
    {
      this.normalAccountMap.clear();
      blockSave();
      return true;
    }
    if ((paramAccountType == AccountType.PHONE) && (this.mobileAccountMap.size() > 0))
    {
      this.mobileAccountMap.clear();
      blockSave();
      return true;
    }
    return false;
  }

  protected boolean blockDelete(String paramString, AccountType paramAccountType)
  {
    if ((paramAccountType == AccountType.NORMAL) && (this.normalAccountMap.containsKey(paramString)))
    {
      this.normalAccountMap.remove(paramString);
      blockSave();
      return true;
    }
    if ((paramAccountType == AccountType.PHONE) && (this.mobileAccountMap.containsKey(paramString)))
    {
      this.mobileAccountMap.remove(paramString);
      blockSave();
      return true;
    }
    return false;
  }

  protected List<DisplayAccount> blockGetAccountMap(AccountType paramAccountType)
  {
    if (paramAccountType == AccountType.NORMAL)
    {
      if ((this.normalAccountMap != null) && (this.normalAccountMap.size() != 0))
        return createOrderedList(this.normalAccountMap);
      initAccountMap();
      return createOrderedList(this.normalAccountMap);
    }
    if (paramAccountType == AccountType.PHONE)
    {
      if ((this.mobileAccountMap != null) && (this.mobileAccountMap.size() != 0))
        return createOrderedList(this.mobileAccountMap);
      initAccountMap();
      return createOrderedList(this.mobileAccountMap);
    }
    return null;
  }

  protected boolean blockSave()
  {
    JSONArray localJSONArray = new JSONArray();
    Iterator localIterator1 = this.normalAccountMap.keySet().iterator();
    while (localIterator1.hasNext())
      localJSONArray.put(DisplayAccount.toJsonObject(this.mContext, (DisplayAccount)this.normalAccountMap.get(localIterator1.next())));
    Iterator localIterator2 = this.mobileAccountMap.keySet().iterator();
    while (localIterator2.hasNext())
      localJSONArray.put(DisplayAccount.toJsonObject(this.mContext, (DisplayAccount)this.mobileAccountMap.get(localIterator2.next())));
    return AccountStorage.getInstance(this.mContext).blockUpdate(localJSONArray.toString());
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.AccountAgent
 * JD-Core Version:    0.6.2
 */