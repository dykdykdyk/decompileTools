package com.baidu.sapi2.account;

import java.util.List;

public abstract interface LocalAccountsListener
{
  public abstract void getResult(List<DisplayAccount> paramList);

  public abstract void getResult(boolean paramBoolean);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.LocalAccountsListener
 * JD-Core Version:    0.6.2
 */