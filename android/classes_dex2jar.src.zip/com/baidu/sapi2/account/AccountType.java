package com.baidu.sapi2.account;

public enum AccountType
{
  private int accountType;

  static
  {
    QR = new AccountType("QR", 4, 4);
    DEVICE = new AccountType("DEVICE", 5, 5);
    FASTREG = new AccountType("FASTREG", 6, 6);
    DYNAMICPWD = new AccountType("DYNAMICPWD", 7, 7);
    AccountType[] arrayOfAccountType = new AccountType[8];
    arrayOfAccountType[0] = DEFAULT;
    arrayOfAccountType[1] = NORMAL;
    arrayOfAccountType[2] = PHONE;
    arrayOfAccountType[3] = SOCIAL;
    arrayOfAccountType[4] = QR;
    arrayOfAccountType[5] = DEVICE;
    arrayOfAccountType[6] = FASTREG;
    arrayOfAccountType[7] = DYNAMICPWD;
  }

  private AccountType(int paramInt)
  {
    this.accountType = paramInt;
  }

  public static AccountType getAccountType(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return DEFAULT;
    case 1:
      return NORMAL;
    case 2:
      return PHONE;
    case 3:
      return SOCIAL;
    case 4:
      return QR;
    case 5:
      return DEVICE;
    case 6:
      return FASTREG;
    case 7:
    }
    return DYNAMICPWD;
  }

  public int getTypeID()
  {
    return this.accountType;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.AccountType
 * JD-Core Version:    0.6.2
 */