package com.baidu.sapi2.account;

import android.content.Context;
import com.baidu.sapi2.log.Logger;
import com.baidu.sapi2.share.NativeCrypto;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class AccountStorage
{
  private static final String STORAGE_ACCOUNT_FILENAME = "Baidu_Storage_ACS";
  private static volatile AccountStorage accountStorage = null;
  private Context mContext = null;

  private AccountStorage(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private String decrypt(Context paramContext, String paramString)
  {
    try
    {
      String str = NativeCrypto.decrypt(paramContext, paramString);
      return str;
    }
    catch (Throwable localThrowable)
    {
    }
    return null;
  }

  private String encrypt(Context paramContext, String paramString)
  {
    try
    {
      String str = NativeCrypto.encrypt(paramContext, paramString);
      return str;
    }
    catch (Throwable localThrowable)
    {
    }
    return null;
  }

  public static AccountStorage getInstance(Context paramContext)
  {
    if (accountStorage == null);
    try
    {
      if (accountStorage == null)
        accountStorage = new AccountStorage(paramContext);
      return accountStorage;
    }
    finally
    {
    }
  }

  public boolean blockClear()
  {
    if (this.mContext == null)
      return false;
    this.mContext.deleteFile("Baidu_Storage_ACS");
    return true;
  }

  public String blockReceive()
  {
    FileInputStream localFileInputStream = null;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    try
    {
      localFileInputStream = this.mContext.openFileInput("Baidu_Storage_ACS");
      if (localFileInputStream == null)
      {
        localByteArrayOutputStream.flush();
        localByteArrayOutputStream.close();
        return null;
      }
      byte[] arrayOfByte = new byte[2048];
      for (int i = 0; i != -1; i = localFileInputStream.read(arrayOfByte))
        localByteArrayOutputStream.write(arrayOfByte, 0, i);
      localFileInputStream.close();
      String str = decrypt(this.mContext, new String(localByteArrayOutputStream.toByteArray()));
      return str;
    }
    catch (Exception localException1)
    {
      Logger.w(localException1);
      try
      {
        localByteArrayOutputStream.flush();
        localByteArrayOutputStream.close();
        localFileInputStream.close();
        return null;
      }
      catch (Exception localException2)
      {
        Logger.w(localException2);
      }
    }
    return null;
  }

  public boolean blockUpdate(String paramString)
  {
    String str = encrypt(this.mContext, paramString);
    FileOutputStream localFileOutputStream = null;
    try
    {
      localFileOutputStream = this.mContext.openFileOutput("Baidu_Storage_ACS", 0);
      localFileOutputStream.write(str.getBytes());
      localFileOutputStream.flush();
      localFileOutputStream.close();
      return true;
    }
    catch (Exception localException1)
    {
      Logger.w(localException1);
      try
      {
        localFileOutputStream.flush();
        localFileOutputStream.close();
        return false;
      }
      catch (Exception localException2)
      {
        Logger.w(localException2);
      }
    }
    return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.AccountStorage
 * JD-Core Version:    0.6.2
 */