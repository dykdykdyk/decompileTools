package com.baidu.sapi2.account;

public class AccountException extends Exception
{
  private static final long serialVersionUID = 1L;
  private String errMsg;
  private int errno;

  public AccountException(int paramInt)
  {
    this.errno = paramInt;
  }

  public AccountException(int paramInt, String paramString)
  {
    super(paramString);
    this.errno = paramInt;
    this.errMsg = paramString;
  }

  public AccountException(String paramString)
  {
    super(paramString);
    this.errMsg = paramString;
  }

  public String getErrMsg()
  {
    return this.errMsg;
  }

  public int getErrno()
  {
    return this.errno;
  }

  public void setErrMsg(String paramString)
  {
    this.errMsg = paramString;
  }

  public void setErrno(int paramInt)
  {
    this.errno = paramInt;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.AccountException
 * JD-Core Version:    0.6.2
 */