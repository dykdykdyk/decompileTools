package com.baidu.sapi2.account;

import android.accounts.AccountsException;
import android.content.Context;
import com.baidu.sapi2.log.Logger;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AccountAPI
{
  private static volatile AccountAPI api = null;
  private AccountAgent agent;
  private ExecutorService threadPools = Executors.newFixedThreadPool(1);

  public AccountAPI(Context paramContext)
  {
    this.agent = new AccountAgent(paramContext);
  }

  public static AccountAPI getInstance(Context paramContext)
  {
    if (api == null);
    try
    {
      if (api == null)
        api = new AccountAPI(paramContext);
      return api;
    }
    finally
    {
    }
  }

  public void asyncAddAccount(LocalAccountsListener paramLocalAccountsListener, DisplayAccount paramDisplayAccount)
  {
    this.threadPools.submit(new AccountThread(this.agent, paramLocalAccountsListener, RunType.ADD_ACCOUNT, paramDisplayAccount));
  }

  public void asyncClearAccount(LocalAccountsListener paramLocalAccountsListener)
  {
    this.threadPools.submit(new AccountThread(this.agent, paramLocalAccountsListener, RunType.CLEAR_ACCOUNT));
  }

  public void asyncDeleteByType(LocalAccountsListener paramLocalAccountsListener, AccountType paramAccountType)
  {
    this.threadPools.submit(new AccountThread(this.agent, paramLocalAccountsListener, RunType.DELETE_BY_TYPE, paramAccountType));
  }

  public void asyncDeleteSingleItem(LocalAccountsListener paramLocalAccountsListener, AccountType paramAccountType, String paramString)
  {
    this.threadPools.submit(new AccountThread(this.agent, paramLocalAccountsListener, RunType.DELETE_SINGLE_ITEM, paramString, paramAccountType));
  }

  public void asyncGetAccounts(LocalAccountsListener paramLocalAccountsListener, AccountType paramAccountType)
  {
    this.threadPools.submit(new AccountThread(this.agent, paramLocalAccountsListener, RunType.GET_ACCOUNT_BY_TYPE, paramAccountType));
  }

  public void asyncSaveAccount(LocalAccountsListener paramLocalAccountsListener)
  {
    this.threadPools.submit(new AccountThread(this.agent, paramLocalAccountsListener, RunType.SAVE_ACCOUNT));
  }

  public boolean blockAddAccount(DisplayAccount paramDisplayAccount)
  {
    try
    {
      boolean bool = this.agent.blockAddAccount(paramDisplayAccount);
      return bool;
    }
    catch (AccountsException localAccountsException)
    {
      Logger.w(localAccountsException);
    }
    return false;
  }

  public boolean blockClearAccount()
  {
    return this.agent.blockClear();
  }

  public boolean blockDeleteByType(AccountType paramAccountType)
  {
    return this.agent.blockDelete(paramAccountType);
  }

  public boolean blockDeleteSingleItem(AccountType paramAccountType, String paramString)
  {
    return this.agent.blockDelete(paramString, paramAccountType);
  }

  public List<DisplayAccount> blockGetAccounts(AccountType paramAccountType)
  {
    return this.agent.blockGetAccountMap(paramAccountType);
  }

  public boolean blockSaveAccount()
  {
    return this.agent.blockSave();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.AccountAPI
 * JD-Core Version:    0.6.2
 */