package com.baidu.sapi2.account;

public enum RunType
{
  private int runType;

  static
  {
    DELETE_SINGLE_ITEM = new RunType("DELETE_SINGLE_ITEM", 3, 3);
    DELETE_BY_TYPE = new RunType("DELETE_BY_TYPE", 4, 4);
    CLEAR_ACCOUNT = new RunType("CLEAR_ACCOUNT", 5, 5);
    RunType[] arrayOfRunType = new RunType[6];
    arrayOfRunType[0] = ADD_ACCOUNT;
    arrayOfRunType[1] = GET_ACCOUNT_BY_TYPE;
    arrayOfRunType[2] = SAVE_ACCOUNT;
    arrayOfRunType[3] = DELETE_SINGLE_ITEM;
    arrayOfRunType[4] = DELETE_BY_TYPE;
    arrayOfRunType[5] = CLEAR_ACCOUNT;
  }

  private RunType(int paramInt)
  {
    this.runType = paramInt;
  }

  public int getType()
  {
    return this.runType;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.account.RunType
 * JD-Core Version:    0.6.2
 */