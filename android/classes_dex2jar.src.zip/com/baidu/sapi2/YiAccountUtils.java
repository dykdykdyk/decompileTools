package com.baidu.sapi2;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.accounts.AuthenticatorDescription;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import com.baidu.sapi2.log.Logger;
import java.io.IOException;

public class YiAccountUtils
{
  public static final String BAIDUACCOUNT_ACTION = "com.baidu.account";
  public static final String BAIDUACCOUNT_KEY = "com.baidu.account.key";
  public static final String BAIDUACCOUNT_TYPE = "com.baidu";
  private static YiAccountUtils mInstance = null;
  private static Object mSync = new Object();
  private Context mContext;
  private boolean mIsActivity;

  public YiAccountUtils(Context paramContext)
  {
    this.mContext = paramContext;
    this.mIsActivity = (paramContext instanceof Activity);
  }

  private Activity getActivity()
  {
    if (this.mIsActivity)
      return (Activity)this.mContext;
    return null;
  }

  private String getBaiduAccountDisplayName()
  {
    String str = getYiUserData("displayname");
    if ((str == null) || ((str != null) && (str.trim().length() == 0)))
      str = getUserName();
    return str;
  }

  public static YiAccountUtils getInstance(Context paramContext)
  {
    synchronized (mSync)
    {
      if (mInstance == null)
        mInstance = new YiAccountUtils(paramContext);
      return mInstance;
    }
  }

  private String getUserName()
  {
    Account[] arrayOfAccount = AccountManager.get(this.mContext).getAccountsByType("com.baidu");
    if ((arrayOfAccount != null) && (arrayOfAccount.length > 0) && (arrayOfAccount[0].name != null))
      return arrayOfAccount[0].name;
    return null;
  }

  private String getYiUserData(String paramString)
  {
    try
    {
      String[] arrayOfString = { paramString };
      Uri localUri = Uri.parse("content://com.baidu.account.provider.AccountInfoProvider/accountInfo");
      Cursor localCursor = this.mContext.getContentResolver().query(localUri, arrayOfString, null, null, null);
      Object localObject = null;
      if (localCursor != null)
      {
        boolean bool = localCursor.moveToFirst();
        localObject = null;
        if (bool)
        {
          String str = localCursor.getString(localCursor.getColumnIndex(paramString));
          localObject = str;
        }
      }
      return localObject;
    }
    catch (SQLiteException localSQLiteException)
    {
      Logger.w(localSQLiteException);
    }
    return null;
  }

  public String blockingGetBaiduAuthToken(boolean paramBoolean)
  {
    AccountManager localAccountManager;
    Account[] arrayOfAccount;
    if (isLogin())
    {
      localAccountManager = AccountManager.get(this.mContext);
      arrayOfAccount = localAccountManager.getAccountsByType("com.baidu");
      if ((arrayOfAccount == null) || (arrayOfAccount.length <= 0));
    }
    try
    {
      String str = localAccountManager.blockingGetAuthToken(arrayOfAccount[0], "BDUSS", paramBoolean);
      return str;
    }
    catch (OperationCanceledException localOperationCanceledException)
    {
      Logger.w(localOperationCanceledException);
      return null;
    }
    catch (AuthenticatorException localAuthenticatorException)
    {
      while (true)
        Logger.w(localAuthenticatorException);
    }
    catch (IOException localIOException)
    {
      while (true)
        Logger.w(localIOException);
    }
  }

  public int getNumOfAccounts(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
      paramString = "com.baidu";
    return AccountManager.get(this.mContext).getAccountsByType(paramString).length;
  }

  public void getTokenAsync(String paramString, ITokenCallback paramITokenCallback, Activity paramActivity)
  {
    if ((paramString == null) || (paramString.length() == 0))
      paramString = "com.baidu";
    Activity localActivity;
    AccountManager localAccountManager;
    if (paramActivity == null)
    {
      localActivity = getActivity();
      localAccountManager = AccountManager.get(this.mContext);
      if (localAccountManager == null)
        break label143;
      arrayOfAccount = localAccountManager.getAccountsByType(paramString);
      localBundle = new Bundle();
      localBundle.putBoolean("PASSWDCK", true);
      if (arrayOfAccount.length != 0)
        break label119;
      bool = true;
      localMyAccountManagerCallback = new MyAccountManagerCallback(paramITokenCallback, paramString, bool, localActivity);
      if (arrayOfAccount.length == 0)
        break label125;
      localAccountManager.getAuthToken(arrayOfAccount[0], "BDUSS", null, localActivity, localMyAccountManagerCallback, null);
    }
    label119: label125: 
    while (paramITokenCallback == null)
    {
      Bundle localBundle;
      MyAccountManagerCallback localMyAccountManagerCallback;
      while (true)
      {
        Account[] arrayOfAccount;
        return;
        localActivity = paramActivity;
        break;
        boolean bool = false;
      }
      localAccountManager.addAccount(paramString, "BDUSS", null, localBundle, localActivity, localMyAccountManagerCallback, null);
      return;
    }
    label143: paramITokenCallback.onResult(null);
  }

  public String getUserData(String paramString)
  {
    if ((paramString == null) || (paramString.trim().length() == 0))
      return null;
    if (paramString.equals("username"))
      return getUserName();
    if (paramString.equals("displayname"))
      return getBaiduAccountDisplayName();
    return getYiUserData(paramString);
  }

  public boolean hasYiAccount()
  {
    AuthenticatorDescription[] arrayOfAuthenticatorDescription = AccountManager.get(this.mContext).getAuthenticatorTypes();
    int i = arrayOfAuthenticatorDescription.length;
    for (int j = 0; ; j++)
    {
      boolean bool = false;
      if (j < i)
      {
        if (arrayOfAuthenticatorDescription[j].type.equalsIgnoreCase("com.baidu"))
          bool = true;
      }
      else
        return bool;
    }
  }

  public void invalidateToken(String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString1.length() == 0))
      paramString1 = "com.baidu";
    AccountManager localAccountManager = AccountManager.get(this.mContext);
    if (localAccountManager != null)
      localAccountManager.invalidateAuthToken(paramString1, paramString2);
  }

  public boolean isLogin()
  {
    return (hasYiAccount()) && (getNumOfAccounts("com.baidu") > 0);
  }

  public void manageAccount()
  {
    Intent localIntent = new Intent("android.settings.SYNC_SETTINGS");
    localIntent.addFlags(268435456);
    this.mContext.startActivity(localIntent);
  }

  public void removeAccount()
  {
    AccountManager localAccountManager = AccountManager.get(this.mContext);
    Account[] arrayOfAccount = localAccountManager.getAccountsByType("com.baidu");
    if (arrayOfAccount.length != 0)
    {
      localAccountManager.removeAccount(arrayOfAccount[0], new AccountManagerCallback()
      {
        public void run(AccountManagerFuture<Boolean> paramAnonymousAccountManagerFuture)
        {
          try
          {
            paramAnonymousAccountManagerFuture.getResult();
            return;
          }
          catch (Exception localException)
          {
            Logger.w(localException);
          }
        }
      }
      , null);
      return;
    }
  }

  public void setAccount(String paramString)
  {
    if ((paramString == null) || (paramString.length() == 0))
      paramString = "com.baidu";
    AccountManager localAccountManager = AccountManager.get(this.mContext);
    if (localAccountManager != null)
    {
      Account[] arrayOfAccount = localAccountManager.getAccountsByType(paramString);
      if (arrayOfAccount.length == 1)
      {
        Intent localIntent = new Intent("android.settings.ACCOUNT_SYNC_SETTINGS");
        localIntent.addFlags(268435456);
        localIntent.putExtra("account", arrayOfAccount[0]);
        this.mContext.startActivity(localIntent);
      }
    }
  }

  public void startFillNameActivity(Activity paramActivity, int paramInt, boolean paramBoolean)
    throws ActivityNotFoundException
  {
    Intent localIntent = new Intent("com.baidu.account.FILL_NAME");
    localIntent.setFlags(268435456);
    localIntent.putExtra("show_dialog", paramBoolean);
    paramActivity.startActivityForResult(localIntent, paramInt);
  }

  public static abstract interface BaiduAccountCallback
  {
    public abstract void onLoginResult(int paramInt);
  }

  class MyAccountManagerCallback
    implements AccountManagerCallback<Bundle>
  {
    private String mAccountType;
    private Activity mActivity;
    private ITokenCallback mCallback = null;
    private boolean mIfAddAccount;
    public String mytoken = null;

    public MyAccountManagerCallback(ITokenCallback paramString, String paramBoolean, boolean paramActivity, Activity arg5)
    {
      this.mCallback = paramString;
      this.mAccountType = paramBoolean;
      this.mIfAddAccount = paramActivity;
      Object localObject;
      this.mActivity = localObject;
    }

    private void endAll()
    {
      if (this.mCallback != null)
        this.mCallback.onResult(this.mytoken);
      if ((this.mActivity instanceof Activity))
      {
        Intent localIntent = new Intent("com.baidu.account");
        localIntent.setComponent(this.mActivity.getComponentName());
        localIntent.putExtra("com.baidu.account.key", this.mytoken);
        this.mActivity.sendBroadcast(localIntent);
      }
      notify();
    }

    // ERROR //
    public void run(AccountManagerFuture<Bundle> paramAccountManagerFuture)
    {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: aload_1
      //   4: invokeinterface 81 1 0
      //   9: checkcast 83	android/os/Bundle
      //   12: ldc 85
      //   14: invokevirtual 89	android/os/Bundle:getString	(Ljava/lang/String;)Ljava/lang/String;
      //   17: putfield 27	com/baidu/sapi2/YiAccountUtils$MyAccountManagerCallback:mytoken	Ljava/lang/String;
      //   20: aload_0
      //   21: getfield 22	com/baidu/sapi2/YiAccountUtils$MyAccountManagerCallback:this$0	Lcom/baidu/sapi2/YiAccountUtils;
      //   24: invokestatic 95	com/baidu/sapi2/YiAccountUtils:access$000	(Lcom/baidu/sapi2/YiAccountUtils;)Landroid/content/Context;
      //   27: invokestatic 101	android/accounts/AccountManager:get	(Landroid/content/Context;)Landroid/accounts/AccountManager;
      //   30: astore 4
      //   32: aload 4
      //   34: aload_0
      //   35: getfield 31	com/baidu/sapi2/YiAccountUtils$MyAccountManagerCallback:mAccountType	Ljava/lang/String;
      //   38: invokevirtual 105	android/accounts/AccountManager:getAccountsByType	(Ljava/lang/String;)[Landroid/accounts/Account;
      //   41: astore 5
      //   43: aload_0
      //   44: getfield 33	com/baidu/sapi2/YiAccountUtils$MyAccountManagerCallback:mIfAddAccount	Z
      //   47: ifeq +38 -> 85
      //   50: aload_0
      //   51: getfield 27	com/baidu/sapi2/YiAccountUtils$MyAccountManagerCallback:mytoken	Ljava/lang/String;
      //   54: ifnonnull +31 -> 85
      //   57: aload 5
      //   59: arraylength
      //   60: ifle +25 -> 85
      //   63: aload 4
      //   65: aload 5
      //   67: iconst_0
      //   68: aaload
      //   69: ldc 107
      //   71: aconst_null
      //   72: aload_0
      //   73: getfield 35	com/baidu/sapi2/YiAccountUtils$MyAccountManagerCallback:mActivity	Landroid/app/Activity;
      //   76: aload_0
      //   77: aconst_null
      //   78: invokevirtual 111	android/accounts/AccountManager:getAuthToken	(Landroid/accounts/Account;Ljava/lang/String;Landroid/os/Bundle;Landroid/app/Activity;Landroid/accounts/AccountManagerCallback;Landroid/os/Handler;)Landroid/accounts/AccountManagerFuture;
      //   81: pop
      //   82: aload_0
      //   83: monitorexit
      //   84: return
      //   85: aload_0
      //   86: invokespecial 113	com/baidu/sapi2/YiAccountUtils$MyAccountManagerCallback:endAll	()V
      //   89: aload_0
      //   90: monitorexit
      //   91: return
      //   92: astore_3
      //   93: aload_0
      //   94: monitorexit
      //   95: aload_3
      //   96: athrow
      //   97: astore_2
      //   98: aload_0
      //   99: invokespecial 113	com/baidu/sapi2/YiAccountUtils$MyAccountManagerCallback:endAll	()V
      //   102: goto -13 -> 89
      //
      // Exception table:
      //   from	to	target	type
      //   2	82	92	finally
      //   82	84	92	finally
      //   85	89	92	finally
      //   89	91	92	finally
      //   93	95	92	finally
      //   98	102	92	finally
      //   2	82	97	java/lang/Exception
      //   85	89	97	java/lang/Exception
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.YiAccountUtils
 * JD-Core Version:    0.6.2
 */