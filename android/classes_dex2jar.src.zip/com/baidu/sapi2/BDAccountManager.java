package com.baidu.sapi2;

import android.app.Activity;
import android.content.Context;
import com.baidu.sapi2.loginshare.Token;
import com.baidu.sapi2.utils.DeviceId;
import org.json.JSONException;
import org.json.JSONObject;

public class BDAccountManager
{
  public static final String KEY_DISPLAY_NAME = "displayname";
  public static final String KEY_EMAIL = "email";
  public static final String KEY_PHONE = "phone";
  public static final String KEY_PTOKEN = "ptoken";
  public static final String KEY_RESULTCODE = "sapi_resultcode";
  public static final String KEY_RESULTMSG = "sapi_resultmsg";
  public static final String KEY_STOKEN = "stoken";
  public static final String KEY_UID = "uid";
  public static final String KEY_USERNAME = "username";
  private static BDAccountManager mInstance = null;
  private static Object mSync = new Object();
  private final String BAIDUACCOUNT_TYPE = "com.baidu";
  private Context mContext;
  private SapiConfig mSapiConfig;

  public static BDAccountManager getInstance()
  {
    if (mInstance == null);
    synchronized (mSync)
    {
      mInstance = new BDAccountManager();
      return mInstance;
    }
  }

  public String blockingGetAuthToken()
  {
    if ((this.mSapiConfig.isEnableYi()) && (YiAccountUtils.getInstance(this.mContext).hasYiAccount()))
      return YiAccountUtils.getInstance(this.mContext).blockingGetBaiduAuthToken(true);
    return SapiHelper.getInstance().getToken().mBduss;
  }

  public void getAuthTokenAsync(ITokenCallback paramITokenCallback)
  {
    getAuthTokenAsync(paramITokenCallback, null, null, null);
  }

  public void getAuthTokenAsync(ITokenCallback paramITokenCallback, Activity paramActivity)
  {
    getAuthTokenAsync(paramITokenCallback, paramActivity, null, null);
  }

  public void getAuthTokenAsync(ITokenCallback paramITokenCallback, Activity paramActivity, Class paramClass)
  {
    getAuthTokenAsync(paramITokenCallback, paramActivity, paramClass, null);
  }

  public void getAuthTokenAsync(ITokenCallback paramITokenCallback, Activity paramActivity, Class paramClass, OnUnLoginListener paramOnUnLoginListener)
  {
    getAuthTokenAsync(paramITokenCallback, paramActivity, paramClass, paramOnUnLoginListener, -1);
  }

  public void getAuthTokenAsync(ITokenCallback paramITokenCallback, Activity paramActivity, Class paramClass, OnUnLoginListener paramOnUnLoginListener, int paramInt)
  {
    if (paramITokenCallback == null)
      throw new IllegalArgumentException();
    if ((this.mSapiConfig.isEnableYi()) && (YiAccountUtils.getInstance(this.mContext).hasYiAccount()))
    {
      YiAccountUtils.getInstance(this.mContext).getTokenAsync("com.baidu", paramITokenCallback, paramActivity);
      return;
    }
    if (isLogin())
    {
      paramITokenCallback.onResult(blockingGetAuthToken());
      return;
    }
    if (paramOnUnLoginListener != null)
    {
      SapiHelper.getInstance().getAuthTokenAsync(paramITokenCallback);
      paramOnUnLoginListener.onUnLogin();
      return;
    }
    SapiHelper.getInstance().getAuthTokenAsync(paramITokenCallback, paramActivity, paramClass, paramInt);
  }

  public String getUserData(String paramString)
  {
    if ((paramString == null) || (paramString.trim().length() == 0))
      return null;
    if ((this.mSapiConfig.isEnableYi()) && (YiAccountUtils.getInstance(this.mContext).hasYiAccount()))
      return YiAccountUtils.getInstance(this.mContext).getUserData(paramString);
    return SapiHelper.getInstance().getUserData(paramString);
  }

  public boolean initial(Context paramContext, SapiConfig paramSapiConfig)
  {
    if ((paramContext == null) || (paramSapiConfig == null))
      throw new IllegalArgumentException();
    this.mSapiConfig = paramSapiConfig;
    this.mSapiConfig.setClientId(DeviceId.getDeviceID(paramContext));
    SapiHelper.getInstance().initial(paramContext, this.mSapiConfig);
    this.mContext = paramContext;
    return true;
  }

  public void invalidateAuthToken()
  {
    if ((this.mSapiConfig.isEnableYi()) && (YiAccountUtils.getInstance(this.mContext).hasYiAccount()))
    {
      if (isLogin())
        YiAccountUtils.getInstance(this.mContext).invalidateToken("com.baidu", blockingGetAuthToken());
      return;
    }
    SapiHelper.getInstance().invalidateAuthToken();
  }

  public boolean isLogin()
  {
    if ((this.mSapiConfig.isEnableYi()) && (YiAccountUtils.getInstance(this.mContext).hasYiAccount()))
      return YiAccountUtils.getInstance(this.mContext).isLogin();
    return SapiHelper.getInstance().isLogin();
  }

  public void logout()
  {
    if ((this.mSapiConfig.isEnableYi()) && (YiAccountUtils.getInstance(this.mContext).hasYiAccount()))
    {
      YiAccountUtils.getInstance(this.mContext).setAccount("com.baidu");
      return;
    }
    invalidateAuthToken();
    SapiHelper.getInstance().logout();
    SapiHelper.getInstance().invalidToken();
  }

  public void setFirstInstallLoginShareListener(IFirstInstallLoginShareListener paramIFirstInstallLoginShareListener)
  {
    SapiHelper.getInstance().setFirstInstallLoginShareListener(paramIFirstInstallLoginShareListener);
  }

  public void startFillNameActivity(Activity paramActivity, Class paramClass, int paramInt)
  {
    if ((this.mSapiConfig.isEnableYi()) && (YiAccountUtils.getInstance(this.mContext).hasYiAccount()))
    {
      YiAccountUtils.getInstance(this.mContext).startFillNameActivity(paramActivity, paramInt, false);
      return;
    }
    SapiHelper.getInstance().startFillNameActivity(paramActivity, paramClass, paramInt);
  }

  public void syncAccountToken(Token paramToken, String paramString)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("uid", paramString);
      paramToken.mJson = localJSONObject.toString();
      SapiHelper.getInstance().setToken(paramToken);
      SapiHelper.getInstance().valid();
      return;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
  }

  public static abstract interface OnUnLoginListener
  {
    public abstract void onUnLogin();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.BDAccountManager
 * JD-Core Version:    0.6.2
 */