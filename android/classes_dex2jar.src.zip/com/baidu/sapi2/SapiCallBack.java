package com.baidu.sapi2;

public abstract interface SapiCallBack
{
  public abstract void onEvent(int paramInt, Object paramObject);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.SapiCallBack
 * JD-Core Version:    0.6.2
 */