package com.baidu.sapi2.social.model;

public class FillUProfileResponse
{
  private String bduid;
  private String bduss;
  private String displayname;
  private int errorCode;
  private String errorMsg;
  private String ptoken;

  public FillUProfileResponse()
  {
    this.errorCode = -100;
    this.errorMsg = "";
    this.displayname = "";
    this.bduss = "";
    this.ptoken = "";
    this.bduid = "";
  }

  public FillUProfileResponse(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
  {
    this.errorCode = paramInt;
    this.errorMsg = paramString1;
    this.displayname = paramString2;
    this.bduss = paramString3;
    this.ptoken = paramString4;
    this.bduid = paramString7;
  }

  public String getBduid()
  {
    return this.bduid;
  }

  public String getBduss()
  {
    return this.bduss;
  }

  public String getDisplayname()
  {
    return this.displayname;
  }

  public int getErrorCode()
  {
    return this.errorCode;
  }

  public String getErrorMsg()
  {
    return this.errorMsg;
  }

  public String getPtoken()
  {
    return this.ptoken;
  }

  public void setBduid(String paramString)
  {
    this.bduid = paramString;
  }

  public void setBduss(String paramString)
  {
    this.bduss = paramString;
  }

  public void setDisplayname(String paramString)
  {
    this.displayname = paramString;
  }

  public void setErrorCode(int paramInt)
  {
    this.errorCode = paramInt;
  }

  public void setErrorMsg(String paramString)
  {
    this.errorMsg = paramString;
  }

  public void setPtoken(String paramString)
  {
    this.ptoken = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.model.FillUProfileResponse
 * JD-Core Version:    0.6.2
 */