package com.baidu.sapi2.social.model;

import com.baidu.sapi2.social.config.Sex;
import com.baidu.sapi2.social.config.SocialType;

public class SocialToken
{
  public String headURL;
  public boolean isBinded;
  public Sex sex;
  public SocialType type;
  public String username;

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("mUsername:");
    localStringBuffer.append(this.username);
    localStringBuffer.append("\n");
    localStringBuffer.append("isBinded:");
    localStringBuffer.append(this.isBinded);
    localStringBuffer.append("\n");
    localStringBuffer.append("sex:");
    localStringBuffer.append(this.sex.getName());
    localStringBuffer.append("\n");
    localStringBuffer.append("headURL:");
    localStringBuffer.append(this.headURL);
    localStringBuffer.append("\n");
    localStringBuffer.append("type:");
    localStringBuffer.append(this.type.getName());
    localStringBuffer.append("\n");
    return localStringBuffer.toString();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.model.SocialToken
 * JD-Core Version:    0.6.2
 */