package com.baidu.sapi2.social.model;

import com.baidu.sapi2.social.config.Sex;
import com.baidu.sapi2.social.config.SocialType;

public class SocialResponse
{
  private String baidu_uname;
  private String bduid;
  private String bduss;
  private String displayname;
  private int errorCode;
  private String errorMsg;
  private boolean isBinded;
  private String ptoken;
  private String social_headurl;
  private Sex social_sex;
  private SocialType social_type;
  private String social_uname;

  public SocialResponse()
  {
    this.errorCode = -100;
    this.errorMsg = "";
    this.displayname = "";
    this.bduid = "";
    this.ptoken = "";
    this.isBinded = false;
    this.bduss = "";
    this.baidu_uname = "";
    this.social_uname = "";
    this.social_sex = Sex.UNKNOWN;
    this.social_headurl = "";
    this.social_type = SocialType.UNKNOWN;
  }

  public SocialResponse(int paramInt, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean, String paramString5, String paramString6, String paramString7, Sex paramSex, String paramString8, SocialType paramSocialType)
  {
    this.errorCode = paramInt;
    this.errorMsg = paramString1;
    this.displayname = paramString2;
    this.bduid = paramString3;
    this.ptoken = paramString4;
    this.isBinded = paramBoolean;
    this.bduss = paramString5;
    this.baidu_uname = paramString6;
    this.social_uname = paramString7;
    this.social_sex = paramSex;
    this.social_headurl = paramString8;
    this.social_type = paramSocialType;
  }

  public String getBaidu_uname()
  {
    return this.baidu_uname;
  }

  public String getBduid()
  {
    return this.bduid;
  }

  public String getBduss()
  {
    return this.bduss;
  }

  public String getDisplayname()
  {
    return this.displayname;
  }

  public int getErrorCode()
  {
    return this.errorCode;
  }

  public String getErrorMsg()
  {
    return this.errorMsg;
  }

  public String getPtoken()
  {
    return this.ptoken;
  }

  public String getSocial_headurl()
  {
    return this.social_headurl;
  }

  public Sex getSocial_sex()
  {
    return this.social_sex;
  }

  public SocialType getSocial_type()
  {
    return this.social_type;
  }

  public String getSocial_uname()
  {
    return this.social_uname;
  }

  public boolean isBinded()
  {
    return this.isBinded;
  }

  public void setBaidu_uname(String paramString)
  {
    this.baidu_uname = paramString;
  }

  public void setBduid(String paramString)
  {
    this.bduid = paramString;
  }

  public void setBduss(String paramString)
  {
    this.bduss = paramString;
  }

  public void setBinded(boolean paramBoolean)
  {
    this.isBinded = paramBoolean;
  }

  public void setDisplayname(String paramString)
  {
    this.displayname = paramString;
  }

  public void setErrorCode(int paramInt)
  {
    this.errorCode = paramInt;
  }

  public void setErrorMsg(String paramString)
  {
    this.errorMsg = paramString;
  }

  public void setPtoken(String paramString)
  {
    this.ptoken = paramString;
  }

  public void setSocial_headurl(String paramString)
  {
    this.social_headurl = paramString;
  }

  public void setSocial_sex(Sex paramSex)
  {
    this.social_sex = paramSex;
  }

  public void setSocial_type(SocialType paramSocialType)
  {
    this.social_type = paramSocialType;
  }

  public void setSocial_uname(String paramString)
  {
    this.social_uname = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.model.SocialResponse
 * JD-Core Version:    0.6.2
 */