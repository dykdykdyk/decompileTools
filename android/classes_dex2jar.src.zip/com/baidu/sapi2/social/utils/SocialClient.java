package com.baidu.sapi2.social.utils;

import android.text.TextUtils;
import java.util.Iterator;
import java.util.List;
import org.apache.http.NameValuePair;

public class SocialClient
{
  private static volatile SocialClient socialClient = null;

  public static SocialClient getInstance()
  {
    if (socialClient == null);
    try
    {
      if (socialClient == null)
        socialClient = new SocialClient();
      return socialClient;
    }
    finally
    {
    }
  }

  public String createRequestParams(List<NameValuePair> paramList)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      NameValuePair localNameValuePair = (NameValuePair)localIterator.next();
      if ((!TextUtils.isEmpty(localNameValuePair.getName())) && (!TextUtils.isEmpty(localNameValuePair.getValue())))
        if (TextUtils.isEmpty(localStringBuffer.toString()))
          localStringBuffer.append(localNameValuePair.getName()).append("=").append(localNameValuePair.getValue());
        else
          localStringBuffer.append("&").append(localNameValuePair.getName()).append("=").append(localNameValuePair.getValue());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.utils.SocialClient
 * JD-Core Version:    0.6.2
 */