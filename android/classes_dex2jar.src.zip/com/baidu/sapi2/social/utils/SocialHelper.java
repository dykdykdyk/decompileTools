package com.baidu.sapi2.social.utils;

import android.content.Context;
import android.text.TextUtils;
import com.baidu.sapi2.SapiConfig;
import com.baidu.sapi2.SapiHelper;
import com.baidu.sapi2.log.Logger;
import com.baidu.sapi2.loginshare.Token;
import com.baidu.sapi2.social.config.BindType;
import com.baidu.sapi2.social.config.Display;
import com.baidu.sapi2.social.config.SocialType;
import com.baidu.sapi2.social.model.FillUProfileResponse;
import com.baidu.sapi2.social.model.SocialResponse;
import com.baidu.sapi2.social.model.SocialToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

public class SocialHelper
{
  private Token mToken;
  private SapiConfig sapiConfig = null;

  private String getMatcher(String paramString1, String paramString2)
  {
    String str = "";
    Matcher localMatcher = Pattern.compile(paramString1).matcher(paramString2);
    while (localMatcher.find())
      str = localMatcher.group().toString();
    return str;
  }

  public SocialResponse authResult(String paramString, SocialType paramSocialType)
  {
    SocialResponse localSocialResponse = SocialParser.parserAfterAuthResult(getMatcher("<client>([\\S\\s]*?)</client>", paramString), this.sapiConfig.getBindType().getCallbackPage());
    if (localSocialResponse != null)
    {
      if ((!TextUtils.isEmpty(localSocialResponse.getBduss())) && (!TextUtils.isEmpty(localSocialResponse.getPtoken())) && (localSocialResponse.getErrorCode() == -100))
        localSocialResponse.setErrorCode(0);
      SocialToken localSocialToken = new SocialToken();
      localSocialToken.isBinded = localSocialResponse.isBinded();
      localSocialToken.username = localSocialResponse.getSocial_uname();
      localSocialToken.sex = localSocialResponse.getSocial_sex();
      localSocialToken.headURL = localSocialResponse.getSocial_headurl();
      localSocialToken.type = localSocialResponse.getSocial_type();
      this.mToken = new Token();
      this.mToken.mDisplayname = localSocialResponse.getDisplayname();
      this.mToken.mBduss = localSocialResponse.getBduss();
      this.mToken.mPtoken = localSocialResponse.getPtoken();
      this.mToken.mUsername = localSocialResponse.getBaidu_uname();
      this.mToken.isSocialAccount = true;
      this.mToken.socialTokenMap.put(paramSocialType, localSocialToken);
    }
    while (true)
    {
      try
      {
        this.mToken.mJson = new JSONObject().put("uid", localSocialResponse.getBduid()).toString();
        if ((this.mToken != null) && (localSocialResponse.getErrorCode() == 0) && (!TextUtils.isEmpty(this.mToken.mBduss)) && (!TextUtils.isEmpty(this.mToken.mPtoken)))
        {
          SapiHelper.getInstance().setToken(this.mToken);
          SapiHelper.getInstance().valid();
        }
        return localSocialResponse;
      }
      catch (JSONException localJSONException)
      {
        this.mToken.mJson = "{}";
        Logger.w(localJSONException);
        continue;
      }
      this.mToken = null;
    }
  }

  public FillUProfileResponse fillUProfileResult(String paramString)
  {
    FillUProfileResponse localFillUProfileResponse = SocialParser.parserFillUProfileResult(getMatcher("<client>([\\S\\s]*?)</client>", paramString));
    JSONObject localJSONObject;
    if (localFillUProfileResponse != null)
    {
      if ((!TextUtils.isEmpty(localFillUProfileResponse.getBduss())) && (!TextUtils.isEmpty(localFillUProfileResponse.getPtoken())) && (localFillUProfileResponse.getErrorCode() == -100))
        localFillUProfileResponse.setErrorCode(0);
      this.mToken = new Token();
      this.mToken.mBduss = localFillUProfileResponse.getBduss();
      this.mToken.mPtoken = localFillUProfileResponse.getPtoken();
      this.mToken.mDisplayname = localFillUProfileResponse.getDisplayname();
      this.mToken.isSocialAccount = true;
      localJSONObject = new JSONObject();
    }
    try
    {
      localJSONObject.put("uid", localFillUProfileResponse.getBduid());
      this.mToken.mJson = localJSONObject.toString();
      if ((this.mToken != null) && (localFillUProfileResponse.getErrorCode() == 0) && (!TextUtils.isEmpty(this.mToken.mBduss)) && (!TextUtils.isEmpty(this.mToken.mPtoken)))
      {
        SapiHelper.getInstance().setToken(this.mToken);
        SapiHelper.getInstance().valid();
      }
      return localFillUProfileResponse;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        Logger.w(localJSONException);
    }
  }

  public String getUrlAfterAuth()
  {
    if (this.sapiConfig == null)
      return null;
    return this.sapiConfig.getDomanAfterAuth();
  }

  public String getUrlBind(SocialType paramSocialType)
  {
    if (this.sapiConfig == null)
      return null;
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(new BasicNameValuePair("tpl", this.sapiConfig.getTpl()));
    localArrayList.add(new BasicNameValuePair("display", Display.NATIVE.getName()));
    localArrayList.add(new BasicNameValuePair("type", paramSocialType.getType() + ""));
    localArrayList.add(new BasicNameValuePair("act", this.sapiConfig.getBindType().getName()));
    return this.sapiConfig.getDomanStart() + "?" + SocialClient.getInstance().createRequestParams(localArrayList);
  }

  public String getUrlBind(SocialType paramSocialType, String paramString1, String paramString2)
  {
    if (this.sapiConfig == null)
      return null;
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(new BasicNameValuePair("tpl", this.sapiConfig.getTpl()));
    localArrayList.add(new BasicNameValuePair("display", Display.NATIVE.getName()));
    localArrayList.add(new BasicNameValuePair("type", paramSocialType.getType() + ""));
    localArrayList.add(new BasicNameValuePair("act", this.sapiConfig.getBindType().getName()));
    localArrayList.add(new BasicNameValuePair("access_token", paramString1));
    localArrayList.add(new BasicNameValuePair("osuid", paramString2));
    return this.sapiConfig.getDomainSSOStart() + "?" + SocialClient.getInstance().createRequestParams(localArrayList);
  }

  public String getUrlFillFinish()
  {
    if (this.sapiConfig == null)
      return null;
    return this.sapiConfig.getDomanFillFinish();
  }

  public String getUrlFillStart()
  {
    if (this.sapiConfig == null)
      return null;
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(new BasicNameValuePair("tpl", this.sapiConfig.getTpl()));
    localArrayList.add(new BasicNameValuePair("showtype", "phone"));
    localArrayList.add(new BasicNameValuePair("device", "wap"));
    localArrayList.add(new BasicNameValuePair("adapter", "apps"));
    return this.sapiConfig.getDomanFillStart() + SocialClient.getInstance().createRequestParams(localArrayList);
  }

  public String getUrlFinishBind()
  {
    if (this.sapiConfig == null)
      return null;
    return this.sapiConfig.getDomanFinishBind();
  }

  public String getUrlSSOFinish()
  {
    if (this.sapiConfig == null)
      return null;
    return this.sapiConfig.getDomainSSOFinish();
  }

  public boolean initial(Context paramContext, SapiConfig paramSapiConfig)
  {
    if ((paramContext == null) || (paramSapiConfig == null))
      throw new IllegalArgumentException();
    this.sapiConfig = paramSapiConfig;
    this.mToken = new Token();
    return true;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.utils.SocialHelper
 * JD-Core Version:    0.6.2
 */