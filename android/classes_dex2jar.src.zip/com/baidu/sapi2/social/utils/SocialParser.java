package com.baidu.sapi2.social.utils;

public class SocialParser
{
  // ERROR //
  public static com.baidu.sapi2.social.model.SocialResponse parserAfterAuthResult(java.lang.String paramString1, java.lang.String paramString2)
  {
    // Byte code:
    //   0: invokestatic 18	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   3: astore_2
    //   4: aload_2
    //   5: new 20	java/io/ByteArrayInputStream
    //   8: dup
    //   9: aload_0
    //   10: invokevirtual 26	java/lang/String:getBytes	()[B
    //   13: invokespecial 29	java/io/ByteArrayInputStream:<init>	([B)V
    //   16: ldc 31
    //   18: invokeinterface 37 3 0
    //   23: aload_2
    //   24: invokeinterface 41 1 0
    //   29: istore 4
    //   31: aconst_null
    //   32: astore 5
    //   34: goto +563 -> 597
    //   37: aload_2
    //   38: invokeinterface 44 1 0
    //   43: istore 7
    //   45: iload 7
    //   47: istore 4
    //   49: aload 6
    //   51: astore 5
    //   53: goto +544 -> 597
    //   56: aload_2
    //   57: invokeinterface 48 1 0
    //   62: astore 9
    //   64: aload 9
    //   66: ldc 50
    //   68: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   71: ifeq +20 -> 91
    //   74: aload 5
    //   76: ifnonnull +552 -> 628
    //   79: new 56	com/baidu/sapi2/social/model/SocialResponse
    //   82: dup
    //   83: invokespecial 57	com/baidu/sapi2/social/model/SocialResponse:<init>	()V
    //   86: astore 6
    //   88: goto -51 -> 37
    //   91: aload 5
    //   93: ifnonnull +46 -> 139
    //   96: aload 9
    //   98: ldc 59
    //   100: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   103: ifeq +36 -> 139
    //   106: new 56	com/baidu/sapi2/social/model/SocialResponse
    //   109: dup
    //   110: invokespecial 57	com/baidu/sapi2/social/model/SocialResponse:<init>	()V
    //   113: astore 6
    //   115: aload 6
    //   117: aload_2
    //   118: invokeinterface 62 1 0
    //   123: invokestatic 68	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   126: invokevirtual 72	com/baidu/sapi2/social/model/SocialResponse:setErrorCode	(I)V
    //   129: goto -92 -> 37
    //   132: astore_3
    //   133: aload_3
    //   134: invokestatic 78	com/baidu/sapi2/log/Logger:w	(Ljava/lang/Throwable;)V
    //   137: aconst_null
    //   138: areturn
    //   139: aload 5
    //   141: ifnonnull +36 -> 177
    //   144: aload 9
    //   146: ldc 80
    //   148: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   151: ifeq +26 -> 177
    //   154: new 56	com/baidu/sapi2/social/model/SocialResponse
    //   157: dup
    //   158: invokespecial 57	com/baidu/sapi2/social/model/SocialResponse:<init>	()V
    //   161: astore 6
    //   163: aload 6
    //   165: aload_2
    //   166: invokeinterface 62 1 0
    //   171: invokevirtual 84	com/baidu/sapi2/social/model/SocialResponse:setErrorMsg	(Ljava/lang/String;)V
    //   174: goto -137 -> 37
    //   177: aload 5
    //   179: ifnull +449 -> 628
    //   182: aload 9
    //   184: ldc 59
    //   186: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   189: ifeq +24 -> 213
    //   192: aload 5
    //   194: aload_2
    //   195: invokeinterface 62 1 0
    //   200: invokestatic 68	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   203: invokevirtual 72	com/baidu/sapi2/social/model/SocialResponse:setErrorCode	(I)V
    //   206: aload 5
    //   208: astore 6
    //   210: goto -173 -> 37
    //   213: aload 9
    //   215: ldc 80
    //   217: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   220: ifeq +21 -> 241
    //   223: aload 5
    //   225: aload_2
    //   226: invokeinterface 62 1 0
    //   231: invokevirtual 84	com/baidu/sapi2/social/model/SocialResponse:setErrorMsg	(Ljava/lang/String;)V
    //   234: aload 5
    //   236: astore 6
    //   238: goto -201 -> 37
    //   241: aload 9
    //   243: ldc 86
    //   245: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   248: ifeq +34 -> 282
    //   251: aload_2
    //   252: invokeinterface 62 1 0
    //   257: ldc 88
    //   259: invokevirtual 92	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   262: ifeq +373 -> 635
    //   265: iconst_1
    //   266: istore 11
    //   268: aload 5
    //   270: iload 11
    //   272: invokevirtual 96	com/baidu/sapi2/social/model/SocialResponse:setBinded	(Z)V
    //   275: aload 5
    //   277: astore 6
    //   279: goto -242 -> 37
    //   282: aload 9
    //   284: ldc 98
    //   286: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   289: ifeq +21 -> 310
    //   292: aload 5
    //   294: aload_2
    //   295: invokeinterface 62 1 0
    //   300: invokevirtual 101	com/baidu/sapi2/social/model/SocialResponse:setDisplayname	(Ljava/lang/String;)V
    //   303: aload 5
    //   305: astore 6
    //   307: goto -270 -> 37
    //   310: aload 9
    //   312: ldc 103
    //   314: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   317: ifeq +21 -> 338
    //   320: aload 5
    //   322: aload_2
    //   323: invokeinterface 62 1 0
    //   328: invokevirtual 106	com/baidu/sapi2/social/model/SocialResponse:setBaidu_uname	(Ljava/lang/String;)V
    //   331: aload 5
    //   333: astore 6
    //   335: goto -298 -> 37
    //   338: aload 9
    //   340: ldc 108
    //   342: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   345: ifeq +21 -> 366
    //   348: aload 5
    //   350: aload_2
    //   351: invokeinterface 62 1 0
    //   356: invokevirtual 111	com/baidu/sapi2/social/model/SocialResponse:setBduid	(Ljava/lang/String;)V
    //   359: aload 5
    //   361: astore 6
    //   363: goto -326 -> 37
    //   366: aload 9
    //   368: ldc 113
    //   370: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   373: ifeq +21 -> 394
    //   376: aload 5
    //   378: aload_2
    //   379: invokeinterface 62 1 0
    //   384: invokevirtual 116	com/baidu/sapi2/social/model/SocialResponse:setBduss	(Ljava/lang/String;)V
    //   387: aload 5
    //   389: astore 6
    //   391: goto -354 -> 37
    //   394: aload 9
    //   396: ldc 118
    //   398: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   401: ifeq +21 -> 422
    //   404: aload 5
    //   406: aload_2
    //   407: invokeinterface 62 1 0
    //   412: invokevirtual 121	com/baidu/sapi2/social/model/SocialResponse:setPtoken	(Ljava/lang/String;)V
    //   415: aload 5
    //   417: astore 6
    //   419: goto -382 -> 37
    //   422: aload 9
    //   424: ldc 123
    //   426: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   429: ifeq +21 -> 450
    //   432: aload 5
    //   434: aload_2
    //   435: invokeinterface 62 1 0
    //   440: invokevirtual 126	com/baidu/sapi2/social/model/SocialResponse:setSocial_uname	(Ljava/lang/String;)V
    //   443: aload 5
    //   445: astore 6
    //   447: goto -410 -> 37
    //   450: aload 9
    //   452: ldc 128
    //   454: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   457: ifeq +61 -> 518
    //   460: aload_2
    //   461: invokeinterface 62 1 0
    //   466: astore 10
    //   468: aload 10
    //   470: ldc 130
    //   472: invokevirtual 92	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   475: ifne +23 -> 498
    //   478: aload 10
    //   480: ldc 88
    //   482: invokevirtual 92	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   485: ifne +13 -> 498
    //   488: aload 10
    //   490: ldc 132
    //   492: invokevirtual 92	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   495: ifeq +146 -> 641
    //   498: aload 5
    //   500: aload 10
    //   502: invokestatic 68	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   505: invokestatic 138	com/baidu/sapi2/social/config/Sex:getSex	(I)Lcom/baidu/sapi2/social/config/Sex;
    //   508: invokevirtual 142	com/baidu/sapi2/social/model/SocialResponse:setSocial_sex	(Lcom/baidu/sapi2/social/config/Sex;)V
    //   511: aload 5
    //   513: astore 6
    //   515: goto -478 -> 37
    //   518: aload 9
    //   520: ldc 144
    //   522: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   525: ifeq +21 -> 546
    //   528: aload 5
    //   530: aload_2
    //   531: invokeinterface 62 1 0
    //   536: invokevirtual 147	com/baidu/sapi2/social/model/SocialResponse:setSocial_headurl	(Ljava/lang/String;)V
    //   539: aload 5
    //   541: astore 6
    //   543: goto -506 -> 37
    //   546: aload 9
    //   548: ldc 149
    //   550: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   553: ifeq +75 -> 628
    //   556: aload 5
    //   558: aload_2
    //   559: invokeinterface 62 1 0
    //   564: invokestatic 68	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   567: invokestatic 155	com/baidu/sapi2/social/config/SocialType:getSocialType	(I)Lcom/baidu/sapi2/social/config/SocialType;
    //   570: invokevirtual 159	com/baidu/sapi2/social/model/SocialResponse:setSocial_type	(Lcom/baidu/sapi2/social/config/SocialType;)V
    //   573: aload 5
    //   575: astore 6
    //   577: goto -540 -> 37
    //   580: aload 5
    //   582: astore 6
    //   584: goto -547 -> 37
    //   587: aload 5
    //   589: areturn
    //   590: astore_3
    //   591: aload 5
    //   593: pop
    //   594: goto -461 -> 133
    //   597: iload 4
    //   599: iconst_1
    //   600: if_icmpeq -13 -> 587
    //   603: iload 4
    //   605: tableswitch	default:+23 -> 628, 2:+-549->56, 3:+-25->580
    //   629: iconst_2
    //   630: astore 6
    //   632: goto -595 -> 37
    //   635: iconst_0
    //   636: istore 11
    //   638: goto -370 -> 268
    //   641: ldc 130
    //   643: astore 10
    //   645: goto -147 -> 498
    //
    // Exception table:
    //   from	to	target	type
    //   4	31	132	java/lang/Exception
    //   37	45	132	java/lang/Exception
    //   115	129	132	java/lang/Exception
    //   163	174	132	java/lang/Exception
    //   56	74	590	java/lang/Exception
    //   79	88	590	java/lang/Exception
    //   96	115	590	java/lang/Exception
    //   144	163	590	java/lang/Exception
    //   182	206	590	java/lang/Exception
    //   213	234	590	java/lang/Exception
    //   241	265	590	java/lang/Exception
    //   268	275	590	java/lang/Exception
    //   282	303	590	java/lang/Exception
    //   310	331	590	java/lang/Exception
    //   338	359	590	java/lang/Exception
    //   366	387	590	java/lang/Exception
    //   394	415	590	java/lang/Exception
    //   422	443	590	java/lang/Exception
    //   450	498	590	java/lang/Exception
    //   498	511	590	java/lang/Exception
    //   518	539	590	java/lang/Exception
    //   546	573	590	java/lang/Exception
  }

  // ERROR //
  public static com.baidu.sapi2.social.model.FillUProfileResponse parserFillUProfileResult(java.lang.String paramString)
  {
    // Byte code:
    //   0: invokestatic 18	android/util/Xml:newPullParser	()Lorg/xmlpull/v1/XmlPullParser;
    //   3: astore_1
    //   4: aload_1
    //   5: new 20	java/io/ByteArrayInputStream
    //   8: dup
    //   9: aload_0
    //   10: invokevirtual 26	java/lang/String:getBytes	()[B
    //   13: invokespecial 29	java/io/ByteArrayInputStream:<init>	([B)V
    //   16: ldc 31
    //   18: invokeinterface 37 3 0
    //   23: aload_1
    //   24: invokeinterface 41 1 0
    //   29: istore_3
    //   30: aconst_null
    //   31: astore 4
    //   33: goto +335 -> 368
    //   36: aload_1
    //   37: invokeinterface 44 1 0
    //   42: istore 6
    //   44: iload 6
    //   46: istore_3
    //   47: aload 5
    //   49: astore 4
    //   51: goto +317 -> 368
    //   54: aload_1
    //   55: invokeinterface 48 1 0
    //   60: astore 8
    //   62: aload 8
    //   64: ldc 50
    //   66: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   69: ifeq +20 -> 89
    //   72: aload 4
    //   74: ifnonnull +322 -> 396
    //   77: new 163	com/baidu/sapi2/social/model/FillUProfileResponse
    //   80: dup
    //   81: invokespecial 164	com/baidu/sapi2/social/model/FillUProfileResponse:<init>	()V
    //   84: astore 5
    //   86: goto -50 -> 36
    //   89: aload 4
    //   91: ifnonnull +46 -> 137
    //   94: aload 8
    //   96: ldc 59
    //   98: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   101: ifeq +36 -> 137
    //   104: new 163	com/baidu/sapi2/social/model/FillUProfileResponse
    //   107: dup
    //   108: invokespecial 164	com/baidu/sapi2/social/model/FillUProfileResponse:<init>	()V
    //   111: astore 5
    //   113: aload 5
    //   115: aload_1
    //   116: invokeinterface 62 1 0
    //   121: invokestatic 68	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   124: invokevirtual 165	com/baidu/sapi2/social/model/FillUProfileResponse:setErrorCode	(I)V
    //   127: goto -91 -> 36
    //   130: astore_2
    //   131: aload_2
    //   132: invokestatic 78	com/baidu/sapi2/log/Logger:w	(Ljava/lang/Throwable;)V
    //   135: aconst_null
    //   136: areturn
    //   137: aload 4
    //   139: ifnonnull +36 -> 175
    //   142: aload 8
    //   144: ldc 80
    //   146: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   149: ifeq +26 -> 175
    //   152: new 163	com/baidu/sapi2/social/model/FillUProfileResponse
    //   155: dup
    //   156: invokespecial 164	com/baidu/sapi2/social/model/FillUProfileResponse:<init>	()V
    //   159: astore 5
    //   161: aload 5
    //   163: aload_1
    //   164: invokeinterface 62 1 0
    //   169: invokevirtual 166	com/baidu/sapi2/social/model/FillUProfileResponse:setErrorMsg	(Ljava/lang/String;)V
    //   172: goto -136 -> 36
    //   175: aload 4
    //   177: ifnull +219 -> 396
    //   180: aload 8
    //   182: ldc 168
    //   184: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   187: ifeq +24 -> 211
    //   190: aload 4
    //   192: aload_1
    //   193: invokeinterface 62 1 0
    //   198: invokestatic 68	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   201: invokevirtual 165	com/baidu/sapi2/social/model/FillUProfileResponse:setErrorCode	(I)V
    //   204: aload 4
    //   206: astore 5
    //   208: goto -172 -> 36
    //   211: aload 8
    //   213: ldc 170
    //   215: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   218: ifeq +21 -> 239
    //   221: aload 4
    //   223: aload_1
    //   224: invokeinterface 62 1 0
    //   229: invokevirtual 166	com/baidu/sapi2/social/model/FillUProfileResponse:setErrorMsg	(Ljava/lang/String;)V
    //   232: aload 4
    //   234: astore 5
    //   236: goto -200 -> 36
    //   239: aload 8
    //   241: ldc 113
    //   243: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   246: ifeq +21 -> 267
    //   249: aload 4
    //   251: aload_1
    //   252: invokeinterface 62 1 0
    //   257: invokevirtual 171	com/baidu/sapi2/social/model/FillUProfileResponse:setBduss	(Ljava/lang/String;)V
    //   260: aload 4
    //   262: astore 5
    //   264: goto -228 -> 36
    //   267: aload 8
    //   269: ldc 118
    //   271: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   274: ifeq +21 -> 295
    //   277: aload 4
    //   279: aload_1
    //   280: invokeinterface 62 1 0
    //   285: invokevirtual 172	com/baidu/sapi2/social/model/FillUProfileResponse:setPtoken	(Ljava/lang/String;)V
    //   288: aload 4
    //   290: astore 5
    //   292: goto -256 -> 36
    //   295: aload 8
    //   297: ldc 174
    //   299: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   302: ifeq +21 -> 323
    //   305: aload 4
    //   307: aload_1
    //   308: invokeinterface 62 1 0
    //   313: invokevirtual 175	com/baidu/sapi2/social/model/FillUProfileResponse:setDisplayname	(Ljava/lang/String;)V
    //   316: aload 4
    //   318: astore 5
    //   320: goto -284 -> 36
    //   323: aload 8
    //   325: ldc 177
    //   327: invokevirtual 54	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   330: ifeq +66 -> 396
    //   333: aload 4
    //   335: aload_1
    //   336: invokeinterface 62 1 0
    //   341: invokevirtual 178	com/baidu/sapi2/social/model/FillUProfileResponse:setBduid	(Ljava/lang/String;)V
    //   344: aload 4
    //   346: astore 5
    //   348: goto -312 -> 36
    //   351: aload 4
    //   353: astore 5
    //   355: goto -319 -> 36
    //   358: aload 4
    //   360: areturn
    //   361: astore_2
    //   362: aload 4
    //   364: pop
    //   365: goto -234 -> 131
    //   368: iload_3
    //   369: iconst_1
    //   370: if_icmpeq -12 -> 358
    //   373: iload_3
    //   374: tableswitch	default:+22 -> 396, 2:+-320->54, 3:+-23->351
    //   397: iconst_1
    //   398: astore 5
    //   400: goto -364 -> 36
    //
    // Exception table:
    //   from	to	target	type
    //   4	30	130	java/lang/Exception
    //   36	44	130	java/lang/Exception
    //   113	127	130	java/lang/Exception
    //   161	172	130	java/lang/Exception
    //   54	72	361	java/lang/Exception
    //   77	86	361	java/lang/Exception
    //   94	113	361	java/lang/Exception
    //   142	161	361	java/lang/Exception
    //   180	204	361	java/lang/Exception
    //   211	232	361	java/lang/Exception
    //   239	260	361	java/lang/Exception
    //   267	288	361	java/lang/Exception
    //   295	316	361	java/lang/Exception
    //   323	344	361	java/lang/Exception
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.utils.SocialParser
 * JD-Core Version:    0.6.2
 */