package com.baidu.sapi2.social.config;

public enum Sex
{
  private String name;
  private int sexType;

  static
  {
    MALE = new Sex("MALE", 1, 1, "男");
    FEMALE = new Sex("FEMALE", 2, 2, "女");
    Sex[] arrayOfSex = new Sex[3];
    arrayOfSex[0] = UNKNOWN;
    arrayOfSex[1] = MALE;
    arrayOfSex[2] = FEMALE;
  }

  private Sex(int paramInt, String paramString)
  {
    this.sexType = paramInt;
    this.name = paramString;
  }

  public static Sex getSex(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return UNKNOWN;
    case 1:
      return MALE;
    case 2:
    }
    return FEMALE;
  }

  public String getName()
  {
    return this.name;
  }

  public int getSexType()
  {
    return this.sexType;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.config.Sex
 * JD-Core Version:    0.6.2
 */