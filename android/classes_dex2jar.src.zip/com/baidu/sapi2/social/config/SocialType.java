package com.baidu.sapi2.social.config;

public enum SocialType
{
  private String name;
  private int type;

  static
  {
    RENREN = new SocialType("RENREN", 1, 1, "人人");
    SINA_WEIBO = new SocialType("SINA_WEIBO", 2, 2, "新浪微博");
    TENCENT_WEIBO = new SocialType("TENCENT_WEIBO", 3, 4, "腾讯微博");
    QZONE = new SocialType("QZONE", 4, 15, "QQ空间");
    QQ = new SocialType("QQ", 5, 15, "QQ");
    FEIXIN = new SocialType("FEIXIN", 6, 16, "飞信");
    SocialType[] arrayOfSocialType = new SocialType[7];
    arrayOfSocialType[0] = UNKNOWN;
    arrayOfSocialType[1] = RENREN;
    arrayOfSocialType[2] = SINA_WEIBO;
    arrayOfSocialType[3] = TENCENT_WEIBO;
    arrayOfSocialType[4] = QZONE;
    arrayOfSocialType[5] = QQ;
    arrayOfSocialType[6] = FEIXIN;
  }

  private SocialType(int paramInt, String paramString)
  {
    this.type = paramInt;
    this.name = paramString;
  }

  public static SocialType getSocialType(int paramInt)
  {
    switch (paramInt)
    {
    default:
      return UNKNOWN;
    case 1:
      return RENREN;
    case 2:
      return SINA_WEIBO;
    case 4:
      return TENCENT_WEIBO;
    case 15:
      return QQ;
    case 16:
    }
    return FEIXIN;
  }

  public String getName()
  {
    return this.name;
  }

  public int getType()
  {
    return this.type;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.config.SocialType
 * JD-Core Version:    0.6.2
 */