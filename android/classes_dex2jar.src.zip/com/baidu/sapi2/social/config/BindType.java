package com.baidu.sapi2.social.config;

public enum BindType
{
  private String callbackPage;
  private String finishBindPage;
  private String name = "";

  static
  {
    IMPLICIT = new BindType("IMPLICIT", 2, "implicit", "afterauth", "afterauth");
    BindType[] arrayOfBindType = new BindType[3];
    arrayOfBindType[0] = EXPLICIT;
    arrayOfBindType[1] = OPTIONAL;
    arrayOfBindType[2] = IMPLICIT;
  }

  private BindType(String paramString1, String paramString2, String paramString3)
  {
    this.name = paramString1;
    this.callbackPage = paramString2;
    this.finishBindPage = paramString3;
  }

  public String getCallbackPage()
  {
    return this.callbackPage;
  }

  public String getFinishBindPage()
  {
    return this.finishBindPage;
  }

  public String getName()
  {
    return this.name;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.config.BindType
 * JD-Core Version:    0.6.2
 */