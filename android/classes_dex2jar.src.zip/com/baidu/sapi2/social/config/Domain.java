package com.baidu.sapi2.social.config;

public enum Domain
{
  private String deviceUrl;
  private String url;
  private String wap;

  static
  {
    DOMAIN_QA = new Domain("DOMAIN_QA", 2, "http://passport.qatest.baidu.com", "http://wappass.qatest.baidu.com", "http://db-infbk-online-17.db01.baidu.com:8080");
    Domain[] arrayOfDomain = new Domain[3];
    arrayOfDomain[0] = DOMAIN_ONLINE;
    arrayOfDomain[1] = DOMAIN_RD;
    arrayOfDomain[2] = DOMAIN_QA;
  }

  private Domain(String paramString1, String paramString2, String paramString3)
  {
    this.url = paramString1;
    this.wap = paramString2;
    this.deviceUrl = paramString3;
  }

  public String getDeviceUrl()
  {
    return this.deviceUrl;
  }

  public String getURL()
  {
    return this.url;
  }

  public String getWap()
  {
    return this.wap;
  }

  public void setURL(String paramString)
  {
    this.url = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.config.Domain
 * JD-Core Version:    0.6.2
 */