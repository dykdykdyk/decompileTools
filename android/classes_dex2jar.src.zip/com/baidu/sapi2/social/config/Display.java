package com.baidu.sapi2.social.config;

public enum Display
{
  private String name;

  static
  {
    Display[] arrayOfDisplay = new Display[1];
    arrayOfDisplay[0] = NATIVE;
  }

  private Display(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.social.config.Display
 * JD-Core Version:    0.6.2
 */