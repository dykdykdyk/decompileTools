package com.baidu.sapi2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import com.baidu.sapi2.log.Logger;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;

public class Utils
{
  public static String createDeviceID(Context paramContext)
  {
    return md5Encode(getIMEI(paramContext) + getMac(paramContext)).replace("\n", "");
  }

  public static String createDeviceInfo()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("os_version=").append(getOSVersion()).append("&brand_name=").append(getBrandName()).append("&brand_model=").append(getBrandMode()).append("&os_type=").append("Android");
    return localStringBuffer.toString();
  }

  private static String getBrandMode()
  {
    try
    {
      if (TextUtils.isEmpty(Build.MODEL));
      for (String str = ""; ; str = Build.MODEL)
        return URLEncoder.encode(str, "UTF-8");
    }
    catch (Exception localException)
    {
    }
    return "";
  }

  private static String getBrandName()
  {
    try
    {
      if (TextUtils.isEmpty(Build.BRAND));
      for (String str = ""; ; str = Build.BRAND)
        return URLEncoder.encode(str, "UTF-8");
    }
    catch (Exception localException)
    {
    }
    return "";
  }

  public static String getIMEI(Context paramContext)
  {
    return ((TelephonyManager)paramContext.getSystemService("phone")).getDeviceId();
  }

  public static String getMac(Context paramContext)
  {
    try
    {
      WifiInfo localWifiInfo = ((WifiManager)paramContext.getSystemService("wifi")).getConnectionInfo();
      if (TextUtils.isEmpty(localWifiInfo.getMacAddress()))
        return "";
      String str = localWifiInfo.getMacAddress();
      return str;
    }
    catch (Exception localException)
    {
    }
    return "";
  }

  private static String getOSVersion()
  {
    try
    {
      if (TextUtils.isEmpty(Build.VERSION.RELEASE));
      for (String str = ""; ; str = Build.VERSION.RELEASE)
        return URLEncoder.encode(str, "UTF-8");
    }
    catch (Exception localException)
    {
    }
    return "";
  }

  public static void hideInputMethod(Activity paramActivity)
  {
    if (paramActivity == null);
    InputMethodManager localInputMethodManager;
    do
    {
      return;
      localInputMethodManager = (InputMethodManager)paramActivity.getSystemService("input_method");
    }
    while (paramActivity.getCurrentFocus() == null);
    localInputMethodManager.hideSoftInputFromWindow(paramActivity.getCurrentFocus().getWindowToken(), 0);
  }

  public static boolean isValid(String paramString)
  {
    return (paramString != null) && (paramString.length() > 0);
  }

  public static boolean isValidEmail(String paramString)
  {
    if (isValid(paramString))
      return Pattern.matches("^\\s*\\w+(?:\\.{0,1}[\\w-]+)*@[a-zA-Z0-9]+(?:[-.][a-zA-Z0-9]+)*\\.[a-zA-Z]+\\s*$", paramString);
    return false;
  }

  public static boolean isValidPassword(String paramString)
  {
    return (paramString != null) && (paramString.length() >= 2) && (paramString.length() <= 14);
  }

  public static boolean isValidPhone(String paramString)
  {
    return (paramString != null) && (paramString.length() > 0);
  }

  public static boolean isValidSmsCode(String paramString)
  {
    return (paramString != null) && (paramString.length() == 6);
  }

  public static boolean isValidUsername(String paramString)
  {
    boolean bool1 = false;
    if (paramString != null)
    {
      boolean bool2 = paramString.equals("");
      bool1 = false;
      if (!bool2)
      {
        int i = paramString.length();
        bool1 = false;
        if (i <= 14)
          bool1 = true;
      }
    }
    return bool1;
  }

  public static String md5Encode(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(paramString.getBytes());
      byte[] arrayOfByte = localMessageDigest.digest();
      for (int i = 0; i < arrayOfByte.length; i++)
      {
        String str = Integer.toHexString(0xFF & arrayOfByte[i]);
        if (str.length() == 1)
          localStringBuffer.append("0");
        localStringBuffer.append(str);
      }
    }
    catch (Exception localException)
    {
    }
    return localStringBuffer.toString();
  }

  public static String md5sLogin(String paramString)
  {
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(paramString.getBytes("GBK"));
      byte[] arrayOfByte = localMessageDigest.digest();
      StringBuffer localStringBuffer = new StringBuffer("");
      for (int i = 0; i < arrayOfByte.length; i++)
      {
        int j = arrayOfByte[i];
        if (j < 0)
          j += 256;
        if (j < 16)
          localStringBuffer.append("0");
        localStringBuffer.append(Integer.toHexString(j));
      }
      String str = localStringBuffer.toString();
      return str;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      return null;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      Logger.w(localUnsupportedEncodingException);
    }
    return null;
  }

  public static void showInputMethod(Activity paramActivity)
  {
    if (paramActivity == null);
    InputMethodManager localInputMethodManager;
    do
    {
      return;
      localInputMethodManager = (InputMethodManager)paramActivity.getSystemService("input_method");
    }
    while (paramActivity.getCurrentFocus() == null);
    localInputMethodManager.showSoftInput(paramActivity.getCurrentFocus(), 0);
  }

  public static boolean startWap(String paramString, Context paramContext)
  {
    try
    {
      paramContext.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(paramString)));
      return true;
    }
    catch (Exception localException)
    {
    }
    return false;
  }

  public static String toGbk(String paramString)
  {
    try
    {
      String str = URLEncoder.encode(paramString, "GBK");
      return str;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
    }
    return null;
  }

  public static String utf8Togb2312(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 0;
    if (i < paramString.length())
    {
      char c = paramString.charAt(i);
      switch (c)
      {
      default:
        localStringBuffer.append(c);
      case '+':
      case '%':
      }
      while (true)
      {
        i++;
        break;
        localStringBuffer.append(' ');
        continue;
        int j = i + 1;
        int k = i + 3;
        try
        {
          localStringBuffer.append((char)Integer.parseInt(paramString.substring(j, k), 16));
          i += 2;
        }
        catch (NumberFormatException localNumberFormatException)
        {
          throw new IllegalArgumentException();
        }
      }
    }
    String str1 = localStringBuffer.toString();
    try
    {
      String str2 = new String(str1.getBytes("8859_1"), "UTF-8");
      return str2;
    }
    catch (Exception localException)
    {
    }
    return null;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.Utils
 * JD-Core Version:    0.6.2
 */