package com.baidu.sapi2;

import android.app.Application;
import com.baidu.sapi2.social.config.BindType;
import com.baidu.sapi2.social.config.Domain;

public class SapiApplication extends Application
{
  public void onCreate()
  {
    super.onCreate();
    SapiConfig localSapiConfig = new SapiConfig("iknow", "2", "e56b4eb0473d219c5317afb7ccf66e8f", Domain.DOMAIN_ONLINE, BindType.IMPLICIT);
    localSapiConfig.setDevicePackageSign("12345");
    BDAccountManager.getInstance().initial(getApplicationContext(), localSapiConfig);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.SapiApplication
 * JD-Core Version:    0.6.2
 */