package com.baidu.sapi2;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class DeviceCrypto
{
  private static final String AES_ALGORITHM = "AES";
  private static final String DEFAULT_ENCODEING = "UTF-8";
  private static final int IVS_LENGTH = 16;
  private static final int KEY_LENGTH = 16;
  private static final String MD5_ALGORITHM = "MD5";

  public static String AES128Decrypt(String paramString1, String paramString2)
  {
    try
    {
      String str1 = getHexString(getMd5DigestFormStr(paramString2.trim()));
      String str2 = str1.substring(0, 16);
      String str3 = new StringBuffer(str1.substring(0, 16)).reverse().toString();
      Cipher localCipher = Cipher.getInstance(CppUtils.nativeGetDeviceAESMode());
      localCipher.init(2, new SecretKeySpec(str2.getBytes("UTF-8"), "AES"), new IvParameterSpec(str3.getBytes("UTF-8")));
      String str4 = base64Encode(localCipher.doFinal(paddingBlock(paramString1.getBytes("UTF-8"))));
      return str4;
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public static String AES128Encrypt(String paramString1, String paramString2)
  {
    try
    {
      String str1 = getHexString(getMd5DigestFormStr(paramString2.trim()));
      String str2 = str1.substring(0, 16);
      String str3 = new StringBuffer(str1.substring(0, 16)).reverse().toString();
      Cipher localCipher = Cipher.getInstance(CppUtils.nativeGetDeviceAESMode());
      localCipher.init(1, new SecretKeySpec(str2.getBytes("UTF-8"), "AES"), new IvParameterSpec(str3.getBytes("UTF-8")));
      String str4 = base64Encode(localCipher.doFinal(paddingBlock(paramString1.getBytes("UTF-8"))));
      return str4;
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  private static String base64Encode(byte[] paramArrayOfByte)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = 0;
    int j = 6;
    int k = 0;
    int m = 0;
    int n = 8 * paramArrayOfByte.length;
    int i1 = 0;
    if ((i > 0) && (j > 0))
    {
      i1 = (byte)(0x3F & (byte)((0xFF & paramArrayOfByte[k]) << j | (0xFF & paramArrayOfByte[(k + 1)]) >> 8 - j));
      i = 8 - j;
      j = 6 - i;
    }
    while (true)
    {
      localStringBuilder.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(i1));
      m += 6;
      k = m / 8;
      int i2 = n - m;
      if (i2 >= 6)
        break;
      if (i2 > 0)
        localStringBuilder.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt((byte)(0x3F & paramArrayOfByte[(-1 + paramArrayOfByte.length)] << 6 - i2)));
      int i3 = n % 3;
      for (int i4 = 0; i4 < i3; i4++)
        localStringBuilder.append("=");
      if (i == 0)
      {
        i1 = (byte)((0xFF & paramArrayOfByte[k]) >> 8 - j);
        i = 2;
        j = 4;
      }
      else if (j == 0)
      {
        i1 = (byte)(0x3F & paramArrayOfByte[k]);
        j = 6;
        i = 0;
      }
    }
    return localStringBuilder.toString();
  }

  public static String encryptDeviceId(String paramString)
  {
    String str1 = CppUtils.nativeGetDeviceKey();
    try
    {
      String str2 = base64Encode(paramString.getBytes("UTF-8"));
      String str3 = getHexString(getMd5DigestFormStr(str2 + str1));
      String str4 = AES128Encrypt(str2 + "." + str3, str1);
      return str4;
    }
    catch (Exception localException)
    {
    }
    return null;
  }

  public static String getHexString(byte[] paramArrayOfByte)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    for (int i = 0; i < paramArrayOfByte.length; i++)
      localStringBuilder.append(Integer.toString(256 + (0xFF & paramArrayOfByte[i]), 16).substring(1));
    return localStringBuilder.toString();
  }

  private static byte[] getMd5DigestFormStr(String paramString)
  {
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(paramString.getBytes());
      byte[] arrayOfByte = localMessageDigest.digest();
      return arrayOfByte;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
    }
    return null;
  }

  private static byte[] paddingBlock(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length % 16 != 0)
    {
      arrayOfByte = new byte[16 * (1 + paramArrayOfByte.length / 16)];
      for (int i = 0; i < paramArrayOfByte.length; i++)
        arrayOfByte[i] = paramArrayOfByte[i];
      for (int j = paramArrayOfByte.length; j < arrayOfByte.length; j++)
        arrayOfByte[j] = 0;
    }
    byte[] arrayOfByte = paramArrayOfByte;
    return arrayOfByte;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.sapi2.DeviceCrypto
 * JD-Core Version:    0.6.2
 */