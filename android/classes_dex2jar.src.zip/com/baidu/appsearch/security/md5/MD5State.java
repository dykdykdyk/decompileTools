package com.baidu.appsearch.security.md5;

class MD5State
{
  byte[] buffer = new byte[64];
  long count = 0L;
  int[] state = new int[4];

  public MD5State()
  {
    this.state[0] = 1732584193;
    this.state[1] = -271733879;
    this.state[2] = -1732584194;
    this.state[3] = 271733878;
  }

  public MD5State(MD5State paramMD5State)
  {
    this();
    int i = 0;
    if (i >= this.buffer.length);
    for (int j = 0; ; j++)
    {
      if (j >= this.state.length)
      {
        this.count = paramMD5State.count;
        return;
        this.buffer[i] = paramMD5State.buffer[i];
        i++;
        break;
      }
      this.state[j] = paramMD5State.state[j];
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.appsearch.security.md5.MD5State
 * JD-Core Version:    0.6.2
 */