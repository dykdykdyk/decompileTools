package com.baidu.appsearch.security.md5;

import android.util.Log;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;

public class MD5InputStream extends FilterInputStream
{
  private MD5 md5 = new MD5();

  public MD5InputStream(InputStream paramInputStream)
  {
    super(paramInputStream);
  }

  public static void main(String[] paramArrayOfString)
  {
    while (true)
    {
      String str;
      int j;
      int k;
      byte[] arrayOfByte;
      try
      {
        str = paramArrayOfString[(-1 + paramArrayOfString.length)];
        int i = 0;
        j = 1;
        k = 0;
        MessageDigest localMessageDigest;
        int m;
        if (k >= -1 + paramArrayOfString.length)
        {
          arrayOfByte = new byte[65536];
          if (i == 0)
            break label133;
          BufferedInputStream localBufferedInputStream = new BufferedInputStream(new FileInputStream(str));
          localMessageDigest = MessageDigest.getInstance("MD5");
          m = localBufferedInputStream.read(arrayOfByte);
          if (m == -1)
            localBufferedInputStream.close();
        }
        else
        {
          if (paramArrayOfString[k].equals("--use-default-md5"))
          {
            i = 1;
            break label184;
          }
          if (!paramArrayOfString[k].equals("--no-native-lib"))
            break label184;
          j = 0;
          break label184;
        }
        localMessageDigest.update(arrayOfByte, 0, m);
        continue;
      }
      catch (Exception localException)
      {
        localException.printStackTrace();
        return;
      }
      label133: if (j == 0)
        MD5.initNativeLibrary(true);
      MD5InputStream localMD5InputStream = new MD5InputStream(new BufferedInputStream(new FileInputStream(str)));
      while (localMD5InputStream.read(arrayOfByte) != -1);
      localMD5InputStream.close();
      return;
      label184: k++;
    }
  }

  public MD5 getMD5()
  {
    return this.md5;
  }

  public byte[] hash()
  {
    return this.md5.finalEncode();
  }

  public int read()
    throws IOException
  {
    int i = this.in.read();
    if (i == -1)
      return -1;
    if ((i & 0xFFFFFF00) != 0)
    {
      Log.i("MD5InputStream", "MD5InputStream.read() got character with (c & ~0xff) != 0)!");
      return i;
    }
    this.md5.update(i);
    return i;
  }

  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
    if (i == -1)
      return i;
    this.md5.update(paramArrayOfByte, paramInt1, i);
    return i;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.appsearch.security.md5.MD5InputStream
 * JD-Core Version:    0.6.2
 */