package com.baidu.feedback.sdk.android.api;

import android.content.Context;
import com.baidu.feedback.sdk.android.model.CategoryResult;
import com.baidu.feedback.sdk.android.model.Content;
import com.baidu.feedback.sdk.android.model.ProducUserParam;
import com.baidu.feedback.sdk.android.model.ReplyResult;
import com.baidu.feedback.sdk.android.model.Result;
import com.baidu.feedback.sdk.android.model.SubSucResult;
import com.baidu.feedback.sdk.android.model.SummitResult;
import com.baidu.feedback.sdk.android.model.TmpMarkResult;
import com.baidu.feedback.sdk.android.network.HttpReqFeedback;
import com.baidu.feedback.sdk.android.network.HttpService;
import com.baidu.feedback.sdk.android.network.ReqParam;
import com.baidu.feedback.sdk.android.util.Location;
import java.util.List;

public class FeedbackAPI
{
  private static FeedbackAPI mFeedbackAPI;

  private Result extracted(HttpReqFeedback paramHttpReqFeedback)
  {
    return HttpService.getInstance().addImmediateReq(paramHttpReqFeedback);
  }

  public static FeedbackAPI getInstance()
  {
    if (mFeedbackAPI == null)
      mFeedbackAPI = new FeedbackAPI();
    return mFeedbackAPI;
  }

  public void destroy()
  {
    if (mFeedbackAPI != null)
      mFeedbackAPI = null;
    Location.getInstance().Destroy();
    HttpService.getInstance().Destroy();
  }

  public CategoryResult getCategory(Context paramContext, String paramString)
  {
    return (CategoryResult)extracted(new HttpReqFeedback(paramContext, new ReqParam(paramContext, paramString, "getCategory")));
  }

  public TmpMarkResult getMark(Context paramContext, String paramString)
  {
    return (TmpMarkResult)extracted(new HttpReqFeedback(paramContext, new ReqParam(paramContext, paramString, "getMark")));
  }

  public ReplyResult getReply(Context paramContext, ProducUserParam paramProducUserParam)
  {
    return (ReplyResult)extracted(new HttpReqFeedback(paramContext, new ReqParam(paramContext, paramProducUserParam, "getReply")));
  }

  public SummitResult submitFeedback(Context paramContext, Content paramContent, ProducUserParam paramProducUserParam)
  {
    return (SummitResult)extracted(new HttpReqFeedback(paramContext, new ReqParam(paramContext, paramContent, paramProducUserParam, "submit")));
  }

  public SubSucResult submitSuccess(Context paramContext, String paramString, List<Integer> paramList)
  {
    return (SubSucResult)extracted(new HttpReqFeedback(paramContext, new ReqParam(paramContext, paramString, paramList, "submitSuccess")));
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.api.FeedbackAPI
 * JD-Core Version:    0.6.2
 */