package com.baidu.feedback.sdk.android.model;

import java.io.Serializable;

public class ProducUserParam
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String productBuildVersion;
  private String productName;
  private String productUpdateDate;
  private String productVersion;
  private String uid;
  private String userName;

  public String getProductBuildVersion()
  {
    return this.productBuildVersion;
  }

  public String getProductName()
  {
    return this.productName;
  }

  public String getProductUpdateDate()
  {
    return this.productUpdateDate;
  }

  public String getProductVersion()
  {
    return this.productVersion;
  }

  public String getUid()
  {
    return this.uid;
  }

  public String getUserName()
  {
    return this.userName;
  }

  public void setProductBuildVersion(String paramString)
  {
    this.productBuildVersion = paramString;
  }

  public void setProductName(String paramString)
  {
    this.productName = paramString;
  }

  public void setProductUpdateDate(String paramString)
  {
    this.productUpdateDate = paramString;
  }

  public void setProductVersion(String paramString)
  {
    this.productVersion = paramString;
  }

  public void setUid(String paramString)
  {
    this.uid = paramString;
  }

  public void setUserName(String paramString)
  {
    this.userName = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.ProducUserParam
 * JD-Core Version:    0.6.2
 */