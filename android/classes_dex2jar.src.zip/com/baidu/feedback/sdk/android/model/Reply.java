package com.baidu.feedback.sdk.android.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Reply
  implements Serializable
{
  public static String FB_CUSTOMER_MANAGER_NAME = "";
  public static ArrayList<Integer> readMsgIds = new ArrayList();
  private static final long serialVersionUID = 1L;
  private int isRead = 0;
  private int msg_id;
  private String question;
  private String reply;

  public int getIsRead()
  {
    return this.isRead;
  }

  public int getMsg_id()
  {
    return this.msg_id;
  }

  public String getQuestion()
  {
    return this.question;
  }

  public String getReply()
  {
    return this.reply;
  }

  public void setIsRead(int paramInt)
  {
    this.isRead = paramInt;
  }

  public void setMsg_id(int paramInt)
  {
    this.msg_id = paramInt;
  }

  public void setQuestion(String paramString)
  {
    this.question = paramString;
  }

  public void setReply(String paramString)
  {
    this.reply = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.Reply
 * JD-Core Version:    0.6.2
 */