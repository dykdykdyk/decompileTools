package com.baidu.feedback.sdk.android.model;

import java.io.Serializable;

public class UserParam
  implements Serializable
{
  public static final String FB_USERPARAM_KEY = "userparam";
  private static final long serialVersionUID = 1L;
  private ProducUserParam ProducUserParam;
  private boolean isGetLocation;
  private String producCustomerManagerName;
  private UserSet userSet;

  public String getProducCustomerManagerName()
  {
    return this.producCustomerManagerName;
  }

  public ProducUserParam getProducUserParam()
  {
    return this.ProducUserParam;
  }

  public UserSet getUserSet()
  {
    return this.userSet;
  }

  public boolean isGetLocation()
  {
    return this.isGetLocation;
  }

  public void setIsGetLocation(boolean paramBoolean)
  {
    this.isGetLocation = paramBoolean;
  }

  public void setProducCustomerManagerName(String paramString)
  {
    this.producCustomerManagerName = paramString;
  }

  public void setProducUserParam(ProducUserParam paramProducUserParam)
  {
    this.ProducUserParam = paramProducUserParam;
  }

  public void setUserSet(UserSet paramUserSet)
  {
    this.userSet = paramUserSet;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.UserParam
 * JD-Core Version:    0.6.2
 */