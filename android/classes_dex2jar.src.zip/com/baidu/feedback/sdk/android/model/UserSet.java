package com.baidu.feedback.sdk.android.model;

import java.io.Serializable;

public class UserSet
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String leftSelector;
  private String logo;
  private String rightDisable;
  private String rightSelector;
  private String titleBg;

  public String getLeftSelector()
  {
    return this.leftSelector;
  }

  public String getLogo()
  {
    return this.logo;
  }

  public String getRightDisable()
  {
    return this.rightDisable;
  }

  public String getRightSelector()
  {
    return this.rightSelector;
  }

  public String getTitleBg()
  {
    return this.titleBg;
  }

  public void setLeftSelector(String paramString)
  {
    this.leftSelector = paramString;
  }

  public void setLogo(String paramString)
  {
    this.logo = paramString;
  }

  public void setRightDisable(String paramString)
  {
    this.rightDisable = paramString;
  }

  public void setRightSelector(String paramString)
  {
    this.rightSelector = paramString;
  }

  public void setTitleBg(String paramString)
  {
    this.titleBg = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.UserSet
 * JD-Core Version:    0.6.2
 */