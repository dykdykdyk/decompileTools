package com.baidu.feedback.sdk.android.model;

public class DeviceInfo
{
  private String imei;
  private int is_prison_break;
  private String mac;
  private String mobile_model;
  private String network;

  public String getImei()
  {
    return this.imei;
  }

  public int getIs_prison_break()
  {
    return this.is_prison_break;
  }

  public String getMac()
  {
    return this.mac;
  }

  public String getMobile_model()
  {
    return this.mobile_model;
  }

  public String getNetwork()
  {
    return this.network;
  }

  public void setImei(String paramString)
  {
    this.imei = paramString;
  }

  public void setIs_prison_break(int paramInt)
  {
    this.is_prison_break = paramInt;
  }

  public void setMac(String paramString)
  {
    this.mac = paramString;
  }

  public void setMobile_model(String paramString)
  {
    this.mobile_model = paramString;
  }

  public void setNetwork(String paramString)
  {
    this.network = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.DeviceInfo
 * JD-Core Version:    0.6.2
 */