package com.baidu.feedback.sdk.android.model;

public class Result
{
  private String action;
  private int errnoCode = 0;
  private String from;
  private String product;
  private boolean success;

  public String getAction()
  {
    return this.action;
  }

  public int getErrnoCode()
  {
    return this.errnoCode;
  }

  public String getFrom()
  {
    return this.from;
  }

  public String getProduct()
  {
    return this.product;
  }

  public boolean isSuccess()
  {
    return this.success;
  }

  public void setAction(String paramString)
  {
    this.action = paramString;
  }

  public void setErrnoCode(int paramInt)
  {
    this.errnoCode = paramInt;
  }

  public void setFrom(String paramString)
  {
    this.from = paramString;
  }

  public void setProduct(String paramString)
  {
    this.product = paramString;
  }

  public void setSuccess(boolean paramBoolean)
  {
    this.success = paramBoolean;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.Result
 * JD-Core Version:    0.6.2
 */