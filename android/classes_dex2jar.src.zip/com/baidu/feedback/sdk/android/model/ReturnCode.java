package com.baidu.feedback.sdk.android.model;

public class ReturnCode
{
  public static final int EMPTYDATE = 3003;
  public static final int SUCCESS = 0;
  public static final int TIMEOUT = -1;
  public static final int TOFAST = 3004;
  public static final int WRONGDESCRIB = 3005;
  public static final int WRONGPRODUCT = 3002;
  public static final int WRONGREADTIME = 3007;
  public static final int WRONGTOKEN = 3001;
  public static final int WRONGUID = 3006;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.ReturnCode
 * JD-Core Version:    0.6.2
 */