package com.baidu.feedback.sdk.android.model;

import java.io.Serializable;

public class Content
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String category_content;
  private int category_id;
  private String contact;

  public Content()
  {
  }

  public Content(int paramInt, String paramString1, String paramString2)
  {
    this.category_id = paramInt;
    this.category_content = paramString1;
    this.contact = paramString2;
  }

  public String getCategory_content()
  {
    return this.category_content;
  }

  public int getCategory_id()
  {
    return this.category_id;
  }

  public String getContact()
  {
    return this.contact;
  }

  public void setCategory_content(String paramString)
  {
    this.category_content = paramString;
  }

  public void setCategory_id(int paramInt)
  {
    this.category_id = paramInt;
  }

  public void setContact(String paramString)
  {
    this.contact = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.Content
 * JD-Core Version:    0.6.2
 */