package com.baidu.feedback.sdk.android.model;

import java.io.Serializable;

public class Category
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String categoryDes;
  private String categoryName;
  private String category_id;

  public String getCategoryDes()
  {
    return this.categoryDes;
  }

  public String getCategoryName()
  {
    return this.categoryName;
  }

  public String getCategory_id()
  {
    return this.category_id;
  }

  public void setCategoryDes(String paramString)
  {
    this.categoryDes = paramString;
  }

  public void setCategoryName(String paramString)
  {
    this.categoryName = paramString;
  }

  public void setCategory_id(String paramString)
  {
    this.category_id = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.model.Category
 * JD-Core Version:    0.6.2
 */