package com.baidu.feedback.sdk.android.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class FeedBackPreference
{
  public static final String KEY_REPLY = "feedback_reply_key";
  public static final String KEY_UID = "feedback_temp_uid_key";

  public static int getInt(Context paramContext, String paramString)
  {
    return getSharedPreferences(paramContext).getInt(paramString, 0);
  }

  public static SharedPreferences getSharedPreferences(Context paramContext)
  {
    return PreferenceManager.getDefaultSharedPreferences(paramContext);
  }

  public static String getValue(Context paramContext, String paramString)
  {
    return getSharedPreferences(paramContext).getString(paramString, "");
  }

  public static void setInt(Context paramContext, String paramString, int paramInt)
  {
    getSharedPreferences(paramContext).edit().putInt(paramString, paramInt).commit();
  }

  public static void setValue(Context paramContext, String paramString1, String paramString2)
  {
    getSharedPreferences(paramContext).edit().putString(paramString1, paramString2).commit();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.util.FeedBackPreference
 * JD-Core Version:    0.6.2
 */