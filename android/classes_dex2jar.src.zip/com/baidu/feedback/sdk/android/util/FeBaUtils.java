package com.baidu.feedback.sdk.android.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.telephony.TelephonyManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class FeBaUtils
{
  public static final String FEEDBACK_UID_FILENAME = "baidufeedback.txt";
  public static final String FEEDBACK_UID_FOLEDERNAME = ".baidufeedback";
  public static final int NETWOKR_TYPE_MOBILE = 2;
  public static final int NETWOKR_TYPE_MOBILE_2G = 4;
  public static final int NETWOKR_TYPE_MOBILE_3G = 3;
  public static final int NETWORK_TYPE_NONE = -1;
  public static final int NETWORK_TYPE_WIFI = 1;
  private static final int kSystemRootStateDisable = 0;
  private static final int kSystemRootStateEnable = 1;
  private static final int kSystemRootStateUnknow = -1;
  private static int systemRootState = -1;

  public static <T> T checkNotNull(T paramT)
  {
    if (paramT == null)
      throw new NullPointerException();
    return paramT;
  }

  public static int getCurrentNetType(Context paramContext)
  {
    ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    NetworkInfo localNetworkInfo1 = localConnectivityManager.getNetworkInfo(1);
    NetworkInfo localNetworkInfo2 = localConnectivityManager.getNetworkInfo(0);
    if ((localNetworkInfo1 != null) && (localNetworkInfo1.getState() == NetworkInfo.State.CONNECTED))
      return 1;
    if ((localNetworkInfo2 != null) && (localNetworkInfo2.getState() == NetworkInfo.State.CONNECTED))
    {
      if ((localNetworkInfo2.getSubtype() == 3) || (localNetworkInfo2.getSubtype() == 5) || (localNetworkInfo2.getSubtype() == 6) || (localNetworkInfo2.getSubtype() == 8) || (localNetworkInfo2.getSubtype() == 12))
        return 3;
      return 4;
    }
    return -1;
  }

  public static String getImei(Context paramContext)
  {
    return ((TelephonyManager)paramContext.getSystemService("phone")).getDeviceId();
  }

  public static int getIsPrisonBreak()
  {
    if (isRootSystem())
      return 1;
    return 0;
  }

  public static String getMac(Context paramContext)
  {
    return ((WifiManager)paramContext.getSystemService("wifi")).getConnectionInfo().getMacAddress();
  }

  public static String getMobile_model()
  {
    return Build.MODEL;
  }

  public static String getNetwork(Context paramContext)
  {
    int i = getCurrentNetType(paramContext);
    if (i == 1)
      return "wifi";
    if (i == 3)
      return "3g";
    if (i == 4)
      return "s2";
    return "noNetwork";
  }

  public static String getTmp_mark(Context paramContext)
  {
    String str1 = FeedBackPreference.getValue(paramContext, "feedback_temp_uid_key");
    if ((str1 == null) || ("".equals(str1)))
    {
      str1 = getTmp_markFromSdCard(paramContext);
      saveTmp_mark2Preference(paramContext, str1);
    }
    String str2;
    do
    {
      return str1;
      str2 = getTmp_markFromSdCard(paramContext);
    }
    while ((str2 != null) && (!"".equals(str2)));
    saveTmp_mark2SdCard(paramContext, str1);
    return str1;
  }

  private static String getTmp_markFromSdCard(Context paramContext)
  {
    if (Environment.getExternalStorageState().equals("mounted"))
      try
      {
        FileInputStream localFileInputStream = new FileInputStream(Environment.getExternalStorageDirectory() + "/" + ".baidufeedback" + "/" + paramContext.getPackageName() + "_" + "baidufeedback.txt");
        String str = inputStream2String(localFileInputStream);
        if (localFileInputStream != null);
        try
        {
          localFileInputStream.close();
          return str;
        }
        catch (Exception localException2)
        {
          localException2.printStackTrace();
          return str;
        }
      }
      catch (Exception localException1)
      {
        localException1.printStackTrace();
      }
    return null;
  }

  public static String inputStream2String(InputStream paramInputStream)
    throws IOException
  {
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    StringBuffer localStringBuffer = new StringBuffer();
    while (true)
    {
      String str = localBufferedReader.readLine();
      if ((str != null) || (localBufferedReader != null));
      try
      {
        localBufferedReader.close();
      }
      catch (IOException localIOException2)
      {
        try
        {
          while (true)
          {
            paramInputStream.close();
            return localStringBuffer.toString();
            localStringBuffer.append(str);
            break;
            localIOException2 = localIOException2;
            localIOException2.printStackTrace();
          }
        }
        catch (IOException localIOException1)
        {
          while (true)
            localIOException1.printStackTrace();
        }
      }
    }
  }

  public static boolean isRootSystem()
  {
    if (systemRootState == 1)
      return true;
    if (systemRootState == 0)
      return false;
    String[] arrayOfString = { "/system/bin/", "/system/xbin/", "/system/sbin/", "/sbin/", "/vendor/bin/" };
    int i = 0;
    Object localObject = null;
    try
    {
      while (true)
      {
        int j = arrayOfString.length;
        if (i >= j);
        label63: File localFile;
        while (true)
        {
          systemRootState = 0;
          return false;
          localFile = new File(arrayOfString[i] + "su");
          if (localFile == null)
            break;
          try
          {
            if (!localFile.exists())
              break;
            systemRootState = 1;
            return true;
          }
          catch (Exception localException2)
          {
          }
        }
        i++;
        localObject = localFile;
      }
    }
    catch (Exception localException1)
    {
      break label63;
    }
  }

  public static void saveTmp_mark(Context paramContext, String paramString)
  {
    saveTmp_mark2Preference(paramContext, paramString);
    saveTmp_mark2SdCard(paramContext, paramString);
  }

  public static void saveTmp_mark2Preference(Context paramContext, String paramString)
  {
    FeedBackPreference.setValue(paramContext, "feedback_temp_uid_key", paramString);
  }

  private static void saveTmp_mark2SdCard(Context paramContext, String paramString)
  {
    File localFile2;
    if (Environment.getExternalStorageState().equals("mounted"))
    {
      File localFile1 = new File(Environment.getExternalStorageDirectory(), ".baidufeedback");
      if (!localFile1.exists())
        localFile1.mkdir();
      localFile2 = new File(localFile1, paramContext.getPackageName() + "_" + "baidufeedback.txt");
    }
    try
    {
      FileOutputStream localFileOutputStream = new FileOutputStream(localFile2);
      localFileOutputStream.write(paramString.getBytes());
      localFileOutputStream.flush();
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.util.FeBaUtils
 * JD-Core Version:    0.6.2
 */