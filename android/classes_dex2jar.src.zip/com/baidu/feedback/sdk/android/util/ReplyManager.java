package com.baidu.feedback.sdk.android.util;

import android.content.Context;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ReplyManager
{
  public static final String FEEDBACK_REPLY_ID_KEY = "feedback_reply_read_id_key";

  public static void deleteReadReply(Context paramContext, List<Integer> paramList)
  {
    List localList = getReadReply(paramContext);
    int i = 0;
    if (i >= paramList.size())
    {
      saveReply(paramContext, localList);
      return;
    }
    for (int j = 0; ; j++)
    {
      if (j >= localList.size())
      {
        i++;
        break;
      }
      if (((Integer)paramList.get(i)).intValue() == ((Integer)localList.get(j)).intValue())
      {
        localList.remove(j);
        j--;
      }
    }
  }

  public static List<Integer> getReadReply(Context paramContext)
  {
    ArrayList localArrayList = new ArrayList();
    try
    {
      String str = FeedBackPreference.getValue(paramContext, "feedback_reply_key");
      if (str != null)
      {
        if ("".equals(str))
          return localArrayList;
        JSONArray localJSONArray = new JSONArray();
        int i = localJSONArray.length();
        if (i > 0)
          for (int j = 0; j < i; j++)
            localArrayList.add(Integer.valueOf(((JSONObject)localJSONArray.get(j)).getInt("feedback_reply_read_id_key")));
      }
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
    return localArrayList;
  }

  public static void saveReadReply(Context paramContext, List<Integer> paramList)
  {
    if ((paramList == null) || (paramList.size() == 0))
      return;
    List localList = getReadReply(paramContext);
    int i = 0;
    if (i >= paramList.size())
    {
      saveReply(paramContext, localList);
      return;
    }
    int j = 0;
    for (int k = 0; ; k++)
    {
      if (k >= localList.size())
      {
        if (j == 0)
          localList.add((Integer)paramList.get(i));
        i++;
        break;
      }
      if (((Integer)paramList.get(i)).intValue() == ((Integer)localList.get(k)).intValue())
        j = 1;
    }
  }

  private static void saveReply(Context paramContext, List<Integer> paramList)
  {
    try
    {
      JSONArray localJSONArray = new JSONArray();
      Iterator localIterator = paramList.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
        {
          FeedBackPreference.setValue(paramContext, "feedback_reply_key", localJSONArray.toString());
          return;
        }
        Integer localInteger = (Integer)localIterator.next();
        JSONObject localJSONObject = new JSONObject();
        localJSONObject.put("feedback_reply_read_id_key", localInteger);
        localJSONArray.put(localJSONObject);
      }
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.util.ReplyManager
 * JD-Core Version:    0.6.2
 */