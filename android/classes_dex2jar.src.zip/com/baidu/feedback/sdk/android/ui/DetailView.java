package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.graphics.Color;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ScrollView;
import android.widget.TextView;
import com.baidu.feedback.sdk.android.model.Reply;
import com.baidu.feedback.sdk.android.model.UserSet;

public class DetailView
  implements View.OnKeyListener
{
  private TextView feedTvInfo;
  private LinearLayout linear1;
  private LinearLayout linear2;
  private Listener listener;
  private Context mContext;
  private TextView signature;
  private TextView subTvInfo;
  private CommonTitle title;
  private UserSet userSet;

  public DetailView(Context paramContext, UserSet paramUserSet, Listener paramListener)
  {
    this.listener = paramListener;
    this.mContext = paramContext;
    this.userSet = paramUserSet;
  }

  private void addTitle()
  {
    this.title = new CommonTitle(this.mContext, this.userSet);
    LinearLayout localLinearLayout = this.title.initTitle();
    this.title.setBookLeftButtonListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        DetailView.this.listener.onDetailBack();
      }
    });
    this.title.setTitleText("   意见反馈--回复");
    this.linear1.addView(localLinearLayout);
  }

  private void getFocus()
  {
    this.linear1.setFocusable(true);
    this.linear1.setFocusableInTouchMode(true);
    this.linear1.requestFocus();
  }

  public LinearLayout initView()
  {
    this.linear1 = new LinearLayout(this.mContext);
    this.linear1.setOnKeyListener(this);
    getFocus();
    LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-1, -1);
    this.linear1.setLayoutParams(localLayoutParams1);
    this.linear1.setOrientation(1);
    this.linear1.setBackgroundColor(-1);
    addTitle();
    BackGroundSelector localBackGroundSelector = new BackGroundSelector(this.mContext);
    TextView localTextView1 = new TextView(this.mContext);
    ScrollView localScrollView = new ScrollView(this.mContext);
    localScrollView.setLayoutParams(localLayoutParams1);
    this.linear2 = new LinearLayout(this.mContext);
    LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-1, -1);
    this.linear2.setLayoutParams(localLayoutParams2);
    this.linear2.setOrientation(1);
    LinearLayout.LayoutParams localLayoutParams3 = new LinearLayout.LayoutParams(-1, -2);
    localTextView1.setPadding(PxAndDp.dip2px(this.mContext, 9.0F), PxAndDp.dip2px(this.mContext, 9.0F), 0, PxAndDp.dip2px(this.mContext, 9.0F));
    localTextView1.setLayoutParams(localLayoutParams3);
    localTextView1.setGravity(16);
    localTextView1.setText("您的反馈");
    localTextView1.setTextColor(Color.parseColor("#333333"));
    localTextView1.setTextSize(2, 14.0F);
    localTextView1.setBackgroundDrawable(localBackGroundSelector.getdrawble("huise_1", this.mContext));
    this.linear2.addView(localTextView1);
    this.subTvInfo = new TextView(this.mContext);
    LinearLayout.LayoutParams localLayoutParams4 = new LinearLayout.LayoutParams(-1, -2);
    this.subTvInfo.setLayoutParams(localLayoutParams4);
    this.subTvInfo.setPadding(PxAndDp.dip2px(this.mContext, 9.0F), PxAndDp.dip2px(this.mContext, 9.0F), PxAndDp.dip2px(this.mContext, 9.0F), PxAndDp.dip2px(this.mContext, 9.0F));
    this.subTvInfo.setTextColor(Color.parseColor("#333333"));
    this.subTvInfo.setTextSize(2, 16.0F);
    this.linear2.addView(this.subTvInfo);
    TextView localTextView2 = new TextView(this.mContext);
    LinearLayout.LayoutParams localLayoutParams5 = new LinearLayout.LayoutParams(-1, -2);
    localTextView2.setPadding(PxAndDp.dip2px(this.mContext, 9.0F), PxAndDp.dip2px(this.mContext, 9.0F), 0, PxAndDp.dip2px(this.mContext, 9.0F));
    localTextView2.setLayoutParams(localLayoutParams5);
    localTextView2.setGravity(16);
    localTextView2.setText("回复");
    localTextView2.setTextColor(Color.parseColor("#333333"));
    localTextView2.setTextSize(2, 14.0F);
    localTextView2.setBackgroundDrawable(localBackGroundSelector.getdrawble("huise_1", this.mContext));
    this.linear2.addView(localTextView2);
    this.feedTvInfo = new TextView(this.mContext);
    LinearLayout.LayoutParams localLayoutParams6 = new LinearLayout.LayoutParams(-1, -2);
    this.feedTvInfo.setLayoutParams(localLayoutParams6);
    this.feedTvInfo.setPadding(PxAndDp.dip2px(this.mContext, 9.0F), PxAndDp.dip2px(this.mContext, 9.0F), PxAndDp.dip2px(this.mContext, 9.0F), 0);
    this.feedTvInfo.setTextColor(Color.parseColor("#333333"));
    this.feedTvInfo.setTextSize(2, 16.0F);
    this.linear2.addView(this.feedTvInfo);
    this.signature = new TextView(this.mContext);
    this.signature.setLayoutParams(localLayoutParams6);
    this.signature.setPadding(PxAndDp.dip2px(this.mContext, 9.0F), 0, PxAndDp.dip2px(this.mContext, 9.0F), PxAndDp.dip2px(this.mContext, 9.0F));
    this.signature.setTextColor(Color.parseColor("#333333"));
    this.signature.setTextSize(2, 16.0F);
    this.signature.setGravity(5);
    this.linear2.addView(this.signature);
    localScrollView.addView(this.linear2);
    this.linear1.addView(localScrollView);
    return this.linear1;
  }

  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
      this.listener.onDetailBack();
    return true;
  }

  public void setFocus()
  {
    getFocus();
  }

  public void setInfo(Reply paramReply)
  {
    this.subTvInfo.setText(paramReply.getQuestion());
    this.feedTvInfo.setText(paramReply.getReply());
    this.signature.setText("\n\n" + Reply.FB_CUSTOMER_MANAGER_NAME + "产品经理");
  }

  public static abstract interface Listener
  {
    public abstract void onDetailBack();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.DetailView
 * JD-Core Version:    0.6.2
 */