package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import com.baidu.feedback.sdk.android.model.Reply;
import java.util.List;

public class ReplyAdapter extends BaseAdapter
{
  private Context mContext;
  private List<Reply> replys = null;

  public ReplyAdapter(Context paramContext, List<Reply> paramList)
  {
    this.mContext = paramContext;
    this.replys = paramList;
  }

  public int getCount()
  {
    if (this.replys == null)
      return 0;
    return this.replys.size();
  }

  public Object getItem(int paramInt)
  {
    if (this.replys == null)
      return new Object();
    return this.replys.get(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    if (paramView == null)
    {
      ReplyItemView localReplyItemView = new ReplyItemView(this.mContext);
      ViewHolder localViewHolder = new ViewHolder(localReplyItemView, paramInt);
      localViewHolder.refresh(paramInt);
      localReplyItemView.setTag(localViewHolder);
      return localReplyItemView;
    }
    ((ViewHolder)paramView.getTag()).refresh(paramInt);
    return paramView;
  }

  public void setData(List<Reply> paramList)
  {
    this.replys = paramList;
  }

  public final class ViewHolder
  {
    private ReplyItemView mConvertView;
    private Reply mItem;

    public ViewHolder(View paramInt, int arg3)
    {
      this.mConvertView = ((ReplyItemView)paramInt);
    }

    public void refresh(int paramInt)
    {
      this.mItem = ((Reply)ReplyAdapter.this.replys.get(paramInt));
      this.mConvertView.setId(this.mItem.getMsg_id());
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.ReplyAdapter
 * JD-Core Version:    0.6.2
 */