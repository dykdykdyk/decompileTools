package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.graphics.Color;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import com.baidu.feedback.sdk.android.model.Reply;
import com.baidu.feedback.sdk.android.model.UserSet;
import java.util.List;

public class ReplyListView extends LinearLayout
  implements AdapterView.OnItemClickListener, View.OnKeyListener
{
  private boolean isBack = false;
  private ListView listView;
  private Listener listener;
  private Context mContext;
  private LinearLayout.LayoutParams mParent;
  private ReplyAdapter replyAdapter;
  private List<Reply> replys;
  private CommonTitle title;
  private UserSet userSet;

  public ReplyListView(Context paramContext, UserSet paramUserSet, Listener paramListener)
  {
    super(paramContext);
    this.listener = paramListener;
    this.mContext = paramContext;
    this.userSet = paramUserSet;
    initView();
  }

  private void addListView()
  {
    this.mParent = new LinearLayout.LayoutParams(-1, -1);
    this.listView = new ListView(this.mContext);
    this.listView.setOnItemClickListener(this);
    this.listView.setCacheColorHint(Color.parseColor("#00000000"));
    this.listView.setDivider(null);
    addView(this.listView, this.mParent);
  }

  private void addTitle()
  {
    this.title = new CommonTitle(this.mContext, this.userSet);
    LinearLayout localLinearLayout = this.title.initTitle();
    this.title.setBookLeftButtonListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        if (ReplyListView.this.listener != null)
          ReplyListView.this.listener.onReplyBack();
      }
    });
    this.title.setTitleText("   意见反馈--回复列表");
    addView(localLinearLayout);
  }

  private void getFocus()
  {
    setFocusable(true);
    setFocusableInTouchMode(true);
    requestFocus();
  }

  private void initView()
  {
    setOnKeyListener(this);
    getFocus();
    this.isBack = true;
    setOrientation(1);
    this.mParent = new LinearLayout.LayoutParams(-1, -1);
    setLayoutParams(this.mParent);
    setBackgroundColor(Color.parseColor("#FFFFFF"));
    addTitle();
    addListView();
  }

  private void refreshList()
  {
    if (this.replyAdapter == null)
    {
      this.replyAdapter = new ReplyAdapter(this.mContext, this.replys);
      this.listView.setAdapter(this.replyAdapter);
      return;
    }
    this.replyAdapter.setData(this.replys);
  }

  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    this.listener.onItemClick(paramInt);
  }

  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramInt == 4)
    {
      if (this.isBack)
        this.listener.onReplyBack();
    }
    else
      return true;
    this.isBack = true;
    return true;
  }

  public void setFocus()
  {
    this.isBack = false;
    getFocus();
  }

  public void setReplyData(List<Reply> paramList)
  {
    this.replys = paramList;
    refreshList();
  }

  public static abstract interface Listener
  {
    public abstract void onItemClick(int paramInt);

    public abstract void onReplyBack();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.ReplyListView
 * JD-Core Version:    0.6.2
 */