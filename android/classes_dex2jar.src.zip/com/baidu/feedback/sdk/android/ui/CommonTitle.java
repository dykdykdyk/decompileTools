package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.content.res.Resources;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.baidu.feedback.sdk.android.model.UserSet;

public class CommonTitle
{
  public static String leftSelector;
  public static String rightDisable;
  public static String rightSelector;
  private Context context;
  private ImageView leftButton;
  private String logo;
  private ImageView logoImg;
  private Resources mRes;
  private LinearLayout realroot;
  private ImageView rightButton;
  private BackGroundSelector selector;
  private TextView title;
  private String titleBg;
  private TextView tltieView;
  private UserSet userSet;

  public CommonTitle(Context paramContext, UserSet paramUserSet)
  {
    this.context = paramContext;
    this.userSet = paramUserSet;
    initTitle();
  }

  public void addTitle()
  {
    this.titleBg = this.userSet.getTitleBg();
    String str1;
    if (this.titleBg != null)
    {
      str1 = this.titleBg;
      setTitleBg(str1);
      this.logo = this.userSet.getLogo();
      if (this.logo == null)
        break label115;
    }
    label115: for (String str2 = this.logo; ; str2 = "logo")
    {
      setLogoBg(str2);
      leftSelector = this.userSet.getLeftSelector();
      setleftButton();
      rightDisable = this.userSet.getRightDisable();
      rightSelector = this.userSet.getRightSelector();
      setRightButton();
      getRightButton().setClickable(false);
      setTitleText("意见反馈");
      return;
      str1 = "lanse";
      break;
    }
  }

  public ImageView getLogoImg()
  {
    return this.logoImg;
  }

  protected int getResID(String paramString1, String paramString2)
  {
    if (this.mRes == null)
      this.mRes = this.context.getResources();
    return this.mRes.getIdentifier(paramString1, paramString2, this.context.getPackageName());
  }

  public ImageView getRightButton()
  {
    return this.rightButton;
  }

  public LinearLayout initTitle()
  {
    this.selector = new BackGroundSelector(this.context);
    LinearLayout localLinearLayout = new LinearLayout(this.context);
    localLinearLayout.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
    localLinearLayout.setOrientation(1);
    FrameLayout localFrameLayout = new FrameLayout(this.context);
    localFrameLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
    this.realroot = new LinearLayout(this.context);
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-1, -2);
    localLayoutParams.gravity = 16;
    this.realroot.setLayoutParams(localLayoutParams);
    this.realroot.setOrientation(0);
    this.realroot.setGravity(16);
    this.leftButton = new ImageView(this.context);
    LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-2, -2);
    localLayoutParams1.setMargins(PxAndDp.dip2px(this.context, 9.0F), PxAndDp.dip2px(this.context, 5.0F), 0, PxAndDp.dip2px(this.context, 5.0F));
    this.leftButton.setLayoutParams(localLayoutParams1);
    this.leftButton.setVisibility(8);
    this.realroot.addView(this.leftButton);
    this.tltieView = new TextView(this.context);
    LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-2, -2, 1.0F);
    this.tltieView.setGravity(1);
    this.tltieView.setLayoutParams(localLayoutParams2);
    this.realroot.addView(this.tltieView);
    this.rightButton = new ImageView(this.context);
    LinearLayout.LayoutParams localLayoutParams3 = new LinearLayout.LayoutParams(-2, -2);
    this.rightButton.setLayoutParams(localLayoutParams3);
    localLayoutParams3.setMargins(0, PxAndDp.dip2px(this.context, 5.0F), PxAndDp.dip2px(this.context, 9.0F), PxAndDp.dip2px(this.context, 5.0F));
    this.rightButton.setVisibility(8);
    this.realroot.addView(this.rightButton);
    localFrameLayout.addView(this.realroot);
    this.title = new TextView(this.context);
    this.title.setLayoutParams(localLayoutParams);
    this.title.setGravity(17);
    localFrameLayout.addView(this.title);
    localLinearLayout.addView(localFrameLayout);
    this.logoImg = new ImageView(this.context);
    LinearLayout.LayoutParams localLayoutParams4 = new LinearLayout.LayoutParams(-1, -2);
    this.logoImg.setLayoutParams(localLayoutParams4);
    localLinearLayout.addView(this.logoImg);
    addTitle();
    return localLinearLayout;
  }

  public void setBookLeftButtonListener(View.OnClickListener paramOnClickListener)
  {
    ImageView localImageView = this.leftButton;
    if (paramOnClickListener == null);
    for (int i = 4; ; i = 0)
    {
      localImageView.setVisibility(i);
      this.leftButton.setOnClickListener(paramOnClickListener);
      return;
    }
  }

  public void setBookRightButtonListener(View.OnClickListener paramOnClickListener)
  {
    ImageView localImageView = this.rightButton;
    if (paramOnClickListener == null);
    for (int i = 4; ; i = 0)
    {
      localImageView.setVisibility(i);
      this.rightButton.setOnClickListener(paramOnClickListener);
      return;
    }
  }

  public void setLogoBg(String paramString)
  {
    this.logoImg.setBackgroundDrawable(this.selector.getdrawble(paramString, this.context));
  }

  public void setRightButton()
  {
    if (rightDisable != null)
    {
      this.rightButton.setBackgroundDrawable(this.context.getResources().getDrawable(getResID(rightDisable, "drawable")));
      return;
    }
    this.rightButton.setBackgroundDrawable(this.selector.getdrawble("disable", this.context));
  }

  public void setRightButtonText(String paramString)
  {
  }

  public void setTitleBg(String paramString)
  {
    if (this.titleBg != null)
    {
      int i = getResID(paramString, "drawable");
      this.realroot.setBackgroundDrawable(this.context.getResources().getDrawable(i));
      return;
    }
    this.realroot.setBackgroundDrawable(this.selector.getdrawble(paramString, this.context));
  }

  public void setTitleText(String paramString)
  {
    this.title.setText(paramString);
    this.title.setTextColor(-1);
    this.title.setTextSize(2, 18.0F);
  }

  public void setleftButton()
  {
    if (leftSelector != null)
    {
      this.leftButton.setBackgroundDrawable(this.context.getResources().getDrawable(getResID(leftSelector, "drawable")));
      return;
    }
    this.leftButton.setBackgroundDrawable(this.selector.createBgByImageIds(new String[] { "fanhui", "fanhui_dianji" }));
  }

  public void setleftButtonText(String paramString)
  {
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.CommonTitle
 * JD-Core Version:    0.6.2
 */