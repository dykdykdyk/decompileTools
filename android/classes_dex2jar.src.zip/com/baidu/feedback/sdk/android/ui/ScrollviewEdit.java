package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ScrollView;

public class ScrollviewEdit extends ScrollView
{
  public ScrollviewEdit(Context paramContext)
  {
    this(paramContext, null);
  }

  public ScrollviewEdit(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.ScrollviewEdit
 * JD-Core Version:    0.6.2
 */