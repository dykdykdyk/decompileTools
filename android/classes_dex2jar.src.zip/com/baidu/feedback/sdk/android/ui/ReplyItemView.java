package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.graphics.Color;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

public class ReplyItemView extends LinearLayout
{
  private int mId;
  private TextView textView;

  public ReplyItemView(Context paramContext)
  {
    super(paramContext);
    BackGroundSelector localBackGroundSelector = new BackGroundSelector(paramContext);
    LinearLayout localLinearLayout = new LinearLayout(paramContext);
    localLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
    localLinearLayout.setBackgroundDrawable(localBackGroundSelector.createBgByImageIds(new String[] { "xichangtiao_bai", "xichangtiao" }));
    localLinearLayout.setGravity(16);
    this.textView = new TextView(paramContext);
    LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-2, -2, 1.0F);
    this.textView.setPadding(PxAndDp.dip2px(paramContext, 13.0F), 0, 0, 0);
    this.textView.setGravity(16);
    this.textView.setText("您收到一条回复");
    this.textView.setTextSize(2, 14.0F);
    this.textView.setTextColor(Color.parseColor("#333333"));
    localLinearLayout.addView(this.textView, localLayoutParams1);
    ImageView localImageView = new ImageView(paramContext);
    LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-2, -2);
    localLayoutParams2.rightMargin = PxAndDp.dip2px(paramContext, 13.0F);
    localImageView.setLayoutParams(localLayoutParams2);
    localImageView.setBackgroundDrawable(localBackGroundSelector.getdrawble("jiantou", paramContext));
    localLinearLayout.addView(localImageView);
    addView(localLinearLayout);
  }

  public int getmId()
  {
    return this.mId;
  }

  public void setmId(int paramInt)
  {
    this.mId = paramInt;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.ReplyItemView
 * JD-Core Version:    0.6.2
 */