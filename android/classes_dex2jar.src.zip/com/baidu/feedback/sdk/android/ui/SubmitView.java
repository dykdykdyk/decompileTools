package com.baidu.feedback.sdk.android.ui;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.text.InputFilter;
import android.text.InputFilter.LengthFilter;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import com.baidu.feedback.sdk.android.model.Category;
import com.baidu.feedback.sdk.android.model.Reply;
import com.baidu.feedback.sdk.android.model.UserSet;
import java.util.ArrayList;
import java.util.List;

public class SubmitView
  implements View.OnKeyListener
{
  public static boolean IS_CLICKABLE;
  public static boolean IS_NO_MSG;
  private EditText addet;
  private TextView addtv;
  private TextView bt0;
  private TextView bt1;
  private TextView bt2;
  private TextView bt3;
  private List<TextView> btList;
  private List<Category> categories;
  private EditText contentet;
  private TextView contentsum;
  private Context context;
  private List<String> hintList;
  private List<String> idList;
  private ImageView lineView;
  private LinearLayout linear4;
  private LinearLayout linear5;
  private LinearLayout linearroot;
  private Listener listener;
  private ImageView logoImg;
  private LinearLayout msgll;
  private TextView msgtv;
  private ScrollviewEdit myScrollView;
  private LinearLayout.LayoutParams params_bt;
  private List<Reply> replies = new ArrayList();
  private BackGroundSelector selector;
  private int sum = 0;
  private CommonTitle title;
  private UserSet userSet;

  public SubmitView(Context paramContext, Listener paramListener)
  {
    this.context = paramContext;
    this.listener = paramListener;
  }

  private void getFocus()
  {
    this.linearroot.setFocusable(true);
    this.linearroot.setFocusableInTouchMode(true);
    this.linearroot.requestFocus();
  }

  public void addTitle()
  {
    this.title = new CommonTitle(this.context, this.userSet);
    LinearLayout localLinearLayout = this.title.initTitle();
    this.title.getLogoImg().setVisibility(8);
    this.title.setBookLeftButtonListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        SubmitView.this.listener.onSubmitBack();
      }
    });
    this.title.setBookRightButtonListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
      }
    });
    this.linearroot.addView(localLinearLayout);
  }

  public EditText getAddet()
  {
    return this.addet;
  }

  public TextView getAddtv()
  {
    return this.addtv;
  }

  public TextView getBt0()
  {
    return this.bt0;
  }

  public TextView getBt1()
  {
    return this.bt1;
  }

  public TextView getBt2()
  {
    return this.bt2;
  }

  public TextView getBt3()
  {
    return this.bt3;
  }

  public List<TextView> getBtList()
  {
    return this.btList;
  }

  public EditText getContentet()
  {
    return this.contentet;
  }

  public TextView getContentsum()
  {
    return this.contentsum;
  }

  public void getData()
  {
    IS_CLICKABLE = false;
    this.title.getRightButton().setClickable(false);
  }

  public List<String> getHintList()
  {
    return this.hintList;
  }

  public List<String> getIdList()
  {
    return this.idList;
  }

  public ImageView getLineView()
  {
    return this.lineView;
  }

  public LinearLayout getLinear4()
  {
    return this.linear4;
  }

  public LinearLayout getMsgll()
  {
    return this.msgll;
  }

  public ScrollviewEdit getMyScrollView()
  {
    return this.myScrollView;
  }

  public CommonTitle getTitle()
  {
    return this.title;
  }

  public LinearLayout initView()
  {
    this.selector = new BackGroundSelector(this.context);
    this.linearroot = new LinearLayout(this.context);
    this.linearroot.setOnKeyListener(this);
    getFocus();
    LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-1, -1);
    this.linearroot.setOrientation(1);
    this.linearroot.setLayoutParams(localLayoutParams);
    this.linearroot.setBackgroundColor(Color.parseColor("#f4f4f4"));
    return this.linearroot;
  }

  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramKeyEvent.getAction() == 0) && (paramInt == 4))
    {
      this.listener.onSubmitBack();
      return true;
    }
    return false;
  }

  public void reSetInfoSumView(List<Reply> paramList)
  {
    this.replies = paramList;
    if (this.replies != null)
      this.sum = this.replies.size();
    StringBuilder localStringBuilder = new StringBuilder("  您有");
    Object localObject;
    SpannableString localSpannableString;
    if (this.sum == 1)
    {
      localObject = Integer.valueOf(1);
      localSpannableString = new SpannableString(localObject + "条新消息！");
      if (this.sum != 1)
        break label118;
      localSpannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#e5ab3a")), 4, 5, 33);
    }
    while (true)
    {
      this.msgtv.setText(localSpannableString);
      return;
      localObject = "多";
      break;
      label118: if (this.sum == 0)
      {
        this.msgll.setVisibility(8);
        this.lineView.setVisibility(0);
      }
    }
  }

  public void setAddet(EditText paramEditText)
  {
    this.addet = paramEditText;
  }

  public void setAddtv(TextView paramTextView)
  {
    this.addtv = paramTextView;
  }

  public void setBt0(TextView paramTextView)
  {
    this.bt0 = paramTextView;
  }

  public void setBt1(TextView paramTextView)
  {
    this.bt1 = paramTextView;
  }

  public void setBt2(TextView paramTextView)
  {
    this.bt2 = paramTextView;
  }

  public void setBt3(TextView paramTextView)
  {
    this.bt3 = paramTextView;
  }

  public void setContentet(EditText paramEditText)
  {
    this.contentet = paramEditText;
  }

  public void setContentsum(TextView paramTextView)
  {
    this.contentsum = paramTextView;
  }

  public void setFocus()
  {
    getFocus();
  }

  public void setInfo(List<Category> paramList, UserSet paramUserSet, List<Reply> paramList1)
  {
    this.categories = paramList;
    this.userSet = paramUserSet;
    this.replies = paramList1;
    setSecondView();
  }

  public void setLineView(ImageView paramImageView)
  {
    this.lineView = paramImageView;
  }

  public void setLinear4(LinearLayout paramLinearLayout)
  {
    this.linear4 = paramLinearLayout;
  }

  public void setMsgll(LinearLayout paramLinearLayout)
  {
    this.msgll = paramLinearLayout;
  }

  public void setMyScrollView(ScrollviewEdit paramScrollviewEdit)
  {
    this.myScrollView = paramScrollviewEdit;
  }

  public void setSecondView()
  {
    addTitle();
    LinearLayout localLinearLayout1 = new LinearLayout(this.context);
    localLinearLayout1.setOrientation(1);
    LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-1, -1);
    localLinearLayout1.setLayoutParams(localLayoutParams1);
    localLinearLayout1.setBackgroundColor(Color.parseColor("#f4f4f4"));
    this.myScrollView = new ScrollviewEdit(this.context);
    LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-1, -1);
    this.myScrollView.setLayoutParams(localLayoutParams2);
    this.myScrollView.setBackgroundColor(Color.parseColor("#00000000"));
    LinearLayout localLinearLayout2 = new LinearLayout(this.context);
    localLinearLayout2.setOrientation(1);
    LinearLayout.LayoutParams localLayoutParams3 = new LinearLayout.LayoutParams(-1, -1);
    localLinearLayout2.setBackgroundColor(Color.parseColor("#f4f4f4"));
    localLinearLayout2.setLayoutParams(localLayoutParams3);
    this.logoImg = new ImageView(this.context);
    LinearLayout.LayoutParams localLayoutParams4 = new LinearLayout.LayoutParams(-1, -2);
    this.logoImg.setLayoutParams(localLayoutParams4);
    ImageView localImageView1 = this.logoImg;
    BackGroundSelector localBackGroundSelector = this.selector;
    String str1;
    int i;
    label426: label440: Object localObject;
    label726: FrameLayout localFrameLayout1;
    FrameLayout.LayoutParams localLayoutParams13;
    EditText localEditText;
    if (((Activity)this.context).getIntent().getStringExtra("logo") != null)
    {
      str1 = ((Activity)this.context).getIntent().getStringExtra("logo");
      Context localContext = this.context;
      localImageView1.setBackgroundDrawable(localBackGroundSelector.getdrawble(str1, localContext));
      localLinearLayout2.addView(this.logoImg);
      this.linear4 = new LinearLayout(this.context);
      LinearLayout.LayoutParams localLayoutParams5 = new LinearLayout.LayoutParams(-1, -2);
      this.linear4.setPadding(PxAndDp.dip2px(this.context, 9.0F), PxAndDp.dip2px(this.context, 5.0F), PxAndDp.dip2px(this.context, 9.0F), PxAndDp.dip2px(this.context, 5.0F));
      this.linear4.setLayoutParams(localLayoutParams5);
      this.linear4.setGravity(16);
      this.linear4.setBackgroundColor(Color.parseColor("#f4f4f4"));
      this.btList = new ArrayList();
      this.idList = new ArrayList();
      this.hintList = new ArrayList();
      this.params_bt = new LinearLayout.LayoutParams(-1, -2, 1.0F);
      if ((this.categories == null) || (this.categories.size() <= 0))
        break label1919;
      i = 0;
      if (i < this.categories.size())
        break label1767;
      localLinearLayout2.addView(this.linear4);
      this.linear5 = new LinearLayout(this.context);
      LinearLayout.LayoutParams localLayoutParams7 = new LinearLayout.LayoutParams(-1, -1);
      this.linear5.setLayoutParams(localLayoutParams7);
      this.linear5.setBackgroundColor(Color.parseColor("#00000000"));
      this.linear5.setOrientation(1);
      this.lineView = new ImageView(this.context);
      LinearLayout.LayoutParams localLayoutParams8 = new LinearLayout.LayoutParams(-1, PxAndDp.dip2px(this.context, 1.0F));
      this.lineView.setLayoutParams(localLayoutParams8);
      this.lineView.setBackgroundDrawable(this.selector.getdrawble("xixian", this.context));
      this.lineView.setVisibility(8);
      if (this.replies != null)
        this.sum = this.replies.size();
      this.msgll = new LinearLayout(this.context);
      LinearLayout.LayoutParams localLayoutParams9 = new LinearLayout.LayoutParams(-1, -2);
      this.msgll.setLayoutParams(localLayoutParams9);
      this.msgll.setGravity(16);
      this.msgll.setBackgroundDrawable(this.selector.getdrawble("huang_se", this.context));
      this.msgtv = new TextView(this.context);
      LinearLayout.LayoutParams localLayoutParams10 = new LinearLayout.LayoutParams(-2, -2, 1.0F);
      this.msgtv.setLayoutParams(localLayoutParams10);
      StringBuilder localStringBuilder = new StringBuilder("  您有");
      if (this.sum != 1)
        break label2407;
      localObject = Integer.valueOf(1);
      SpannableString localSpannableString = new SpannableString(localObject + "条新消息！");
      if (this.sum == 1)
        localSpannableString.setSpan(new ForegroundColorSpan(Color.parseColor("#e5ab3a")), 4, 5, 33);
      this.msgtv.setText(localSpannableString);
      this.msgtv.setTextSize(2, 15.0F);
      this.msgtv.setTextColor(Color.parseColor("#333333"));
      this.msgll.addView(this.msgtv);
      this.linear5.addView(this.msgll);
      if (this.sum == 0)
      {
        this.msgll.setVisibility(8);
        this.lineView.setVisibility(0);
      }
      LinearLayout localLinearLayout3 = this.msgll;
      View.OnClickListener local3 = new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          if ((SubmitView.this.replies != null) && (SubmitView.this.replies.size() > 1))
            SubmitView.this.listener.onMultiReplyClick();
          while ((SubmitView.this.replies == null) || (SubmitView.this.replies.size() != 1))
            return;
          SubmitView.IS_NO_MSG = true;
          SubmitView.this.listener.onSingleReplyClick();
        }
      };
      localLinearLayout3.setOnClickListener(local3);
      this.linear5.addView(this.lineView);
      ImageView localImageView2 = new ImageView(this.context);
      LinearLayout.LayoutParams localLayoutParams11 = new LinearLayout.LayoutParams(-1, -2);
      localLayoutParams11.setMargins(0, 0, 0, PxAndDp.dip2px(this.context, 15.0F));
      localImageView2.setLayoutParams(localLayoutParams11);
      this.linear5.addView(localImageView2);
      localFrameLayout1 = new FrameLayout(this.context);
      LinearLayout.LayoutParams localLayoutParams12 = new LinearLayout.LayoutParams(-1, -2);
      localLayoutParams12.setMargins(PxAndDp.dip2px(this.context, 10.0F), 0, PxAndDp.dip2px(this.context, 10.0F), PxAndDp.dip2px(this.context, 10.0F));
      localFrameLayout1.setLayoutParams(localLayoutParams12);
      this.contentet = new EditText(this.context);
      InputFilter[] arrayOfInputFilter1 = new InputFilter[1];
      arrayOfInputFilter1[0] = new InputFilter.LengthFilter(500);
      this.contentet.setFilters(arrayOfInputFilter1);
      this.contentet.setOnKeyListener(this);
      localLayoutParams13 = new FrameLayout.LayoutParams(-1, -2);
      this.contentet.setLayoutParams(localLayoutParams13);
      this.contentet.setGravity(48);
      this.contentet.setBackgroundDrawable(this.selector.getdrawble("kuang_zi_1", this.context));
      localEditText = this.contentet;
      if (this.hintList.size() == 0)
        break label2415;
    }
    label1767: label2415: for (String str2 = (String)this.hintList.get(0); ; str2 = "")
    {
      localEditText.setHint(str2);
      this.contentet.setHintTextColor(Color.parseColor("#D0D0D0"));
      this.contentet.setLines(7);
      this.contentet.setLineSpacing(0.5F, 1.1F);
      this.contentet.setTextSize(2, 15.0F);
      this.contentet.setTextColor(Color.parseColor("#333333"));
      localFrameLayout1.addView(this.contentet);
      this.contentsum = new TextView(this.context);
      FrameLayout.LayoutParams localLayoutParams14 = new FrameLayout.LayoutParams(-1, -2);
      localLayoutParams14.gravity = 85;
      this.contentsum.setLayoutParams(localLayoutParams14);
      this.contentsum.setGravity(5);
      this.contentsum.setText("(0/500)");
      this.contentsum.setTextSize(2, 12.0F);
      localFrameLayout1.addView(this.contentsum);
      this.linear5.addView(localFrameLayout1);
      FrameLayout localFrameLayout2 = new FrameLayout(this.context);
      LinearLayout.LayoutParams localLayoutParams15 = new LinearLayout.LayoutParams(-1, -2);
      localLayoutParams15.setMargins(PxAndDp.dip2px(this.context, 10.0F), 0, PxAndDp.dip2px(this.context, 10.0F), PxAndDp.dip2px(this.context, 17.0F));
      localFrameLayout2.setLayoutParams(localLayoutParams15);
      this.addet = new EditText(this.context);
      InputFilter[] arrayOfInputFilter2 = new InputFilter[1];
      arrayOfInputFilter2[0] = new InputFilter.LengthFilter(70);
      this.addet.setFilters(arrayOfInputFilter2);
      this.addet.setOnKeyListener(this);
      this.addet.setLayoutParams(localLayoutParams13);
      this.addet.setGravity(48);
      this.addet.setHint("您的手机号或者电子邮箱地址");
      this.addet.setHintTextColor(Color.parseColor("#D0D0D0"));
      this.addet.setBackgroundDrawable(this.selector.getdrawble("kuang_zi_2", this.context));
      this.addet.setTextSize(2, 15.0F);
      this.addet.setTextColor(Color.parseColor("#333333"));
      this.addet.setLines(1);
      this.addet.setSingleLine(true);
      localFrameLayout2.addView(this.addet);
      this.addtv = new TextView(this.context);
      FrameLayout.LayoutParams localLayoutParams16 = new FrameLayout.LayoutParams(-1, -2);
      localLayoutParams16.gravity = 85;
      localLayoutParams16.setMargins(0, 0, 0, PxAndDp.dip2px(this.context, 8.0F));
      this.addtv.setLayoutParams(localLayoutParams16);
      this.addtv.setGravity(5);
      this.addtv.setText("(0/70)");
      this.addtv.setTextSize(2, 12.0F);
      localFrameLayout2.addView(this.addtv);
      this.linear5.addView(localFrameLayout2);
      getData();
      localLinearLayout2.addView(this.linear5);
      this.myScrollView.addView(localLinearLayout2);
      localLinearLayout1.addView(this.myScrollView);
      this.linearroot.addView(localLinearLayout1);
      LinearLayout localLinearLayout4 = new LinearLayout(this.context);
      LinearLayout.LayoutParams localLayoutParams17 = new LinearLayout.LayoutParams(-1, PxAndDp.dip2px(this.context, 180.0F), 1.0F);
      localLinearLayout4.setLayoutParams(localLayoutParams17);
      localLinearLayout4.setBackgroundColor(Color.parseColor("#f4f4f4"));
      this.linearroot.addView(localLinearLayout4);
      return;
      str1 = "logo";
      break;
      TextView localTextView = new TextView(this.context);
      localTextView.setLayoutParams(this.params_bt);
      localTextView.setGravity(17);
      localTextView.setText(((Category)this.categories.get(i)).getCategoryName());
      localTextView.setTextSize(2, 16.0F);
      localTextView.setTextColor(Color.parseColor("#333333"));
      this.linear4.addView(localTextView);
      this.btList.add(localTextView);
      this.idList.add(((Category)this.categories.get(i)).getCategory_id());
      this.hintList.add(((Category)this.categories.get(i)).getCategoryDes());
      i++;
      break label426;
      label1919: this.bt0 = new TextView(this.context);
      LinearLayout.LayoutParams localLayoutParams6 = new LinearLayout.LayoutParams(-1, -2, 1.0F);
      this.bt0.setLayoutParams(localLayoutParams6);
      this.bt0.setGravity(17);
      this.bt0.setText("提建议");
      this.bt0.setTextSize(2, 16.0F);
      this.bt0.setTextColor(Color.parseColor("#333333"));
      this.linear4.addView(this.bt0);
      this.idList.add("1");
      this.btList.add(this.bt0);
      this.bt1 = new TextView(this.context);
      this.bt1.setLayoutParams(localLayoutParams6);
      this.bt1.setGravity(17);
      this.bt1.setText("有错误");
      this.bt1.setTextSize(2, 16.0F);
      this.bt1.setTextColor(Color.parseColor("#333333"));
      this.linear4.addView(this.bt1);
      this.btList.add(this.bt1);
      this.idList.add("2");
      this.bt2 = new TextView(this.context);
      this.bt2.setLayoutParams(localLayoutParams6);
      this.bt2.setGravity(17);
      this.bt2.setText("不会用");
      this.bt2.setTextSize(2, 16.0F);
      this.bt2.setTextColor(Color.parseColor("#333333"));
      this.linear4.addView(this.bt2);
      this.btList.add(this.bt2);
      this.idList.add("3");
      this.bt3 = new TextView(this.context);
      this.bt3.setLayoutParams(localLayoutParams6);
      this.bt3.setGravity(17);
      this.bt3.setText("其他");
      this.bt3.setTextSize(2, 16.0F);
      this.bt3.setTextColor(Color.parseColor("#333333"));
      this.linear4.addView(this.bt3);
      this.btList.add(this.bt3);
      this.idList.add("4");
      this.hintList.add("请留下您的建议,我们将尽快回复!");
      this.hintList.add("发现错误?我们将尽快修改!");
      this.hintList.add("我们来解答您的使用困惑!");
      this.hintList.add("用心倾听,我们将做的更好!");
      break label440;
      localObject = "多";
      break label726;
    }
  }

  public void setTitle(CommonTitle paramCommonTitle)
  {
    this.title = paramCommonTitle;
  }

  public static abstract interface Listener
  {
    public abstract void onMultiReplyClick();

    public abstract void onSingleReplyClick();

    public abstract void onSubmitBack();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.SubmitView
 * JD-Core Version:    0.6.2
 */