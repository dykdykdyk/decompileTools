package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.graphics.Color;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

public class MyDialog extends LinearLayout
{
  private Context context;
  private BackGroundSelector selector;
  private LinearLayout sureBt;
  private TextView title;

  public MyDialog(Context paramContext)
  {
    super(paramContext);
    this.context = paramContext;
    this.selector = new BackGroundSelector(paramContext);
    initView();
  }

  private void initView()
  {
    setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
    setBackgroundDrawable(this.selector.getdrawble("dialog", this.context));
    setOrientation(1);
    this.title = new TextView(this.context);
    LinearLayout.LayoutParams localLayoutParams1 = new LinearLayout.LayoutParams(-1, -1, 1.0F);
    this.title.setLayoutParams(localLayoutParams1);
    this.title.setGravity(17);
    this.title.setTextColor(-16777216);
    this.title.setTextSize(2, 16.0F);
    addView(this.title);
    this.sureBt = new LinearLayout(this.context);
    LinearLayout.LayoutParams localLayoutParams2 = new LinearLayout.LayoutParams(-2, -2);
    localLayoutParams2.gravity = 81;
    this.sureBt.setLayoutParams(localLayoutParams2);
    this.sureBt.setBackgroundDrawable(this.selector.createBgByImageIds(new String[] { "dialog_button", "dialog_button_click" }));
    TextView localTextView = new TextView(this.context);
    localTextView.setLayoutParams(new LinearLayout.LayoutParams(-1, -1, 1.0F));
    localTextView.setGravity(17);
    localTextView.setText("确定");
    localTextView.setTextColor(Color.parseColor("#2773dc"));
    localTextView.setTextSize(2, 18.0F);
    this.sureBt.addView(localTextView);
    addView(this.sureBt);
  }

  public void SetTitleText(String paramString)
  {
    this.title.setText(paramString);
  }

  public LinearLayout getSureBt()
  {
    return this.sureBt;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.MyDialog
 * JD-Core Version:    0.6.2
 */