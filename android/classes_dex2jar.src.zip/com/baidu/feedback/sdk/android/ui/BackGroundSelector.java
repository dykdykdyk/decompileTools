package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import java.io.IOException;

public class BackGroundSelector
{
  static int[] EMPTY_STATE_SET = new int[0];
  static int[] ENABLED_STATE_SET;
  static int[] PRESSED_ENABLED_STATE_SET = { 16842910, 16842919 };
  private static String pix;
  private static String[] pixs = { "320x480", "480x800", "720x1280" };
  private Context context;

  static
  {
    ENABLED_STATE_SET = new int[] { 16842910 };
  }

  public BackGroundSelector(Context paramContext)
  {
    this.context = paramContext;
  }

  public static void setPix(String paramString)
  {
    int i = 0;
    for (int j = 0; ; j++)
    {
      if (j >= 3)
      {
        if (i == 0)
        {
          if (!paramString.equals("480x854"))
            break;
          pix = "480x800";
        }
        return;
      }
      if (paramString.equals(pixs[j]))
      {
        pix = paramString;
        i = 1;
      }
    }
    pix = "";
  }

  public StateListDrawable createBgByImageIds(String[] paramArrayOfString)
  {
    StateListDrawable localStateListDrawable = new StateListDrawable();
    Drawable localDrawable1 = getdrawble(paramArrayOfString[0], this.context);
    Drawable localDrawable2 = getdrawble(paramArrayOfString[1], this.context);
    localStateListDrawable.addState(PRESSED_ENABLED_STATE_SET, localDrawable2);
    localStateListDrawable.addState(ENABLED_STATE_SET, localDrawable1);
    localStateListDrawable.addState(EMPTY_STATE_SET, localDrawable1);
    return localStateListDrawable;
  }

  public Drawable getdrawble(String paramString, Context paramContext)
  {
    Bitmap localBitmap = null;
    try
    {
      String str = paramString + pix + ".png";
      localBitmap = BitmapFactory.decodeStream(paramContext.getAssets().open(str));
      BitmapDrawable localBitmapDrawable = new BitmapDrawable(paramContext.getResources(), localBitmap);
      return localBitmapDrawable;
    }
    catch (IOException localIOException)
    {
      if (localBitmap != null)
        localBitmap.recycle();
      localIOException.printStackTrace();
    }
    return null;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.BackGroundSelector
 * JD-Core Version:    0.6.2
 */