package com.baidu.feedback.sdk.android.ui;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;

public class PxAndDp
{
  public static int dip2px(Context paramContext, float paramFloat)
  {
    return (int)(0.5F + paramFloat * paramContext.getResources().getDisplayMetrics().density);
  }

  public static int px2dip(Context paramContext, float paramFloat)
  {
    return (int)(0.5F + paramFloat / paramContext.getResources().getDisplayMetrics().density);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.ui.PxAndDp
 * JD-Core Version:    0.6.2
 */