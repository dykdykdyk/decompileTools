package com.baidu.feedback.sdk.android.network;

import android.content.Context;
import android.util.Log;
import com.baidu.feedback.sdk.android.model.CategoryResult;
import com.baidu.feedback.sdk.android.model.ReplyResult;
import com.baidu.feedback.sdk.android.model.Result;
import com.baidu.feedback.sdk.android.model.SubSucResult;
import com.baidu.feedback.sdk.android.model.SummitResult;
import com.baidu.feedback.sdk.android.model.TmpMarkResult;
import java.io.InputStream;
import java.util.List;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpConnectionManager;
import org.apache.commons.httpclient.methods.PostMethod;

public abstract class HttpReq
{
  protected HttpClient httpClient;
  protected Context mContext;
  protected ReqParam mParam;
  protected String mUrl = null;
  protected PostMethod postMethod;

  public void cancelConnection()
  {
    if (this.postMethod != null)
      this.postMethod.releaseConnection();
    if (this.httpClient != null)
      this.httpClient.getHttpConnectionManager().closeIdleConnections(0L);
  }

  public Result execute()
  {
    try
    {
      Object localObject = runReq();
      if (localObject == null)
      {
        Result localResult = failedResult(-1);
        localObject = localResult;
      }
      return localObject;
    }
    catch (Exception localException)
    {
      Log.e("result", localException.toString());
      localException.printStackTrace();
    }
    return failedResult(-1);
  }

  public Result failedResult(int paramInt)
  {
    Result localResult = getBackResult(getAction());
    localResult.setSuccess(false);
    localResult.setErrnoCode(paramInt);
    return localResult;
  }

  public String getAction()
  {
    if (this.mParam == null)
      return "";
    return this.mParam.getAction();
  }

  protected Result getBackResult(String paramString)
  {
    if ("submit".equals(paramString))
      return new SummitResult();
    if ("getMark".equals(paramString))
      return new TmpMarkResult();
    if ("getCategory".equals(paramString))
      return new CategoryResult();
    if ("getReply".equals(paramString))
    {
      ReplyResult localReplyResult = new ReplyResult();
      ReplyResult.replies.clear();
      return localReplyResult;
    }
    return new SubSucResult();
  }

  protected abstract Result processResponse(InputStream paramInputStream)
    throws Exception;

  protected abstract Result runReq()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.network.HttpReq
 * JD-Core Version:    0.6.2
 */