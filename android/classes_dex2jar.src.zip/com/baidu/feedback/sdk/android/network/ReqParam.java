package com.baidu.feedback.sdk.android.network;

import android.content.Context;
import com.baidu.feedback.sdk.android.model.Content;
import com.baidu.feedback.sdk.android.model.DeviceInfo;
import com.baidu.feedback.sdk.android.model.ProducUserParam;
import com.baidu.feedback.sdk.android.util.Base64Util;
import com.baidu.feedback.sdk.android.util.FeBaUtils;
import com.baidu.feedback.sdk.android.util.Location;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ReqParam
{
  public static final String CRM_SERVER_PARAM_ACTION = "action";
  public static final String CRM_SERVER_PARAM_CATEGORY_ID = "category_id";
  public static final String CRM_SERVER_PARAM_CONTACT = "contact";
  public static final String CRM_SERVER_PARAM_CONTENT = "content";
  public static final String CRM_SERVER_PARAM_DATA = "data";
  public static final String CRM_SERVER_PARAM_FROM = "from";
  public static final String CRM_SERVER_PARAM_FROM_VALUE = "mobile";
  public static final String CRM_SERVER_PARAM_IMEI = "imei";
  public static final String CRM_SERVER_PARAM_IS_PRISON_BREAK = "is_prison_break";
  public static final String CRM_SERVER_PARAM_MAC = "mac";
  public static final String CRM_SERVER_PARAM_MOBILE_EDITION = "mobile_edition";
  public static final String CRM_SERVER_PARAM_MOBILE_MODEL = "mobile_model";
  public static final String CRM_SERVER_PARAM_MSG_IDS = "msg_ids";
  public static final String CRM_SERVER_PARAM_NETWORK = "network";
  public static final String CRM_SERVER_PARAM_POSITION = "position";
  public static final String CRM_SERVER_PARAM_PRODUCT = "product";
  public static final String CRM_SERVER_PARAM_PRODUCT_BUILD_VERSION = "product_build_version";
  public static final String CRM_SERVER_PARAM_PRODUCT_UPDATE_DATE = "product_update_date";
  public static final String CRM_SERVER_PARAM_PRODUCT_VERSION = "product_version";
  public static final String CRM_SERVER_PARAM_TMP_MARK = "tmp_mark";
  public static final String CRM_SERVER_PARAM_TOKEN = "token";
  public static final String CRM_SERVER_PARAM_TOKEN_VALUE = "e8ea9cf7101477ff8c757bbde7721c13";
  public static final String CRM_SERVER_PARAM_UID = "uid";
  public static final String CRM_SERVER_PARAM_UIP = "uip";
  public static final String CRM_SERVER_PARAM_USERNAME = "username";
  private String Tmp_mark;
  private String action;
  private Content content;
  private DeviceInfo deviceInfo;
  private List<Integer> msg_ids;
  private String product;
  private String product_build_version;
  private String product_update_date;
  private String product_version;
  private String uid;
  private String username;

  public ReqParam(Context paramContext, Content paramContent, ProducUserParam paramProducUserParam, String paramString)
  {
    this.action = paramString;
    this.content = paramContent;
    this.uid = paramProducUserParam.getUid();
    this.product = paramProducUserParam.getProductName();
    this.username = paramProducUserParam.getUserName();
    this.product_version = paramProducUserParam.getProductVersion();
    this.product_build_version = paramProducUserParam.getProductBuildVersion();
    this.product_update_date = paramProducUserParam.getProductUpdateDate();
    this.Tmp_mark = FeBaUtils.getTmp_mark(paramContext);
    getDeviceInfo(paramContext);
  }

  public ReqParam(Context paramContext, ProducUserParam paramProducUserParam, String paramString)
  {
    this.action = paramString;
    this.uid = paramProducUserParam.getUid();
    this.product = paramProducUserParam.getProductName();
    this.username = paramProducUserParam.getUserName();
    this.product_version = paramProducUserParam.getProductVersion();
    this.product_build_version = paramProducUserParam.getProductBuildVersion();
    this.product_update_date = paramProducUserParam.getProductUpdateDate();
    this.Tmp_mark = FeBaUtils.getTmp_mark(paramContext);
    getDeviceInfo(paramContext);
  }

  public ReqParam(Context paramContext, String paramString1, String paramString2)
  {
    this.action = paramString2;
    this.Tmp_mark = FeBaUtils.getTmp_mark(paramContext);
    this.product = paramString1;
  }

  public ReqParam(Context paramContext, String paramString1, List<Integer> paramList, String paramString2)
  {
    this.action = paramString2;
    this.Tmp_mark = FeBaUtils.getTmp_mark(paramContext);
    this.product = paramString1;
    this.msg_ids = paramList;
  }

  private String base64Encode(String paramString)
  {
    return new String(Base64Util.encode(paramString.getBytes()));
  }

  private void getDeviceInfo(Context paramContext)
  {
    this.deviceInfo = new DeviceInfo();
    this.deviceInfo.setImei(FeBaUtils.getImei(paramContext));
    this.deviceInfo.setMac(FeBaUtils.getMac(paramContext));
    this.deviceInfo.setImei(FeBaUtils.getImei(paramContext));
    this.deviceInfo.setMobile_model(FeBaUtils.getMobile_model());
    this.deviceInfo.setIs_prison_break(FeBaUtils.getIsPrisonBreak());
    this.deviceInfo.setNetwork(FeBaUtils.getNetwork(paramContext));
  }

  private JSONObject getDeviceInfoData()
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      if ("submitSuccess".equals(this.action))
      {
        JSONArray localJSONArray = new JSONArray();
        Iterator localIterator = this.msg_ids.iterator();
        while (true)
        {
          if (!localIterator.hasNext())
          {
            localJSONObject.put("msg_ids", localJSONArray);
            return localJSONObject;
          }
          localJSONArray.put(((Integer)localIterator.next()).intValue());
        }
      }
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
      return localJSONObject;
    }
    if (this.uid != null)
      localJSONObject.put("uid", this.uid);
    while (!"getReply".equals(this.action))
    {
      if (this.uid != null)
        localJSONObject.put("username", this.username);
      setInfo(localJSONObject);
      return localJSONObject;
      localJSONObject.put("tmp_mark", this.Tmp_mark);
    }
    return localJSONObject;
  }

  private void setInfo(JSONObject paramJSONObject)
    throws JSONException
  {
    paramJSONObject.put("mac", this.deviceInfo.getMac());
    paramJSONObject.put("imei", this.deviceInfo.getImei());
    paramJSONObject.put("mobile_edition", "2");
    paramJSONObject.put("mobile_model", this.deviceInfo.getMobile_model());
    paramJSONObject.put("is_prison_break", this.deviceInfo.getIs_prison_break());
    paramJSONObject.put("network", this.deviceInfo.getNetwork());
    paramJSONObject.put("position", Location.LocAddrStr);
    paramJSONObject.put("product_version", this.product_version);
    paramJSONObject.put("product_build_version", this.product_build_version);
    paramJSONObject.put("product_update_date", this.product_update_date);
    paramJSONObject.put("category_id", this.content.getCategory_id());
    paramJSONObject.put("content", this.content.getCategory_content());
    paramJSONObject.put("contact", this.content.getContact());
  }

  public String getAction()
  {
    return this.action;
  }

  public DeviceInfo getDeviceInfo()
  {
    return this.deviceInfo;
  }

  public String getParamsBody()
  {
    String str1 = "";
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("from", "mobile");
      localJSONObject.put("token", "e8ea9cf7101477ff8c757bbde7721c13");
      localJSONObject.put("action", this.action);
      localJSONObject.put("product", this.product);
      if ((!"getMark".equals(this.action)) && (!"getCategory".equals(this.action)))
        localJSONObject.put("data", getDeviceInfoData());
      str1 = localJSONObject.toString();
      String str2 = base64Encode(str1);
      return str2;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
    return str1;
  }

  public String getUid()
  {
    return this.uid;
  }

  public void setDeviceInfo(DeviceInfo paramDeviceInfo)
  {
    this.deviceInfo = paramDeviceInfo;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.network.ReqParam
 * JD-Core Version:    0.6.2
 */