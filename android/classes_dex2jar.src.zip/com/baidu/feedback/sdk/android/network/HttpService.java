package com.baidu.feedback.sdk.android.network;

import com.baidu.feedback.sdk.android.model.Result;
import java.util.List;

public class HttpService
{
  private static HttpService instance = null;
  private boolean isDestroy;
  private List<HttpReq> mRunningReqList = null;

  private void cancelNetWork(String paramString)
  {
    for (int i = 0; ; i++)
      try
      {
        int j = this.mRunningReqList.size();
        if (i >= j)
          return;
        HttpReq localHttpReq = (HttpReq)this.mRunningReqList.get(i);
        if (localHttpReq != null)
          if (localHttpReq.getAction().equals(paramString))
          {
            localHttpReq.cancelConnection();
            this.mRunningReqList.remove(localHttpReq);
            i--;
          }
          else if (("".equals(paramString)) && (!localHttpReq.getAction().equals("submitSuccess")))
          {
            localHttpReq.cancelConnection();
            this.mRunningReqList.remove(localHttpReq);
            i--;
          }
      }
      finally
      {
      }
  }

  public static HttpService getInstance()
  {
    try
    {
      if (instance == null)
        instance = new HttpService();
      return instance;
    }
    finally
    {
    }
  }

  public void Destroy()
  {
    this.isDestroy = true;
    cancelHttpReq("");
    instance = null;
  }

  public Result addImmediateReq(HttpReq paramHttpReq)
  {
    try
    {
      Object localObject2;
      if (!this.isDestroy)
      {
        this.mRunningReqList.add(paramHttpReq);
        localObject2 = paramHttpReq.execute();
        if (this.mRunningReqList.contains(paramHttpReq))
          this.mRunningReqList.remove(paramHttpReq);
      }
      while (true)
      {
        return localObject2;
        Result localResult = paramHttpReq.failedResult(-1);
        localObject2 = localResult;
      }
    }
    finally
    {
    }
  }

  public void cancelHttpReq(final String paramString)
  {
    new Thread(new Runnable()
    {
      public void run()
      {
        try
        {
          HttpService.this.cancelNetWork(paramString);
          return;
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
        }
      }
    }).start();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.network.HttpService
 * JD-Core Version:    0.6.2
 */