package com.baidu.feedback.sdk.android.network;

public class HttpConfig
{
  public static String CRM_SERVER_URI = "http://qingting.baidu.com/api_mobile/";
  public static int FB_CONNECTION_TIMEOUT = 0;
  public static int FB_READ_DATA_TIMEOUT = 0;
  public static final String SERVER_ACTION_GETCATEGORY = "getCategory";
  public static final String SERVER_ACTION_GETMARK = "getMark";
  public static final String SERVER_ACTION_GETREPLY = "getReply";
  public static final String SERVER_ACTION_SUBMIT = "submit";
  public static final String SERVER_ACTION_SUBMITSUCCESS = "submitSuccess";
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.feedback.sdk.android.network.HttpConfig
 * JD-Core Version:    0.6.2
 */