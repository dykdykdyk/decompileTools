package com.baidu.util;

public class Base64Encoder
{
  static
  {
    try
    {
      System.loadLibrary("base64encoder_v1_4");
      return;
    }
    catch (Error localError)
    {
    }
    catch (Exception localException)
    {
    }
  }

  public static final byte[] B64Decode(byte[] paramArrayOfByte)
  {
    try
    {
      byte[] arrayOfByte = nativeB64Decode(paramArrayOfByte);
      return arrayOfByte;
    }
    catch (Exception localException)
    {
      return paramArrayOfByte;
    }
    catch (Error localError)
    {
    }
    return paramArrayOfByte;
  }

  public static final byte[] B64Encode(byte[] paramArrayOfByte)
  {
    try
    {
      byte[] arrayOfByte = nativeB64Encode(paramArrayOfByte);
      return arrayOfByte;
    }
    catch (Exception localException)
    {
      return paramArrayOfByte;
    }
    catch (Error localError)
    {
    }
    return paramArrayOfByte;
  }

  public static final int B64GetVersion()
  {
    try
    {
      int i = nativeB64GetVersion();
      return i;
    }
    catch (Exception localException)
    {
      return 0;
    }
    catch (Error localError)
    {
    }
    return 0;
  }

  public static final native byte[] nativeB64Decode(byte[] paramArrayOfByte);

  private static final native byte[] nativeB64Encode(byte[] paramArrayOfByte);

  public static final native int nativeB64GetVersion();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.util.Base64Encoder
 * JD-Core Version:    0.6.2
 */