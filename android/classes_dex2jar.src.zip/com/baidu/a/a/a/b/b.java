package com.baidu.a.a.a.b;

import android.content.Context;
import android.os.Environment;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.baidu.a.a.a.a.a;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public final class b
{
  // ERROR //
  public static String a(Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: ldc 10
    //   3: invokestatic 13	com/baidu/a/a/a/b/b:a	(Landroid/content/Context;Ljava/lang/String;)V
    //   6: aload_0
    //   7: ldc 15
    //   9: invokestatic 13	com/baidu/a/a/a/b/b:a	(Landroid/content/Context;Ljava/lang/String;)V
    //   12: aload_0
    //   13: ldc 17
    //   15: invokestatic 13	com/baidu/a/a/a/b/b:a	(Landroid/content/Context;Ljava/lang/String;)V
    //   18: iconst_0
    //   19: istore_1
    //   20: ldc 19
    //   22: astore_2
    //   23: aload_0
    //   24: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   27: ldc 27
    //   29: invokestatic 33	android/provider/Settings$System:getString	(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   32: astore_2
    //   33: aload_2
    //   34: ifnonnull +323 -> 357
    //   37: aload_0
    //   38: invokestatic 36	com/baidu/a/a/a/b/b:b	(Landroid/content/Context;)Ljava/lang/String;
    //   41: astore 18
    //   43: aload 18
    //   45: astore 5
    //   47: aload_0
    //   48: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   51: ldc 27
    //   53: aload 5
    //   55: invokestatic 40	android/provider/Settings$System:putString	(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z
    //   58: pop
    //   59: aload_0
    //   60: invokestatic 43	com/baidu/a/a/a/b/b:c	(Landroid/content/Context;)Ljava/lang/String;
    //   63: astore 7
    //   65: iload_1
    //   66: ifeq +57 -> 123
    //   69: new 45	java/lang/StringBuilder
    //   72: dup
    //   73: invokespecial 49	java/lang/StringBuilder:<init>	()V
    //   76: ldc 51
    //   78: invokevirtual 55	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: aload 7
    //   83: invokevirtual 55	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: invokevirtual 59	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   89: invokevirtual 65	java/lang/String:getBytes	()[B
    //   92: iconst_1
    //   93: invokestatic 70	com/baidu/a/a/a/b/c:a	([BZ)Ljava/lang/String;
    //   96: astore 8
    //   98: aload 8
    //   100: areturn
    //   101: astore_3
    //   102: aload_3
    //   103: astore 4
    //   105: aload_2
    //   106: astore 5
    //   108: ldc 72
    //   110: ldc 74
    //   112: aload 4
    //   114: invokestatic 80	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   117: pop
    //   118: iconst_1
    //   119: istore_1
    //   120: goto -61 -> 59
    //   123: aload_0
    //   124: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   127: ldc 82
    //   129: invokestatic 33	android/provider/Settings$System:getString	(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   132: astore 8
    //   134: aload 8
    //   136: invokestatic 88	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   139: istore 9
    //   141: aconst_null
    //   142: astore 10
    //   144: iload 9
    //   146: ifeq +75 -> 221
    //   149: new 45	java/lang/StringBuilder
    //   152: dup
    //   153: invokespecial 49	java/lang/StringBuilder:<init>	()V
    //   156: ldc 51
    //   158: invokevirtual 55	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: aload 5
    //   163: invokevirtual 55	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: aload 7
    //   168: invokevirtual 55	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: invokevirtual 59	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   174: invokevirtual 65	java/lang/String:getBytes	()[B
    //   177: iconst_1
    //   178: invokestatic 70	com/baidu/a/a/a/b/c:a	([BZ)Ljava/lang/String;
    //   181: astore 10
    //   183: aload_0
    //   184: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   187: aload 10
    //   189: invokestatic 33	android/provider/Settings$System:getString	(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   192: astore 8
    //   194: aload 8
    //   196: invokestatic 88	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   199: ifne +22 -> 221
    //   202: aload_0
    //   203: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   206: ldc 82
    //   208: aload 8
    //   210: invokestatic 40	android/provider/Settings$System:putString	(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z
    //   213: pop
    //   214: aload 5
    //   216: aload 8
    //   218: invokestatic 91	com/baidu/a/a/a/b/b:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   221: aload 8
    //   223: invokestatic 88	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   226: ifeq +42 -> 268
    //   229: aload 5
    //   231: invokestatic 94	com/baidu/a/a/a/b/b:a	(Ljava/lang/String;)Ljava/lang/String;
    //   234: astore 8
    //   236: aload 8
    //   238: invokestatic 88	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   241: ifne +27 -> 268
    //   244: aload_0
    //   245: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   248: aload 10
    //   250: aload 8
    //   252: invokestatic 40	android/provider/Settings$System:putString	(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z
    //   255: pop
    //   256: aload_0
    //   257: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   260: ldc 82
    //   262: aload 8
    //   264: invokestatic 40	android/provider/Settings$System:putString	(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z
    //   267: pop
    //   268: aload 8
    //   270: invokestatic 88	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   273: ifeq -175 -> 98
    //   276: invokestatic 100	java/util/UUID:randomUUID	()Ljava/util/UUID;
    //   279: invokevirtual 101	java/util/UUID:toString	()Ljava/lang/String;
    //   282: astore 11
    //   284: new 45	java/lang/StringBuilder
    //   287: dup
    //   288: invokespecial 49	java/lang/StringBuilder:<init>	()V
    //   291: aload 5
    //   293: invokevirtual 55	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   296: aload 7
    //   298: invokevirtual 55	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   301: aload 11
    //   303: invokevirtual 55	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   306: invokevirtual 59	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   309: invokevirtual 65	java/lang/String:getBytes	()[B
    //   312: iconst_1
    //   313: invokestatic 70	com/baidu/a/a/a/b/c:a	([BZ)Ljava/lang/String;
    //   316: astore 12
    //   318: aload_0
    //   319: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   322: aload 10
    //   324: aload 12
    //   326: invokestatic 40	android/provider/Settings$System:putString	(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z
    //   329: pop
    //   330: aload_0
    //   331: invokevirtual 25	android/content/Context:getContentResolver	()Landroid/content/ContentResolver;
    //   334: ldc 82
    //   336: aload 12
    //   338: invokestatic 40	android/provider/Settings$System:putString	(Landroid/content/ContentResolver;Ljava/lang/String;Ljava/lang/String;)Z
    //   341: pop
    //   342: aload 5
    //   344: aload 12
    //   346: invokestatic 91	com/baidu/a/a/a/b/b:a	(Ljava/lang/String;Ljava/lang/String;)V
    //   349: aload 12
    //   351: areturn
    //   352: astore 4
    //   354: goto -246 -> 108
    //   357: aload_2
    //   358: astore 5
    //   360: goto -313 -> 47
    //
    // Exception table:
    //   from	to	target	type
    //   23	33	101	java/lang/Exception
    //   37	43	101	java/lang/Exception
    //   47	59	352	java/lang/Exception
  }

  private static String a(String paramString)
  {
    String str1;
    if (TextUtils.isEmpty(paramString))
      str1 = "";
    while (true)
    {
      return str1;
      str1 = "";
      File localFile = new File(Environment.getExternalStorageDirectory(), "baidu/.cuid");
      try
      {
        BufferedReader localBufferedReader = new BufferedReader(new FileReader(localFile));
        StringBuilder localStringBuilder = new StringBuilder();
        while (true)
        {
          String str2 = localBufferedReader.readLine();
          if (str2 == null)
            break;
          localStringBuilder.append(str2);
          localStringBuilder.append("\r\n");
        }
        localBufferedReader.close();
        String[] arrayOfString = new String(a.b("30212102dicudiab", "30212102dicudiab", com.baidu.a.a.a.a.b.a(localStringBuilder.toString().getBytes()))).split("=");
        if ((arrayOfString != null) && (arrayOfString.length == 2) && (paramString.equals(arrayOfString[0])))
        {
          String str3 = arrayOfString[1];
          return str3;
        }
      }
      catch (Exception localException)
      {
        return str1;
      }
      catch (IOException localIOException)
      {
        return str1;
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
      }
    }
    return str1;
  }

  private static void a(Context paramContext, String paramString)
  {
    if (paramContext.checkCallingOrSelfPermission(paramString) == 0);
    for (int i = 1; i == 0; i = 0)
      throw new SecurityException("Permission Denial: requires permission " + paramString);
  }

  private static void a(String paramString1, String paramString2)
  {
    if (TextUtils.isEmpty(paramString1))
      return;
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(paramString1);
    localStringBuilder.append("=");
    localStringBuilder.append(paramString2);
    File localFile = new File(Environment.getExternalStorageDirectory(), "baidu/.cuid");
    try
    {
      new File(localFile.getParent()).mkdirs();
      FileWriter localFileWriter = new FileWriter(localFile, false);
      localFileWriter.write(com.baidu.a.a.a.a.b.a(a.a("30212102dicudiab", "30212102dicudiab", localStringBuilder.toString().getBytes()), "utf-8"));
      localFileWriter.flush();
      localFileWriter.close();
      return;
    }
    catch (IOException localIOException)
    {
    }
    catch (Exception localException)
    {
    }
  }

  public static String b(Context paramContext)
  {
    TelephonyManager localTelephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
    if (localTelephonyManager != null)
    {
      String str = localTelephonyManager.getDeviceId();
      if (TextUtils.isEmpty(str))
        str = "";
      return str;
    }
    return "";
  }

  public static String c(Context paramContext)
  {
    String str = Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
    if (TextUtils.isEmpty(str))
      str = "";
    return str;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.a.a.a.b.b
 * JD-Core Version:    0.6.2
 */