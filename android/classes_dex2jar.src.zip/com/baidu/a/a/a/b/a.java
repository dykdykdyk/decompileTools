package com.baidu.a.a.a.b;

import android.content.Context;
import android.text.TextUtils;

public class a
{
  private static final String a = a.class.getSimpleName();

  public static String a(Context paramContext)
  {
    String str1 = b(paramContext);
    String str2 = b.b(paramContext);
    if (TextUtils.isEmpty(str2))
      str2 = "0";
    String str3 = new StringBuffer(str2).reverse().toString();
    return str1 + "|" + str3;
  }

  private static String b(Context paramContext)
  {
    return b.a(paramContext);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.a.a.a.b.a
 * JD-Core Version:    0.6.2
 */