package com.baidu.wearable;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.os.AsyncTask;
import android.text.TextUtils;
import com.baidu.mobstat.StatService;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.sapi2.SapiConfig;
import com.baidu.sapi2.social.config.BindType;
import com.baidu.sapi2.social.config.Domain;
import com.baidu.wearable.ble.util.LogUtil;
import java.io.IOException;
import java.io.InputStream;
import org.apache.http.util.EncodingUtils;

public class WearableApplication extends Application
{
  private static Bitmap SLightSleepBitmap;
  private static final String TAG = "WearableApplication";
  private static String channel_ID = "";
  private static Bitmap sDeepSleepBitmap;
  private static Bitmap sNightBitmap;
  private static Bitmap sSportsProgressBitmap;

  public static String getChannelID()
  {
    return channel_ID;
  }

  public static Bitmap getDeepSleepBitmap()
  {
    return sDeepSleepBitmap;
  }

  public static Bitmap getLightSleepBitmap()
  {
    return SLightSleepBitmap;
  }

  public static Bitmap getNightBitmap()
  {
    return sNightBitmap;
  }

  public static Bitmap getSportsProgressBitmap()
  {
    return sSportsProgressBitmap;
  }

  private void loadBitmaps()
  {
    BitmapFactory.Options localOptions = new BitmapFactory.Options();
    localOptions.inJustDecodeBounds = true;
    BitmapFactory.decodeResource(getResources(), 2130837822, localOptions);
    localOptions.inJustDecodeBounds = false;
    sSportsProgressBitmap = BitmapFactory.decodeResource(getResources(), 2130837822);
    sDeepSleepBitmap = BitmapFactory.decodeResource(getResources(), 2130837564);
    SLightSleepBitmap = BitmapFactory.decodeResource(getResources(), 2130837674);
    sNightBitmap = BitmapFactory.decodeResource(getResources(), 2130837601);
  }

  public void initConfig()
  {
    if (BDAccountManager.getInstance().isLogin())
      Config.init(this, getSharedPreferences("usercount", 0).getString("usercount_bduss", ""), BDAccountManager.getInstance().getUserData("uid"));
  }

  public void onCreate()
  {
    super.onCreate();
    LogUtil.d("WearableApplication", "onCreate");
    SapiConfig localSapiConfig = new SapiConfig("dulife", "1", "abc3ccf0769c1c4f2c80ba80957b9e53", Domain.DOMAIN_ONLINE, BindType.IMPLICIT);
    BDAccountManager.getInstance().initial(getApplicationContext(), localSapiConfig);
    initConfig();
    LoadBitmapTask localLoadBitmapTask = new LoadBitmapTask(null);
    channel_ID = readChannelNum(this);
    LogUtil.d("WearableApplication", "setAppChannel channel_ID=" + channel_ID);
    StatService.setAppChannel(this, channel_ID, true);
    localLoadBitmapTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
  }

  public void onLowMemory()
  {
    super.onLowMemory();
    LogUtil.d("WearableApplication", "onLowMemory");
  }

  public void onTerminate()
  {
    super.onTerminate();
    LogUtil.d("WearableApplication", "onTerminate");
  }

  public String readChannelNum(Context paramContext)
  {
    SharedPreferences localSharedPreferences = getSharedPreferences("usercount", 0);
    String str1 = localSharedPreferences.getString("usercount_channel", "");
    if (!TextUtils.isEmpty(str1))
      return str1;
    InputStream localInputStream = null;
    try
    {
      localInputStream = getResources().getAssets().open("channel");
      byte[] arrayOfByte = new byte[localInputStream.available()];
      localInputStream.read(arrayOfByte);
      String str2 = EncodingUtils.getString(arrayOfByte, "UTF-8").trim();
      SharedPreferences.Editor localEditor = localSharedPreferences.edit();
      localEditor.putString("usercount_channel", str2);
      localEditor.commit();
      if (localInputStream != null);
      try
      {
        localInputStream.close();
        return str2;
      }
      catch (IOException localIOException3)
      {
        while (true)
          LogUtil.e("WearableApplication", localIOException3.getMessage(), localIOException3);
      }
    }
    catch (Exception localException)
    {
      LogUtil.e("WearableApplication", localException.getMessage(), localException);
      if (localInputStream != null);
      try
      {
        localInputStream.close();
        return "";
      }
      catch (IOException localIOException2)
      {
        while (true)
          LogUtil.e("WearableApplication", localIOException2.getMessage(), localIOException2);
      }
    }
    finally
    {
      if (localInputStream == null);
    }
    try
    {
      localInputStream.close();
      throw localObject;
    }
    catch (IOException localIOException1)
    {
      while (true)
        LogUtil.e("WearableApplication", localIOException1.getMessage(), localIOException1);
    }
  }

  private class LoadBitmapTask extends AsyncTask<Void, Integer, Integer>
  {
    private LoadBitmapTask()
    {
    }

    protected Integer doInBackground(Void[] paramArrayOfVoid)
    {
      WearableApplication.this.loadBitmaps();
      return null;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.WearableApplication
 * JD-Core Version:    0.6.2
 */