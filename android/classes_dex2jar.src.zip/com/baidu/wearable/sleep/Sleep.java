package com.baidu.wearable.sleep;

import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.util.TimeUtil;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Sleep
  implements Comparable<Sleep>, Serializable
{
  private static final String TAG = "Sleep";
  private static final long serialVersionUID = 1L;
  private List<SleepSlot> asleepToWakeSleepSlots;
  private List<SleepDetail> sleepDetails;
  private SleepDuration sleepDuration;
  private List<SleepSlot> sleepSlots;

  public Sleep(SleepDuration paramSleepDuration, List<SleepDetail> paramList)
  {
    if ((paramSleepDuration == null) || (paramList == null))
    {
      this.sleepDuration = null;
      this.sleepDetails = null;
      this.sleepSlots = null;
      this.asleepToWakeSleepSlots = null;
      return;
    }
    this.sleepDuration = paramSleepDuration;
    this.sleepDetails = paramList;
    this.sleepSlots = constructSleepSlotList(getStartSleepInSeconds(), getEndSleepInSeconds(), paramList);
    this.asleepToWakeSleepSlots = constructSleepSlotList(getFallAsleepInSeconds(), getWakeInSeconds(), paramList);
  }

  private List<SleepSlot> constructSleepSlotList(long paramLong1, long paramLong2, List<SleepDetail> paramList)
  {
    if ((paramLong1 == 0L) || (paramLong2 == 0L) || (paramList == null) || ((paramList != null) && (paramList.size() == 0)))
      return null;
    Collections.sort(paramList);
    LogUtil.d("Sleep", "start construct SleepSlot");
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    label72: SleepDetail localSleepDetail3;
    if (i >= -1 + paramList.size())
    {
      localSleepDetail3 = (SleepDetail)paramList.get(-1 + paramList.size());
      if ((localSleepDetail3.getTimestampS() <= paramLong1) || (localSleepDetail3.getTimestampS() >= paramLong2))
        break label501;
      LogUtil.d("Sleep", "construct SleepSlot, deal with last detail between duration: startTime=" + localSleepDetail3.getTimestampS() + ", duration=" + (paramLong2 - localSleepDetail3.getTimestampS()) + ", state=" + localSleepDetail3.getState());
      localArrayList.add(new SleepSlot(localSleepDetail3.getTimestampS(), paramLong2 - localSleepDetail3.getTimestampS(), localSleepDetail3.getState()));
    }
    while (true)
    {
      LogUtil.d("Sleep", "end construct SleepSlot");
      return localArrayList;
      SleepDetail localSleepDetail1 = (SleepDetail)paramList.get(i);
      SleepDetail localSleepDetail2 = (SleepDetail)paramList.get(i + 1);
      long l1 = localSleepDetail1.getTimestampS();
      long l2 = localSleepDetail2.getTimestampS();
      if ((l1 < paramLong1) && (l2 > paramLong1) && (l2 <= paramLong2))
      {
        LogUtil.d("Sleep", "construct SleepSlot, first is before duration, second is in duration");
        localArrayList.add(new SleepSlot(paramLong1, l2 - paramLong1, localSleepDetail1.getState()));
      }
      label484: 
      do
        while (true)
        {
          i++;
          break;
          if ((l1 >= paramLong1) && (l1 < paramLong2) && (l2 > paramLong2))
          {
            LogUtil.d("Sleep", "construct SleepSlot, first is in duration, second is after duration");
            localArrayList.add(new SleepSlot(l1, paramLong2 - l1, localSleepDetail1.getState()));
          }
          else if ((l1 >= paramLong1) && (l2 <= paramLong2))
          {
            LogUtil.d("Sleep", "construct SleepSlot, first and second is in duration");
            localArrayList.add(new SleepSlot(l1, l2 - l1, localSleepDetail1.getState()));
          }
          else if (l2 < paramLong1)
          {
            LogUtil.d("Sleep", "construct SleepSlot, first and second is before duration");
          }
          else
          {
            if ((l1 >= paramLong1) || (l2 <= paramLong2))
              break label484;
            LogUtil.d("Sleep", "construct SleepSlot, first is before duration, second is after duration");
            localArrayList.add(new SleepSlot(paramLong1, paramLong2 - paramLong1, localSleepDetail1.getState()));
          }
        }
      while (l1 <= paramLong2);
      LogUtil.d("Sleep", "construct SleepSlot, first and second is after duration");
      break label72;
      label501: if (localSleepDetail3.getTimestampS() <= paramLong1)
      {
        LogUtil.d("Sleep", "construct SleepSlot, deal with last detail before duration: startTime=" + paramLong1 + ", duration=" + (paramLong2 - paramLong1) + ", state=" + localSleepDetail3.getState());
        localArrayList.add(new SleepSlot(paramLong1, paramLong2 - paramLong1, localSleepDetail3.getState()));
      }
      else
      {
        localSleepDetail3.getTimestampS();
      }
    }
  }

  public int compareTo(Sleep paramSleep)
  {
    Integer localInteger1 = Integer.valueOf((int)getSleepDuration().getEndTime());
    Integer localInteger2 = Integer.valueOf((int)paramSleep.getSleepDuration().getEndTime());
    return localInteger1.intValue() - localInteger2.intValue();
  }

  public String getDate()
  {
    boolean bool = this.sleepDuration.getEndTime() < 0L;
    String str = null;
    if (bool)
      str = TimeUtil.getDate(1000L * this.sleepDuration.getEndTime());
    return str;
  }

  public long getEndSleepInSeconds()
  {
    if (this.sleepDuration == null)
    {
      LogUtil.d("Sleep", "getEndSleepInSeconds:0");
      return 0L;
    }
    LogUtil.d("Sleep", "getEndSleepInSeconds:" + this.sleepDuration.getEndTime());
    return this.sleepDuration.getEndTime();
  }

  public long getFallAsleepInSeconds()
  {
    if ((this.sleepSlots == null) || ((this.sleepSlots != null) && (this.sleepSlots.size() == 0)))
      LogUtil.d("Sleep", "getFallAsleepInSeconds:0");
    SleepSlot localSleepSlot;
    do
    {
      Iterator localIterator;
      while (!localIterator.hasNext())
      {
        return 0L;
        localIterator = this.sleepSlots.iterator();
      }
      localSleepSlot = (SleepSlot)localIterator.next();
    }
    while (localSleepSlot.getState() == SleepState.AWAKE);
    LogUtil.d("Sleep", "getFallAsleepInSeconds:" + localSleepSlot.getStartTime());
    return localSleepSlot.getStartTime();
  }

  public long getSleepConsumeInSeconds()
  {
    long l = getFallAsleepInSeconds() - getStartSleepInSeconds();
    if (l >= 0L)
    {
      LogUtil.d("Sleep", "getSleepConsumeInSeconds:" + l);
      return l;
    }
    LogUtil.d("Sleep", "getSleepConsumeInSeconds:0");
    return 0L;
  }

  public List<SleepSlot> getSleepDataFromFallAsleepToWake()
  {
    return this.asleepToWakeSleepSlots;
  }

  public List<SleepSlot> getSleepDataFromStartToEnd()
  {
    return this.sleepSlots;
  }

  public List<SleepDetail> getSleepDetails()
  {
    return this.sleepDetails;
  }

  public SleepDuration getSleepDuration()
  {
    return this.sleepDuration;
  }

  public double getSleepEfficiency()
  {
    double d1 = getTotalDeepSleepInSeconds();
    double d2 = getTotalSleepInSeconds();
    if (d2 == 0.0D)
    {
      LogUtil.d("Sleep", "getSleepEfficiency:0");
      return 0.0D;
    }
    LogUtil.d("Sleep", "getSleepEfficiency:" + d1 / d2);
    return d1 / d2;
  }

  public long getStartSleepInSeconds()
  {
    if (this.sleepDuration == null)
    {
      LogUtil.d("Sleep", "getStartSleepInSeconds:0");
      return 0L;
    }
    LogUtil.d("Sleep", "getStartSleepInSeconds:" + this.sleepDuration.getStartTime());
    return this.sleepDuration.getStartTime();
  }

  public long getTotalDeepSleepInSeconds()
  {
    long l = 0L;
    Iterator localIterator;
    if (this.asleepToWakeSleepSlots != null)
      localIterator = this.asleepToWakeSleepSlots.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        LogUtil.d("Sleep", "getTotalDeepSleepInSeconds:" + l);
        return l;
      }
      SleepSlot localSleepSlot = (SleepSlot)localIterator.next();
      if (localSleepSlot.getState() == SleepState.DEEP_SLEEP)
        l += localSleepSlot.getDuration();
    }
  }

  public long getTotalLightSleepInSeconds()
  {
    long l = 0L;
    Iterator localIterator;
    if ((this.asleepToWakeSleepSlots != null) && (this.asleepToWakeSleepSlots.size() > 1))
      localIterator = this.asleepToWakeSleepSlots.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        LogUtil.d("Sleep", "getTotalLightSleepInSeconds:" + l);
        return l;
      }
      SleepSlot localSleepSlot = (SleepSlot)localIterator.next();
      if (localSleepSlot.getState() == SleepState.LIGHT_SLEEP)
        l += localSleepSlot.getDuration();
    }
  }

  public long getTotalSleepInSeconds()
  {
    long l = getWakeInSeconds() - getFallAsleepInSeconds();
    if ((getFallAsleepInSeconds() == 0L) || (getWakeInSeconds() == 0L) || (l <= 0L))
    {
      LogUtil.d("Sleep", "getTotalSleepInSeconds:0");
      return 0L;
    }
    LogUtil.d("Sleep", "getTotalSleepInSeconds:" + l);
    return l;
  }

  public long getWakeInSeconds()
  {
    if ((this.sleepSlots != null) && (this.sleepSlots.size() > 0))
    {
      SleepSlot localSleepSlot = (SleepSlot)this.sleepSlots.get(-1 + this.sleepSlots.size());
      if (localSleepSlot.getState() == SleepState.AWAKE)
      {
        LogUtil.d("Sleep", "getWakeInSeconds:" + (this.sleepDuration.getEndTime() - localSleepSlot.getDuration()));
        return this.sleepDuration.getEndTime() - localSleepSlot.getDuration();
      }
      LogUtil.d("Sleep", "getWakeInSeconds:" + this.sleepDuration.getEndTime());
      return this.sleepDuration.getEndTime();
    }
    LogUtil.d("Sleep", "getWakeInSeconds:0");
    return 0L;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sleep.Sleep
 * JD-Core Version:    0.6.2
 */