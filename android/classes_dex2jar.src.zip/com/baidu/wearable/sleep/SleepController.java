package com.baidu.wearable.sleep;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v4.content.LocalBroadcastManager;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SleepDao;
import com.baidu.wearable.net.SleepTransport;
import com.baidu.wearable.net.Transport.CommonResult;
import com.baidu.wearable.preference.SleepPreference;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.util.NetworkCheck;
import com.baidu.wearable.util.TimeUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.Executor;

public class SleepController
{
  private static final String TAG = "SleepController";

  public static void addSleepSettingTask(Context paramContext, List<SleepSettingDetail> paramList)
  {
    new AsyncTask()
    {
      protected Object doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        SleepController.dealWithSleepSetting((Context)paramAnonymousArrayOfObject[0], (List)paramAnonymousArrayOfObject[1]);
        return null;
      }
    }
    .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, new Object[] { paramContext, paramList });
  }

  public static void addSleepTask(Context paramContext, List<SleepDetail> paramList)
  {
    new AsyncTask()
    {
      protected Object doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        Context localContext = (Context)paramAnonymousArrayOfObject[0];
        List localList = (List)paramAnonymousArrayOfObject[1];
        SleepDao.bulkInsertSleepDetail(Database.getDb(localContext), localList, true);
        return null;
      }
    }
    .executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, new Object[] { paramContext, paramList });
  }

  private static List<Sleep> constructSleepList(List<SleepDuration> paramList, List<SleepDetail> paramList1)
  {
    Collections.sort(paramList);
    Collections.sort(paramList1);
    ArrayList localArrayList1 = new ArrayList();
    Iterator localIterator1 = paramList.iterator();
    if (!localIterator1.hasNext())
    {
      printSleepLog(localArrayList1);
      return localArrayList1;
    }
    SleepDuration localSleepDuration = (SleepDuration)localIterator1.next();
    long l1 = localSleepDuration.getStartTime();
    long l2 = localSleepDuration.getEndTime();
    LogUtil.d("SleepController", "constructSleepList startTime:" + l1 + ", endTime:" + l2);
    ArrayList localArrayList2 = new ArrayList();
    ArrayList localArrayList3 = new ArrayList();
    Iterator localIterator2 = paramList1.iterator();
    label121: if (!localIterator2.hasNext());
    while (true)
    {
      if (localArrayList3.size() > 0)
        localArrayList2.add((SleepDetail)localArrayList3.get(-1 + localArrayList3.size()));
      localArrayList1.add(new Sleep(localSleepDuration, localArrayList2));
      break;
      SleepDetail localSleepDetail = (SleepDetail)localIterator2.next();
      long l3 = localSleepDetail.getTimestampS();
      if (l3 <= l1)
      {
        localArrayList3.add(localSleepDetail);
        break label121;
      }
      if ((l1 < l3) && (l3 <= l2))
      {
        localArrayList2.add(localSleepDetail);
        break label121;
      }
      if (l3 <= l2)
        break label121;
    }
  }

  private static void dealWithSleepSetting(Context paramContext, List<SleepSettingDetail> paramList)
  {
    if (paramList == null)
      return;
    LogUtil.d("SleepController", "dealWithSleepSetting count:" + paramList.size());
    SQLiteDatabase localSQLiteDatabase = Database.getDb(paramContext);
    Object localObject = null;
    long l1 = -1L;
    Iterator localIterator = paramList.iterator();
    label51: SleepSettingState localSleepSettingState;
    long l2;
    if (localIterator.hasNext())
    {
      SleepSettingDetail localSleepSettingDetail = (SleepSettingDetail)localIterator.next();
      localSleepSettingState = localSleepSettingDetail.getState();
      l2 = localSleepSettingDetail.getTimestampS();
      LogUtil.d("SleepController", "state:" + localSleepSettingState + ", previousState:" + localObject);
      if (localSleepSettingState != SleepSettingState.SLEEP_MODE)
        break label238;
      LogUtil.d("SleepController", "enter sleep");
      long l6 = SleepDao.insertSleepDuration(localSQLiteDatabase, new SleepDuration(l2), true);
      if (-1L != l6)
        SleepPreference.getInstance(paramContext).saveLastStartTimeS(l2);
      LogUtil.d("SleepController", "insert sleep duration ret:" + l6);
    }
    while (true)
    {
      if ((paramContext != null) && (paramList != null) && (paramList.size() > 0))
      {
        Intent localIntent = new Intent("com.baidu.wearable.ACTION_SLEEP_SETTING_COMPLETE");
        LocalBroadcastManager.getInstance(paramContext).sendBroadcast(localIntent);
      }
      localObject = localSleepSettingState;
      l1 = l2;
      break label51;
      break;
      label238: if ((localSleepSettingState == SleepSettingState.SPORT_MODE) && (localObject == SleepSettingState.SLEEP_MODE))
      {
        LogUtil.d("SleepController", "enter sport");
        long l5 = SleepDao.updateSleepDuration(localSQLiteDatabase, new SleepDuration(l1, l2), true);
        if (-1L != l5)
          SleepPreference.getInstance(paramContext).saveLastStartTimeS(0L);
        LogUtil.d("SleepController", "update sleep duration ret:" + l5);
      }
      else if ((localSleepSettingState == SleepSettingState.SPORT_MODE) && (localObject == null))
      {
        long l3 = SleepPreference.getInstance(paramContext).getLastStartTimeS();
        LogUtil.d("SleepController", "prefTimeS:" + l3);
        if (-1L == l3)
        {
          SleepDuration localSleepDuration2 = SleepDao.selectLastSleepDuration(localSQLiteDatabase);
          if ((localSleepDuration2 != null) && (localSleepDuration2.getEndTime() == 0L))
          {
            localSleepDuration2.setEndTime(l2);
            long l4 = SleepDao.updateSleepDuration(localSQLiteDatabase, localSleepDuration2, true);
            LogUtil.d("SleepController", "update sleep duration ret:" + l4);
          }
        }
        else if (0L != l3)
        {
          SleepDuration localSleepDuration1 = new SleepDuration(l3, l2);
          SleepDao.updateSleepDuration(localSQLiteDatabase, localSleepDuration1, true);
        }
      }
    }
  }

  private static List<SleepDuration> getDurationValues(HashMap<Long, SleepDuration> paramHashMap)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = paramHashMap.entrySet().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return localArrayList;
      localArrayList.add((SleepDuration)((Map.Entry)localIterator.next()).getValue());
    }
  }

  private static List<SleepDuration> getMaxSleepDurationSomeDays(List<SleepDuration> paramList)
  {
    HashMap localHashMap = new HashMap();
    Iterator localIterator3;
    Iterator localIterator1;
    label46: List localList;
    Iterator localIterator2;
    if ((paramList != null) && (paramList.size() > 0))
    {
      localIterator3 = paramList.iterator();
      if (localIterator3.hasNext());
    }
    else
    {
      localIterator1 = paramList.iterator();
      if (localIterator1.hasNext())
        break label190;
      localList = getDurationValues(localHashMap);
      LogUtil.d("SleepController", "getMaxSleepDurationSomeDays count:" + paramList.size());
      if ((localList != null) && (localList.size() > 0))
        localIterator2 = localList.iterator();
    }
    while (true)
    {
      if (!localIterator2.hasNext())
      {
        return localList;
        SleepDuration localSleepDuration3 = (SleepDuration)localIterator3.next();
        LogUtil.d("SleepController", "before getMaxSleepDurationSomeDays sleep durationstart time:" + localSleepDuration3.getStartTime() + ", end time:" + localSleepDuration3.getEndTime() + ", total time:" + localSleepDuration3.getTotalTime());
        break;
        label190: SleepDuration localSleepDuration1 = (SleepDuration)localIterator1.next();
        long l = TimeUtil.getDayStartTimestamp(1000L * localSleepDuration1.getEndTime()) / 1000L;
        if (localHashMap.containsKey(Long.valueOf(l)))
        {
          if (((SleepDuration)localHashMap.get(Long.valueOf(l))).getTotalTime() >= localSleepDuration1.getTotalTime())
            break label46;
          localHashMap.put(Long.valueOf(l), localSleepDuration1);
          break label46;
        }
        localHashMap.put(Long.valueOf(l), localSleepDuration1);
        break label46;
      }
      SleepDuration localSleepDuration2 = (SleepDuration)localIterator2.next();
      LogUtil.d("SleepController", "after getMaxSleepDurationSomeDays sleep durationstart time:" + localSleepDuration2.getStartTime() + ", end time:" + localSleepDuration2.getEndTime() + ", total time:" + localSleepDuration2.getTotalTime());
    }
  }

  public static void getMaxSleepSomeDays(Context paramContext, int paramInt, SleepListener paramSleepListener)
  {
    getSleeps(paramContext, TimeUtil.getDayStartTimestamp(paramInt) / 1000L, (86400000L + TimeUtil.getDayStartTimestamp()) / 1000L, new SleepListener()
    {
      public void onReceive(List<Sleep> paramAnonymousList)
      {
        if (SleepController.this != null)
          SleepController.this.onReceive(paramAnonymousList);
      }
    });
  }

  public static void getSleepDetails(Context paramContext, SleepDuration paramSleepDuration, SleepDetailListener paramSleepDetailListener)
  {
    new AsyncTask()
    {
      protected List<SleepDetail> doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return SleepDao.selectSleepDetail(Database.getDb((Context)paramAnonymousArrayOfObject[0]), (SleepDuration)paramAnonymousArrayOfObject[1]);
      }

      protected void onPostExecute(List<SleepDetail> paramAnonymousList)
      {
        super.onPostExecute(paramAnonymousList);
        if (SleepController.this != null)
          SleepController.this.onReceive(paramAnonymousList);
      }
    }
    .executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Object[] { paramContext, paramSleepDuration });
  }

  public static void getSleepDurations(Context paramContext, long paramLong1, long paramLong2, SleepDurationListener paramSleepDurationListener)
  {
    AsyncTask local3 = new AsyncTask()
    {
      protected List<SleepDuration> doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return SleepDao.selectSleepDuration(Database.getDb((Context)paramAnonymousArrayOfObject[0]), ((Long)paramAnonymousArrayOfObject[1]).longValue(), ((Long)paramAnonymousArrayOfObject[2]).longValue());
      }

      protected void onPostExecute(List<SleepDuration> paramAnonymousList)
      {
        super.onPostExecute(paramAnonymousList);
        if (SleepController.this != null)
          SleepController.this.onReceive(paramAnonymousList);
      }
    };
    Executor localExecutor = AsyncTask.THREAD_POOL_EXECUTOR;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = paramContext;
    arrayOfObject[1] = Long.valueOf(paramLong1);
    arrayOfObject[2] = Long.valueOf(paramLong2);
    local3.executeOnExecutor(localExecutor, arrayOfObject);
  }

  public static void getSleeps(Context paramContext, long paramLong1, long paramLong2, SleepListener paramSleepListener)
  {
    AsyncTask local2 = new AsyncTask()
    {
      protected List<Sleep> doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return SleepController.getSleepsSync((Context)paramAnonymousArrayOfObject[0], ((Long)paramAnonymousArrayOfObject[1]).longValue(), ((Long)paramAnonymousArrayOfObject[2]).longValue());
      }

      protected void onPostExecute(List<Sleep> paramAnonymousList)
      {
        super.onPostExecute(paramAnonymousList);
        if (SleepController.this != null)
          SleepController.this.onReceive(paramAnonymousList);
      }
    };
    Executor localExecutor = AsyncTask.THREAD_POOL_EXECUTOR;
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = paramContext;
    arrayOfObject[1] = Long.valueOf(paramLong1);
    arrayOfObject[2] = Long.valueOf(paramLong2);
    local2.executeOnExecutor(localExecutor, arrayOfObject);
  }

  private static List<Sleep> getSleepsSync(Context paramContext, long paramLong1, long paramLong2)
  {
    LogUtil.d("SleepController", "getSleepsSync startTime:" + paramLong1 + ", endTime:" + paramLong2);
    SQLiteDatabase localSQLiteDatabase = Database.getDb(paramContext);
    List localList1 = SleepDao.selectSleepDuration(localSQLiteDatabase, paramLong1, paramLong2);
    LogUtil.d("SleepController", "getSleepsSync sleep duration count:" + localList1.size());
    List localList2 = getMaxSleepDurationSomeDays(localList1);
    LogUtil.d("SleepController", "getSleepsSync sleep max duration count:" + localList2.size());
    Collections.sort(localList2);
    SleepDuration localSleepDuration = null;
    if (localList2 != null)
    {
      int i = localList2.size();
      localSleepDuration = null;
      if (i > 0)
        localSleepDuration = new SleepDuration(((SleepDuration)localList2.get(0)).getStartTime(), ((SleepDuration)localList2.get(-1 + localList2.size())).getEndTime());
    }
    List localList3 = SleepDao.selectSleepDetail(localSQLiteDatabase, localSleepDuration);
    LogUtil.d("SleepController", "getSleepsSync sleep detail count:" + localList3.size());
    if (localSleepDuration != null)
    {
      SleepDetail localSleepDetail = SleepDao.selectLastSleepDetail(localSQLiteDatabase, localSleepDuration.getStartTime());
      LogUtil.d("SleepController", "getSleepsSync lastDetail:" + localSleepDetail);
      if (localSleepDetail != null)
        localList3.add(localSleepDetail);
    }
    return constructSleepList(localList2, localList3);
  }

  private static void printSleepLog(List<Sleep> paramList)
  {
    LogUtil.d("SleepController", "printSleepLog count:" + paramList.size());
    Iterator localIterator1;
    if ((paramList != null) && (paramList.size() > 0))
    {
      localIterator1 = paramList.iterator();
      if (localIterator1.hasNext());
    }
    else
    {
      return;
    }
    Sleep localSleep = (Sleep)localIterator1.next();
    LogUtil.d("SleepController", "sleep infodate:" + localSleep.getDate() + ", start time:" + localSleep.getStartSleepInSeconds() + ", end time:" + localSleep.getEndSleepInSeconds() + ", fall asleep time:" + localSleep.getFallAsleepInSeconds() + ", wake time:" + localSleep.getWakeInSeconds() + ", sleep consume time:" + localSleep.getSleepConsumeInSeconds() + ", sleep efficiency:" + localSleep.getSleepEfficiency() + ", total deep sleep:" + localSleep.getTotalDeepSleepInSeconds() + ", total light sleep:" + localSleep.getTotalLightSleepInSeconds() + ", total sleep" + localSleep.getTotalSleepInSeconds());
    List localList1 = localSleep.getSleepDetails();
    Iterator localIterator4;
    label234: Iterator localIterator3;
    if ((localList1 != null) && (localList1.size() > 0))
    {
      localIterator4 = localList1.iterator();
      if (localIterator4.hasNext());
    }
    else
    {
      List localList2 = localSleep.getSleepDataFromStartToEnd();
      if ((localList2 != null) && (localList2.size() > 0))
        localIterator3 = localList2.iterator();
    }
    while (true)
    {
      if (!localIterator3.hasNext())
      {
        List localList3 = localSleep.getSleepDataFromFallAsleepToWake();
        if ((localList3 == null) || (localList3.size() <= 0))
          break;
        Iterator localIterator2 = localList3.iterator();
        while (localIterator2.hasNext())
        {
          SleepSlot localSleepSlot1 = (SleepSlot)localIterator2.next();
          LogUtil.d("SleepController", "start to end slot:start time:" + localSleepSlot1.getStartTime() + ", duration:" + localSleepSlot1.getDuration() + ", state:" + localSleepSlot1.getState());
        }
        break;
        SleepDetail localSleepDetail = (SleepDetail)localIterator4.next();
        LogUtil.d("SleepController", "sleep detail:date:" + localSleepDetail.getDate() + ", time:" + localSleepDetail.getTimestampS() + ", state:" + localSleepDetail.getState());
        break label234;
      }
      SleepSlot localSleepSlot2 = (SleepSlot)localIterator3.next();
      LogUtil.d("SleepController", "start to end slot:start time:" + localSleepSlot2.getStartTime() + ", duration:" + localSleepSlot2.getDuration() + ", state:" + localSleepSlot2.getState());
    }
  }

  public static void saveSleepDurationToDb(Context paramContext, List<SleepDuration> paramList, boolean paramBoolean)
  {
    if (paramContext == null);
    while ((paramList == null) || (paramList.size() <= 0))
      return;
    AsyncTask local5 = new AsyncTask()
    {
      protected Object doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        SleepDao.bulkInsertSleepDuration(Database.getDb((Context)paramAnonymousArrayOfObject[0]), (List)paramAnonymousArrayOfObject[1], ((Boolean)paramAnonymousArrayOfObject[2]).booleanValue());
        return null;
      }
    };
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = paramContext;
    arrayOfObject[1] = paramList;
    arrayOfObject[2] = Boolean.valueOf(paramBoolean);
    local5.execute(arrayOfObject);
  }

  public static void saveSleepToDb(Context paramContext, List<SleepDetail> paramList, boolean paramBoolean)
  {
    if (paramContext == null);
    while ((paramList == null) || (paramList.size() <= 0))
      return;
    AsyncTask local6 = new AsyncTask()
    {
      protected Object doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        SleepDao.bulkInsertSleepDetail(Database.getDb((Context)paramAnonymousArrayOfObject[0]), (List)paramAnonymousArrayOfObject[1], ((Boolean)paramAnonymousArrayOfObject[2]).booleanValue());
        return null;
      }
    };
    Object[] arrayOfObject = new Object[3];
    arrayOfObject[0] = paramContext;
    arrayOfObject[1] = paramList;
    arrayOfObject[2] = Boolean.valueOf(paramBoolean);
    local6.execute(arrayOfObject);
  }

  public static void sendSleepDurationToNetAndUpdateDb(Context paramContext)
  {
    if (paramContext == null);
    while (!NetworkCheck.isNetworkAvailable(paramContext))
      return;
    new AsyncTask()
    {
      protected Object doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return Boolean.valueOf(SleepController.sendSleepDurationToNetAndUpdateDbSync((Context)paramAnonymousArrayOfObject[0]));
      }
    }
    .execute(new Object[] { paramContext });
  }

  public static boolean sendSleepDurationToNetAndUpdateDbSync(Context paramContext)
  {
    SleepTransport localSleepTransport = SleepTransport.getInstance(paramContext);
    SQLiteDatabase localSQLiteDatabase = Database.getDb(paramContext);
    List localList = SleepDao.selectDirtySleepDuration(localSQLiteDatabase);
    if ((localList != null) && (localList.size() > 0))
    {
      if (localSleepTransport.updateSleepDurationSync(localList).errCode == 0)
        SleepDao.bulkUpdateSleepDurationToNotDirty(localSQLiteDatabase, localList);
    }
    else
      return true;
    return false;
  }

  public static void sendSleepToNetAndUpdateDb(Context paramContext)
  {
    if (paramContext == null);
    while (!NetworkCheck.isNetworkAvailable(paramContext))
      return;
    new AsyncTask()
    {
      protected Object doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return Boolean.valueOf(SleepController.sendSleepToNetAndUpdateDbSync((Context)paramAnonymousArrayOfObject[0]));
      }
    }
    .execute(new Object[] { paramContext });
  }

  public static boolean sendSleepToNetAndUpdateDbSync(Context paramContext)
  {
    SleepTransport localSleepTransport = SleepTransport.getInstance(paramContext);
    SQLiteDatabase localSQLiteDatabase = Database.getDb(paramContext);
    List localList = SleepDao.selectDirtySleepDetail(localSQLiteDatabase);
    if ((localList != null) && (localList.size() > 0))
    {
      if (localSleepTransport.updateSleepDetailSync(TrackerHelper.getInstance(paramContext).getTrackerID(), localList).errCode == 0)
        SleepDao.bulkUpdateSleepDetailToNotDirty(localSQLiteDatabase, localList);
    }
    else
      return true;
    return false;
  }

  public static abstract interface MaxSleepListener
  {
    public abstract void onReceive(Sleep paramSleep);
  }

  public static abstract interface SleepDetailListener
  {
    public abstract void onReceive(List<SleepDetail> paramList);
  }

  public static abstract interface SleepDurationListener
  {
    public abstract void onReceive(List<SleepDuration> paramList);
  }

  public static abstract interface SleepListener
  {
    public abstract void onReceive(List<Sleep> paramList);
  }

  public static abstract interface SleepSettingDetailListener
  {
    public abstract void onReceive(List<SleepSettingDetail> paramList);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sleep.SleepController
 * JD-Core Version:    0.6.2
 */