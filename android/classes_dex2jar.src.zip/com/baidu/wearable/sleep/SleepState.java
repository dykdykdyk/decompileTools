package com.baidu.wearable.sleep;

public enum SleepState
{
  private int state;

  static
  {
    DEEP_SLEEP = new SleepState("DEEP_SLEEP", 2, 1);
    SleepState[] arrayOfSleepState = new SleepState[3];
    arrayOfSleepState[0] = AWAKE;
    arrayOfSleepState[1] = LIGHT_SLEEP;
    arrayOfSleepState[2] = DEEP_SLEEP;
  }

  private SleepState(int arg3)
  {
    int j;
    this.state = j;
  }

  public static SleepState valueOf(int paramInt)
  {
    switch (paramInt)
    {
    default:
      throw new IndexOutOfBoundsException("Invalid sleep state");
    case 3:
      return AWAKE;
    case 2:
      return LIGHT_SLEEP;
    case 1:
    }
    return DEEP_SLEEP;
  }

  public int value()
  {
    return this.state;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sleep.SleepState
 * JD-Core Version:    0.6.2
 */