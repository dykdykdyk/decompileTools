package com.baidu.wearable.sleep;

import java.io.Serializable;

public class SleepSlot
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private long durationS;
  private long startTimeS;
  private SleepState state;

  public SleepSlot(long paramLong1, long paramLong2, SleepState paramSleepState)
  {
    this.startTimeS = paramLong1;
    this.durationS = paramLong2;
    this.state = paramSleepState;
  }

  public long getDuration()
  {
    return this.durationS;
  }

  public long getStartTime()
  {
    return this.startTimeS;
  }

  public SleepState getState()
  {
    return this.state;
  }

  public void setDuration(long paramLong)
  {
    this.durationS = paramLong;
  }

  public void setStartTime(long paramLong)
  {
    this.startTimeS = paramLong;
  }

  public void setState(SleepState paramSleepState)
  {
    this.state = paramSleepState;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sleep.SleepSlot
 * JD-Core Version:    0.6.2
 */