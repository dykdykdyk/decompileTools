package com.baidu.wearable.sleep;

import java.io.Serializable;

public class SleepDuration
  implements Comparable<SleepDuration>, Serializable
{
  private static final long serialVersionUID = 1L;
  private long endTimeS;
  private long startTimeS;

  public SleepDuration(long paramLong)
  {
    this.startTimeS = paramLong;
  }

  public SleepDuration(long paramLong1, long paramLong2)
  {
    this.startTimeS = paramLong1;
    this.endTimeS = paramLong2;
  }

  public int compareTo(SleepDuration paramSleepDuration)
  {
    Integer localInteger1 = Integer.valueOf((int)getStartTime());
    Integer localInteger2 = Integer.valueOf((int)paramSleepDuration.getStartTime());
    return localInteger1.intValue() - localInteger2.intValue();
  }

  public long getEndTime()
  {
    return this.endTimeS;
  }

  public long getStartTime()
  {
    return this.startTimeS;
  }

  public long getTotalTime()
  {
    return this.endTimeS - this.startTimeS;
  }

  public void setEndTime(long paramLong)
  {
    this.endTimeS = paramLong;
  }

  public void setStartTime(long paramLong)
  {
    this.startTimeS = paramLong;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sleep.SleepDuration
 * JD-Core Version:    0.6.2
 */