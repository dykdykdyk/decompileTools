package com.baidu.wearable.sleep;

import com.baidu.wearable.util.TimeUtil;
import java.io.Serializable;

public class SleepDetail
  implements Comparable<SleepDetail>, Serializable
{
  private static final long serialVersionUID = 1L;
  private String date;
  private SleepState state;
  private long timestampS;

  public SleepDetail(long paramLong, SleepState paramSleepState)
  {
    this.timestampS = paramLong;
    this.date = TimeUtil.getDate(1000L * paramLong);
    this.state = paramSleepState;
  }

  public SleepDetail(long paramLong, String paramString, SleepState paramSleepState)
  {
    this.timestampS = paramLong;
    this.date = paramString;
    this.state = paramSleepState;
  }

  public int compareTo(SleepDetail paramSleepDetail)
  {
    Integer localInteger1 = Integer.valueOf((int)getTimestampS());
    Integer localInteger2 = Integer.valueOf((int)paramSleepDetail.getTimestampS());
    return localInteger1.intValue() - localInteger2.intValue();
  }

  public String getDate()
  {
    return this.date;
  }

  public SleepState getState()
  {
    return this.state;
  }

  public long getTimestampS()
  {
    return this.timestampS;
  }

  public void setDate(String paramString)
  {
    this.date = paramString;
  }

  public void setState(SleepState paramSleepState)
  {
    this.state = paramSleepState;
  }

  public void setTimestampS(long paramLong)
  {
    this.timestampS = paramLong;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sleep.SleepDetail
 * JD-Core Version:    0.6.2
 */