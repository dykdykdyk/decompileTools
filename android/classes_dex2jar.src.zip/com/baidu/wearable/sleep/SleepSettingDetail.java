package com.baidu.wearable.sleep;

public class SleepSettingDetail
  implements Comparable<SleepSettingDetail>
{
  private String date;
  private SleepSettingState state;
  private long timestampS;

  public SleepSettingDetail(long paramLong, String paramString, SleepSettingState paramSleepSettingState)
  {
    this.timestampS = paramLong;
    this.date = paramString;
    this.state = paramSleepSettingState;
  }

  public int compareTo(SleepSettingDetail paramSleepSettingDetail)
  {
    Integer localInteger1 = Integer.valueOf((int)getTimestampS());
    Integer localInteger2 = Integer.valueOf((int)paramSleepSettingDetail.getTimestampS());
    return localInteger1.intValue() - localInteger2.intValue();
  }

  public String getDate()
  {
    return this.date;
  }

  public SleepSettingState getState()
  {
    return this.state;
  }

  public long getTimestampS()
  {
    return this.timestampS;
  }

  public void setDate(String paramString)
  {
    this.date = paramString;
  }

  public void setState(SleepSettingState paramSleepSettingState)
  {
    this.state = paramSleepSettingState;
  }

  public void setTimestampS(long paramLong)
  {
    this.timestampS = paramLong;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sleep.SleepSettingDetail
 * JD-Core Version:    0.6.2
 */