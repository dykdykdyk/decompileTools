package com.baidu.wearable.sleep;

public enum SleepSettingState
{
  private int mode;

  static
  {
    SLEEP_MODE = new SleepSettingState("SLEEP_MODE", 1, 1);
    SleepSettingState[] arrayOfSleepSettingState = new SleepSettingState[2];
    arrayOfSleepSettingState[0] = SPORT_MODE;
    arrayOfSleepSettingState[1] = SLEEP_MODE;
  }

  private SleepSettingState(int arg3)
  {
    int j;
    this.mode = j;
  }

  public static SleepSettingState valueOf(int paramInt)
  {
    switch (paramInt)
    {
    default:
      throw new IndexOutOfBoundsException("Invalid sleep setting state");
    case 0:
      return SPORT_MODE;
    case 1:
    }
    return SLEEP_MODE;
  }

  public int value()
  {
    return this.mode;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sleep.SleepSettingState
 * JD-Core Version:    0.6.2
 */