package com.baidu.wearable.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.sleep.SleepDetail;
import com.baidu.wearable.sleep.SleepDuration;
import com.baidu.wearable.sleep.SleepState;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class SleepDao
{
  private static final String TAG = "SleepDao";
  private static final String mDbName = Database.getName();

  // ERROR //
  public static List<Long> bulkInsertSleepDetail(SQLiteDatabase paramSQLiteDatabase, List<SleepDetail> paramList, boolean paramBoolean)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: ldc 8
    //   5: new 26	java/lang/StringBuilder
    //   8: dup
    //   9: getstatic 19	com/baidu/wearable/database/SleepDao:mDbName	Ljava/lang/String;
    //   12: invokestatic 32	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   15: invokespecial 35	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   18: ldc 37
    //   20: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: invokevirtual 44	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   26: invokestatic 50	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   29: aconst_null
    //   30: astore 4
    //   32: aload_0
    //   33: ifnull +10 -> 43
    //   36: aconst_null
    //   37: astore 4
    //   39: aload_1
    //   40: ifnonnull +9 -> 49
    //   43: ldc 2
    //   45: monitorexit
    //   46: aload 4
    //   48: areturn
    //   49: new 52	java/util/ArrayList
    //   52: dup
    //   53: invokespecial 53	java/util/ArrayList:<init>	()V
    //   56: astore 4
    //   58: aload_0
    //   59: invokevirtual 58	android/database/sqlite/SQLiteDatabase:beginTransaction	()V
    //   62: aload_1
    //   63: invokeinterface 64 1 0
    //   68: astore 6
    //   70: aload 6
    //   72: invokeinterface 70 1 0
    //   77: ifne +20 -> 97
    //   80: aload_0
    //   81: invokevirtual 73	android/database/sqlite/SQLiteDatabase:setTransactionSuccessful	()V
    //   84: aload_0
    //   85: invokevirtual 76	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   88: goto -45 -> 43
    //   91: astore_3
    //   92: ldc 2
    //   94: monitorexit
    //   95: aload_3
    //   96: athrow
    //   97: aload 6
    //   99: invokeinterface 80 1 0
    //   104: checkcast 82	com/baidu/wearable/sleep/SleepDetail
    //   107: astore 7
    //   109: new 84	android/content/ContentValues
    //   112: dup
    //   113: invokespecial 85	android/content/ContentValues:<init>	()V
    //   116: astore 8
    //   118: aload 7
    //   120: invokevirtual 89	com/baidu/wearable/sleep/SleepDetail:getTimestampS	()J
    //   123: ldc2_w 90
    //   126: lcmp
    //   127: iflt -57 -> 70
    //   130: aload 8
    //   132: getstatic 97	com/baidu/wearable/database/Database$SleepDetailEnum:timestamp	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   135: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   138: aload 7
    //   140: invokevirtual 89	com/baidu/wearable/sleep/SleepDetail:getTimestampS	()J
    //   143: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   146: invokevirtual 109	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Long;)V
    //   149: aload 8
    //   151: getstatic 112	com/baidu/wearable/database/Database$SleepDetailEnum:date	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   154: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   157: aload 7
    //   159: invokevirtual 115	com/baidu/wearable/sleep/SleepDetail:getDate	()Ljava/lang/String;
    //   162: invokevirtual 117	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/String;)V
    //   165: aload 8
    //   167: getstatic 120	com/baidu/wearable/database/Database$SleepDetailEnum:state	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   170: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   173: aload 7
    //   175: invokevirtual 124	com/baidu/wearable/sleep/SleepDetail:getState	()Lcom/baidu/wearable/sleep/SleepState;
    //   178: invokevirtual 130	com/baidu/wearable/sleep/SleepState:value	()I
    //   181: invokestatic 135	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   184: invokevirtual 138	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Integer;)V
    //   187: aload 8
    //   189: getstatic 141	com/baidu/wearable/database/Database$SleepDetailEnum:dirty	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   192: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   195: iload_2
    //   196: invokestatic 146	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   199: invokevirtual 149	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Boolean;)V
    //   202: aload 4
    //   204: aload_0
    //   205: ldc 151
    //   207: aconst_null
    //   208: aload 8
    //   210: invokevirtual 155	android/database/sqlite/SQLiteDatabase:insert	(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   213: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   216: invokeinterface 159 2 0
    //   221: pop
    //   222: goto -152 -> 70
    //   225: astore 5
    //   227: aload_0
    //   228: invokevirtual 76	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   231: aload 5
    //   233: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   3	29	91	finally
    //   49	62	91	finally
    //   84	88	91	finally
    //   227	234	91	finally
    //   62	70	225	finally
    //   70	84	225	finally
    //   97	222	225	finally
  }

  // ERROR //
  public static List<Long> bulkInsertSleepDuration(SQLiteDatabase paramSQLiteDatabase, List<SleepDuration> paramList, boolean paramBoolean)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: aconst_null
    //   4: astore_3
    //   5: aload_0
    //   6: ifnull +9 -> 15
    //   9: aconst_null
    //   10: astore_3
    //   11: aload_1
    //   12: ifnonnull +8 -> 20
    //   15: ldc 2
    //   17: monitorexit
    //   18: aload_3
    //   19: areturn
    //   20: aload_1
    //   21: invokeinterface 163 1 0
    //   26: pop
    //   27: new 52	java/util/ArrayList
    //   30: dup
    //   31: invokespecial 53	java/util/ArrayList:<init>	()V
    //   34: astore_3
    //   35: aload_0
    //   36: invokevirtual 58	android/database/sqlite/SQLiteDatabase:beginTransaction	()V
    //   39: aload_1
    //   40: invokeinterface 64 1 0
    //   45: astore 7
    //   47: aload 7
    //   49: invokeinterface 70 1 0
    //   54: ifne +22 -> 76
    //   57: aload_0
    //   58: invokevirtual 73	android/database/sqlite/SQLiteDatabase:setTransactionSuccessful	()V
    //   61: aload_0
    //   62: invokevirtual 76	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   65: goto -50 -> 15
    //   68: astore 4
    //   70: ldc 2
    //   72: monitorexit
    //   73: aload 4
    //   75: athrow
    //   76: aload 7
    //   78: invokeinterface 80 1 0
    //   83: checkcast 165	com/baidu/wearable/sleep/SleepDuration
    //   86: astore 8
    //   88: new 84	android/content/ContentValues
    //   91: dup
    //   92: invokespecial 85	android/content/ContentValues:<init>	()V
    //   95: astore 9
    //   97: aload 9
    //   99: getstatic 171	com/baidu/wearable/database/Database$SleepDurationEnum:startTime	Lcom/baidu/wearable/database/Database$SleepDurationEnum;
    //   102: invokevirtual 172	com/baidu/wearable/database/Database$SleepDurationEnum:name	()Ljava/lang/String;
    //   105: aload 8
    //   107: invokevirtual 175	com/baidu/wearable/sleep/SleepDuration:getStartTime	()J
    //   110: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   113: invokevirtual 109	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Long;)V
    //   116: aload 9
    //   118: getstatic 178	com/baidu/wearable/database/Database$SleepDurationEnum:endTime	Lcom/baidu/wearable/database/Database$SleepDurationEnum;
    //   121: invokevirtual 172	com/baidu/wearable/database/Database$SleepDurationEnum:name	()Ljava/lang/String;
    //   124: aload 8
    //   126: invokevirtual 181	com/baidu/wearable/sleep/SleepDuration:getEndTime	()J
    //   129: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   132: invokevirtual 109	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Long;)V
    //   135: aload 9
    //   137: getstatic 183	com/baidu/wearable/database/Database$SleepDurationEnum:dirty	Lcom/baidu/wearable/database/Database$SleepDurationEnum;
    //   140: invokevirtual 172	com/baidu/wearable/database/Database$SleepDurationEnum:name	()Ljava/lang/String;
    //   143: iload_2
    //   144: invokestatic 146	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   147: invokevirtual 149	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Boolean;)V
    //   150: aload_3
    //   151: aload_0
    //   152: ldc 185
    //   154: aconst_null
    //   155: aload 9
    //   157: invokevirtual 155	android/database/sqlite/SQLiteDatabase:insert	(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   160: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   163: invokeinterface 159 2 0
    //   168: pop
    //   169: goto -122 -> 47
    //   172: astore 6
    //   174: aload_0
    //   175: invokevirtual 76	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   178: aload 6
    //   180: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   20	39	68	finally
    //   61	65	68	finally
    //   174	181	68	finally
    //   39	47	172	finally
    //   47	61	172	finally
    //   76	169	172	finally
  }

  // ERROR //
  public static List<Long> bulkReplaceSleepDetail(SQLiteDatabase paramSQLiteDatabase, List<SleepDetail> paramList, boolean paramBoolean)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: ldc 8
    //   5: new 26	java/lang/StringBuilder
    //   8: dup
    //   9: getstatic 19	com/baidu/wearable/database/SleepDao:mDbName	Ljava/lang/String;
    //   12: invokestatic 32	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   15: invokespecial 35	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   18: ldc 37
    //   20: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   23: invokevirtual 44	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   26: invokestatic 50	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   29: aconst_null
    //   30: astore 4
    //   32: aload_0
    //   33: ifnull +10 -> 43
    //   36: aconst_null
    //   37: astore 4
    //   39: aload_1
    //   40: ifnonnull +9 -> 49
    //   43: ldc 2
    //   45: monitorexit
    //   46: aload 4
    //   48: areturn
    //   49: new 52	java/util/ArrayList
    //   52: dup
    //   53: invokespecial 53	java/util/ArrayList:<init>	()V
    //   56: astore 4
    //   58: aload_0
    //   59: invokevirtual 58	android/database/sqlite/SQLiteDatabase:beginTransaction	()V
    //   62: aload_1
    //   63: invokeinterface 64 1 0
    //   68: astore 6
    //   70: aload 6
    //   72: invokeinterface 70 1 0
    //   77: ifne +20 -> 97
    //   80: aload_0
    //   81: invokevirtual 73	android/database/sqlite/SQLiteDatabase:setTransactionSuccessful	()V
    //   84: aload_0
    //   85: invokevirtual 76	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   88: goto -45 -> 43
    //   91: astore_3
    //   92: ldc 2
    //   94: monitorexit
    //   95: aload_3
    //   96: athrow
    //   97: aload 6
    //   99: invokeinterface 80 1 0
    //   104: checkcast 82	com/baidu/wearable/sleep/SleepDetail
    //   107: astore 7
    //   109: new 84	android/content/ContentValues
    //   112: dup
    //   113: invokespecial 85	android/content/ContentValues:<init>	()V
    //   116: astore 8
    //   118: aload 7
    //   120: invokevirtual 89	com/baidu/wearable/sleep/SleepDetail:getTimestampS	()J
    //   123: ldc2_w 90
    //   126: lcmp
    //   127: iflt -57 -> 70
    //   130: aload 8
    //   132: getstatic 97	com/baidu/wearable/database/Database$SleepDetailEnum:timestamp	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   135: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   138: aload 7
    //   140: invokevirtual 89	com/baidu/wearable/sleep/SleepDetail:getTimestampS	()J
    //   143: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   146: invokevirtual 109	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Long;)V
    //   149: aload 8
    //   151: getstatic 112	com/baidu/wearable/database/Database$SleepDetailEnum:date	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   154: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   157: aload 7
    //   159: invokevirtual 115	com/baidu/wearable/sleep/SleepDetail:getDate	()Ljava/lang/String;
    //   162: invokevirtual 117	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/String;)V
    //   165: aload 8
    //   167: getstatic 120	com/baidu/wearable/database/Database$SleepDetailEnum:state	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   170: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   173: aload 7
    //   175: invokevirtual 124	com/baidu/wearable/sleep/SleepDetail:getState	()Lcom/baidu/wearable/sleep/SleepState;
    //   178: invokevirtual 130	com/baidu/wearable/sleep/SleepState:value	()I
    //   181: invokestatic 135	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   184: invokevirtual 138	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Integer;)V
    //   187: aload 8
    //   189: getstatic 141	com/baidu/wearable/database/Database$SleepDetailEnum:dirty	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   192: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   195: iload_2
    //   196: invokestatic 146	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   199: invokevirtual 149	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Boolean;)V
    //   202: aload 4
    //   204: aload_0
    //   205: ldc 151
    //   207: aconst_null
    //   208: aload 8
    //   210: invokevirtual 189	android/database/sqlite/SQLiteDatabase:replace	(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   213: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   216: invokeinterface 159 2 0
    //   221: pop
    //   222: goto -152 -> 70
    //   225: astore 5
    //   227: aload_0
    //   228: invokevirtual 76	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   231: aload 5
    //   233: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   3	29	91	finally
    //   49	62	91	finally
    //   84	88	91	finally
    //   227	234	91	finally
    //   62	70	225	finally
    //   70	84	225	finally
    //   97	222	225	finally
  }

  // ERROR //
  public static List<Long> bulkReplaceSleepDuration(SQLiteDatabase paramSQLiteDatabase, List<SleepDuration> paramList, boolean paramBoolean)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: aconst_null
    //   4: astore_3
    //   5: aload_0
    //   6: ifnull +9 -> 15
    //   9: aconst_null
    //   10: astore_3
    //   11: aload_1
    //   12: ifnonnull +8 -> 20
    //   15: ldc 2
    //   17: monitorexit
    //   18: aload_3
    //   19: areturn
    //   20: aload_1
    //   21: invokeinterface 163 1 0
    //   26: pop
    //   27: new 52	java/util/ArrayList
    //   30: dup
    //   31: invokespecial 53	java/util/ArrayList:<init>	()V
    //   34: astore_3
    //   35: aload_0
    //   36: invokevirtual 58	android/database/sqlite/SQLiteDatabase:beginTransaction	()V
    //   39: aload_1
    //   40: invokeinterface 64 1 0
    //   45: astore 7
    //   47: aload 7
    //   49: invokeinterface 70 1 0
    //   54: ifne +22 -> 76
    //   57: aload_0
    //   58: invokevirtual 73	android/database/sqlite/SQLiteDatabase:setTransactionSuccessful	()V
    //   61: aload_0
    //   62: invokevirtual 76	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   65: goto -50 -> 15
    //   68: astore 4
    //   70: ldc 2
    //   72: monitorexit
    //   73: aload 4
    //   75: athrow
    //   76: aload 7
    //   78: invokeinterface 80 1 0
    //   83: checkcast 165	com/baidu/wearable/sleep/SleepDuration
    //   86: astore 8
    //   88: new 84	android/content/ContentValues
    //   91: dup
    //   92: invokespecial 85	android/content/ContentValues:<init>	()V
    //   95: astore 9
    //   97: aload 9
    //   99: getstatic 171	com/baidu/wearable/database/Database$SleepDurationEnum:startTime	Lcom/baidu/wearable/database/Database$SleepDurationEnum;
    //   102: invokevirtual 172	com/baidu/wearable/database/Database$SleepDurationEnum:name	()Ljava/lang/String;
    //   105: aload 8
    //   107: invokevirtual 175	com/baidu/wearable/sleep/SleepDuration:getStartTime	()J
    //   110: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   113: invokevirtual 109	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Long;)V
    //   116: aload 9
    //   118: getstatic 178	com/baidu/wearable/database/Database$SleepDurationEnum:endTime	Lcom/baidu/wearable/database/Database$SleepDurationEnum;
    //   121: invokevirtual 172	com/baidu/wearable/database/Database$SleepDurationEnum:name	()Ljava/lang/String;
    //   124: aload 8
    //   126: invokevirtual 181	com/baidu/wearable/sleep/SleepDuration:getEndTime	()J
    //   129: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   132: invokevirtual 109	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Long;)V
    //   135: aload 9
    //   137: getstatic 183	com/baidu/wearable/database/Database$SleepDurationEnum:dirty	Lcom/baidu/wearable/database/Database$SleepDurationEnum;
    //   140: invokevirtual 172	com/baidu/wearable/database/Database$SleepDurationEnum:name	()Ljava/lang/String;
    //   143: iload_2
    //   144: invokestatic 146	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   147: invokevirtual 149	android/content/ContentValues:put	(Ljava/lang/String;Ljava/lang/Boolean;)V
    //   150: aload_3
    //   151: aload_0
    //   152: ldc 185
    //   154: aconst_null
    //   155: aload 9
    //   157: invokevirtual 189	android/database/sqlite/SQLiteDatabase:replace	(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   160: invokestatic 105	java/lang/Long:valueOf	(J)Ljava/lang/Long;
    //   163: invokeinterface 159 2 0
    //   168: pop
    //   169: goto -122 -> 47
    //   172: astore 6
    //   174: aload_0
    //   175: invokevirtual 76	android/database/sqlite/SQLiteDatabase:endTransaction	()V
    //   178: aload 6
    //   180: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   20	39	68	finally
    //   61	65	68	finally
    //   174	181	68	finally
    //   39	47	172	finally
    //   47	61	172	finally
    //   76	169	172	finally
  }

  public static long bulkUpdateSleepDetailToNotDirty(SQLiteDatabase paramSQLiteDatabase, SleepDuration paramSleepDuration)
  {
    long l1;
    if ((paramSQLiteDatabase == null) || (paramSleepDuration == null))
      l1 = 0L;
    while (true)
    {
      return l1;
      try
      {
        long l2 = paramSleepDuration.getStartTime();
        long l3 = paramSleepDuration.getEndTime();
        LogUtil.d("SleepDao", mDbName + " bulkUpdateSleepDetailToNotDirty startTimeS:" + l2 + ", endTimeS:" + l3);
        String str = "(" + Database.SleepDetailEnum.timestamp.name() + "=?)";
        String[] arrayOfString = new String[1];
        arrayOfString[0] = String.valueOf(l2);
        ContentValues localContentValues = new ContentValues();
        localContentValues.put(Database.SleepDetailEnum.dirty.name(), Boolean.valueOf(false));
        l1 = paramSQLiteDatabase.update("SleepDetail", localContentValues, str, arrayOfString);
        LogUtil.d("SleepDao", mDbName + " bulkUpdateSleepDetailToNotDirty res:" + l1);
      }
      finally
      {
      }
    }
  }

  public static long bulkUpdateSleepDetailToNotDirty(SQLiteDatabase paramSQLiteDatabase, List<SleepDetail> paramList)
  {
    long l;
    if ((paramSQLiteDatabase == null) || (paramList == null))
    {
      l = 0L;
      return l;
    }
    String str = "";
    while (true)
    {
      String[] arrayOfString;
      int i;
      try
      {
        arrayOfString = new String[paramList.size()];
        i = 0;
        if (i >= paramList.size())
        {
          ContentValues localContentValues = new ContentValues();
          localContentValues.put(Database.SleepDetailEnum.dirty.name(), Boolean.valueOf(false));
          l = paramSQLiteDatabase.update("SleepDetail", localContentValues, str, arrayOfString);
          LogUtil.d("SleepDao", mDbName + " bulkUpdateSleepDetailToNotDirty res:" + l);
          break;
        }
      }
      finally
      {
      }
      str = str + "(" + Database.SleepDetailEnum.timestamp.name() + "=?)";
      if (i != -1 + paramList.size())
        str = str + " OR ";
      arrayOfString[i] = String.valueOf(((SleepDetail)paramList.get(i)).getTimestampS());
      i++;
    }
  }

  public static long bulkUpdateSleepDurationToNotDirty(SQLiteDatabase paramSQLiteDatabase, List<SleepDuration> paramList)
  {
    try
    {
      LogUtil.d("SleepDao", mDbName + " bulkUpdateSleepDurationToNotDirty");
      long l;
      if ((paramSQLiteDatabase == null) || (paramList == null))
        l = 0L;
      while (true)
      {
        return l;
        String str = contructSleepDurationSelection(paramList);
        String[] arrayOfString = contructSleepDurationSelectionArgs(paramList);
        ContentValues localContentValues = new ContentValues();
        localContentValues.put(Database.SleepDurationEnum.dirty.name(), Boolean.valueOf(false));
        l = paramSQLiteDatabase.update("SleepDuration", localContentValues, str, arrayOfString);
        LogUtil.d("SleepDao", mDbName + " bulkUpdateSleepDurationToNotDirty res:" + l);
      }
    }
    finally
    {
    }
  }

  public static long clearSleepDetail(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      LogUtil.d("SleepDao", mDbName + " clearSleepDetail");
      int i = paramSQLiteDatabase.delete("SleepDetail", null, null);
      long l = i;
      return l;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public static long clearSleepDuration(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      LogUtil.d("SleepDao", mDbName + " clearSleepDuration");
      int i = paramSQLiteDatabase.delete("SleepDuration", null, null);
      long l = i;
      return l;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private static String contructSleepDurationSelection(List<SleepDuration> paramList)
  {
    String str;
    if ((paramList == null) || ((paramList != null) && (paramList.size() == 0)))
      str = null;
    while (true)
    {
      return str;
      str = "";
      for (int i = 0; i < paramList.size(); i++)
      {
        str = str + "(" + Database.SleepDurationEnum.startTime.name() + "=?)";
        if (i != -1 + paramList.size())
          str = str + " OR ";
      }
    }
  }

  private static String[] contructSleepDurationSelectionArgs(List<SleepDuration> paramList)
  {
    String[] arrayOfString;
    if ((paramList == null) || ((paramList != null) && (paramList.size() == 0)))
      arrayOfString = null;
    while (true)
    {
      return arrayOfString;
      arrayOfString = new String[paramList.size()];
      int i = 0;
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        arrayOfString[i] = String.valueOf(((SleepDuration)localIterator.next()).getStartTime());
        i++;
      }
    }
  }

  public static long insertSleepDuration(SQLiteDatabase paramSQLiteDatabase, SleepDuration paramSleepDuration, boolean paramBoolean)
  {
    long l;
    if ((paramSQLiteDatabase == null) || (paramSleepDuration == null))
      l = 0L;
    while (true)
    {
      return l;
      try
      {
        ContentValues localContentValues = new ContentValues();
        localContentValues.put(Database.SleepDurationEnum.startTime.name(), Long.valueOf(paramSleepDuration.getStartTime()));
        localContentValues.put(Database.SleepDurationEnum.endTime.name(), Long.valueOf(paramSleepDuration.getEndTime()));
        localContentValues.put(Database.SleepDurationEnum.dirty.name(), Boolean.valueOf(paramBoolean));
        l = paramSQLiteDatabase.insert("SleepDuration", null, localContentValues);
        LogUtil.d("SleepDao", mDbName + " insertSleepDuration ret:" + l);
      }
      finally
      {
      }
    }
  }

  public static List<SleepDetail> selectDirtySleepDetail(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      LogUtil.d("SleepDao", mDbName + " selectDirtySleepDetail");
      String str1 = "(" + Database.SleepDetailEnum.dirty.name() + "=? AND " + Database.SleepDetailEnum.timestamp.name() + ">1000)";
      String[] arrayOfString = new String[1];
      arrayOfString[0] = String.valueOf(1);
      String str2 = Database.SleepDetailEnum.timestamp.name() + " ASC";
      ArrayList localArrayList = new ArrayList();
      Cursor localCursor = paramSQLiteDatabase.query("SleepDetail", null, str1, arrayOfString, null, null, str2);
      try
      {
        LogUtil.d("SleepDao", mDbName + " selectDirtySleepDetail cursor count:" + localCursor.getCount());
        while (true)
        {
          boolean bool = localCursor.moveToNext();
          if (!bool)
          {
            localCursor.close();
            return localArrayList;
          }
          localArrayList.add(new SleepDetail(localCursor.getLong(localCursor.getColumnIndex(Database.SleepDetailEnum.timestamp.name())), localCursor.getString(localCursor.getColumnIndex(Database.SleepDetailEnum.date.name())), SleepState.valueOf(localCursor.getInt(localCursor.getColumnIndex(Database.SleepDetailEnum.state.name())))));
        }
      }
      finally
      {
        localCursor.close();
      }
    }
    finally
    {
    }
  }

  public static List<SleepDuration> selectDirtySleepDuration(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      LogUtil.d("SleepDao", mDbName + " selectDirtySleepDuration");
      String str1 = "(" + Database.SleepDurationEnum.dirty.name() + "=? AND " + Database.SleepDurationEnum.endTime.name() + ">1000 AND " + Database.SleepDurationEnum.startTime.name() + ">1000 AND " + Database.SleepDurationEnum.endTime + ">" + Database.SleepDurationEnum.startTime + ")";
      LogUtil.d("SleepDao", "selectDirtySleepDuration selection:" + str1);
      String[] arrayOfString = new String[1];
      arrayOfString[0] = String.valueOf(1);
      String str2 = Database.SleepDurationEnum.startTime.name() + " ASC";
      LinkedList localLinkedList = new LinkedList();
      Cursor localCursor = paramSQLiteDatabase.query("SleepDuration", null, str1, arrayOfString, null, null, str2);
      try
      {
        while (true)
        {
          boolean bool = localCursor.moveToNext();
          if (!bool)
          {
            localCursor.close();
            return localLinkedList;
          }
          localLinkedList.add(new SleepDuration(localCursor.getLong(localCursor.getColumnIndex(Database.SleepDurationEnum.startTime.name())), localCursor.getLong(localCursor.getColumnIndex(Database.SleepDurationEnum.endTime.name()))));
        }
      }
      finally
      {
        localCursor.close();
      }
    }
    finally
    {
    }
  }

  public static SleepDetail selectLastSleepDetail(SQLiteDatabase paramSQLiteDatabase, long paramLong)
  {
    try
    {
      String str = "(" + Database.SleepDetailEnum.timestamp.name() + "<?)";
      String[] arrayOfString = new String[1];
      arrayOfString[0] = String.valueOf(paramLong);
      localCursor = paramSQLiteDatabase.query("SleepDetail", null, str, arrayOfString, null, null, Database.SleepDetailEnum.timestamp.name() + " DESC", String.valueOf(1));
    }
    finally
    {
      try
      {
        if (localCursor.moveToNext())
        {
          localSleepDetail = new SleepDetail(localCursor.getLong(localCursor.getColumnIndex(Database.SleepDetailEnum.timestamp.name())), localCursor.getString(localCursor.getColumnIndex(Database.SleepDetailEnum.date.name())), SleepState.valueOf(localCursor.getInt(localCursor.getColumnIndex(Database.SleepDetailEnum.state.name()))));
          localCursor.close();
          return localSleepDetail;
        }
        localCursor.close();
        SleepDetail localSleepDetail = null;
      }
      finally
      {
        Cursor localCursor;
        localCursor.close();
      }
    }
  }

  public static SleepDuration selectLastSleepDuration(SQLiteDatabase paramSQLiteDatabase)
  {
    while (true)
    {
      Cursor localCursor;
      try
      {
        LogUtil.d("SleepDao", mDbName + " selectLastSleepDuration:");
        localCursor = paramSQLiteDatabase.query("SleepDuration", null, null, null, null, null, Database.SleepDurationEnum.startTime.name() + " DESC", String.valueOf(1));
        try
        {
          if (localCursor.moveToNext())
          {
            long l1 = localCursor.getLong(localCursor.getColumnIndex(Database.SleepDurationEnum.startTime.name()));
            long l2 = localCursor.getLong(localCursor.getColumnIndex(Database.SleepDurationEnum.endTime.name()));
            localCursor.close();
            localSleepDuration = new SleepDuration(l1, l2);
            localCursor.close();
            return localSleepDuration;
          }
        }
        finally
        {
          localObject2 = finally;
          localCursor.close();
          throw localObject2;
        }
      }
      finally
      {
      }
      localCursor.close();
      SleepDuration localSleepDuration = null;
    }
  }

  // ERROR //
  public static List<SleepDetail> selectSleepDetail(SQLiteDatabase paramSQLiteDatabase, SleepDuration paramSleepDuration)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: new 319	java/util/LinkedList
    //   6: dup
    //   7: invokespecial 320	java/util/LinkedList:<init>	()V
    //   10: astore_2
    //   11: aload_0
    //   12: ifnull +7 -> 19
    //   15: aload_1
    //   16: ifnonnull +8 -> 24
    //   19: ldc 2
    //   21: monitorexit
    //   22: aload_2
    //   23: areturn
    //   24: aload_1
    //   25: invokevirtual 175	com/baidu/wearable/sleep/SleepDuration:getStartTime	()J
    //   28: lstore 4
    //   30: aload_1
    //   31: invokevirtual 181	com/baidu/wearable/sleep/SleepDuration:getEndTime	()J
    //   34: lstore 6
    //   36: ldc 8
    //   38: new 26	java/lang/StringBuilder
    //   41: dup
    //   42: getstatic 19	com/baidu/wearable/database/SleepDao:mDbName	Ljava/lang/String;
    //   45: invokestatic 32	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   48: invokespecial 35	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   51: ldc_w 340
    //   54: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   57: lload 4
    //   59: invokevirtual 197	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   62: ldc_w 342
    //   65: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: lload 6
    //   70: invokevirtual 197	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   73: invokevirtual 44	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   76: invokestatic 50	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   79: new 26	java/lang/StringBuilder
    //   82: dup
    //   83: ldc 201
    //   85: invokespecial 35	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   88: getstatic 97	com/baidu/wearable/database/Database$SleepDetailEnum:timestamp	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   91: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   94: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: ldc_w 344
    //   100: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: getstatic 97	com/baidu/wearable/database/Database$SleepDetailEnum:timestamp	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   106: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   109: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: ldc_w 346
    //   115: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   118: invokevirtual 44	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   121: astore 8
    //   123: iconst_2
    //   124: anewarray 28	java/lang/String
    //   127: astore 9
    //   129: aload 9
    //   131: iconst_0
    //   132: lload 4
    //   134: invokestatic 206	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   137: aastore
    //   138: aload 9
    //   140: iconst_1
    //   141: lload 6
    //   143: invokestatic 206	java/lang/String:valueOf	(J)Ljava/lang/String;
    //   146: aastore
    //   147: aload_0
    //   148: ldc 151
    //   150: aconst_null
    //   151: aload 8
    //   153: aload 9
    //   155: aconst_null
    //   156: aconst_null
    //   157: new 26	java/lang/StringBuilder
    //   160: dup
    //   161: getstatic 97	com/baidu/wearable/database/Database$SleepDetailEnum:timestamp	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   164: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   167: invokestatic 32	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   170: invokespecial 35	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   173: ldc_w 262
    //   176: invokevirtual 41	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: invokevirtual 44	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   182: invokevirtual 266	android/database/sqlite/SQLiteDatabase:query	(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   185: astore 10
    //   187: aload 10
    //   189: invokeinterface 279 1 0
    //   194: istore 12
    //   196: iload 12
    //   198: ifne +19 -> 217
    //   201: aload 10
    //   203: invokeinterface 282 1 0
    //   208: goto -189 -> 19
    //   211: astore_3
    //   212: ldc 2
    //   214: monitorexit
    //   215: aload_3
    //   216: athrow
    //   217: aload_2
    //   218: new 82	com/baidu/wearable/sleep/SleepDetail
    //   221: dup
    //   222: aload 10
    //   224: aload 10
    //   226: getstatic 97	com/baidu/wearable/database/Database$SleepDetailEnum:timestamp	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   229: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   232: invokeinterface 286 2 0
    //   237: invokeinterface 290 2 0
    //   242: aload 10
    //   244: aload 10
    //   246: getstatic 112	com/baidu/wearable/database/Database$SleepDetailEnum:date	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   249: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   252: invokeinterface 286 2 0
    //   257: invokeinterface 293 2 0
    //   262: aload 10
    //   264: aload 10
    //   266: getstatic 120	com/baidu/wearable/database/Database$SleepDetailEnum:state	Lcom/baidu/wearable/database/Database$SleepDetailEnum;
    //   269: invokevirtual 100	com/baidu/wearable/database/Database$SleepDetailEnum:name	()Ljava/lang/String;
    //   272: invokeinterface 286 2 0
    //   277: invokeinterface 297 2 0
    //   282: invokestatic 300	com/baidu/wearable/sleep/SleepState:valueOf	(I)Lcom/baidu/wearable/sleep/SleepState;
    //   285: invokespecial 303	com/baidu/wearable/sleep/SleepDetail:<init>	(JLjava/lang/String;Lcom/baidu/wearable/sleep/SleepState;)V
    //   288: invokeinterface 159 2 0
    //   293: pop
    //   294: goto -107 -> 187
    //   297: astore 11
    //   299: aload 10
    //   301: invokeinterface 282 1 0
    //   306: aload 11
    //   308: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   3	11	211	finally
    //   24	187	211	finally
    //   201	208	211	finally
    //   299	309	211	finally
    //   187	196	297	finally
    //   217	294	297	finally
  }

  public static List<SleepDuration> selectSleepDuration(SQLiteDatabase paramSQLiteDatabase, long paramLong1, long paramLong2)
  {
    try
    {
      LogUtil.d("SleepDao", mDbName + " selectSleepDuration startTime:" + paramLong1 + ", endTime:" + paramLong2);
      String str1 = "(" + Database.SleepDurationEnum.endTime.name() + ">=?1 AND " + Database.SleepDurationEnum.endTime.name() + "<=?2 AND " + Database.SleepDurationEnum.endTime.name() + ">1000 AND " + Database.SleepDurationEnum.startTime.name() + ">1000 AND " + Database.SleepDurationEnum.endTime + ">" + Database.SleepDurationEnum.startTime + ")";
      LogUtil.d("SleepDao", "selectSleepDuration selection:" + str1);
      String[] arrayOfString = new String[2];
      arrayOfString[0] = String.valueOf(paramLong1);
      arrayOfString[1] = String.valueOf(paramLong2);
      String str2 = Database.SleepDurationEnum.endTime.name() + " ASC";
      ArrayList localArrayList = new ArrayList();
      Cursor localCursor = paramSQLiteDatabase.query("SleepDuration", null, str1, arrayOfString, null, null, str2);
      try
      {
        while (true)
        {
          boolean bool = localCursor.moveToNext();
          if (!bool)
          {
            localCursor.close();
            return localArrayList;
          }
          localArrayList.add(new SleepDuration(localCursor.getLong(localCursor.getColumnIndex(Database.SleepDurationEnum.startTime.name())), localCursor.getLong(localCursor.getColumnIndex(Database.SleepDurationEnum.endTime.name()))));
        }
      }
      finally
      {
        localCursor.close();
      }
    }
    finally
    {
    }
  }

  public static long updateSleepDuration(SQLiteDatabase paramSQLiteDatabase, SleepDuration paramSleepDuration, boolean paramBoolean)
  {
    long l = 0L;
    if ((paramSQLiteDatabase == null) || (paramSleepDuration == null));
    while (true)
    {
      return l;
      try
      {
        if (l == paramSleepDuration.getStartTime())
        {
          l = -1L;
          continue;
        }
        ContentValues localContentValues = new ContentValues();
        localContentValues.put(Database.SleepDurationEnum.endTime.name(), Long.valueOf(paramSleepDuration.getEndTime()));
        localContentValues.put(Database.SleepDurationEnum.dirty.name(), Boolean.valueOf(paramBoolean));
        String[] arrayOfString = new String[1];
        arrayOfString[0] = String.valueOf(paramSleepDuration.getStartTime());
        l = paramSQLiteDatabase.update("SleepDuration", localContentValues, Database.SleepDurationEnum.startTime.name() + "=?", arrayOfString);
        LogUtil.d("SleepDao", mDbName + " updateSleepDuration ret:" + l);
      }
      finally
      {
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.database.SleepDao
 * JD-Core Version:    0.6.2
 */