package com.baidu.wearable.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import com.baidu.wearable.ble.model.Clock;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.LinkedList;
import java.util.List;

public class ClockDao
{
  private static final String TAG = "ClockDao";
  private static final String mDbName = Database.getName();

  public static long clearClock(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      LogUtil.d("ClockDao", mDbName + " clearClock");
      int i = paramSQLiteDatabase.delete("Clock", null, null);
      long l = i;
      return l;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public static long deleteClock(SQLiteDatabase paramSQLiteDatabase, long paramLong)
  {
    try
    {
      String str = Database.ClockEnum.id.name() + "=?";
      String[] arrayOfString = new String[1];
      arrayOfString[0] = String.valueOf(paramLong);
      long l = paramSQLiteDatabase.delete("Clock", str, arrayOfString);
      LogUtil.d("ClockDao", mDbName + " deleteClock res:" + l);
      return l;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public static long insertClock(SQLiteDatabase paramSQLiteDatabase, Clock paramClock)
  {
    long l1;
    if ((paramSQLiteDatabase == null) || (paramClock == null))
      l1 = 0L;
    while (true)
    {
      return l1;
      try
      {
        ContentValues localContentValues = new ContentValues();
        localContentValues.put(Database.ClockEnum.alarm_id.name(), Integer.valueOf(paramClock.getAlarmId()));
        localContentValues.put(Database.ClockEnum.year.name(), Integer.valueOf(paramClock.getYear()));
        localContentValues.put(Database.ClockEnum.month.name(), Integer.valueOf(paramClock.getMonth()));
        localContentValues.put(Database.ClockEnum.day.name(), Integer.valueOf(paramClock.getDay()));
        localContentValues.put(Database.ClockEnum.hour.name(), Integer.valueOf(paramClock.getHour()));
        localContentValues.put(Database.ClockEnum.minute.name(), Integer.valueOf(paramClock.getMinute()));
        localContentValues.put(Database.ClockEnum.sunday.name(), Boolean.valueOf(paramClock.isSun()));
        localContentValues.put(Database.ClockEnum.monday.name(), Boolean.valueOf(paramClock.isMon()));
        localContentValues.put(Database.ClockEnum.tuesday.name(), Boolean.valueOf(paramClock.isTue()));
        localContentValues.put(Database.ClockEnum.wednesday.name(), Boolean.valueOf(paramClock.isWed()));
        localContentValues.put(Database.ClockEnum.thursday.name(), Boolean.valueOf(paramClock.isThu()));
        localContentValues.put(Database.ClockEnum.friday.name(), Boolean.valueOf(paramClock.isFri()));
        localContentValues.put(Database.ClockEnum.saturday.name(), Boolean.valueOf(paramClock.isSat()));
        localContentValues.put(Database.ClockEnum.onOrOff.name(), Boolean.valueOf(paramClock.isOn()));
        localContentValues.put(Database.ClockEnum.netDirty.name(), Boolean.valueOf(paramClock.isNetDirty()));
        localContentValues.put(Database.ClockEnum.braceletDirty.name(), Boolean.valueOf(paramClock.isBraceletDirty()));
        printClockLog("insertClock", paramClock);
        long l2 = paramSQLiteDatabase.insert("Clock", null, localContentValues);
        l1 = l2;
      }
      finally
      {
      }
    }
  }

  private static void printClockLog(String paramString, Clock paramClock)
  {
    if (paramClock == null)
      return;
    LogUtil.d("ClockDao", paramString + ", id:" + paramClock.getId() + ", alarmId:" + paramClock.getAlarmId() + ", year:" + paramClock.getYear() + ", month:" + paramClock.getMonth() + ", day:" + paramClock.getDay() + ", hour:" + paramClock.getHour() + ", minute:" + paramClock.getMinute() + ", is every day:" + paramClock.isEveryDay() + ", expire:" + paramClock.isExpire() + ", on:" + paramClock.isOn() + ", expire:" + paramClock.isExpire() + ", bracelet dirty:" + paramClock.isBraceletDirty() + ", is mon:" + paramClock.isMon() + ", is tue:" + paramClock.isTue() + ", is web:" + paramClock.isWed() + ", is Thu" + paramClock.isThu() + ", is Fri:" + paramClock.isFri() + ", is Sat:" + paramClock.isSat() + ", is sun:" + paramClock.isSun());
  }

  public static List<Clock> selectClock(SQLiteDatabase paramSQLiteDatabase)
  {
    while (true)
    {
      Clock localClock;
      try
      {
        LinkedList localLinkedList = new LinkedList();
        Cursor localCursor = paramSQLiteDatabase.query("Clock", null, null, null, null, null, null);
        try
        {
          LogUtil.d("ClockDao", mDbName + " selectClock count:" + localCursor.getCount());
          boolean bool = localCursor.moveToNext();
          if (!bool)
          {
            localCursor.close();
            return localLinkedList;
          }
          localClock = new Clock();
          localClock.setId(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.id.name())));
          localClock.setAlarmId(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.alarm_id.name())));
          localClock.setYear(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.year.name())));
          localClock.setMonth(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.month.name())));
          localClock.setDay(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.day.name())));
          localClock.setHour(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.hour.name())));
          localClock.setMinute(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.minute.name())));
          if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.sunday.name())) == 0)
          {
            localClock.setSun(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.monday.name())) != 0)
              break label571;
            localClock.setMon(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.tuesday.name())) != 0)
              break label580;
            localClock.setTue(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.wednesday.name())) != 0)
              break label589;
            localClock.setWed(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.thursday.name())) != 0)
              break label598;
            localClock.setThu(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.friday.name())) != 0)
              break label607;
            localClock.setFri(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.saturday.name())) != 0)
              break label616;
            localClock.setSat(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.onOrOff.name())) != 0)
              break label625;
            localClock.setOn(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.netDirty.name())) != 0)
              break label634;
            localClock.setNetDirty(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.braceletDirty.name())) != 0)
              break label643;
            localClock.setBraceletDirty(false);
            localLinkedList.add(localClock);
            printClockLog("selectClock", localClock);
            continue;
          }
        }
        finally
        {
          localCursor.close();
        }
      }
      finally
      {
      }
      localClock.setSun(true);
      continue;
      label571: localClock.setMon(true);
      continue;
      label580: localClock.setTue(true);
      continue;
      label589: localClock.setWed(true);
      continue;
      label598: localClock.setThu(true);
      continue;
      label607: localClock.setFri(true);
      continue;
      label616: localClock.setSat(true);
      continue;
      label625: localClock.setOn(true);
      continue;
      label634: localClock.setNetDirty(true);
      continue;
      label643: localClock.setBraceletDirty(true);
    }
  }

  public static List<Clock> selectOpenClock(SQLiteDatabase paramSQLiteDatabase)
  {
    while (true)
    {
      Clock localClock;
      try
      {
        String str = "(" + Database.ClockEnum.onOrOff.name() + "=?)";
        String[] arrayOfString = new String[1];
        arrayOfString[0] = String.valueOf(1);
        LinkedList localLinkedList = new LinkedList();
        Cursor localCursor = paramSQLiteDatabase.query("Clock", null, str, arrayOfString, null, null, null);
        try
        {
          boolean bool = localCursor.moveToNext();
          if (!bool)
          {
            localCursor.close();
            return localLinkedList;
          }
          localClock = new Clock();
          localClock.setId(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.id.name())));
          localClock.setAlarmId(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.alarm_id.name())));
          localClock.setYear(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.year.name())));
          localClock.setMonth(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.month.name())));
          localClock.setDay(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.day.name())));
          localClock.setHour(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.hour.name())));
          localClock.setMinute(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.minute.name())));
          if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.sunday.name())) == 0)
          {
            localClock.setSun(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.monday.name())) != 0)
              break label617;
            localClock.setMon(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.tuesday.name())) != 0)
              break label626;
            localClock.setTue(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.wednesday.name())) != 0)
              break label635;
            localClock.setWed(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.thursday.name())) != 0)
              break label644;
            localClock.setThu(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.friday.name())) != 0)
              break label653;
            localClock.setFri(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.saturday.name())) != 0)
              break label662;
            localClock.setSat(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.onOrOff.name())) != 0)
              break label671;
            localClock.setOn(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.netDirty.name())) != 0)
              break label680;
            localClock.setNetDirty(false);
            if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.braceletDirty.name())) != 0)
              break label689;
            localClock.setBraceletDirty(false);
            localLinkedList.add(localClock);
            printClockLog("selectOpenClock", localClock);
            continue;
          }
        }
        finally
        {
          localCursor.close();
        }
      }
      finally
      {
      }
      localClock.setSun(true);
      continue;
      label617: localClock.setMon(true);
      continue;
      label626: localClock.setTue(true);
      continue;
      label635: localClock.setWed(true);
      continue;
      label644: localClock.setThu(true);
      continue;
      label653: localClock.setFri(true);
      continue;
      label662: localClock.setSat(true);
      continue;
      label671: localClock.setOn(true);
      continue;
      label680: localClock.setNetDirty(true);
      continue;
      label689: localClock.setBraceletDirty(true);
    }
  }

  public static long updateClock(SQLiteDatabase paramSQLiteDatabase, Clock paramClock)
  {
    long l;
    if ((paramSQLiteDatabase == null) || (paramClock == null))
      l = 0L;
    while (true)
    {
      return l;
      try
      {
        LogUtil.d("ClockDao", mDbName + " updateClock id:" + paramClock.getId() + ", on:" + paramClock.isOn());
        ContentValues localContentValues = new ContentValues();
        localContentValues.put(Database.ClockEnum.alarm_id.name(), Integer.valueOf(paramClock.getAlarmId()));
        localContentValues.put(Database.ClockEnum.year.name(), Integer.valueOf(paramClock.getYear()));
        localContentValues.put(Database.ClockEnum.month.name(), Integer.valueOf(paramClock.getMonth()));
        localContentValues.put(Database.ClockEnum.day.name(), Integer.valueOf(paramClock.getDay()));
        localContentValues.put(Database.ClockEnum.hour.name(), Integer.valueOf(paramClock.getHour()));
        localContentValues.put(Database.ClockEnum.minute.name(), Integer.valueOf(paramClock.getMinute()));
        localContentValues.put(Database.ClockEnum.sunday.name(), Boolean.valueOf(paramClock.isSun()));
        localContentValues.put(Database.ClockEnum.monday.name(), Boolean.valueOf(paramClock.isMon()));
        localContentValues.put(Database.ClockEnum.tuesday.name(), Boolean.valueOf(paramClock.isTue()));
        localContentValues.put(Database.ClockEnum.wednesday.name(), Boolean.valueOf(paramClock.isWed()));
        localContentValues.put(Database.ClockEnum.thursday.name(), Boolean.valueOf(paramClock.isThu()));
        localContentValues.put(Database.ClockEnum.friday.name(), Boolean.valueOf(paramClock.isFri()));
        localContentValues.put(Database.ClockEnum.saturday.name(), Boolean.valueOf(paramClock.isSat()));
        localContentValues.put(Database.ClockEnum.onOrOff.name(), Boolean.valueOf(paramClock.isOn()));
        localContentValues.put(Database.ClockEnum.netDirty.name(), Boolean.valueOf(paramClock.isBraceletDirty()));
        localContentValues.put(Database.ClockEnum.braceletDirty.name(), Boolean.valueOf(paramClock.isBraceletDirty()));
        printClockLog("updateClock", paramClock);
        String[] arrayOfString = new String[1];
        arrayOfString[0] = String.valueOf(paramClock.getId());
        int i = paramSQLiteDatabase.update("Clock", localContentValues, Database.ClockEnum.id.name() + "=?", arrayOfString);
        l = i;
      }
      finally
      {
      }
    }
  }

  public static long updateClockToClose(SQLiteDatabase paramSQLiteDatabase, int paramInt)
  {
    try
    {
      LogUtil.d("ClockDao", mDbName + " updateClockWithAlarmId alarmId:" + paramInt);
      ContentValues localContentValues = new ContentValues();
      localContentValues.put(Database.ClockEnum.onOrOff.name(), Boolean.valueOf(false));
      String[] arrayOfString = new String[1];
      arrayOfString[0] = String.valueOf(paramInt);
      int i = paramSQLiteDatabase.update("Clock", localContentValues, Database.ClockEnum.alarm_id.name() + "=?", arrayOfString);
      long l = i;
      return l;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.database.ClockDao
 * JD-Core Version:    0.6.2
 */