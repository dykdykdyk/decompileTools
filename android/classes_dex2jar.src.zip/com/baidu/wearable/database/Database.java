package com.baidu.wearable.database;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.ble.util.LogUtil;

public class Database
{
  private static final String DATABASE_PATH = "/data/data/com.baidu.wearable/databases/";
  public static final int DB_VERSION = 1;
  private static final String TAG = "Database";
  private static SQLiteDatabase mDb;
  private static String mDbName;
  private static String mLastUid;
  private static String mUid;

  public static void close()
  {
    try
    {
      if (mDb != null)
      {
        LogUtil.d("Database", "db close");
        mDb.close();
        mDb = null;
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  @SuppressLint({"NewApi"})
  public static SQLiteDatabase getDb(Context paramContext)
  {
    try
    {
      mUid = BDAccountManager.getInstance().getUserData("uid");
      LogUtil.d("Database", "mUid:" + mUid + ", mLastUid:" + mLastUid);
      if ((mUid != null) && (mLastUid != null) && (!mUid.equals(mLastUid)))
        close();
      if (mDb == null)
      {
        mLastUid = mUid;
        DbOpenHelper localDbOpenHelper = new DbOpenHelper(paramContext, mUid + ".db", 1);
        mDbName = localDbOpenHelper.getDatabaseName();
        LogUtil.d("Database", "database name:" + mDbName + ", uid:" + mUid);
        mDb = localDbOpenHelper.getWritableDatabase();
      }
      SQLiteDatabase localSQLiteDatabase = mDb;
      return localSQLiteDatabase;
    }
    finally
    {
    }
  }

  public static String getName()
  {
    return mDbName;
  }

  public static enum ClockEnum
  {
    public static final String TABLE_NAME = "Clock";

    static
    {
      alarm_id = new ClockEnum("alarm_id", 1);
      year = new ClockEnum("year", 2);
      month = new ClockEnum("month", 3);
      day = new ClockEnum("day", 4);
      hour = new ClockEnum("hour", 5);
      minute = new ClockEnum("minute", 6);
      sunday = new ClockEnum("sunday", 7);
      monday = new ClockEnum("monday", 8);
      tuesday = new ClockEnum("tuesday", 9);
      wednesday = new ClockEnum("wednesday", 10);
      thursday = new ClockEnum("thursday", 11);
      friday = new ClockEnum("friday", 12);
      saturday = new ClockEnum("saturday", 13);
      onOrOff = new ClockEnum("onOrOff", 14);
      netDirty = new ClockEnum("netDirty", 15);
      braceletDirty = new ClockEnum("braceletDirty", 16);
      ClockEnum[] arrayOfClockEnum = new ClockEnum[17];
      arrayOfClockEnum[0] = id;
      arrayOfClockEnum[1] = alarm_id;
      arrayOfClockEnum[2] = year;
      arrayOfClockEnum[3] = month;
      arrayOfClockEnum[4] = day;
      arrayOfClockEnum[5] = hour;
      arrayOfClockEnum[6] = minute;
      arrayOfClockEnum[7] = sunday;
      arrayOfClockEnum[8] = monday;
      arrayOfClockEnum[9] = tuesday;
      arrayOfClockEnum[10] = wednesday;
      arrayOfClockEnum[11] = thursday;
      arrayOfClockEnum[12] = friday;
      arrayOfClockEnum[13] = saturday;
      arrayOfClockEnum[14] = onOrOff;
      arrayOfClockEnum[15] = netDirty;
      arrayOfClockEnum[16] = braceletDirty;
    }
  }

  public static class DbOpenHelper extends SQLiteOpenHelper
  {
    public DbOpenHelper(Context paramContext, String paramString, int paramInt)
    {
      super(paramString, null, paramInt);
    }

    private void dropTables(SQLiteDatabase paramSQLiteDatabase)
    {
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS SportSummary");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS SportDetail");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS SleepDetail");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS SleepDuration");
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS Clock");
    }

    public void onCreate(SQLiteDatabase paramSQLiteDatabase)
    {
      paramSQLiteDatabase.execSQL("CREATE TABLE SportSummary (" + Database.SportSummaryEnum.timestamp.name() + " INTEGER NOT NULL PRIMARY KEY, " + Database.SportSummaryEnum.date.name() + " TEXT NOT NULL, " + Database.SportSummaryEnum.totalSteps.name() + " INTEGER NOT NULL, " + Database.SportSummaryEnum.totalCalories.name() + " REAL NOT NULL, " + Database.SportSummaryEnum.totalDistance.name() + " REAL NOT NULL" + ");");
      paramSQLiteDatabase.execSQL("CREATE TABLE SportDetail (" + Database.SportDetailEnum.timestamp.name() + " INTEGER NOT NULL PRIMARY KEY, " + Database.SportDetailEnum.steps.name() + " INTEGER NOT NULL, " + Database.SportDetailEnum.calories.name() + " REAL NOT NULL, " + Database.SportDetailEnum.distance.name() + " REAL NOT NULL, " + Database.SportDetailEnum.dirty.name() + " INTEGER NOT NULL" + ");");
      paramSQLiteDatabase.execSQL("CREATE TABLE SleepDetail (" + Database.SleepDetailEnum.timestamp.name() + " INTEGER NOT NULL PRIMARY KEY, " + Database.SleepDetailEnum.date.name() + " TEXT NOT NULL, " + Database.SleepDetailEnum.state.name() + " INTEGER NOT NULL, " + Database.SleepDetailEnum.dirty.name() + " INTEGER NOT NULL" + ");");
      paramSQLiteDatabase.execSQL("CREATE TABLE SleepDuration (" + Database.SleepDurationEnum.startTime.name() + " INTEGER NOT NULL PRIMARY KEY, " + Database.SleepDurationEnum.endTime.name() + " INTEGER, " + Database.SleepDurationEnum.dirty.name() + " INTEGER NOT NULL" + ");");
      paramSQLiteDatabase.execSQL("CREATE TABLE Clock (" + Database.ClockEnum.id.name() + " INTEGER NOT NULL PRIMARY KEY, " + Database.ClockEnum.alarm_id.name() + " INTERGER, " + Database.ClockEnum.year.name() + " INTEGER, " + Database.ClockEnum.month.name() + " INTEGER, " + Database.ClockEnum.day.name() + " INTEGER, " + Database.ClockEnum.hour.name() + " INTEGER, " + Database.ClockEnum.minute.name() + " INTEGER, " + Database.ClockEnum.sunday.name() + " INTEGER, " + Database.ClockEnum.monday.name() + " INTERGER, " + Database.ClockEnum.tuesday.name() + " INTERGER, " + Database.ClockEnum.wednesday.name() + " INTERGER, " + Database.ClockEnum.thursday.name() + " INTERGER, " + Database.ClockEnum.friday.name() + " INTERGER, " + Database.ClockEnum.saturday.name() + " INTERGER, " + Database.ClockEnum.onOrOff.name() + " INTERGER, " + Database.ClockEnum.netDirty.name() + " INTERGER, " + Database.ClockEnum.braceletDirty.name() + " INTERGER" + ");");
    }

    public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
    {
      dropTables(paramSQLiteDatabase);
      onCreate(paramSQLiteDatabase);
    }
  }

  public static enum SleepDetailEnum
  {
    static final String TABLE_NAME = "SleepDetail";

    static
    {
      date = new SleepDetailEnum("date", 1);
      state = new SleepDetailEnum("state", 2);
      dirty = new SleepDetailEnum("dirty", 3);
      SleepDetailEnum[] arrayOfSleepDetailEnum = new SleepDetailEnum[4];
      arrayOfSleepDetailEnum[0] = timestamp;
      arrayOfSleepDetailEnum[1] = date;
      arrayOfSleepDetailEnum[2] = state;
      arrayOfSleepDetailEnum[3] = dirty;
    }
  }

  public static enum SleepDurationEnum
  {
    static final String TABLE_NAME = "SleepDuration";

    static
    {
      endTime = new SleepDurationEnum("endTime", 1);
      dirty = new SleepDurationEnum("dirty", 2);
      SleepDurationEnum[] arrayOfSleepDurationEnum = new SleepDurationEnum[3];
      arrayOfSleepDurationEnum[0] = startTime;
      arrayOfSleepDurationEnum[1] = endTime;
      arrayOfSleepDurationEnum[2] = dirty;
    }
  }

  public static enum SportDetailEnum
  {
    static final String TABLE_NAME = "SportDetail";

    static
    {
      steps = new SportDetailEnum("steps", 1);
      calories = new SportDetailEnum("calories", 2);
      distance = new SportDetailEnum("distance", 3);
      dirty = new SportDetailEnum("dirty", 4);
      SportDetailEnum[] arrayOfSportDetailEnum = new SportDetailEnum[5];
      arrayOfSportDetailEnum[0] = timestamp;
      arrayOfSportDetailEnum[1] = steps;
      arrayOfSportDetailEnum[2] = calories;
      arrayOfSportDetailEnum[3] = distance;
      arrayOfSportDetailEnum[4] = dirty;
    }
  }

  public static enum SportSummaryEnum
  {
    static final String TABLE_NAME = "SportSummary";

    static
    {
      date = new SportSummaryEnum("date", 1);
      totalSteps = new SportSummaryEnum("totalSteps", 2);
      totalCalories = new SportSummaryEnum("totalCalories", 3);
      totalDistance = new SportSummaryEnum("totalDistance", 4);
      SportSummaryEnum[] arrayOfSportSummaryEnum = new SportSummaryEnum[5];
      arrayOfSportSummaryEnum[0] = timestamp;
      arrayOfSportSummaryEnum[1] = date;
      arrayOfSportSummaryEnum[2] = totalSteps;
      arrayOfSportSummaryEnum[3] = totalCalories;
      arrayOfSportSummaryEnum[4] = totalDistance;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.database.Database
 * JD-Core Version:    0.6.2
 */