package com.baidu.wearable.database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.sport.SportDetail;
import com.baidu.wearable.sport.SportPart;
import com.baidu.wearable.sport.SportSummary;
import com.baidu.wearable.util.TimeUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SportDao
{
  private static final String TAG = "SportDao";
  private static final String mDbName = Database.getName();

  public static List<Long> bulkReplaceSportDetail(SQLiteDatabase paramSQLiteDatabase, List<SportDetail> paramList, boolean paramBoolean)
  {
    LogUtil.d("SportDao", mDbName + " bulkReplaceSportDetail");
    if ((paramSQLiteDatabase == null) || (paramList == null))
      return null;
    paramList.size();
    ArrayList localArrayList = new ArrayList();
    paramSQLiteDatabase.beginTransaction();
    try
    {
      Iterator localIterator = paramList.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
        {
          paramSQLiteDatabase.setTransactionSuccessful();
          return localArrayList;
        }
        SportDetail localSportDetail = (SportDetail)localIterator.next();
        ContentValues localContentValues = new ContentValues();
        if (localSportDetail.getTimestampS() >= 1000L)
        {
          localContentValues.put(Database.SportDetailEnum.timestamp.name(), Long.valueOf(localSportDetail.getTimestampS()));
          localContentValues.put(Database.SportDetailEnum.steps.name(), Integer.valueOf(localSportDetail.getSteps()));
          localContentValues.put(Database.SportDetailEnum.calories.name(), Float.valueOf(localSportDetail.getCalories()));
          localContentValues.put(Database.SportDetailEnum.distance.name(), Float.valueOf(localSportDetail.getDistance()));
          localContentValues.put(Database.SportDetailEnum.dirty.name(), Boolean.valueOf(paramBoolean));
          localArrayList.add(Long.valueOf(paramSQLiteDatabase.replace("SportDetail", null, localContentValues)));
        }
      }
    }
    finally
    {
      paramSQLiteDatabase.endTransaction();
    }
  }

  public static List<Long> bulkReplaceSportSummary(SQLiteDatabase paramSQLiteDatabase, List<SportSummary> paramList)
  {
    LogUtil.d("SportDao", mDbName + " bulkReplaceSportSummary");
    if ((paramSQLiteDatabase == null) || (paramList == null))
      return null;
    paramList.size();
    ArrayList localArrayList = new ArrayList();
    paramSQLiteDatabase.beginTransaction();
    try
    {
      Iterator localIterator = paramList.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
        {
          paramSQLiteDatabase.setTransactionSuccessful();
          return localArrayList;
        }
        SportSummary localSportSummary = (SportSummary)localIterator.next();
        dealWithTime(localSportSummary);
        if (localSportSummary.getTimestampS() >= 1000L)
        {
          ContentValues localContentValues = new ContentValues();
          localContentValues.put(Database.SportSummaryEnum.timestamp.name(), Long.valueOf(localSportSummary.getTimestampS()));
          localContentValues.put(Database.SportSummaryEnum.date.name(), localSportSummary.getDate());
          localContentValues.put(Database.SportSummaryEnum.totalSteps.name(), Integer.valueOf(localSportSummary.getSteps()));
          localContentValues.put(Database.SportSummaryEnum.totalCalories.name(), Float.valueOf(localSportSummary.getCalories()));
          localContentValues.put(Database.SportSummaryEnum.totalDistance.name(), Float.valueOf(localSportSummary.getDistance()));
          long l = paramSQLiteDatabase.replace("SportSummary", null, localContentValues);
          LogUtil.d("SportDao", mDbName + " replaceSportSummary, timeStamp:" + localSportSummary.getTimestampS() + ", date:" + localSportSummary.getDate() + ", steps:" + localSportSummary.getSteps() + ", calories:" + localSportSummary.getCalories() + ", distance:" + localSportSummary.getDistance() + ", res:" + l);
          localArrayList.add(Long.valueOf(l));
        }
      }
    }
    finally
    {
      paramSQLiteDatabase.endTransaction();
    }
  }

  public static long clearSportDetail(SQLiteDatabase paramSQLiteDatabase)
  {
    LogUtil.d("SportDao", mDbName + " clearSportDetail");
    return paramSQLiteDatabase.delete("SportDetail", null, null);
  }

  public static long clearSportSummary(SQLiteDatabase paramSQLiteDatabase)
  {
    LogUtil.d("SportDao", mDbName + " clearSportSummary");
    return paramSQLiteDatabase.delete("SportSummary", null, null);
  }

  private static void dealWithTime(SportSummary paramSportSummary)
  {
    if ((paramSportSummary.getDate() == null) && (0L == paramSportSummary.getTimestampS()))
    {
      String str = TimeUtil.getDate(System.currentTimeMillis());
      long l = TimeUtil.getTimestamp(str) / 1000L;
      paramSportSummary.setDate(str);
      paramSportSummary.setTimestampS(l);
    }
    do
    {
      return;
      if (paramSportSummary.getDate() == null)
      {
        paramSportSummary.setDate(TimeUtil.getDate(1000L * paramSportSummary.getTimestampS()));
        return;
      }
    }
    while (0L != paramSportSummary.getTimestampS());
    paramSportSummary.setTimestampS(TimeUtil.getTimestamp(paramSportSummary.getDate()) / 1000L);
  }

  public static long insertSportDetail(SQLiteDatabase paramSQLiteDatabase, SportDetail paramSportDetail, boolean paramBoolean)
  {
    if ((paramSQLiteDatabase == null) || (paramSportDetail == null));
    while (paramSportDetail.getTimestampS() < 1000L)
      return 0L;
    ContentValues localContentValues = new ContentValues();
    localContentValues.put(Database.SportDetailEnum.timestamp.name(), Long.valueOf(paramSportDetail.getTimestampS()));
    localContentValues.put(Database.SportDetailEnum.steps.name(), Integer.valueOf(paramSportDetail.getSteps()));
    localContentValues.put(Database.SportDetailEnum.calories.name(), Float.valueOf(paramSportDetail.getCalories()));
    localContentValues.put(Database.SportDetailEnum.distance.name(), Float.valueOf(paramSportDetail.getDistance()));
    localContentValues.put(Database.SportDetailEnum.dirty.name(), Boolean.valueOf(paramBoolean));
    long l = paramSQLiteDatabase.insert("SportDetail", null, localContentValues);
    LogUtil.d("SportDao", mDbName + " insert sport detail, timestamp:" + paramSportDetail.getTimestampS() + ", steps:" + paramSportDetail.getSteps() + ", calories:" + paramSportDetail.getCalories() + ", distance:" + paramSportDetail.getDistance() + ", dirty:" + paramBoolean + ", res:" + l);
    return l;
  }

  public static long insertSportSummary(SQLiteDatabase paramSQLiteDatabase, SportSummary paramSportSummary)
  {
    if ((paramSQLiteDatabase == null) || (paramSportSummary == null));
    do
    {
      return 0L;
      dealWithTime(paramSportSummary);
    }
    while (paramSportSummary.getTimestampS() < 1000L);
    ContentValues localContentValues = new ContentValues();
    localContentValues.put(Database.SportSummaryEnum.timestamp.name(), Long.valueOf(paramSportSummary.getTimestampS()));
    localContentValues.put(Database.SportSummaryEnum.date.name(), paramSportSummary.getDate());
    localContentValues.put(Database.SportSummaryEnum.totalSteps.name(), Integer.valueOf(paramSportSummary.getSteps()));
    localContentValues.put(Database.SportSummaryEnum.totalCalories.name(), Float.valueOf(paramSportSummary.getCalories()));
    localContentValues.put(Database.SportSummaryEnum.totalDistance.name(), Float.valueOf(paramSportSummary.getDistance()));
    long l1 = -1L;
    try
    {
      long l2 = paramSQLiteDatabase.insert("SportSummary", null, localContentValues);
      l1 = l2;
      LogUtil.d("SportDao", mDbName + " insertSportSummary, timeStamp:" + paramSportSummary.getTimestampS() + ", date:" + paramSportSummary.getDate() + ", steps:" + paramSportSummary.getSteps() + ", calories:" + paramSportSummary.getCalories() + ", distance:" + paramSportSummary.getDistance() + ", res:" + l1);
      return l1;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public static long putSportDetailWithSummation(SQLiteDatabase paramSQLiteDatabase, SportPart paramSportPart, boolean paramBoolean)
  {
    if ((paramSQLiteDatabase == null) || (paramSportPart == null))
      return 0L;
    LogUtil.d("SportDao", mDbName + " putPhoneSportDetail steps:" + paramSportPart.getSteps() + ", calories:" + paramSportPart.getCalories() + ", distances:" + paramSportPart.getDistance());
    long l1 = TimeUtil.getDurationStart() / 1000L;
    if (l1 < 1000L)
      return 0L;
    String str = SQLiteQueryBuilder.buildQueryString(true, "SportDetail", null, Database.SportDetailEnum.timestamp.name() + "='" + l1 + "'", null, null, Database.SportDetailEnum.timestamp.name() + " DESC", null);
    LogUtil.d("SportDao", mDbName + " select sql:" + str);
    Cursor localCursor = paramSQLiteDatabase.rawQuery(str, null);
    if (localCursor != null);
    try
    {
      long l4;
      if (localCursor.getCount() > 0)
      {
        localCursor.moveToNext();
        l4 = updateSportDetail(paramSQLiteDatabase, new SportDetail(l1, paramSportPart.getSteps() + localCursor.getInt(localCursor.getColumnIndex(Database.SportDetailEnum.steps.name())), paramSportPart.getCalories() + localCursor.getFloat(localCursor.getColumnIndex(Database.SportDetailEnum.calories.name())), paramSportPart.getDistance() + localCursor.getFloat(localCursor.getColumnIndex(Database.SportDetailEnum.distance.name()))), paramBoolean);
      }
      long l2;
      for (long l3 = l4; ; l3 = l2)
      {
        return l3;
        l2 = insertSportDetail(paramSQLiteDatabase, new SportDetail(l1, paramSportPart.getSteps(), paramSportPart.getCalories(), paramSportPart.getDistance()), paramBoolean);
      }
    }
    finally
    {
      localCursor.close();
    }
  }

  public static long putSportSummaryWithSummation(SQLiteDatabase paramSQLiteDatabase, SportSummary paramSportSummary)
  {
    if ((paramSQLiteDatabase == null) || (paramSportSummary == null));
    do
    {
      return 0L;
      LogUtil.d("SportDao", mDbName + " putSportSummary date:" + paramSportSummary.getDate() + ", timestamp:" + paramSportSummary.getTimestampS() + ", steps:" + paramSportSummary.getSteps() + ", calories:" + paramSportSummary.getCalories() + ", distance:" + paramSportSummary.getDistance());
      dealWithTime(paramSportSummary);
    }
    while (paramSportSummary.getTimestampS() < 1000L);
    String str = SQLiteQueryBuilder.buildQueryString(true, "SportSummary", null, Database.SportSummaryEnum.date.name() + "='" + paramSportSummary.getDate() + "'", null, null, Database.SportSummaryEnum.timestamp.name() + " DESC", null);
    LogUtil.d("SportDao", paramSQLiteDatabase + " select sql:" + str);
    Cursor localCursor = paramSQLiteDatabase.rawQuery(str, null);
    if (localCursor != null);
    try
    {
      long l3;
      if (localCursor.getCount() > 0)
      {
        localCursor.moveToNext();
        paramSportSummary.setSteps(paramSportSummary.getSteps() + localCursor.getInt(localCursor.getColumnIndex(Database.SportSummaryEnum.totalSteps.name())));
        paramSportSummary.setCalories(paramSportSummary.getCalories() + localCursor.getFloat(localCursor.getColumnIndex(Database.SportSummaryEnum.totalCalories.name())));
        paramSportSummary.setDistance(paramSportSummary.getDistance() + localCursor.getFloat(localCursor.getColumnIndex(Database.SportSummaryEnum.totalDistance.name())));
        l3 = updateSportSummary(paramSQLiteDatabase, paramSportSummary);
      }
      long l1;
      for (long l2 = l3; ; l2 = l1)
      {
        localCursor.close();
        LogUtil.d("SportDao", mDbName + " putSportSummary date:" + paramSportSummary.getDate() + ", timestamp:" + paramSportSummary.getTimestampS() + ", steps:" + paramSportSummary.getSteps() + ", calories:" + paramSportSummary.getCalories() + ", distance:" + paramSportSummary.getDistance() + ", res:" + l2);
        return l2;
        l1 = insertSportSummary(paramSQLiteDatabase, paramSportSummary);
      }
    }
    finally
    {
      localCursor.close();
    }
  }

  public static long replaceSportDetail(SQLiteDatabase paramSQLiteDatabase, SportDetail paramSportDetail, boolean paramBoolean)
  {
    if ((paramSQLiteDatabase == null) || (paramSportDetail == null));
    while (paramSportDetail.getTimestampS() < 1000L)
      return 0L;
    ContentValues localContentValues = new ContentValues();
    localContentValues.put(Database.SportDetailEnum.timestamp.name(), Long.valueOf(paramSportDetail.getTimestampS()));
    localContentValues.put(Database.SportDetailEnum.steps.name(), Integer.valueOf(paramSportDetail.getSteps()));
    localContentValues.put(Database.SportDetailEnum.calories.name(), Float.valueOf(paramSportDetail.getCalories()));
    localContentValues.put(Database.SportDetailEnum.distance.name(), Float.valueOf(paramSportDetail.getDistance()));
    localContentValues.put(Database.SportDetailEnum.dirty.name(), Boolean.valueOf(paramBoolean));
    long l = paramSQLiteDatabase.replace("SportDetail", null, localContentValues);
    LogUtil.d("SportDao", mDbName + " replaceSportDetail, timestamp:" + paramSportDetail.getTimestampS() + ", steps:" + paramSportDetail.getSteps() + ", calories:" + paramSportDetail.getCalories() + ", distance:" + paramSportDetail.getDistance() + ", dirty:" + paramBoolean + ", res:" + l);
    return l;
  }

  public static long replaceSportSummary(SQLiteDatabase paramSQLiteDatabase, SportSummary paramSportSummary)
  {
    if ((paramSQLiteDatabase == null) || (paramSportSummary == null));
    do
    {
      return 0L;
      dealWithTime(paramSportSummary);
    }
    while (paramSportSummary.getTimestampS() < 1000L);
    ContentValues localContentValues = new ContentValues();
    localContentValues.put(Database.SportSummaryEnum.timestamp.name(), Long.valueOf(paramSportSummary.getTimestampS()));
    localContentValues.put(Database.SportSummaryEnum.date.name(), paramSportSummary.getDate());
    localContentValues.put(Database.SportSummaryEnum.totalSteps.name(), Integer.valueOf(paramSportSummary.getSteps()));
    localContentValues.put(Database.SportSummaryEnum.totalCalories.name(), Float.valueOf(paramSportSummary.getCalories()));
    localContentValues.put(Database.SportSummaryEnum.totalDistance.name(), Float.valueOf(paramSportSummary.getDistance()));
    long l1 = -1L;
    try
    {
      long l2 = paramSQLiteDatabase.replace("SportSummary", null, localContentValues);
      l1 = l2;
      LogUtil.d("SportDao", mDbName + " replaceSportSummary, timeStamp:" + paramSportSummary.getTimestampS() + ", date:" + paramSportSummary.getDate() + ", steps:" + paramSportSummary.getSteps() + ", calories:" + paramSportSummary.getCalories() + ", distance:" + paramSportSummary.getDistance() + ", res:" + l1);
      return l1;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  public static List<SportDetail> selectDirtySportDetail(SQLiteDatabase paramSQLiteDatabase)
  {
    LogUtil.d("SportDao", mDbName + " selectDirtySportDetail");
    String str1 = "(" + Database.SportDetailEnum.dirty.name() + "=? AND " + Database.SleepDetailEnum.timestamp.name() + ">1000)";
    String[] arrayOfString = new String[1];
    arrayOfString[0] = String.valueOf(1);
    String str2 = Database.SleepDetailEnum.timestamp.name() + " ASC";
    ArrayList localArrayList = new ArrayList();
    Cursor localCursor = paramSQLiteDatabase.query("SportDetail", null, str1, arrayOfString, null, null, str2);
    try
    {
      LogUtil.d("SportDao", mDbName + " selectDirtySportDetail cursor count:" + localCursor.getCount());
      while (true)
      {
        boolean bool = localCursor.moveToNext();
        if (!bool)
          return localArrayList;
        long l = localCursor.getLong(localCursor.getColumnIndex(Database.SportDetailEnum.timestamp.name()));
        int i = localCursor.getInt(localCursor.getColumnIndex(Database.SportDetailEnum.steps.name()));
        float f1 = localCursor.getFloat(localCursor.getColumnIndex(Database.SportDetailEnum.calories.name()));
        float f2 = localCursor.getFloat(localCursor.getColumnIndex(Database.SportDetailEnum.distance.name()));
        localArrayList.add(new SportDetail(l, i, f1, f2));
        LogUtil.d("SportDao", mDbName + " selectSportDetail timestamp:" + l + ", steps:" + i + ", calories:" + f1 + ", distances:" + f2);
      }
    }
    finally
    {
      localCursor.close();
    }
  }

  public static List<SportDetail> selectDirtySportDetail(SQLiteDatabase paramSQLiteDatabase, int paramInt)
  {
    LogUtil.d("SportDao", mDbName + " selectDirtySportDetail limit:" + paramInt);
    String str1 = "(" + Database.SportDetailEnum.dirty.name() + "=?1 AND " + Database.SportDetailEnum.timestamp.name() + ">1000)";
    String[] arrayOfString = new String[1];
    arrayOfString[0] = String.valueOf(1);
    String str2 = Database.SportDetailEnum.timestamp.name() + " ASC";
    ArrayList localArrayList = new ArrayList();
    Cursor localCursor = paramSQLiteDatabase.query("SportDetail", null, str1, arrayOfString, null, null, str2, String.valueOf(paramInt));
    try
    {
      LogUtil.d("SportDao", mDbName + " selectDirtySportDetail with limit cursor count:" + localCursor.getCount());
      while (true)
      {
        boolean bool = localCursor.moveToNext();
        if (!bool)
          return localArrayList;
        long l = localCursor.getLong(localCursor.getColumnIndex(Database.SportDetailEnum.timestamp.name()));
        int i = localCursor.getInt(localCursor.getColumnIndex(Database.SportDetailEnum.steps.name()));
        float f1 = localCursor.getFloat(localCursor.getColumnIndex(Database.SportDetailEnum.calories.name()));
        float f2 = localCursor.getFloat(localCursor.getColumnIndex(Database.SportDetailEnum.distance.name()));
        localArrayList.add(new SportDetail(l, i, f1, f2));
        LogUtil.d("SportDao", mDbName + " selectSportDetail timestamp:" + l + ", steps:" + i + ", calories:" + f1 + ", distances:" + f2);
      }
    }
    finally
    {
      localCursor.close();
    }
  }

  public static List<SportDetail> selectSportDetail(SQLiteDatabase paramSQLiteDatabase, long paramLong1, long paramLong2)
  {
    LogUtil.d("SportDao", mDbName + " selectSportDetail startTime:" + paramLong1 + ", endTime:" + paramLong2);
    String str1 = "(" + Database.SportDetailEnum.timestamp.name() + ">=?1 AND " + Database.SportDetailEnum.timestamp.name() + "<?2)";
    String[] arrayOfString = new String[2];
    arrayOfString[0] = String.valueOf(paramLong1);
    arrayOfString[1] = String.valueOf(paramLong2);
    String str2 = Database.SportDetailEnum.timestamp.name() + " DESC";
    ArrayList localArrayList = new ArrayList();
    Cursor localCursor = paramSQLiteDatabase.query("SportDetail", null, str1, arrayOfString, null, null, str2);
    try
    {
      while (true)
      {
        boolean bool = localCursor.moveToNext();
        if (!bool)
          return localArrayList;
        long l = localCursor.getLong(localCursor.getColumnIndex(Database.SportDetailEnum.timestamp.name()));
        int i = localCursor.getInt(localCursor.getColumnIndex(Database.SportDetailEnum.steps.name()));
        float f1 = localCursor.getFloat(localCursor.getColumnIndex(Database.SportDetailEnum.calories.name()));
        float f2 = localCursor.getFloat(localCursor.getColumnIndex(Database.SportDetailEnum.distance.name()));
        localArrayList.add(new SportDetail(l, i, f1, f2));
        LogUtil.d("SportDao", mDbName + " selectSportDetail timestamp:" + l + ", steps:" + i + ", calories:" + f1 + ", distances:" + f2);
      }
    }
    finally
    {
      localCursor.close();
    }
  }

  public static List<SportSummary> selectSportSummary(SQLiteDatabase paramSQLiteDatabase, long paramLong)
  {
    String str1 = SQLiteQueryBuilder.buildQueryString(true, "SportSummary", null, Database.SportSummaryEnum.timestamp.name() + ">=" + paramLong, null, null, Database.SportSummaryEnum.timestamp.name() + " DESC", null);
    LogUtil.d("SportDao", mDbName + " selectSportSummary sql:" + str1);
    Cursor localCursor = paramSQLiteDatabase.rawQuery(str1, null);
    ArrayList localArrayList = new ArrayList();
    try
    {
      while (true)
      {
        boolean bool = localCursor.moveToNext();
        if (!bool)
          return localArrayList;
        long l = localCursor.getLong(localCursor.getColumnIndex(Database.SportSummaryEnum.timestamp.name()));
        String str2 = localCursor.getString(localCursor.getColumnIndex(Database.SportSummaryEnum.date.name()));
        int i = localCursor.getInt(localCursor.getColumnIndex(Database.SportSummaryEnum.totalSteps.name()));
        float f1 = localCursor.getFloat(localCursor.getColumnIndex(Database.SportSummaryEnum.totalCalories.name()));
        float f2 = localCursor.getFloat(localCursor.getColumnIndex(Database.SportSummaryEnum.totalDistance.name()));
        localArrayList.add(new SportSummary(l, str2, i, f1, f2));
        LogUtil.d("SportDao", mDbName + " selectSportSummary timestamp:" + l + ", date:" + str2 + ", totalSteps:" + i + ", totalCalories:" + f1 + ", totalDistances:" + f2);
      }
    }
    finally
    {
      localCursor.close();
    }
  }

  public static long updateSportDetail(SQLiteDatabase paramSQLiteDatabase, SportDetail paramSportDetail, boolean paramBoolean)
  {
    if ((paramSQLiteDatabase == null) || (paramSportDetail == null))
      return 0L;
    ContentValues localContentValues = new ContentValues();
    localContentValues.put(Database.SportDetailEnum.steps.name(), Integer.valueOf(paramSportDetail.getSteps()));
    localContentValues.put(Database.SportDetailEnum.calories.name(), Float.valueOf(paramSportDetail.getCalories()));
    localContentValues.put(Database.SportDetailEnum.distance.name(), Float.valueOf(paramSportDetail.getDistance()));
    localContentValues.put(Database.SportDetailEnum.dirty.name(), Boolean.valueOf(paramBoolean));
    String[] arrayOfString = new String[1];
    arrayOfString[0] = String.valueOf(paramSportDetail.getTimestampS());
    long l = paramSQLiteDatabase.update("SportDetail", localContentValues, Database.SportSummaryEnum.timestamp.name() + "=?", arrayOfString);
    LogUtil.d("SportDao", mDbName + " update sport detail, timestamp:" + paramSportDetail.getTimestampS() + ", steps:" + paramSportDetail.getSteps() + ", calories:" + paramSportDetail.getCalories() + ", distance:" + paramSportDetail.getDistance() + ", dirty:" + paramBoolean + ", res:" + l);
    return l;
  }

  public static long updateSportDetailToNotDirty(SQLiteDatabase paramSQLiteDatabase, long paramLong)
  {
    if ((paramSQLiteDatabase == null) || (paramLong < 1000L))
      return 0L;
    ContentValues localContentValues = new ContentValues();
    localContentValues.put(Database.SportDetailEnum.dirty.name(), Boolean.valueOf(false));
    String[] arrayOfString = new String[1];
    arrayOfString[0] = String.valueOf(paramLong);
    long l = paramSQLiteDatabase.update("SportDetail", localContentValues, Database.SportDetailEnum.timestamp.name() + "=?", arrayOfString);
    LogUtil.d("SportDao", mDbName + " updateSportDetailToNotDirty, timestamp:" + paramLong + ", res:" + l);
    return l;
  }

  public static long updateSportSummary(SQLiteDatabase paramSQLiteDatabase, SportSummary paramSportSummary)
  {
    if ((paramSQLiteDatabase == null) || (paramSportSummary == null))
      return 0L;
    ContentValues localContentValues = new ContentValues();
    localContentValues.put(Database.SportSummaryEnum.totalSteps.name(), Integer.valueOf(paramSportSummary.getSteps()));
    localContentValues.put(Database.SportSummaryEnum.totalCalories.name(), Float.valueOf(paramSportSummary.getCalories()));
    localContentValues.put(Database.SportSummaryEnum.totalDistance.name(), Float.valueOf(paramSportSummary.getDistance()));
    String[] arrayOfString = new String[1];
    arrayOfString[0] = paramSportSummary.getDate();
    long l = -1L;
    try
    {
      int i = paramSQLiteDatabase.update("SportSummary", localContentValues, Database.SportSummaryEnum.date.name() + "=?", arrayOfString);
      l = i;
      LogUtil.d("SportDao", mDbName + " updateSportSummary, date:" + paramSportSummary.getDate() + ", timestamp:" + paramSportSummary.getTimestampS() + ", steps:" + paramSportSummary.getSteps() + ", calories:" + paramSportSummary.getCalories() + ", distance:" + paramSportSummary.getDistance() + ", res:" + l);
      return l;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.database.SportDao
 * JD-Core Version:    0.6.2
 */