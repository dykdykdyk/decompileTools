package com.baidu.wearable.receiver;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.app.DownloadManager.Query;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import com.baidu.wearable.ble.util.LogUtil;
import java.io.File;

public class DownloadReceiver extends BroadcastReceiver
{
  private static final String TAG = DownloadReceiver.class.getSimpleName();

  @SuppressLint({"NewApi"})
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str1 = paramIntent.getAction();
    LogUtil.d(TAG, "onReceive " + str1);
    long l;
    if ("android.intent.action.DOWNLOAD_COMPLETE".equals(str1))
    {
      l = paramIntent.getLongExtra("extra_download_id", -1L);
      if (l != -1L)
        break label57;
    }
    label57: Cursor localCursor;
    String str2;
    do
    {
      do
      {
        return;
        DownloadManager localDownloadManager = (DownloadManager)paramContext.getSystemService("download");
        DownloadManager.Query localQuery = new DownloadManager.Query();
        localQuery.setFilterById(new long[] { l });
        localCursor = localDownloadManager.query(localQuery);
      }
      while (localCursor == null);
      if (!localCursor.moveToFirst())
        break;
      int i = localCursor.getColumnIndex("local_filename");
      int j = localCursor.getColumnIndex("local_uri");
      str2 = localCursor.getString(i);
      String str3 = localCursor.getString(j);
      LogUtil.d(TAG, str2 + " : " + str3);
    }
    while ((str2 == null) || (!str2.endsWith(".apk")));
    Uri localUri = Uri.fromFile(new File(str2));
    Intent localIntent = new Intent("android.intent.action.VIEW");
    localIntent.addFlags(268435456);
    localIntent.setDataAndType(localUri, "application/vnd.android.package-archive");
    paramContext.startActivity(localIntent);
    localCursor.close();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.receiver.DownloadReceiver
 * JD-Core Version:    0.6.2
 */