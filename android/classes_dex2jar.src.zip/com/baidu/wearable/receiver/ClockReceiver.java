package com.baidu.wearable.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.baidu.wearable.alarm.clock.ClockStorage;
import com.baidu.wearable.alarm.clock.ClockStorage.UpdateClockListener;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;

public class ClockReceiver extends BroadcastReceiver
{
  private static String TAG = "ServiceStartReceiver";

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    LogUtil.d(TAG, "receive action:" + paramIntent.getAction());
    if (paramIntent.getAction().equals("com.baidu.wearable.ACTION_CLOCK_CLOSE"))
    {
      LogUtil.d(TAG, "receive ACTION_CLOCK_CLOSE_INTENT");
      int i = paramIntent.getIntExtra("alarm_id", -1);
      ClockStorage.updateClockToClose(Database.getDb(paramContext), i, new ClockStorage.UpdateClockListener()
      {
        public void onFailure()
        {
        }

        public void onSuccess(long paramAnonymousLong)
        {
        }
      });
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.receiver.ClockReceiver
 * JD-Core Version:    0.6.2
 */