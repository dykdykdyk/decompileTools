package com.baidu.wearable.receiver;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import com.baidu.wearable.AppManager;
import com.baidu.wearable.alarm.NotificationUtil;
import com.baidu.wearable.alarm.completion.CompletionRate;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.preference.AlarmPreference;

public class CompletionReceiver extends BroadcastReceiver
{
  private static String TAG = "CompletionReceiver";

  private void showFinishRateWarnDialog(final Context paramContext)
  {
    View localView = LayoutInflater.from(paramContext).inflate(2130903082, null);
    ((TextView)localView.findViewById(2131231053)).setText(CompletionRate.getFinishRateWarnPercent(paramContext) + "%");
    ((CheckBox)localView.findViewById(2131231055)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
    {
      public void onCheckedChanged(CompoundButton paramAnonymousCompoundButton, boolean paramAnonymousBoolean)
      {
        AlarmPreference localAlarmPreference = AlarmPreference.getInstance(paramContext);
        if (paramAnonymousBoolean);
        for (boolean bool = false; ; bool = true)
        {
          localAlarmPreference.saveCompletionRateSwitch(bool);
          return;
        }
      }
    });
    AlertDialog localAlertDialog = new AlertDialog.Builder(paramContext).setTitle(paramContext.getString(2131296539)).setView(localView).setOnDismissListener(new DialogInterface.OnDismissListener()
    {
      public void onDismiss(DialogInterface paramAnonymousDialogInterface)
      {
        LogUtil.d(CompletionReceiver.TAG, "finishRateWarnDialog setDismissButton");
        LocalBroadcastManager.getInstance(paramContext).sendBroadcast(new Intent("com.baidu.wearable.ACTION_UPDATE_WARN_ACTIVITY"));
      }
    }).setNegativeButton(paramContext.getString(2131296545), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        LogUtil.d(CompletionReceiver.TAG, "finishRateWarnDialog setNegativeButton");
      }
    }).create();
    localAlertDialog.getWindow().setType(2003);
    localAlertDialog.setCanceledOnTouchOutside(false);
    localAlertDialog.show();
  }

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    LogUtil.d(TAG, "receive action:" + paramIntent.getAction());
    if (paramIntent.getAction().equals("com.baidu.wearable.ACTION_COMPLETION_RECEIVE"))
    {
      LogUtil.d(TAG, "receive ACTION_COMPLETION_RECEIVE_INTENT");
      if ((CompletionRate.isOn(paramContext)) && (CompletionRate.getFinishRateWarnPercent(paramContext) < 100))
      {
        boolean bool = AppManager.getAppManager().isRunningForeground(paramContext);
        LogUtil.d(TAG, "isRunning:" + bool);
        if (!bool)
          break label101;
        showFinishRateWarnDialog(paramContext);
      }
    }
    return;
    label101: NotificationUtil.showCompletionRateNotification(paramContext);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.receiver.CompletionReceiver
 * JD-Core Version:    0.6.2
 */