package com.baidu.wearable.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.sapi2.activity.LoginActivity;
import com.baidu.wearable.AppManager;
import com.baidu.wearable.Destroy;
import com.baidu.wearable.Init;
import com.baidu.wearable.ble.connectmanager.BluetoothState;
import com.baidu.wearable.ble.stack.BlueTooth;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothCommonListener;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.net.TrackerTransport;
import com.baidu.wearable.net.Transport.CommonListener;
import com.baidu.wearable.preference.AgentPreference;
import com.baidu.wearable.sync.NetDataSyncManager;
import com.baidu.wearable.sync.NetSync;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.util.ErrorUtil;
import java.util.List;

public class ServiceStartReceiver extends BroadcastReceiver
{
  private static String TAG = "ServiceStartReceiver";

  private void sendDataToNet(final Context paramContext)
  {
    final TrackerHelper localTrackerHelper;
    if (BDAccountManager.getInstance().isLogin())
    {
      localTrackerHelper = TrackerHelper.getInstance(paramContext);
      if (!localTrackerHelper.isHandringMode())
        break label45;
    }
    label45: for (List localList = localTrackerHelper.getHandringTrackerList(); ; localList = localTrackerHelper.getPhoneTrackerList())
    {
      TrackerTransport.getInstance(paramContext).registerTracker(new Transport.CommonListener()
      {
        public void onFailure(int paramAnonymousInt, String paramAnonymousString)
        {
          localTrackerHelper.setRegisterState(false);
          LogUtil.e(ServiceStartReceiver.TAG, "registHandringInfo onFailure, errCode is " + paramAnonymousInt + ",errMsg:" + paramAnonymousString);
        }

        public void onSuccess()
        {
          LogUtil.d(ServiceStartReceiver.TAG, "---registerTracker----onSuccess---");
          localTrackerHelper.setRegisterState(true);
          NetSync.sendDirtyDataToNet(paramContext, Database.getDb(paramContext), localTrackerHelper.getTrackerID(), true, null);
        }
      }
      , localList);
      return;
    }
  }

  public void onReceive(final Context paramContext, Intent paramIntent)
  {
    LogUtil.d(TAG, "receive action:" + paramIntent.getAction());
    String str = paramIntent.getAction();
    if (str.equals("android.intent.action.BOOT_COMPLETED"))
    {
      LogUtil.d(TAG, "ACTION_BOOT_COMPLETED start sensor service");
      if (BDAccountManager.getInstance().isLogin())
        Init.execute(paramContext);
    }
    do
    {
      do
      {
        return;
        if (str.equals("action.wearable.start.net.command"))
        {
          LogUtil.d(TAG, "ACTION_START_NET_COMMAND send data to net");
          sendDataToNet(paramContext);
          return;
        }
        if (str.equals("action.wearable.bduss.expire"))
        {
          LogUtil.d(TAG, "ACTION_BDUSS_EXPIRE");
          NetDataSyncManager.getInstance(paramContext).logout(false, null);
          Destroy.executor(paramContext);
          if (AppManager.getAppManager().isRunningForeground(paramContext))
          {
            LogUtil.d(TAG, "application is running foreground.");
            Intent localIntent2 = new Intent(paramContext, LoginActivity.class);
            localIntent2.setFlags(268435456);
            paramContext.startActivity(localIntent2);
            ErrorUtil.resolveErrorResponse(paramContext, paramIntent.getIntExtra("error_code", -1));
            return;
          }
          LogUtil.d(TAG, "application not is running foreground.");
          return;
        }
        if (str.equals("action.wearable.agent.expire"))
        {
          LogUtil.d(TAG, "ACTION_AGENT_EXPIRE");
          NetDataSyncManager.getInstance(paramContext).logout(false, null);
          Destroy.executor(paramContext);
          if (AppManager.getAppManager().isRunningForeground(paramContext))
          {
            LogUtil.d(TAG, "application is running foreground.");
            paramIntent.getIntExtra("error_code", -1);
            AgentPreference.saveAgentStatus(paramContext, false, paramIntent.getLongExtra("ext_data", -1L));
            Intent localIntent1 = new Intent(paramContext, LoginActivity.class);
            localIntent1.setFlags(268435456);
            paramContext.startActivity(localIntent1);
            return;
          }
          LogUtil.d(TAG, "application not is running foreground.");
          return;
        }
      }
      while (!"android.intent.action.TIME_SET".equals(str));
      LogUtil.d(TAG, "ACTION_TIME_CHANGED");
    }
    while (BluetoothState.getInstance().getBleState() != 5);
    BlueTooth.getInstance().setTime(new BlueTooth.BlueToothCommonListener()
    {
      public void onFailure()
      {
        LogUtil.d(ServiceStartReceiver.TAG, "ACTION_TIME_CHANGED set time to wrist fail");
      }

      public void onSuccess()
      {
        LogUtil.d(ServiceStartReceiver.TAG, "ACTION_TIME_CHANGED set time to wrist success");
        LocalBroadcastManager.getInstance(paramContext).sendBroadcast(new Intent("com.baidu.wearable.ACTION_SYNC_DATA"));
      }
    });
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.receiver.ServiceStartReceiver
 * JD-Core Version:    0.6.2
 */