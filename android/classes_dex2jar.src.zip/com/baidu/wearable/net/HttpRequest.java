package com.baidu.wearable.net;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.params.HttpClientParams;

public class HttpRequest
{
  private static final int Max_Retries = 1;

  public static HttpResponse executeHttpRequest(HttpRequestBase paramHttpRequestBase)
  {
    Object localObject = null;
    HttpClient localHttpClient;
    int i;
    if (paramHttpRequestBase != null)
    {
      localHttpClient = HttpClientFactory.makeHttpClient();
      HttpClientParams.setCookiePolicy(localHttpClient.getParams(), "compatibility");
      i = 0;
    }
    while (true)
    {
      if ((localObject != null) || (i >= 1))
        return localObject;
      try
      {
        HttpResponse localHttpResponse = localHttpClient.execute(paramHttpRequestBase);
        localObject = localHttpResponse;
        if (localObject != null);
      }
      catch (Exception localException)
      {
        try
        {
          Thread.sleep(1000L);
          label56: i++;
          continue;
          localException = localException;
          localException.printStackTrace();
        }
        catch (InterruptedException localInterruptedException)
        {
          break label56;
        }
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.net.HttpRequest
 * JD-Core Version:    0.6.2
 */