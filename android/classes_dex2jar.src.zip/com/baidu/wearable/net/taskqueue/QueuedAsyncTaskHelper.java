package com.baidu.wearable.net.taskqueue;

import android.os.AsyncTask;
import android.os.Handler;
import java.util.ArrayList;

public class QueuedAsyncTaskHelper
{
  private static QueuedAsyncTaskHelper mInstance = null;
  private AsyncTaskExecutor mExecutor = null;
  private Handler mHandler = null;
  private ArrayList<QueuedAsyncTask> mTasks = new ArrayList();

  private void checkRunningStatus()
  {
    this.mHandler.post(new Runnable()
    {
      public void run()
      {
        if ((QueuedAsyncTaskHelper.this.mExecutor == null) && (QueuedAsyncTaskHelper.this.mTasks.size() > 0));
        synchronized (QueuedAsyncTaskHelper.this.mTasks)
        {
          QueuedAsyncTask localQueuedAsyncTask = (QueuedAsyncTask)QueuedAsyncTaskHelper.this.mTasks.get(0);
          QueuedAsyncTaskHelper.this.mTasks.remove(0);
          if (localQueuedAsyncTask != null)
            QueuedAsyncTaskHelper.this.mExecutor = new QueuedAsyncTaskHelper.AsyncTaskExecutor(QueuedAsyncTaskHelper.this, localQueuedAsyncTask);
          if (QueuedAsyncTaskHelper.this.mExecutor != null)
            QueuedAsyncTaskHelper.this.mExecutor.execute(new Void[0]);
          return;
        }
      }
    });
  }

  public static QueuedAsyncTaskHelper instance()
  {
    if (mInstance == null)
      mInstance = new QueuedAsyncTaskHelper();
    return mInstance;
  }

  public boolean appendAsyncTask(QueuedAsyncTask paramQueuedAsyncTask)
  {
    boolean bool1 = false;
    int i;
    ArrayList localArrayList;
    if (paramQueuedAsyncTask != null)
    {
      AsyncTaskExecutor localAsyncTaskExecutor = this.mExecutor;
      i = 0;
      if (localAsyncTaskExecutor != null)
      {
        boolean bool2 = this.mExecutor.isSpecificTaskRunning(paramQueuedAsyncTask);
        i = 0;
        if (bool2)
          i = 1;
      }
      localArrayList = this.mTasks;
      if (i != 0);
    }
    for (int j = 0; ; j++)
      try
      {
        if (j >= this.mTasks.size());
        while (true)
        {
          bool1 = false;
          if (i == 0)
          {
            this.mTasks.add(paramQueuedAsyncTask);
            bool1 = true;
          }
          checkRunningStatus();
          return bool1;
          QueuedAsyncTask localQueuedAsyncTask = (QueuedAsyncTask)this.mTasks.get(j);
          if ((localQueuedAsyncTask == null) || (!localQueuedAsyncTask.equals(paramQueuedAsyncTask)))
            break;
          i = 1;
        }
      }
      finally
      {
      }
  }

  public void executeOnOriginalThread(Runnable paramRunnable)
  {
    this.mHandler.post(paramRunnable);
  }

  public void removeAsyncTask(QueuedAsyncTask paramQueuedAsyncTask)
  {
    if (paramQueuedAsyncTask != null)
    {
      AsyncTaskExecutor localAsyncTaskExecutor = this.mExecutor;
      int i = 0;
      if (localAsyncTaskExecutor != null)
      {
        boolean bool = this.mExecutor.isSpecificTaskRunning(paramQueuedAsyncTask);
        i = 0;
        if (bool)
        {
          this.mExecutor.stopRunning();
          i = 1;
        }
      }
      if (i == 0)
      {
        ArrayList localArrayList = this.mTasks;
        for (int j = 0; ; j++)
          try
          {
            if (j >= this.mTasks.size());
            while (true)
            {
              return;
              if (!paramQueuedAsyncTask.equals(this.mTasks.get(j)))
                break;
              this.mTasks.remove(j);
            }
          }
          finally
          {
          }
      }
    }
  }

  private class AsyncTaskExecutor extends AsyncTask<Void, Void, Void>
  {
    private QueuedAsyncTask mTask = null;

    AsyncTaskExecutor(QueuedAsyncTask arg2)
    {
      Object localObject;
      this.mTask = localObject;
    }

    protected Void doInBackground(Void[] paramArrayOfVoid)
    {
      if (this.mTask != null)
        this.mTask.run();
      return null;
    }

    boolean isSpecificTaskRunning(QueuedAsyncTask paramQueuedAsyncTask)
    {
      boolean bool = false;
      if (paramQueuedAsyncTask != null)
        bool = paramQueuedAsyncTask.equals(this.mTask);
      return bool;
    }

    protected void onPostExecute(Void paramVoid)
    {
      QueuedAsyncTaskHelper.this.mExecutor = null;
      QueuedAsyncTaskHelper.this.checkRunningStatus();
    }

    void stopRunning()
    {
      if (this.mTask != null)
        this.mTask.stop();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.net.taskqueue.QueuedAsyncTaskHelper
 * JD-Core Version:    0.6.2
 */