package com.baidu.wearable.net.taskqueue;

public abstract interface QueuedAsyncTask extends Runnable
{
  public abstract void stop();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.net.taskqueue.QueuedAsyncTask
 * JD-Core Version:    0.6.2
 */