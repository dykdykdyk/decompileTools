package com.baidu.wearable.net;

import android.net.Proxy;
import com.baidu.wearable.ble.util.LogUtil;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import org.apache.http.HttpHost;
import org.apache.http.HttpVersion;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ClientConnectionRequest;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.params.ConnPerRoute;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;

class HttpClientFactory
{
  private static final int DEFAULT_TIMEOUT_MILLIS = 30000;
  private static final String HTTP_USER_AGENT = "PCS_3rdApp";
  private static final int KEEP_ALIVE_DURATION_SECS = 25;
  private static final int KEEP_ALIVE_INTERVAL_SECS = 30;

  public static HttpClient makeHttpClient()
  {
    BasicHttpParams localBasicHttpParams1 = new BasicHttpParams();
    ConnManagerParams.setMaxConnectionsPerRoute(localBasicHttpParams1, new ConnPerRoute()
    {
      public int getMaxForRoute(HttpRoute paramAnonymousHttpRoute)
      {
        return 6;
      }
    });
    ConnManagerParams.setMaxTotalConnections(localBasicHttpParams1, 20);
    try
    {
      KeyStore localKeyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      localKeyStore.load(null, null);
      MySSLSocketFactory localMySSLSocketFactory = new MySSLSocketFactory(localKeyStore);
      localMySSLSocketFactory.setHostnameVerifier(org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
      SchemeRegistry localSchemeRegistry = new SchemeRegistry();
      localSchemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
      localSchemeRegistry.register(new Scheme("https", localMySSLSocketFactory, 443));
      ClientConnectionManager localClientConnectionManager = new ClientConnectionManager(localBasicHttpParams1, localSchemeRegistry);
      BasicHttpParams localBasicHttpParams2 = new BasicHttpParams();
      String str = Proxy.getDefaultHost();
      int i = Proxy.getDefaultPort();
      if ((str != null) && (i != -1))
      {
        LogUtil.i("hybrid", "host: " + str + "," + "port: " + i);
        localBasicHttpParams2.setParameter("http.route.default-proxy", new HttpHost(str, i));
      }
      HttpConnectionParams.setConnectionTimeout(localBasicHttpParams2, 30000);
      HttpConnectionParams.setSoTimeout(localBasicHttpParams2, 30000);
      HttpProtocolParams.setVersion(localBasicHttpParams2, HttpVersion.HTTP_1_1);
      HttpProtocolParams.setContentCharset(localBasicHttpParams2, "UTF-8");
      HttpProtocolParams.setUserAgent(localBasicHttpParams2, "PCS_3rdApp");
      DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient(localClientConnectionManager, localBasicHttpParams2);
      return localDefaultHttpClient;
    }
    catch (KeyStoreException localKeyStoreException)
    {
      localKeyStoreException.printStackTrace();
      return null;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      localNoSuchAlgorithmException.printStackTrace();
      return null;
    }
    catch (CertificateException localCertificateException)
    {
      localCertificateException.printStackTrace();
      return null;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
      return null;
    }
    catch (KeyManagementException localKeyManagementException)
    {
      localKeyManagementException.printStackTrace();
      return null;
    }
    catch (UnrecoverableKeyException localUnrecoverableKeyException)
    {
      localUnrecoverableKeyException.printStackTrace();
    }
    return null;
  }

  private static class ClientConnectionManager extends ThreadSafeClientConnManager
  {
    public ClientConnectionManager(HttpParams paramHttpParams, SchemeRegistry paramSchemeRegistry)
    {
      super(paramSchemeRegistry);
    }

    public ClientConnectionRequest requestConnection(HttpRoute paramHttpRoute, Object paramObject)
    {
      HttpClientFactory.IdleConnectionMonitorThread.ensureRunning(this, 25, 30);
      return super.requestConnection(paramHttpRoute, paramObject);
    }
  }

  private static class IdleConnectionMonitorThread extends Thread
  {
    private static IdleConnectionMonitorThread thread = null;
    private final int checkIntervalSeconds;
    private final int idleTimeoutSeconds;
    private final HttpClientFactory.ClientConnectionManager manager;

    public IdleConnectionMonitorThread(HttpClientFactory.ClientConnectionManager paramClientConnectionManager, int paramInt1, int paramInt2)
    {
      this.manager = paramClientConnectionManager;
      this.idleTimeoutSeconds = paramInt1;
      this.checkIntervalSeconds = paramInt2;
    }

    public static void ensureRunning(HttpClientFactory.ClientConnectionManager paramClientConnectionManager, int paramInt1, int paramInt2)
    {
      try
      {
        if (thread == null)
        {
          thread = new IdleConnectionMonitorThread(paramClientConnectionManager, paramInt1, paramInt2);
          thread.start();
        }
        return;
      }
      finally
      {
        localObject = finally;
        throw localObject;
      }
    }

    // ERROR //
    public void run()
    {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: sipush 1000
      //   6: aload_0
      //   7: getfield 25	com/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread:checkIntervalSeconds	I
      //   10: imul
      //   11: i2l
      //   12: invokevirtual 40	java/lang/Object:wait	(J)V
      //   15: aload_0
      //   16: monitorexit
      //   17: aload_0
      //   18: getfield 21	com/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread:manager	Lcom/baidu/wearable/net/HttpClientFactory$ClientConnectionManager;
      //   21: invokevirtual 45	com/baidu/wearable/net/HttpClientFactory$ClientConnectionManager:closeExpiredConnections	()V
      //   24: aload_0
      //   25: getfield 21	com/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread:manager	Lcom/baidu/wearable/net/HttpClientFactory$ClientConnectionManager;
      //   28: aload_0
      //   29: getfield 23	com/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread:idleTimeoutSeconds	I
      //   32: i2l
      //   33: getstatic 51	java/util/concurrent/TimeUnit:SECONDS	Ljava/util/concurrent/TimeUnit;
      //   36: invokevirtual 55	com/baidu/wearable/net/HttpClientFactory$ClientConnectionManager:closeIdleConnections	(JLjava/util/concurrent/TimeUnit;)V
      //   39: ldc 2
      //   41: monitorenter
      //   42: aload_0
      //   43: getfield 21	com/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread:manager	Lcom/baidu/wearable/net/HttpClientFactory$ClientConnectionManager;
      //   46: invokevirtual 59	com/baidu/wearable/net/HttpClientFactory$ClientConnectionManager:getConnectionsInPool	()I
      //   49: ifne +22 -> 71
      //   52: aconst_null
      //   53: putstatic 15	com/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread:thread	Lcom/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread;
      //   56: ldc 2
      //   58: monitorexit
      //   59: return
      //   60: astore_2
      //   61: aload_0
      //   62: monitorexit
      //   63: aload_2
      //   64: athrow
      //   65: astore_1
      //   66: aconst_null
      //   67: putstatic 15	com/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread:thread	Lcom/baidu/wearable/net/HttpClientFactory$IdleConnectionMonitorThread;
      //   70: return
      //   71: ldc 2
      //   73: monitorexit
      //   74: goto -74 -> 0
      //   77: astore_3
      //   78: ldc 2
      //   80: monitorexit
      //   81: aload_3
      //   82: athrow
      //
      // Exception table:
      //   from	to	target	type
      //   2	17	60	finally
      //   61	63	60	finally
      //   0	2	65	java/lang/InterruptedException
      //   17	42	65	java/lang/InterruptedException
      //   63	65	65	java/lang/InterruptedException
      //   81	83	65	java/lang/InterruptedException
      //   42	59	77	finally
      //   71	74	77	finally
      //   78	81	77	finally
    }
  }

  private static class MySSLSocketFactory extends org.apache.http.conn.ssl.SSLSocketFactory
  {
    SSLContext sslContext = SSLContext.getInstance("TLS");

    public MySSLSocketFactory(KeyStore paramKeyStore)
      throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException, UnrecoverableKeyException
    {
      super();
      X509TrustManager local1 = new X509TrustManager()
      {
        public void checkClientTrusted(X509Certificate[] paramAnonymousArrayOfX509Certificate, String paramAnonymousString)
          throws CertificateException
        {
        }

        public void checkServerTrusted(X509Certificate[] paramAnonymousArrayOfX509Certificate, String paramAnonymousString)
          throws CertificateException
        {
        }

        public X509Certificate[] getAcceptedIssuers()
        {
          return null;
        }
      };
      this.sslContext.init(null, new TrustManager[] { local1 }, null);
    }

    public Socket createSocket()
      throws IOException
    {
      return this.sslContext.getSocketFactory().createSocket();
    }

    public Socket createSocket(Socket paramSocket, String paramString, int paramInt, boolean paramBoolean)
      throws IOException, UnknownHostException
    {
      return this.sslContext.getSocketFactory().createSocket(paramSocket, paramString, paramInt, paramBoolean);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.net.HttpClientFactory
 * JD-Core Version:    0.6.2
 */