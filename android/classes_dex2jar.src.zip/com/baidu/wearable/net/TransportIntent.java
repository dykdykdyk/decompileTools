package com.baidu.wearable.net;

public class TransportIntent
{
  public static final String ACTION_AGENT_EXPIRE = "action.wearable.agent.expire";
  public static final String ACTION_BDUSS_EXPIRE = "action.wearable.bduss.expire";
  public static final String ACTION_START_NET_COMMAND = "action.wearable.start.net.command";
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.net.TransportIntent
 * JD-Core Version:    0.6.2
 */