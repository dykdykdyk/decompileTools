package com.baidu.wearable.net;

import android.content.Context;
import android.content.Intent;
import com.baidu.wearable.Config;
import com.baidu.wearable.ble.util.LogUtil;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

public class Transport
{
  protected static final String AGENT_ID = "agent_id";
  protected static final String APP_ID = "app_id";
  protected static final String DAYS_KEY = "days";
  public static final int ERROR_ACCOUNT_SEIZED = 10;
  public static final int ERROR_AGENT_EXPIRE = 38905;
  public static final int ERROR_CONFIGURE_NOT_EXIST_KEY = 38911;
  public static final int ERROR_DEFAULT = -1;
  public static final int ERROR_DUPLICATED_REGISTER = 38910;
  public static final int ERROR_NET_NOT_AVAILABLE = 10000;
  public static final String ERROR_NET_NOT_AVAILABLE_MSG = "net is not available";
  public static final int ERROR_SERVER = 38800;
  public static final int ERROR_SERVER_RESPONSE_NULL = 10001;
  public static final int ERROR_UNREGISTE_NOT_EXIST_AGENT = 38913;
  public static final int ERROR_USER_NOT_EXIST = 38824;
  protected static final String FROM_DATE_KEY = "from_date";
  protected static final String IS_INPUT_LATEST_KEY = "is_input_latest";
  public static final String KEY_ERROR_CODE = "error_code";
  public static final String KEY_ERROR_EXT_DATA = "ext_data";
  public static final String KEY_ERROR_MSG = "error_msg";
  protected static final String METHOD_GET = "get";
  protected static final String METHOD_INSERT = "insert";
  protected static final String METHOD_KEY = "method";
  protected static final String METHOD_LIST = "list";
  protected static final String METHOD_REGISTER = "register";
  protected static final String METHOD_SELECT = "select";
  protected static final String METHOD_SET = "set";
  protected static final String METHOD_SUMMARIZE = "summarize";
  protected static final String METHOD_UNREGISTER = "unregister";
  protected static final String METHOD_UPDATE = "update";
  protected static final String METHOD_UPDATEX = "updatex";
  protected static final String MTIME = "_mtime";
  public static final int PULL_DATA_FROM_NET_DAYS = 32;
  public static final int SUCCESS = 0;
  private static final String TAG = "Transport";
  protected static final String URL_BASE = "https://pcs.baidu.com/rest/2.0/services/fit/";
  protected static String mUserId;

  protected static String constructUrl(String paramString, List<NameValuePair> paramList)
  {
    paramList.add(new BasicNameValuePair("app_id", "1325340"));
    paramList.add(new BasicNameValuePair("agent_id", Config.DEVICE_ID));
    String str1 = URLEncodedUtils.format(paramList, "UTF-8");
    String str2 = paramString + "?" + str1;
    LogUtil.e("Transport", "url:" + str2);
    return str2;
  }

  protected static void dealWithGeneralError(Context paramContext, int paramInt, String paramString, Object paramObject)
  {
    if (paramInt == 38905)
    {
      LogUtil.d("Transport", "send error agent expire broadcast");
      localIntent2 = new Intent("action.wearable.agent.expire");
      localIntent2.putExtra("error_code", paramInt);
      localIntent2.putExtra("error_msg", paramString);
      localIntent2.putExtra("ext_data", ((JSONObject)paramObject).optJSONObject("latest_agent").optLong("_ctime"));
      paramContext.sendBroadcast(localIntent2);
    }
    while (paramInt != 38824)
    {
      Intent localIntent2;
      return;
    }
    LogUtil.d("Transport", "send error bduss expire broadcast");
    Intent localIntent1 = new Intent("action.wearable.bduss.expire");
    localIntent1.putExtra("error_code", paramInt);
    localIntent1.putExtra("error_msg", paramString);
    paramContext.sendBroadcast(localIntent1);
  }

  protected static void dealWithIgnoreError(CommonResult paramCommonResult)
  {
    if (paramCommonResult.errCode == 38913)
      paramCommonResult.errCode = 0;
  }

  protected static CommonResult parseErrorResponse(Context paramContext, JSONObject paramJSONObject)
  {
    CommonResult localCommonResult = new CommonResult();
    if (paramJSONObject == null)
    {
      localCommonResult.errCode = 10001;
      return localCommonResult;
    }
    if (paramJSONObject.has("error_code"))
      try
      {
        localCommonResult.errCode = paramJSONObject.getInt("error_code");
        localCommonResult.errMsg = paramJSONObject.getString("error_msg");
        localCommonResult.extra = paramJSONObject.optJSONObject("ext_data");
        dealWithGeneralError(paramContext, localCommonResult.errCode, localCommonResult.errMsg, localCommonResult.extra);
        dealWithIgnoreError(localCommonResult);
        return localCommonResult;
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
        return localCommonResult;
      }
    localCommonResult.errCode = 0;
    return localCommonResult;
  }

  protected static JSONObject sendGetRequest(String paramString)
    throws IOException, JSONException
  {
    HttpGet localHttpGet = new HttpGet(paramString);
    LogUtil.d("Transport", "get request Cookie: BDUSS=" + Config.BDUSS);
    localHttpGet.setHeader("Cookie", "BDUSS=" + Config.BDUSS);
    HttpResponse localHttpResponse = HttpRequest.executeHttpRequest(localHttpGet);
    LogUtil.d("Transport", "sendGetRequest response:" + localHttpResponse);
    if ((localHttpResponse != null) && (localHttpResponse.getStatusLine() != null))
      LogUtil.d("Transport", "sendGetRequest status code:" + localHttpResponse.getStatusLine().getStatusCode());
    if (localHttpResponse != null)
    {
      String str = EntityUtils.toString(localHttpResponse.getEntity());
      LogUtil.d("Transport", "response body: " + str + ", body length:" + str.length() + ", status code:" + localHttpResponse.getStatusLine().getStatusCode());
      return new JSONObject(str);
    }
    return null;
  }

  protected static JSONObject sendPostRequest(String paramString, JSONObject paramJSONObject)
    throws IOException, JSONException
  {
    if (paramJSONObject != null)
    {
      LogUtil.d("Transport", paramJSONObject.toString());
      HttpPost localHttpPost = new HttpPost(paramString);
      LogUtil.d("Transport", "post request Cookie: BDUSS=" + Config.BDUSS);
      localHttpPost.setHeader("Cookie", "BDUSS=" + Config.BDUSS);
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(new BasicNameValuePair("param", paramJSONObject.toString()));
      localHttpPost.setEntity(new UrlEncodedFormEntity(localArrayList));
      HttpResponse localHttpResponse = HttpRequest.executeHttpRequest(localHttpPost);
      LogUtil.d("Transport", "sendPostRequest response:" + localHttpResponse);
      if ((localHttpResponse != null) && (localHttpResponse.getStatusLine() != null))
        LogUtil.d("Transport", "sendPostRequest status code:" + localHttpResponse.getStatusLine().getStatusCode());
      if (localHttpResponse != null)
      {
        String str = EntityUtils.toString(localHttpResponse.getEntity());
        LogUtil.d("Transport", "response body: " + str + ", body length:" + str.length() + ", status code:" + localHttpResponse.getStatusLine().getStatusCode());
        return new JSONObject(str);
      }
    }
    return null;
  }

  public static abstract interface CommonListener
  {
    public abstract void onFailure(int paramInt, String paramString);

    public abstract void onSuccess();
  }

  public static class CommonResult
  {
    public int errCode = -1;
    public String errMsg = null;
    public Object extra = null;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.net.Transport
 * JD-Core Version:    0.6.2
 */