package com.baidu.wearable.net;

public class ErrCode
{
  public static final int ERROR_CODE_LOGIN_FAILURE = 11;
  public static final int ERROR_CODE_LOGIN_ON_OTHER_PHONE = 9;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.net.ErrCode
 * JD-Core Version:    0.6.2
 */