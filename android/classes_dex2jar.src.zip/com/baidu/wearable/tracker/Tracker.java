package com.baidu.wearable.tracker;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class Tracker
  implements Parcelable
{
  public static final Parcelable.Creator<Tracker> CREATOR = new Parcelable.Creator()
  {
    public Tracker createFromParcel(Parcel paramAnonymousParcel)
    {
      return new Tracker(paramAnonymousParcel);
    }

    public Tracker[] newArray(int paramAnonymousInt)
    {
      return new Tracker[paramAnonymousInt];
    }
  };
  public static final String DISPLAY_NAME = "display_name";
  public static final String FUNCTION = "function";
  public static final String FUNCTION_SLEEP_MONITOR = "SleepMonitor";
  public static final String FUNCTION_STEP_DETECTOR = "StepDetector";
  public static final String ID = "id";
  public static final String MANUFACTURER = "manufacturer";
  public static final String MODEL = "model";
  public static final String MODEL_APP = "App";
  public static final String MODEL_HANDRING = "BoomBand";
  public static final String displayName = "Boom Band";
  public String function;
  public String id;
  public String manufacturer;
  public String model;

  public Tracker()
  {
  }

  public Tracker(Parcel paramParcel)
  {
    this.function = paramParcel.readString();
    this.manufacturer = paramParcel.readString();
    this.model = paramParcel.readString();
    this.id = paramParcel.readString();
  }

  public Tracker(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    this.function = paramString1;
    this.manufacturer = paramString2;
    this.model = paramString3;
    this.id = paramString4;
  }

  public int describeContents()
  {
    return 0;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeString(this.function);
    paramParcel.writeString(this.manufacturer);
    paramParcel.writeString(this.model);
    paramParcel.writeString(this.id);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.tracker.Tracker
 * JD-Core Version:    0.6.2
 */