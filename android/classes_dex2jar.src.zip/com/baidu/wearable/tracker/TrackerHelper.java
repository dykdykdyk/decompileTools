package com.baidu.wearable.tracker;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import com.baidu.sapi2.BDAccountManager;
import java.util.ArrayList;
import java.util.List;

public class TrackerHelper
{
  private static final String TRACKER_DISPLAY_NAME = "tracker_displayname_key";
  private static final String TRACKER_ID_KEY = "tracker_id_key";
  private static final String TRACKER_INFO = "tracker_info";
  private static final String TRACKER_MODEL = "tracker_model_key";
  private static final String TRACKER_REGISTER_STATE = "tracker_register_key";
  private static TrackerHelper mInstance;
  private final String TAG = "trackID";
  private Context mContext;
  private SharedPreferences.Editor mEditor;
  private SharedPreferences mSharedPreferences;

  private TrackerHelper(Context paramContext)
  {
    this.mContext = paramContext;
    String str = BDAccountManager.getInstance().getUserData("uid");
    this.mSharedPreferences = this.mContext.getSharedPreferences(str + "tracker_info", 0);
    this.mEditor = this.mSharedPreferences.edit();
  }

  public static void close()
  {
    if (mInstance != null)
      mInstance = null;
  }

  public static TrackerHelper getInstance(Context paramContext)
  {
    if (mInstance == null);
    try
    {
      if (mInstance == null)
        mInstance = new TrackerHelper(paramContext);
      return mInstance;
    }
    finally
    {
    }
  }

  public String getDisplayName()
  {
    return "Boom Band";
  }

  public List<Tracker> getHandringTrackerList()
  {
    ArrayList localArrayList = new ArrayList(2);
    localArrayList.add(new Tracker("StepDetector", Build.MANUFACTURER, "BoomBand", getTrackerID()));
    localArrayList.add(new Tracker("SleepMonitor", Build.MANUFACTURER, "BoomBand", getTrackerID()));
    return localArrayList;
  }

  public String getPhoneDevicesID()
  {
    String str = ((TelephonyManager)this.mContext.getSystemService("phone")).getDeviceId();
    if (TextUtils.isEmpty(str))
      str = "123";
    return str;
  }

  public List<Tracker> getPhoneTrackerList()
  {
    ArrayList localArrayList = new ArrayList(2);
    localArrayList.add(new Tracker("StepDetector", Build.MANUFACTURER, "App", getPhoneDevicesID()));
    localArrayList.add(new Tracker("SleepMonitor", Build.MANUFACTURER, "App", getPhoneDevicesID()));
    return localArrayList;
  }

  public String getTrackerID()
  {
    return this.mSharedPreferences.getString("tracker_id_key", "");
  }

  public List<Tracker> getTrackerList()
  {
    if (isHandringMode())
      return getHandringTrackerList();
    return getPhoneTrackerList();
  }

  public String getTrackerModel()
  {
    return this.mSharedPreferences.getString("tracker_model_key", "");
  }

  public TrackerType getTrackerType()
  {
    if ("App".equals(getTrackerModel()))
      return TrackerType.Phone;
    return TrackerType.handring;
  }

  public TrackerType getTrackerType(String paramString)
  {
    if ("App".equals(paramString))
      return TrackerType.Phone;
    return TrackerType.handring;
  }

  public boolean isHandringMode()
  {
    return getTrackerType() == TrackerType.handring;
  }

  public boolean isRegisterSuccess()
  {
    return this.mSharedPreferences.getBoolean("tracker_register_key", true);
  }

  public void saveHandringRegisterInfo(String paramString)
  {
    this.mEditor.putString("tracker_model_key", "BoomBand");
    this.mEditor.putString("tracker_id_key", paramString);
    this.mEditor.commit();
  }

  public void savePhoneRegisterInfo()
  {
    this.mEditor.putString("tracker_model_key", "App");
    this.mEditor.putString("tracker_id_key", getPhoneDevicesID());
    this.mEditor.commit();
  }

  public void setDisplayName(String paramString)
  {
    this.mEditor.putString("tracker_displayname_key", paramString).commit();
  }

  public void setRegisterState(boolean paramBoolean)
  {
    this.mEditor.putBoolean("tracker_register_key", paramBoolean);
  }

  public void setTrackerID(String paramString)
  {
    this.mEditor.putString("tracker_id_key", paramString).commit();
  }

  public void setTrackerModel(String paramString)
  {
    this.mEditor.putString("tracker_model_key", paramString).commit();
  }

  public static enum TrackerType
  {
    static
    {
      TrackerType[] arrayOfTrackerType = new TrackerType[2];
      arrayOfTrackerType[0] = Phone;
      arrayOfTrackerType[1] = handring;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.tracker.TrackerHelper
 * JD-Core Version:    0.6.2
 */