package com.baidu.wearable;

import android.content.Context;
import android.content.Intent;
import com.baidu.wearable.alarm.AlarmManagerUtil;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.services.WearableService;

public class Init
{
  private static final String TAG = "Init";

  public static void execute(Context paramContext)
  {
    LogUtil.d("Init", "init execute");
    paramContext.startService(new Intent(paramContext, WearableService.class));
    AlarmManagerUtil.startServiceAlarm(paramContext);
    AlarmManagerUtil.startCompletionRateAlarm(paramContext);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.Init
 * JD-Core Version:    0.6.2
 */