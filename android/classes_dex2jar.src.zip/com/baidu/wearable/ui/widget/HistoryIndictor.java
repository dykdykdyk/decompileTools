package com.baidu.wearable.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.baidu.wearable.ble.util.LogUtil;

public class HistoryIndictor extends LinearLayout
{
  private static final String TAG = "HistoryIndictor";
  private Context mContext;
  private int mCurrentIndex = 0;
  private int mHighlightResourceID;
  private int mIndictorSum;
  private int mNormalResourceID;

  public HistoryIndictor(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
  }

  public int getmCurrentIndex()
  {
    return this.mCurrentIndex;
  }

  public int getmHighlightResourceID()
  {
    return this.mHighlightResourceID;
  }

  public int getmIndictorSum()
  {
    return this.mIndictorSum;
  }

  public int getmNormalResourceID()
  {
    return this.mNormalResourceID;
  }

  public void initView(int paramInt1, int paramInt2, int paramInt3)
  {
    if (getChildCount() != 0)
      removeAllViews();
    this.mIndictorSum = paramInt1;
    this.mHighlightResourceID = paramInt2;
    this.mNormalResourceID = paramInt3;
    this.mCurrentIndex = 0;
    for (int i = 0; ; i++)
    {
      if (i >= this.mIndictorSum)
      {
        if (paramInt1 > 0)
          getChildAt(this.mCurrentIndex).setBackgroundResource(getmHighlightResourceID());
        return;
      }
      ImageView localImageView = new ImageView(this.mContext);
      localImageView.setBackgroundResource(getmNormalResourceID());
      LinearLayout.LayoutParams localLayoutParams = new LinearLayout.LayoutParams(-2, -2);
      localLayoutParams.setMargins(4, 0, 4, 0);
      localImageView.setLayoutParams(localLayoutParams);
      addView(localImageView);
    }
  }

  public void setCurrentIndictorSelected(int paramInt)
  {
    if (paramInt >= this.mIndictorSum)
    {
      LogUtil.e("HistoryIndictor", "瓒呰繃绱㈠紩");
      return;
    }
    for (int i = 0; ; i++)
    {
      if (i >= this.mIndictorSum)
      {
        getChildAt(paramInt).setBackgroundResource(getmHighlightResourceID());
        return;
      }
      getChildAt(i).setBackgroundResource(getmNormalResourceID());
    }
  }

  public void setmCurrentIndex(int paramInt)
  {
    this.mCurrentIndex = paramInt;
  }

  public void setmHighlightResourceID(int paramInt)
  {
    this.mHighlightResourceID = paramInt;
  }

  public void setmIndictorSum(int paramInt)
  {
    this.mIndictorSum = paramInt;
  }

  public void setmNormalResourceID(int paramInt)
  {
    this.mNormalResourceID = paramInt;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.widget.HistoryIndictor
 * JD-Core Version:    0.6.2
 */