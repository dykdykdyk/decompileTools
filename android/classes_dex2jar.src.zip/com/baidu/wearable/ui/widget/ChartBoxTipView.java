package com.baidu.wearable.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ChartBoxTipView extends LinearLayout
{
  private TextView mContentTextView;
  private TextView mDateTextView;

  public ChartBoxTipView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  protected void onFinishInflate()
  {
    super.onFinishInflate();
    this.mDateTextView = ((TextView)findViewById(2131230935));
    this.mContentTextView = ((TextView)findViewById(2131230936));
  }

  public void setContent(String paramString1, String paramString2)
  {
    this.mDateTextView.setText(paramString1);
    this.mContentTextView.setText(paramString2);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.widget.ChartBoxTipView
 * JD-Core Version:    0.6.2
 */