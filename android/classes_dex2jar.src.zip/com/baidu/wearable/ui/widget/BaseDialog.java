package com.baidu.wearable.ui.widget;

import android.app.AlertDialog;
import android.content.Context;

public class BaseDialog extends AlertDialog
{
  protected BaseDialog(Context paramContext)
  {
    super(paramContext);
    setCanceledOnTouchOutside(false);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.widget.BaseDialog
 * JD-Core Version:    0.6.2
 */