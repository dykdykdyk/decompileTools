package com.baidu.wearable.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MyAlertDialog extends RelativeLayout
{
  private Context mContext;
  private View.OnClickListener mOnNegtiveBtnClickListener;
  private View.OnClickListener mOnPositiveBtnClickListener;
  private ViewHolder viewHolder = null;

  public MyAlertDialog(Context paramContext)
  {
    super(paramContext);
    init(paramContext);
  }

  public MyAlertDialog(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    init(paramContext);
  }

  private void dissmiss()
  {
    ((WindowManager)this.mContext.getApplicationContext().getSystemService("window")).removeView(this);
  }

  private void init(Context paramContext)
  {
    this.mContext = paramContext;
    View localView = LayoutInflater.from(paramContext).inflate(2130903075, null);
    addView(localView);
    if (this.viewHolder == null)
      this.viewHolder = new ViewHolder(null);
    this.viewHolder.text_title = ((TextView)localView.findViewById(2131231040));
    this.viewHolder.text_content = ((TextView)localView.findViewById(2131231042));
    this.viewHolder.btn_ok = ((Button)localView.findViewById(2131231043));
    this.viewHolder.btn_ok.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyAlertDialog.this.mOnPositiveBtnClickListener.onClick(paramAnonymousView);
        MyAlertDialog.this.dissmiss();
      }
    });
  }

  public void setContent(String paramString)
  {
    this.viewHolder.text_content.setText(paramString);
  }

  public void setNegtiveButton(String paramString, View.OnClickListener paramOnClickListener)
  {
    this.mOnNegtiveBtnClickListener = paramOnClickListener;
    this.viewHolder.btn_cancel.setText(paramString);
  }

  public void setPositiveButton(String paramString, View.OnClickListener paramOnClickListener)
  {
    this.mOnPositiveBtnClickListener = paramOnClickListener;
    this.viewHolder.btn_ok.setText(paramString);
  }

  public void setTitle(String paramString)
  {
    this.viewHolder.text_title.setText(paramString);
  }

  public void show()
  {
    WindowManager localWindowManager = (WindowManager)this.mContext.getApplicationContext().getSystemService("window");
    WindowManager.LayoutParams localLayoutParams = new WindowManager.LayoutParams();
    localLayoutParams.type = 2002;
    localLayoutParams.flags = 256;
    localLayoutParams.width = -2;
    localLayoutParams.height = -2;
    localLayoutParams.gravity = 17;
    localLayoutParams.format = 1;
    localWindowManager.addView(this, localLayoutParams);
  }

  private static class ViewHolder
  {
    Button btn_cancel = null;
    Button btn_ok = null;
    TextView text_content = null;
    TextView text_title = null;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.widget.MyAlertDialog
 * JD-Core Version:    0.6.2
 */