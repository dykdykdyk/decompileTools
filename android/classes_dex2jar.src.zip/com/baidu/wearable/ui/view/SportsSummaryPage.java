package com.baidu.wearable.ui.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.sleep.Sleep;
import com.baidu.wearable.ui.activities.FlipActivity.PairDevice;
import com.baidu.wearable.ui.activities.SleepChartActivity;
import com.baidu.wearable.ui.activities.SportsChartActivity;
import com.baidu.wearable.ui.bean.SportsChartFuncType;
import com.baidu.wearable.util.SilentSleepManager;
import com.baidu.wearable.util.TimeUtil;
import java.io.Serializable;
import java.util.Calendar;

public class SportsSummaryPage extends ScrollView
  implements View.OnClickListener
{
  public static final int Default_Update_Interval = 3000;
  private static final long ITEM_CLICK_INTERVAL = 500L;
  private static final int Icon_Height = 60;
  private static final int Icon_Width = 60;
  public static final int MSG_STEP_SMOOTH_UPDATE = 1;
  public static final String TAG = "SportsSummaryPage";
  public static final int Update_Interval_Max = 15000;
  public static final int Update_Interval_Min = 200;
  public static final int View_Update_Min = 100;
  private final boolean SMOOTH_ON = true;
  private Bundle mBundle;
  private TextView mCalorieView;
  private float mCalories = 0.0F;
  private RelativeLayout mCenterProgress;
  private SportsChartFuncType mChartType = SportsChartFuncType.STEP;
  private TextView mCountUnit;
  private TextView mCountView;
  private int mDaysIndex = 0;
  private float mDistance = 0.0F;
  private TextView mDistanceView;
  private int mExpectedBraceletUpdateInterval = 3000;
  private MyHandler mHandler;
  private TextView mHistoryCenter;
  private ImageView mHistoryLeft;
  private ImageView mHistoryRight;
  private boolean mIsInitialized = false;
  private long mLastItemClickTime = 0L;
  private long mLastUpdateTime = -1L;
  private LinearLayout mLinearLayout;
  private View mLinearSportsType;
  private SummaryPageCallback mPageCallback;
  private ImageView mProgressBackground;
  private ProgressView mProgressView;
  private int mRemainingSteps = 0;
  private RelativeLayout mShareButton;
  private View mSleepClickableLayout;
  private SleepLayout mSleepLayout;
  private int mStepDelta = 1;
  private TextView mStepView;
  private long mSteps = 0L;
  private ImageView mTargetButton;
  private int mTargetCalories = 100;
  private float mTargetDistance = 6.0F;
  private long mTargetSteps = 10000L;
  private TextView mTargetUnit;
  private TextView mTargetValue;
  private TextView mTextComplete;
  private View mToToday;
  private int mViewUpdateInterval = 1000;
  private int[] previousWindow = { 3000, 3000, 3000 };

  public SportsSummaryPage(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
  }

  private void initViews()
  {
    int k;
    label265: String str1;
    String str2;
    int i;
    float f1;
    if (!this.mIsInitialized)
    {
      this.mIsInitialized = true;
      if (this.mBundle != null)
      {
        this.mDaysIndex = this.mBundle.getInt("index", -1);
        this.mSteps = this.mBundle.getInt("steps", 0);
        this.mCalories = this.mBundle.getFloat("calories", 0.0F);
        this.mDistance = this.mBundle.getFloat("distance", 0.0F);
        this.mTargetSteps = this.mBundle.getLong("target_steps", 10000L);
        this.mTargetCalories = this.mBundle.getInt("target_calories", 100);
        this.mTargetDistance = this.mBundle.getFloat("target_distance", 6.0F);
        k = this.mBundle.getInt("chart_type", SportsChartFuncType.STEP.ordinal());
        Object[] arrayOfObject4 = new Object[4];
        arrayOfObject4[0] = Integer.valueOf(this.mDaysIndex);
        arrayOfObject4[1] = Long.valueOf(this.mSteps);
        arrayOfObject4[2] = Float.valueOf(this.mCalories);
        arrayOfObject4[3] = Float.valueOf(this.mDistance);
        LogUtil.d("FlipActivity_ViewPager", String.format("mDaysIndex %d mSteps %d mCalories %1.0f mDistance %1.0f", arrayOfObject4));
        if (SportsChartFuncType.STEP.ordinal() != k)
          break label928;
        this.mChartType = SportsChartFuncType.STEP;
      }
      this.mHistoryCenter = ((TextView)findViewById(2131230959));
      if (-1 != this.mDaysIndex)
      {
        if (6 != this.mDaysIndex)
          break label970;
        this.mHistoryCenter.setText(getContext().getString(2131296464));
      }
      this.mHistoryLeft = ((ImageView)findViewById(2131230957));
      if (this.mDaysIndex == 0)
        this.mHistoryLeft.setEnabled(false);
      this.mHistoryLeft.setOnClickListener(this);
      this.mHistoryRight = ((ImageView)findViewById(2131230961));
      if (6 == this.mDaysIndex)
        this.mHistoryRight.setEnabled(false);
      this.mHistoryRight.setOnClickListener(this);
      str1 = "";
      str2 = "";
      i = 2131296461;
      int j = $SWITCH_TABLE$com$baidu$wearable$ui$bean$SportsChartFuncType()[this.mChartType.ordinal()];
      f1 = 0.0F;
      switch (j)
      {
      default:
        this.mProgressBackground = ((ImageView)findViewById(2131230965));
        this.mProgressView = ((ProgressView)findViewById(2131230946));
        setProgressViewPercent(f1);
        this.mTextComplete = ((TextView)findViewById(2131230967));
        this.mTextComplete.setText(getResources().getString(2131296456) + (int)(100.0F * f1) + "%");
        this.mCountView = ((TextView)findViewById(2131230968));
        this.mCountView.setText(str1);
        LogUtil.d("FlipActivity_ViewPager", " mCountView.setBigText " + str1);
        this.mCountUnit = ((TextView)findViewById(2131230969));
        this.mTargetUnit = ((TextView)findViewById(2131230973));
        this.mCountUnit.setText(i);
        this.mTargetUnit.setText(i);
        this.mLinearSportsType = findViewById(2131230975);
        this.mStepView = ((TextView)findViewById(2131230976));
        this.mStepView.setOnClickListener(this);
        this.mCalorieView = ((TextView)findViewById(2131230977));
        this.mCalorieView.setOnClickListener(this);
        this.mDistanceView = ((TextView)findViewById(2131230978));
        this.mDistanceView.setOnClickListener(this);
        switch ($SWITCH_TABLE$com$baidu$wearable$ui$bean$SportsChartFuncType()[this.mChartType.ordinal()])
        {
        default:
        case 1:
        case 2:
        case 3:
        }
        break;
      case 1:
      case 2:
      case 3:
      }
    }
    while (true)
    {
      this.mTargetValue = ((TextView)findViewById(2131230972));
      this.mTargetValue.setText(str2);
      this.mTargetButton = ((ImageView)findViewById(2131230974));
      this.mTargetButton.setOnClickListener(this);
      this.mToToday = findViewById(2131230960);
      if (6 == this.mDaysIndex)
        this.mToToday.setVisibility(8);
      this.mToToday.setOnClickListener(this);
      this.mCenterProgress = ((RelativeLayout)findViewById(2131230964));
      this.mCenterProgress.setOnClickListener(this);
      this.mSleepLayout = ((SleepLayout)findViewById(2131230982));
      Serializable localSerializable = this.mBundle.getSerializable("sleep");
      if ((localSerializable != null) && ((localSerializable instanceof Sleep)))
      {
        this.mSleepLayout.setSleep((Sleep)localSerializable);
        LogUtil.d("FlipActivity", "setSleep with index " + this.mDaysIndex);
      }
      this.mSleepClickableLayout = findViewById(2131230986);
      this.mSleepClickableLayout.setOnClickListener(this);
      this.mShareButton = ((RelativeLayout)findViewById(2131231231));
      this.mShareButton.setOnClickListener(this);
      this.mLinearLayout = ((LinearLayout)findViewById(2131230955));
      return;
      label928: if (SportsChartFuncType.CALORIE.ordinal() == k)
      {
        this.mChartType = SportsChartFuncType.CALORIE;
        break;
      }
      if (SportsChartFuncType.DISTANCE.ordinal() != k)
        break;
      this.mChartType = SportsChartFuncType.DISTANCE;
      break;
      label970: if (5 == this.mDaysIndex)
      {
        this.mHistoryCenter.setText(getContext().getString(2131296465));
        break label265;
      }
      if ((this.mDaysIndex < 0) || (this.mDaysIndex >= 5))
        break label265;
      this.mHistoryCenter.setText(TimeUtil.getDateBeforeDays(6 - this.mDaysIndex));
      break label265;
      if (this.mTargetSteps > 0L);
      for (f1 = (float)this.mSteps / (float)this.mTargetSteps; ; f1 = 0.0F)
      {
        Object[] arrayOfObject2 = new Object[1];
        arrayOfObject2[0] = Long.valueOf(this.mSteps);
        str1 = String.format("%d", arrayOfObject2);
        i = 2131296461;
        Object[] arrayOfObject3 = new Object[1];
        arrayOfObject3[0] = Long.valueOf(this.mTargetSteps);
        str2 = String.format("%d", arrayOfObject3);
        LogUtil.d("SportsSummaryPage", "step:" + this.mSteps + ", target step:" + this.mTargetSteps + ", percent:" + f1 + ", strBigText" + str1 + ", strTargetValue" + str2);
        break;
      }
      if (this.mTargetCalories > 0);
      for (f1 = (int)this.mCalories / this.mTargetCalories; ; f1 = 0.0F)
      {
        str1 = (int)this.mCalories;
        i = 2131296462;
        Object[] arrayOfObject1 = new Object[1];
        arrayOfObject1[0] = Integer.valueOf(this.mTargetCalories);
        str2 = String.format("%d", arrayOfObject1);
        LogUtil.d("SportsSummaryPage", "calories:" + this.mCalories + ", target calories:" + this.mTargetCalories + ", percent:" + f1 + ", strBigText" + str1 + ", strTargetValue" + str2);
        break;
      }
      float f2 = (int)(10.0F * (this.mDistance / 1000.0F));
      LogUtil.d("SportsSummaryPage", "temp:" + f2 + ", strBigText:" + f2 / 10.0F);
      str1 = f2 / 10.0F;
      i = 2131296463;
      float f3 = (int)(10.0F * this.mTargetDistance);
      LogUtil.d("SportsSummaryPage", "temp:" + f3 + ", strTargetValue:" + f3 / 10.0F);
      str2 = f3 / 10.0F;
      if (f3 / 10.0F > 0.0F);
      for (f1 = f2 / f3; ; f1 = 0.0F)
      {
        LogUtil.d("SportsSummaryPage", "distance:" + this.mDistance + ", target distance:" + this.mTargetDistance + ", percent:" + f1 + ", strBigText" + str1 + ", strTargetValue" + str2);
        break;
      }
      this.mLinearSportsType.setBackgroundResource(2130837826);
      Drawable localDrawable3 = getResources().getDrawable(2130837613);
      localDrawable3.setBounds(0, 0, 60, 60);
      this.mStepView.setCompoundDrawables(localDrawable3, null, null, null);
      continue;
      this.mLinearSportsType.setBackgroundResource(2130837827);
      Drawable localDrawable2 = getResources().getDrawable(2130837588);
      localDrawable2.setBounds(0, 0, 60, 60);
      this.mCalorieView.setCompoundDrawables(localDrawable2, null, null, null);
      continue;
      this.mLinearSportsType.setBackgroundResource(2130837825);
      Drawable localDrawable1 = getResources().getDrawable(2130837594);
      localDrawable1.setBounds(0, 0, 60, 60);
      this.mDistanceView.setCompoundDrawables(localDrawable1, null, null, null);
    }
  }

  private void setProgressViewPercent(float paramFloat)
  {
    if ((this.mProgressBackground != null) && (this.mProgressView != null))
    {
      if (paramFloat <= 0.0F)
      {
        if (this.mProgressView.getVisibility() == 0)
          this.mProgressView.setVisibility(8);
        this.mProgressBackground.setImageResource(2130837823);
      }
    }
    else
      return;
    if (paramFloat >= 1.0F)
    {
      if (this.mProgressView.getVisibility() == 0)
        this.mProgressView.setVisibility(8);
      this.mProgressBackground.setImageResource(2130837824);
      return;
    }
    if (this.mProgressView.getVisibility() == 8)
      this.mProgressView.setVisibility(0);
    this.mProgressView.setPercent(paramFloat);
    this.mProgressBackground.setImageResource(2130837823);
  }

  private void updateAsNormal(int paramInt, float paramFloat1, float paramFloat2, FlipActivity.PairDevice paramPairDevice)
  {
    LogUtil.d("SportsSummaryPage", "updateSportsData() called with " + paramInt + " aCalories " + paramFloat1 + " aDistance " + paramFloat2 + " aPairDevice " + paramPairDevice);
    if (FlipActivity.PairDevice.EPhone == paramPairDevice)
    {
      this.mSteps += paramInt;
      this.mCalories = (paramFloat1 + this.mCalories);
      this.mDistance = (paramFloat2 + this.mDistance);
    }
    while (true)
    {
      if (this.mBundle != null)
      {
        this.mBundle.putInt("steps", (int)this.mSteps);
        this.mBundle.putFloat("calories", this.mCalories);
        this.mBundle.putFloat("distance", this.mDistance);
      }
      LogUtil.d("SportsSummaryPage", "mSteps " + this.mSteps + " mCalories " + this.mCalories + " mDistance " + this.mDistance);
      updateDataView(this.mChartType);
      return;
      if (FlipActivity.PairDevice.EBracelet == paramPairDevice)
      {
        this.mSteps = paramInt;
        this.mCalories = paramFloat1;
        this.mDistance = paramFloat2;
      }
    }
  }

  private void updateDataView(SportsChartFuncType paramSportsChartFuncType)
  {
    switch ($SWITCH_TABLE$com$baidu$wearable$ui$bean$SportsChartFuncType()[paramSportsChartFuncType.ordinal()])
    {
    default:
      return;
    case 1:
      TextView localTextView3 = this.mCountView;
      Object[] arrayOfObject3 = new Object[1];
      arrayOfObject3[0] = Long.valueOf(this.mSteps);
      localTextView3.setText(String.format("%d", arrayOfObject3));
      if (this.mTargetSteps > 0L);
      for (float f5 = (float)this.mSteps / (float)this.mTargetSteps; ; f5 = 0.0F)
      {
        setProgressViewPercent(f5);
        this.mTextComplete.setText(getResources().getString(2131296456) + (int)(f5 * 100.0F) + "%");
        LogUtil.d("SportsSummaryPage", "step percent:" + (int)(f5 * 100.0F) + "%" + ", step:" + this.mSteps + ", mTargetSteps:" + this.mTargetSteps);
        this.mCountUnit.setText(2131296461);
        this.mTargetUnit.setText(2131296461);
        TextView localTextView4 = this.mTargetValue;
        Object[] arrayOfObject4 = new Object[1];
        arrayOfObject4[0] = Long.valueOf(this.mTargetSteps);
        localTextView4.setText(String.format("%d", arrayOfObject4));
        this.mLinearSportsType.setBackgroundResource(2130837826);
        Drawable localDrawable7 = getResources().getDrawable(2130837613);
        localDrawable7.setBounds(0, 0, 60, 60);
        this.mStepView.setCompoundDrawables(localDrawable7, null, null, null);
        Drawable localDrawable8 = getResources().getDrawable(2130837588);
        localDrawable8.setBounds(0, 0, 60, 60);
        this.mCalorieView.setCompoundDrawables(localDrawable8, null, null, null);
        Drawable localDrawable9 = getResources().getDrawable(2130837594);
        localDrawable9.setBounds(0, 0, 60, 60);
        this.mDistanceView.setCompoundDrawables(localDrawable9, null, null, null);
        this.mTargetButton.setVisibility(0);
        return;
      }
    case 2:
      TextView localTextView1 = this.mCountView;
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Integer.valueOf((int)this.mCalories);
      localTextView1.setText(String.format("%d", arrayOfObject1));
      if (this.mTargetCalories > 0);
      for (float f4 = (int)this.mCalories / this.mTargetCalories; ; f4 = 0.0F)
      {
        setProgressViewPercent(f4);
        this.mTextComplete.setText(getResources().getString(2131296456) + (int)(f4 * 100.0F) + "%");
        LogUtil.d("SportsSummaryPage", "calorie percent:" + (int)(f4 * 100.0F) + "%" + ", calorie:" + this.mCalories + ", mTargetCalories:" + this.mTargetCalories);
        this.mCountUnit.setText(2131296462);
        this.mTargetUnit.setText(2131296462);
        TextView localTextView2 = this.mTargetValue;
        Object[] arrayOfObject2 = new Object[1];
        arrayOfObject2[0] = Integer.valueOf(this.mTargetCalories);
        localTextView2.setText(String.format("%d", arrayOfObject2));
        this.mLinearSportsType.setBackgroundResource(2130837825);
        Drawable localDrawable4 = getResources().getDrawable(2130837612);
        localDrawable4.setBounds(0, 0, 60, 60);
        this.mStepView.setCompoundDrawables(localDrawable4, null, null, null);
        Drawable localDrawable5 = getResources().getDrawable(2130837589);
        localDrawable5.setBounds(0, 0, 60, 60);
        this.mCalorieView.setCompoundDrawables(localDrawable5, null, null, null);
        Drawable localDrawable6 = getResources().getDrawable(2130837594);
        localDrawable6.setBounds(0, 0, 60, 60);
        this.mDistanceView.setCompoundDrawables(localDrawable6, null, null, null);
        this.mTargetButton.setVisibility(4);
        return;
      }
    case 3:
    }
    float f1 = (int)(10.0F * (this.mDistance / 1000.0F));
    LogUtil.d("SportsSummaryPage", "temp:" + this.mDistance + ", distance:" + f1 / 10.0F);
    this.mCountView.setText(f1 / 10.0F);
    float f2 = (int)(10.0F * this.mTargetDistance);
    if (this.mTargetDistance > 0.0F);
    for (float f3 = f1 / f2; ; f3 = 0.0F)
    {
      setProgressViewPercent(f3);
      this.mTextComplete.setText(getResources().getString(2131296456) + (int)(f3 * 100.0F) + "%");
      LogUtil.d("SportsSummaryPage", "distance percent:" + (int)(f3 * 100.0F) + "%" + ", distance:" + this.mDistance + ", mTargetDistance:" + this.mTargetDistance);
      this.mCountUnit.setText(2131296463);
      this.mTargetUnit.setText(2131296463);
      LogUtil.d("SportsSummaryPage", "tempTarget:" + this.mTargetDistance + ", target distance:" + f2 / 10.0F);
      this.mTargetValue.setText(f2 / 10.0F);
      this.mLinearSportsType.setBackgroundResource(2130837827);
      Drawable localDrawable1 = getResources().getDrawable(2130837612);
      localDrawable1.setBounds(0, 0, 60, 60);
      this.mStepView.setCompoundDrawables(localDrawable1, null, null, null);
      Drawable localDrawable2 = getResources().getDrawable(2130837588);
      localDrawable2.setBounds(0, 0, 60, 60);
      this.mCalorieView.setCompoundDrawables(localDrawable2, null, null, null);
      Drawable localDrawable3 = getResources().getDrawable(2130837595);
      localDrawable3.setBounds(0, 0, 60, 60);
      this.mDistanceView.setCompoundDrawables(localDrawable3, null, null, null);
      this.mTargetButton.setVisibility(4);
      return;
    }
  }

  public void forceSetSleep(Sleep paramSleep)
  {
    if (this.mSleepLayout != null)
    {
      LogUtil.d("FlipActivity", "forceSetSleep");
      this.mSleepLayout.forceSetSleep(paramSleep);
    }
  }

  public void forceUpdatetViews(Bundle paramBundle)
  {
    LogUtil.d("FlipActivity", "forceUpdateView called with index " + this.mDaysIndex);
    Serializable localSerializable;
    if (paramBundle != null)
    {
      this.mBundle = paramBundle;
      if ((-1 != this.mDaysIndex) && (this.mDaysIndex >= 0) && (this.mDaysIndex < 5))
        this.mHistoryCenter.setText(TimeUtil.getDateBeforeDays(6 - this.mDaysIndex));
      this.mSteps = this.mBundle.getInt("steps", 0);
      this.mCalories = this.mBundle.getFloat("calories", 0.0F);
      this.mDistance = this.mBundle.getFloat("distance", 0.0F);
      updateDataView(this.mChartType);
      localSerializable = this.mBundle.getSerializable("sleep");
      if ((localSerializable == null) || (!(localSerializable instanceof Sleep)))
        break label157;
      setSleep((Sleep)localSerializable);
    }
    label157: 
    while (localSerializable != null)
      return;
    setSleep(null);
  }

  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    case 2131230959:
    default:
    case 2131230957:
    case 2131230961:
    case 2131230976:
    case 2131230977:
    case 2131230978:
    case 2131230974:
    case 2131230960:
    case 2131230964:
    case 2131231231:
    case 2131230986:
    }
    do
    {
      do
      {
        long l;
        do
        {
          do
          {
            do
            {
              do
              {
                do
                {
                  do
                  {
                    do
                    {
                      do
                        return;
                      while (this.mPageCallback == null);
                      this.mPageCallback.onPrevious(this.mDaysIndex);
                      return;
                    }
                    while (this.mPageCallback == null);
                    this.mPageCallback.onNext(this.mDaysIndex);
                    return;
                    updateDataView(SportsChartFuncType.STEP);
                    this.mChartType = SportsChartFuncType.STEP;
                  }
                  while (this.mPageCallback == null);
                  this.mPageCallback.onChangeChartType(SportsChartFuncType.STEP);
                  return;
                  updateDataView(SportsChartFuncType.CALORIE);
                  this.mChartType = SportsChartFuncType.CALORIE;
                }
                while (this.mPageCallback == null);
                this.mPageCallback.onChangeChartType(SportsChartFuncType.CALORIE);
                return;
                updateDataView(SportsChartFuncType.DISTANCE);
                this.mChartType = SportsChartFuncType.DISTANCE;
              }
              while (this.mPageCallback == null);
              this.mPageCallback.onChangeChartType(SportsChartFuncType.DISTANCE);
              return;
            }
            while (this.mPageCallback == null);
            this.mPageCallback.onSetTarget(SportsChartFuncType.STEP);
            return;
          }
          while (this.mPageCallback == null);
          this.mPageCallback.toToday();
          return;
          SportsChartActivity.startSportsDetailActivity(getContext(), 6 - this.mDaysIndex, this.mChartType);
          return;
          l = System.currentTimeMillis();
        }
        while (l - this.mLastItemClickTime < 500L);
        this.mLastItemClickTime = l;
      }
      while (this.mPageCallback == null);
      this.mPageCallback.onShareBtnClicked(this.mLinearLayout);
      return;
    }
    while ((SilentSleepManager.getInstance(getContext()).isInSleepState()) && (6 == this.mDaysIndex));
    SleepChartActivity.startSleepChartActivity(getContext(), 6 - this.mDaysIndex);
  }

  protected void onFinishInflate()
  {
    super.onFinishInflate();
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
  }

  public void setBundle(Bundle paramBundle)
  {
    this.mBundle = paramBundle;
    initViews();
  }

  public void setChartType(SportsChartFuncType paramSportsChartFuncType)
  {
    if (paramSportsChartFuncType != this.mChartType)
    {
      this.mChartType = paramSportsChartFuncType;
      updateDataView(this.mChartType);
    }
  }

  public void setPageCallback(SummaryPageCallback paramSummaryPageCallback)
  {
    this.mPageCallback = paramSummaryPageCallback;
  }

  public void setSleep(Sleep paramSleep)
  {
    if (this.mSleepLayout != null)
      this.mSleepLayout.setSleep(paramSleep);
  }

  public void setTargetValue(int paramInt1, int paramInt2, float paramFloat)
  {
    boolean bool = this.mTargetSteps < paramInt1;
    int i = 0;
    if (bool)
    {
      this.mTargetSteps = paramInt1;
      i = 1;
    }
    if (this.mTargetCalories != paramInt2)
    {
      this.mTargetCalories = paramInt2;
      i = 1;
    }
    if (this.mTargetDistance != paramFloat)
    {
      this.mTargetDistance = paramFloat;
      i = 1;
    }
    if (i != 0)
      updateDataView(this.mChartType);
  }

  public void updateSportsData(int paramInt, float paramFloat1, float paramFloat2, FlipActivity.PairDevice paramPairDevice)
  {
    if (FlipActivity.PairDevice.EBracelet == paramPairDevice)
    {
      long l1 = Calendar.getInstance().getTimeInMillis();
      long l2 = 3000L;
      if (-1L != this.mLastUpdateTime)
        l2 = l1 - this.mLastUpdateTime;
      this.mLastUpdateTime = l1;
      if ((l2 > 200L) && (l2 < 15000L))
      {
        this.previousWindow[0] = this.previousWindow[1];
        this.previousWindow[1] = this.previousWindow[2];
        this.previousWindow[2] = ((int)l2);
        this.mExpectedBraceletUpdateInterval = ((int)(0.4D * this.mExpectedBraceletUpdateInterval + 0.3D * this.previousWindow[2] + 0.2D * this.previousWindow[1] + 0.1D * this.previousWindow[0]));
      }
      int i = (int)(paramInt - this.mSteps);
      LogUtil.d("SportsSummaryPage", "aSteps " + paramInt + " delta_step " + i);
      LogUtil.d("SportsSummaryPage", "mExpectedBraceletUpdateInterval " + this.mExpectedBraceletUpdateInterval);
      if ((SportsChartFuncType.STEP == this.mChartType) && (i > 0))
      {
        this.mCalories = paramFloat1;
        this.mDistance = paramFloat2;
        if (this.mHandler == null)
          this.mHandler = new MyHandler(null);
        if (this.mHandler != null)
        {
          int j = this.mExpectedBraceletUpdateInterval / i;
          if (j <= 100)
            break label400;
          this.mViewUpdateInterval = j;
        }
        for (this.mStepDelta = 1; ; this.mStepDelta = (i / (this.mExpectedBraceletUpdateInterval / this.mViewUpdateInterval)))
        {
          Message localMessage = new Message();
          localMessage.what = 1;
          localMessage.arg1 = (this.mStepDelta + this.mRemainingSteps);
          this.mRemainingSteps = i;
          LogUtil.d("SportsSummaryPage", "mRemainingSteps " + this.mRemainingSteps + "mViewUpdateTime " + this.mViewUpdateInterval + "mStepDelta " + this.mStepDelta);
          this.mHandler.removeMessages(1);
          this.mHandler.sendMessage(localMessage);
          return;
          label400: this.mViewUpdateInterval = 200;
        }
      }
      updateAsNormal(paramInt, paramFloat1, paramFloat2, paramPairDevice);
      return;
    }
    updateAsNormal(paramInt, paramFloat1, paramFloat2, paramPairDevice);
  }

  private class MyHandler extends Handler
  {
    private MyHandler()
    {
    }

    public void handleMessage(Message paramMessage)
    {
      LogUtil.d("SportsSummaryPage", "MyHandler handleMessage called");
      super.handleMessage(paramMessage);
      switch (paramMessage.what)
      {
      default:
        return;
      case 1:
      }
      int i = paramMessage.arg1;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = Integer.valueOf(i);
      arrayOfObject[1] = Integer.valueOf(SportsSummaryPage.this.mRemainingSteps);
      arrayOfObject[2] = Long.valueOf(SportsSummaryPage.this.mSteps);
      LogUtil.d("SportsSummaryPage", String.format("deltaSteps is %d mRemainingSteps is %d mSteps is %d", arrayOfObject));
      int j;
      SportsSummaryPage localSportsSummaryPage2;
      if (i > 0)
      {
        SportsSummaryPage localSportsSummaryPage1 = SportsSummaryPage.this;
        long l = localSportsSummaryPage1.mSteps;
        if (i >= SportsSummaryPage.this.mRemainingSteps)
          break label277;
        j = i;
        localSportsSummaryPage1.mSteps = (l + j);
        localSportsSummaryPage2 = SportsSummaryPage.this;
        if (i >= SportsSummaryPage.this.mRemainingSteps)
          break label289;
      }
      label277: label289: for (int k = SportsSummaryPage.this.mRemainingSteps - i; ; k = 0)
      {
        localSportsSummaryPage2.mRemainingSteps = k;
        if (SportsSummaryPage.this.mRemainingSteps > 0)
        {
          Message localMessage = new Message();
          localMessage.what = 1;
          localMessage.arg1 = SportsSummaryPage.this.mStepDelta;
          sendMessageDelayed(localMessage, SportsSummaryPage.this.mViewUpdateInterval);
        }
        LogUtil.d("SportsSummaryPage", "mSteps is " + SportsSummaryPage.this.mSteps + " mRemainingSteps" + SportsSummaryPage.this.mRemainingSteps);
        SportsSummaryPage.this.updateDataView(SportsSummaryPage.this.mChartType);
        return;
        j = SportsSummaryPage.this.mRemainingSteps;
        break;
      }
    }
  }

  public static abstract interface SummaryPageCallback
  {
    public static final int Opt_Conn_Add_Device = 1;
    public static final int Opt_Conn_Set_Bluetooth = 2;

    public abstract void onChangeChartType(SportsChartFuncType paramSportsChartFuncType);

    public abstract void onNext(int paramInt);

    public abstract void onPrevious(int paramInt);

    public abstract void onSetTarget(SportsChartFuncType paramSportsChartFuncType);

    public abstract void onShareBtnClicked(LinearLayout paramLinearLayout);

    public abstract void operationOnConn(int paramInt);

    public abstract void toToday();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.SportsSummaryPage
 * JD-Core Version:    0.6.2
 */