package com.baidu.wearable.ui.view;

import android.view.View;

public abstract interface HistoryItemView
{
  public abstract View getItemView();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.HistoryItemView
 * JD-Core Version:    0.6.2
 */