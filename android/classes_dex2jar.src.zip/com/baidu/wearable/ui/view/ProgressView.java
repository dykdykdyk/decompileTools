package com.baidu.wearable.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.ArcShape;
import android.util.AttributeSet;
import android.view.View;
import com.baidu.wearable.WearableApplication;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.Calendar;

public class ProgressView extends View
{
  private static final String TAG = "ProgressView";
  private Bitmap mBitmap = WearableApplication.getSportsProgressBitmap();
  private BitmapShader mBitmapShader;
  private int mMeasuredHeight = 0;
  private int mMeasuredWidth = 0;
  private float mPercent = 0.0F;
  private int mProgress = 0;
  private ShapeDrawable mShapeDrawable;

  public ProgressView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    if (this.mBitmap != null)
    {
      this.mMeasuredWidth = this.mBitmap.getWidth();
      this.mMeasuredHeight = this.mBitmap.getHeight();
      this.mBitmapShader = new BitmapShader(this.mBitmap, Shader.TileMode.MIRROR, Shader.TileMode.REPEAT);
    }
  }

  private void getArc(Canvas paramCanvas, float paramFloat)
  {
    this.mShapeDrawable = new ShapeDrawable(new ArcShape(-90.0F, paramFloat));
    this.mShapeDrawable.getPaint().setShader(this.mBitmapShader);
    this.mShapeDrawable.setBounds(0, 0, this.mMeasuredWidth, this.mMeasuredHeight);
    this.mShapeDrawable.draw(paramCanvas);
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    long l1 = Calendar.getInstance().getTimeInMillis();
    getArc(paramCanvas, this.mProgress);
    long l2 = Calendar.getInstance().getTimeInMillis();
    Object[] arrayOfObject = new Object[1];
    arrayOfObject[0] = Long.valueOf(l2 - l1);
    LogUtil.d("FlipActivity_ViewPager", String.format("ProgressView onDraw time is %d", arrayOfObject));
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(this.mMeasuredWidth, this.mMeasuredHeight);
  }

  public void setPercent(float paramFloat)
  {
    if (paramFloat > 1.0F);
    for (this.mPercent = 1.0F; ; this.mPercent = paramFloat)
    {
      this.mProgress = ((int)(360.0F * this.mPercent));
      LogUtil.d("FlipActivity", "setPercent with the mProgress is " + this.mProgress);
      invalidate();
      return;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.ProgressView
 * JD-Core Version:    0.6.2
 */