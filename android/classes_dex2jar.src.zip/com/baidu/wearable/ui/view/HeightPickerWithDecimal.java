package com.baidu.wearable.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.NumberPicker;
import android.widget.NumberPicker.OnValueChangeListener;
import com.baidu.wearable.R.styleable;

public class HeightPickerWithDecimal extends FrameLayout
{
  private Context mContext;
  private NumberPicker mDecimalSpinner;
  private String[] mHeightDisplay = new String[this.mNumberOfIntegers];
  private NumberPicker mIntegerSpinner;
  private int mNumberOfIntegers = 250;
  private OnHeightChangedListener mOnHeightChangedListener;

  public HeightPickerWithDecimal(Context paramContext)
  {
    this(paramContext, null);
    this.mContext = paramContext;
  }

  public HeightPickerWithDecimal(Context paramContext, AttributeSet paramAttributeSet)
  {
    this(paramContext, paramAttributeSet, 0);
    this.mContext = paramContext;
  }

  public HeightPickerWithDecimal(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    this.mContext = paramContext;
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.HeightPicker, paramInt, 0);
    int i = localTypedArray.getResourceId(0, 2130903119);
    localTypedArray.recycle();
    ((LayoutInflater)paramContext.getSystemService("layout_inflater")).inflate(i, this, true);
    initHeightShow();
    this.mIntegerSpinner = ((NumberPicker)findViewById(2131231047));
    this.mIntegerSpinner.setMinValue(1);
    this.mIntegerSpinner.setMaxValue(this.mNumberOfIntegers);
    this.mIntegerSpinner.setDisplayedValues(this.mHeightDisplay);
    this.mIntegerSpinner.setOnLongPressUpdateInterval(100L);
    this.mIntegerSpinner.setOnValueChangedListener(new NumberPicker.OnValueChangeListener()
    {
      public void onValueChange(NumberPicker paramAnonymousNumberPicker, int paramAnonymousInt1, int paramAnonymousInt2)
      {
        HeightPickerWithDecimal.this.updateInputState();
        HeightPickerWithDecimal.this.onHeightChanged();
      }
    });
    this.mDecimalSpinner = ((NumberPicker)findViewById(2131231048));
    this.mDecimalSpinner.setMinValue(1);
    this.mDecimalSpinner.setMaxValue(9);
    this.mDecimalSpinner.setOnLongPressUpdateInterval(100L);
    this.mDecimalSpinner.setOnValueChangedListener(new NumberPicker.OnValueChangeListener()
    {
      public void onValueChange(NumberPicker paramAnonymousNumberPicker, int paramAnonymousInt1, int paramAnonymousInt2)
      {
        HeightPickerWithDecimal.this.updateInputState();
        int i = HeightPickerWithDecimal.this.mDecimalSpinner.getMinValue();
        int j = HeightPickerWithDecimal.this.mDecimalSpinner.getMaxValue();
        if ((paramAnonymousInt1 == j) && (paramAnonymousInt2 == i))
        {
          int m = 1 + HeightPickerWithDecimal.this.mIntegerSpinner.getValue();
          HeightPickerWithDecimal.this.mIntegerSpinner.setValue(m);
        }
        while (true)
        {
          HeightPickerWithDecimal.this.onHeightChanged();
          return;
          if ((paramAnonymousInt1 == i) && (paramAnonymousInt2 == j))
          {
            int k = -1 + HeightPickerWithDecimal.this.mIntegerSpinner.getValue();
            HeightPickerWithDecimal.this.mIntegerSpinner.setValue(k);
          }
        }
      }
    });
  }

  private void initHeightShow()
  {
    for (int i = 0; ; i++)
    {
      if (i >= this.mNumberOfIntegers)
        return;
      this.mHeightDisplay[i] = (i + 1 + "cm");
    }
  }

  private void onHeightChanged()
  {
    sendAccessibilityEvent(4);
    if (this.mOnHeightChangedListener != null)
      this.mOnHeightChangedListener.onHeightChanged(this, getCurrentInteger(), getCurrentDecimal());
  }

  private void updateInputState()
  {
    InputMethodManager localInputMethodManager = (InputMethodManager)this.mContext.getSystemService("input_method");
    if (localInputMethodManager != null)
    {
      if (!localInputMethodManager.isActive(this.mIntegerSpinner))
        break label46;
      this.mIntegerSpinner.clearFocus();
      localInputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
    }
    label46: 
    while (!localInputMethodManager.isActive(this.mDecimalSpinner))
      return;
    this.mDecimalSpinner.clearFocus();
    localInputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
  }

  public int getCurrentDecimal()
  {
    return this.mDecimalSpinner.getValue();
  }

  public int getCurrentInteger()
  {
    return this.mIntegerSpinner.getValue();
  }

  public void setOnHeightChangeListener(OnHeightChangedListener paramOnHeightChangedListener)
  {
    this.mOnHeightChangedListener = paramOnHeightChangedListener;
  }

  public static abstract interface OnHeightChangedListener
  {
    public abstract void onHeightChanged(HeightPickerWithDecimal paramHeightPickerWithDecimal, int paramInt1, int paramInt2);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.HeightPickerWithDecimal
 * JD-Core Version:    0.6.2
 */