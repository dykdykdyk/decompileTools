package com.baidu.wearable.ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.ArcShape;
import android.util.AttributeSet;
import android.view.View;
import com.baidu.wearable.WearableApplication;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.sleep.Sleep;
import com.baidu.wearable.sleep.SleepSlot;
import com.baidu.wearable.sleep.SleepState;
import java.util.Calendar;
import java.util.List;

public class SleepTimeView extends View
{
  public static final String TAG = "SleepTimeView";
  private final long Half_Day_In_Seconds = 43200L;
  private BitmapShader mDeepSleepShader;
  private ShapeDrawable mDeepSleepShapeDrawable = new ShapeDrawable();
  private boolean mIsNeedDrawSleep = false;
  private BitmapShader mLightSleepShader;
  private ShapeDrawable mLightSleepShapeDrawable = new ShapeDrawable();
  private int mMeasuredHeight = 0;
  private int mMeasuredWidth = 0;
  private Paint mPaint;
  private Sleep mSleep;

  public SleepTimeView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    Bitmap localBitmap1 = WearableApplication.getDeepSleepBitmap();
    if (localBitmap1 != null)
    {
      this.mMeasuredWidth = localBitmap1.getWidth();
      this.mMeasuredHeight = localBitmap1.getHeight();
      this.mDeepSleepShader = new BitmapShader(localBitmap1, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
      this.mDeepSleepShapeDrawable.getPaint().setShader(this.mDeepSleepShader);
      this.mDeepSleepShapeDrawable.setBounds(0, 0, this.mMeasuredWidth, this.mMeasuredHeight);
    }
    Bitmap localBitmap2 = WearableApplication.getLightSleepBitmap();
    if (localBitmap2 != null)
    {
      this.mLightSleepShader = new BitmapShader(localBitmap2, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
      this.mLightSleepShapeDrawable.getPaint().setShader(this.mLightSleepShader);
      this.mLightSleepShapeDrawable.setBounds(0, 0, this.mMeasuredWidth, this.mMeasuredHeight);
    }
    this.mPaint = new Paint(0);
    LogUtil.d("SleepTimeView", "SleepTimeView created with mMeasuredWidth " + this.mMeasuredWidth + " mMeasuredHeight " + this.mMeasuredHeight);
  }

  private void drawSleepSlot(SleepSlot paramSleepSlot, Canvas paramCanvas)
  {
    int i;
    int j;
    if ((paramSleepSlot != null) && (SleepState.AWAKE != paramSleepSlot.getState()))
    {
      i = getDegreeOnClockForTime(paramSleepSlot.getStartTime());
      j = (int)paramSleepSlot.getDuration() / 120;
      if ((-1 != i) && (j >= 0) && (j <= 360))
      {
        if ((SleepState.DEEP_SLEEP != paramSleepSlot.getState()) || (this.mDeepSleepShader == null))
          break label129;
        this.mDeepSleepShapeDrawable.setShape(new ArcShape(i - 90, j));
        this.mDeepSleepShapeDrawable.draw(paramCanvas);
      }
    }
    while (true)
    {
      LogUtil.d("FlipActivity", "draw sleep slot with begin " + i + " degree " + j);
      return;
      label129: if ((SleepState.LIGHT_SLEEP == paramSleepSlot.getState()) && (this.mLightSleepShader != null))
      {
        this.mLightSleepShapeDrawable.setShape(new ArcShape(i - 90, j));
        this.mLightSleepShapeDrawable.draw(paramCanvas);
      }
    }
  }

  public static int getDegreeOnClockForTime(long paramLong)
  {
    int i = -1;
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTimeInMillis(1000L * paramLong);
    int j = localCalendar.get(10);
    int k = localCalendar.get(12);
    int m = localCalendar.get(13);
    if ((j >= 0) && (k >= 0) && (m >= 0))
      i = (m + (60 * (j * 60) + k * 60)) / 120;
    return i;
  }

  private int getLastDrawSlotIndex()
  {
    int i = -1;
    if ((this.mSleep != null) && (this.mSleep.getSleepDataFromStartToEnd() != null))
    {
      LogUtil.d("FlipActivity", "mSleep.getEndSleepInSeconds() " + this.mSleep.getEndSleepInSeconds() + " mSleep.getStartSleepInSeconds()" + this.mSleep.getStartSleepInSeconds());
      if (this.mSleep.getEndSleepInSeconds() - this.mSleep.getStartSleepInSeconds() <= 43200L)
        i = -1 + this.mSleep.getSleepDataFromStartToEnd().size();
    }
    else
    {
      return i;
    }
    List localList = this.mSleep.getSleepDataFromStartToEnd();
    label183: for (int j = 0; ; j++)
    {
      if (j >= localList.size());
      while (-1 == i)
      {
        return -1 + this.mSleep.getSleepDataFromStartToEnd().size();
        SleepSlot localSleepSlot = (SleepSlot)localList.get(j);
        if (localSleepSlot.getStartTime() + localSleepSlot.getDuration() - this.mSleep.getStartSleepInSeconds() <= 43200L)
          break label183;
        i = j;
      }
      break;
    }
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    LogUtil.d("FlipActivity", "SleepTimeView onDraw");
    this.mIsNeedDrawSleep = false;
    long l1 = Calendar.getInstance().getTimeInMillis();
    List localList;
    int i;
    int k;
    label91: SleepSlot localSleepSlot3;
    long l3;
    if (this.mSleep != null)
    {
      localList = this.mSleep.getSleepDataFromStartToEnd();
      if (localList != null)
      {
        i = 0;
        if (i < localList.size())
          break label249;
        int j = getLastDrawSlotIndex();
        LogUtil.d("FlipActivity", "lastSlotIndex " + j);
        k = 0;
        if (k < j)
          break label309;
        if (j >= 0)
        {
          localSleepSlot3 = (SleepSlot)localList.get(j);
          if ((localSleepSlot3 != null) && (SleepState.AWAKE != localSleepSlot3.getState()) && (localSleepSlot3.getStartTime() < 43200L + this.mSleep.getStartSleepInSeconds()))
          {
            l3 = 43200L + this.mSleep.getStartSleepInSeconds() - localSleepSlot3.getStartTime();
            if (localSleepSlot3.getDuration() <= l3)
              break label352;
          }
        }
      }
    }
    label309: label352: for (long l4 = l3; ; l4 = localSleepSlot3.getDuration())
    {
      drawSleepSlot(new SleepSlot(localSleepSlot3.getStartTime(), l4, localSleepSlot3.getState()), paramCanvas);
      long l2 = Calendar.getInstance().getTimeInMillis();
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Long.valueOf(l2 - l1);
      LogUtil.d("FlipActivity_ViewPager", String.format("SleepTimeView onDraw time is %d", arrayOfObject));
      return;
      label249: SleepSlot localSleepSlot1 = (SleepSlot)localList.get(i);
      LogUtil.d("FlipActivity", "Sleep strart time is " + localSleepSlot1.getStartTime() + " sleep state is " + localSleepSlot1.getState());
      i++;
      break;
      SleepSlot localSleepSlot2 = (SleepSlot)localList.get(k);
      if ((localSleepSlot2 != null) && (SleepState.AWAKE != localSleepSlot2.getState()))
        drawSleepSlot(localSleepSlot2, paramCanvas);
      k++;
      break label91;
    }
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(this.mMeasuredWidth, this.mMeasuredHeight);
  }

  public void setSleep(Sleep paramSleep)
  {
    LogUtil.d("FlipActivity", "setSleep called");
    this.mSleep = paramSleep;
    this.mIsNeedDrawSleep = true;
    invalidate();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.SleepTimeView
 * JD-Core Version:    0.6.2
 */