package com.baidu.wearable.ui.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import com.baidu.wearable.R.styleable;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SleepView extends View
{
  private static final String TAG = "SleepView";
  private int mArcColor1;
  private int mArcColor2;
  private int mArcColor3;
  private List<Arc> mArcList = new ArrayList();
  private int mBottom;
  private int mHeight;
  private int mInnerCircle;
  private int mInnerRingColor;
  private int mLeft;
  private int mOuterRingColor;
  private Paint mPaint;
  private int mRight;
  private int mRingWidth;
  private int mTop;
  private int mWidth;

  public SleepView(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.SleepView);
    this.mRingWidth = localTypedArray.getDimensionPixelSize(0, 30);
    this.mInnerRingColor = localTypedArray.getColor(1, -1);
    this.mOuterRingColor = localTypedArray.getColor(2, -1);
    this.mArcColor1 = localTypedArray.getColor(3, -1);
    this.mArcColor2 = localTypedArray.getColor(4, -1);
    this.mArcColor3 = localTypedArray.getColor(5, -1);
    localTypedArray.recycle();
    this.mPaint = new Paint();
    this.mPaint.setAntiAlias(true);
    this.mPaint.setStyle(Paint.Style.STROKE);
  }

  public SleepView(Context paramContext, AttributeSet paramAttributeSet, int paramInt)
  {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray localTypedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.SleepView);
    this.mRingWidth = localTypedArray.getDimensionPixelSize(0, 30);
    this.mInnerRingColor = localTypedArray.getColor(1, -1);
    this.mOuterRingColor = localTypedArray.getColor(2, -1);
    this.mArcColor1 = localTypedArray.getColor(3, -1);
    this.mArcColor2 = localTypedArray.getColor(4, -1);
    this.mArcColor3 = localTypedArray.getColor(5, -1);
    localTypedArray.recycle();
    this.mPaint = new Paint();
    this.mPaint.setAntiAlias(true);
    this.mPaint.setStyle(Paint.Style.STROKE);
  }

  public void add(Arc paramArc)
  {
    this.mArcList.add(paramArc);
  }

  public void addList(List<Arc> paramList)
  {
    this.mArcList = paramList;
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    this.mPaint.setStrokeWidth(this.mRingWidth);
    RectF localRectF = new RectF(this.mLeft + this.mRingWidth, this.mTop + this.mRingWidth, this.mRight - this.mRingWidth, this.mBottom - this.mRingWidth);
    Iterator localIterator = this.mArcList.iterator();
    if (!localIterator.hasNext())
    {
      this.mPaint.setColor(this.mInnerRingColor);
      this.mPaint.setStrokeWidth(2.0F);
      paramCanvas.drawCircle(this.mWidth / 2, this.mWidth / 2, this.mInnerCircle - this.mRingWidth, this.mPaint);
      this.mPaint.setColor(this.mOuterRingColor);
      this.mPaint.setStrokeWidth(2.0F);
      paramCanvas.drawCircle(this.mWidth / 2, this.mWidth / 2, this.mInnerCircle, this.mPaint);
      return;
    }
    Arc localArc = (Arc)localIterator.next();
    LogUtil.d("SleepView", "++++++++++++++state:" + localArc.getState() + "startAngle:" + localArc.getStartAngle() + ", sweepAngle:" + localArc.getSweepAngle());
    State localState = localArc.getState();
    if (localState == State.FRIST)
      this.mPaint.setColor(this.mArcColor1);
    while (true)
    {
      paramCanvas.drawArc(localRectF, localArc.getStartAngle(), localArc.getSweepAngle(), false, this.mPaint);
      break;
      if (localState == State.SECOND)
        this.mPaint.setColor(this.mArcColor2);
      else
        this.mPaint.setColor(this.mArcColor3);
    }
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    this.mWidth = getWidth();
    this.mHeight = getHeight();
    this.mLeft = paramInt1;
    this.mTop = paramInt2;
    this.mRight = paramInt3;
    this.mBottom = paramInt4;
    this.mInnerCircle = ((this.mRight - this.mLeft - this.mRingWidth) / 2);
    LogUtil.d("SleepView", "==============width:" + this.mWidth + ", height:" + this.mHeight + ", changed:" + paramBoolean + ", left:" + paramInt1 + ", top:" + paramInt2 + ", right:" + paramInt3 + ", bottom:" + paramInt4 + ", mInnerCircle:" + this.mInnerCircle + ", mRingWidth:" + this.mRingWidth);
  }

  public static class Arc
  {
    private int startAngle;
    private SleepView.State state;
    private int sweepAngle;

    public Arc(int paramInt1, int paramInt2, SleepView.State paramState)
    {
      this.startAngle = paramInt1;
      this.sweepAngle = paramInt2;
      this.state = paramState;
    }

    public int getStartAngle()
    {
      return this.startAngle;
    }

    public SleepView.State getState()
    {
      return this.state;
    }

    public int getSweepAngle()
    {
      return this.sweepAngle;
    }
  }

  public static enum State
  {
    static
    {
      State[] arrayOfState = new State[3];
      arrayOfState[0] = FRIST;
      arrayOfState[1] = SECOND;
      arrayOfState[2] = THIRD;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.SleepView
 * JD-Core Version:    0.6.2
 */