package com.baidu.wearable.ui.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Point;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import com.baidu.wearable.WearableApplication;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.sleep.Sleep;

public class SleepLayout extends RelativeLayout
{
  public static final String TAG = "SleepLayout";
  private final int NOTIFIER_HEIGHT_IN_DP = 12;
  private final int NOTIFIER_WIDTH_IN_DP = 12;
  private final int TEXT_HEIGHT_IN_DP = 15;
  private final int TEXT_PADDING_IN_DP = 12;
  private final int TEXT_WIDTH_IN_DP = 15;
  private boolean mIsNeedDrawSleep = false;
  private boolean mIsViewMeasured = false;
  private boolean mIsViewSetup = false;
  private LinearLayout mLinearSleepStatus;
  private int mMeasuredHeight = 0;
  private int mMeasuredWidth = 0;
  private Sleep mSleep;
  private ImageView mSleepImageView;
  private SleepTimeView mSleepTimeView;
  private TextView mTextNineClock;
  private TextView mTextSleepCondition;
  private TextView mTextSleepRecord;
  private TextView mTextSleepState;
  private TextView mTextSleepTotal;
  private ImageView mWakeImageView;

  public SleepLayout(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    Bitmap localBitmap = WearableApplication.getDeepSleepBitmap();
    if (localBitmap != null)
    {
      WindowManager localWindowManager = (WindowManager)getContext().getSystemService("window");
      DisplayMetrics localDisplayMetrics = new DisplayMetrics();
      localWindowManager.getDefaultDisplay().getMetrics(localDisplayMetrics);
      this.mMeasuredWidth = (localBitmap.getWidth() + (int)(54.0F * localDisplayMetrics.density));
      this.mMeasuredHeight = (localBitmap.getHeight() + (int)(54.0F * localDisplayMetrics.density));
    }
    LogUtil.d("SleepLayout", "SleepLayout mMeasuredWidth " + this.mMeasuredWidth + " mMeasuredHeight " + this.mMeasuredHeight);
  }

  private Point getPosForIdentifier(int paramInt, boolean paramBoolean)
  {
    Point localPoint = null;
    int k;
    int m;
    int n;
    label150: int i2;
    label212: int i3;
    if (-1 != paramInt)
    {
      SleepTimeView localSleepTimeView = this.mSleepTimeView;
      localPoint = null;
      if (localSleepTimeView != null)
      {
        localPoint = new Point(0, 0);
        int[] arrayOfInt1 = new int[2];
        int[] arrayOfInt2 = new int[2];
        getLocationOnScreen(arrayOfInt1);
        this.mSleepTimeView.getLocationOnScreen(arrayOfInt2);
        int i = this.mSleepTimeView.getWidth() / 2 + (arrayOfInt2[0] - arrayOfInt1[0]);
        int j = this.mSleepTimeView.getHeight() / 2 + (arrayOfInt2[1] - arrayOfInt1[1]);
        k = this.mTextNineClock.getWidth();
        if (WearableApplication.getNightBitmap() == null)
          break label254;
        m = Math.max(WearableApplication.getNightBitmap().getWidth(), WearableApplication.getNightBitmap().getHeight());
        if (!paramBoolean)
          break label261;
        n = m + (k + this.mSleepTimeView.getWidth() / 2);
        localPoint.x = (i + (int)(n * Math.sin(Math.toRadians(paramInt))));
        localPoint.y = (j - (int)(n * Math.cos(Math.toRadians(paramInt))));
        int i1 = localPoint.x;
        if (WearableApplication.getNightBitmap() == null)
          break label283;
        i2 = WearableApplication.getNightBitmap().getWidth() / 2;
        localPoint.x = (i1 - i2);
        i3 = localPoint.y;
        if (WearableApplication.getNightBitmap() == null)
          break label290;
      }
    }
    label261: label283: label290: for (int i4 = WearableApplication.getNightBitmap().getHeight() / 2; ; i4 = 12)
    {
      localPoint.y = (i3 - i4);
      return localPoint;
      label254: m = 30;
      break;
      n = k + this.mSleepTimeView.getWidth() / 2 + m * 2;
      break label150;
      i2 = 12;
      break label212;
    }
  }

  private void setViewVisibleOrInVisible(View paramView, boolean paramBoolean)
  {
    if (paramView != null)
    {
      if ((!paramBoolean) || (paramView.getVisibility() == 0))
        break label50;
      paramView.setVisibility(0);
    }
    while (true)
    {
      if (paramView == this.mTextSleepState)
        LogUtil.d("SleepState", "sleepState changed " + paramBoolean);
      return;
      label50: if ((!paramBoolean) && (paramView.getVisibility() != 4))
        paramView.setVisibility(4);
    }
  }

  private void updateClockStatusView()
  {
    if (!this.mIsViewSetup)
    {
      this.mSleepImageView = ((ImageView)findViewById(2131230996));
      this.mWakeImageView = ((ImageView)findViewById(2131230997));
      this.mLinearSleepStatus = ((LinearLayout)findViewById(2131230989));
      this.mTextSleepTotal = ((TextView)findViewById(2131230991));
      this.mTextSleepCondition = ((TextView)findViewById(2131230992));
      this.mTextNineClock = ((TextView)findViewById(2131230985));
      this.mTextSleepState = ((TextView)findViewById(2131230981));
      this.mTextSleepRecord = ((TextView)findViewById(2131230993));
      this.mIsViewSetup = true;
    }
    if (this.mSleep != null)
    {
      this.mSleepImageView.setVisibility(0);
      this.mWakeImageView.setVisibility(0);
      int i = SleepTimeView.getDegreeOnClockForTime(this.mSleep.getStartSleepInSeconds());
      LogUtil.d("FlipActivity", "the start time is " + this.mSleep.getStartSleepInSeconds());
      Point localPoint1 = null;
      if (-1 != i)
        localPoint1 = getPosForIdentifier(i, true);
      if (localPoint1 != null)
      {
        RelativeLayout.LayoutParams localLayoutParams2 = (RelativeLayout.LayoutParams)this.mSleepImageView.getLayoutParams();
        localLayoutParams2.leftMargin = localPoint1.x;
        localLayoutParams2.topMargin = localPoint1.y;
        this.mSleepImageView.setLayoutParams(localLayoutParams2);
        int j = SleepTimeView.getDegreeOnClockForTime(this.mSleep.getEndSleepInSeconds());
        Object[] arrayOfObject1 = new Object[2];
        arrayOfObject1[0] = Long.valueOf(this.mSleep.getEndSleepInSeconds());
        arrayOfObject1[1] = Integer.valueOf(j);
        LogUtil.d("FlipActivity", String.format("end sleep time is %d and wakeDegree is %d", arrayOfObject1));
        Point localPoint2 = null;
        if (-1 != j)
          localPoint2 = getPosForIdentifier(j, false);
        if (localPoint2 == null)
          break label491;
        RelativeLayout.LayoutParams localLayoutParams1 = (RelativeLayout.LayoutParams)this.mWakeImageView.getLayoutParams();
        localLayoutParams1.leftMargin = localPoint2.x;
        localLayoutParams1.topMargin = localPoint2.y;
        this.mWakeImageView.setLayoutParams(localLayoutParams1);
      }
      while (true)
      {
        int k = (int)(this.mSleep.getTotalSleepInSeconds() / 3600L);
        int m = (int)(this.mSleep.getTotalSleepInSeconds() % 3600L / 60L);
        TextView localTextView = this.mTextSleepTotal;
        Object[] arrayOfObject2 = new Object[2];
        arrayOfObject2[0] = Integer.valueOf(k);
        arrayOfObject2[1] = Integer.valueOf(m);
        localTextView.setText(String.format("%d:%02d", arrayOfObject2));
        int n = (int)(100.0D * this.mSleep.getSleepEfficiency());
        this.mTextSleepCondition.setText(getResources().getString(2131296503) + n + "%");
        return;
        this.mSleepImageView.setVisibility(8);
        break;
        label491: this.mWakeImageView.setVisibility(8);
      }
    }
    this.mSleepImageView.setVisibility(4);
    this.mWakeImageView.setVisibility(4);
    this.mTextSleepTotal.setText(getContext().getString(2131296501));
    this.mTextSleepCondition.setText(getContext().getString(2131296504));
  }

  public void forceSetSleep(Sleep paramSleep)
  {
    this.mIsNeedDrawSleep = true;
    this.mSleep = paramSleep;
    if (this.mSleepTimeView != null)
      this.mSleepTimeView.setSleep(paramSleep);
  }

  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    LogUtil.d("FlipActivity", "SleepLayout onDraw");
    if (this.mIsNeedDrawSleep)
      this.mIsNeedDrawSleep = false;
  }

  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    this.mIsViewMeasured = true;
  }

  protected void onMeasure(int paramInt1, int paramInt2)
  {
    super.onMeasure(paramInt1, paramInt2);
  }

  public void onWindowFocusChanged(boolean paramBoolean)
  {
    super.onWindowFocusChanged(paramBoolean);
    LogUtil.d("FlipActivity", "SleepLayout onWindowFocus  Changed");
    if (this.mIsNeedDrawSleep)
    {
      this.mIsNeedDrawSleep = false;
      updateClockStatusView();
    }
  }

  public void setSleep(Sleep paramSleep)
  {
    if (((paramSleep != null) && (this.mSleep != null) && (this.mSleep.compareTo(paramSleep) != 0)) || ((paramSleep == null) && (this.mSleep != null)) || ((paramSleep != null) && (this.mSleep == null)))
    {
      this.mIsNeedDrawSleep = true;
      this.mSleep = paramSleep;
      if (this.mSleepTimeView == null)
      {
        View localView = findViewById(2131230988);
        if ((localView != null) && ((localView instanceof SleepTimeView)))
          this.mSleepTimeView = ((SleepTimeView)localView);
      }
      if (this.mSleepTimeView != null)
        this.mSleepTimeView.setSleep(paramSleep);
      if (this.mIsViewMeasured)
      {
        updateClockStatusView();
        this.mIsNeedDrawSleep = false;
      }
    }
  }

  public void updateAccordingSleepState(boolean paramBoolean)
  {
    if (!this.mIsViewSetup)
    {
      this.mSleepImageView = ((ImageView)findViewById(2131230996));
      this.mWakeImageView = ((ImageView)findViewById(2131230997));
      this.mLinearSleepStatus = ((LinearLayout)findViewById(2131230989));
      this.mTextSleepTotal = ((TextView)findViewById(2131230991));
      this.mTextSleepCondition = ((TextView)findViewById(2131230992));
      this.mTextNineClock = ((TextView)findViewById(2131230985));
      this.mTextSleepState = ((TextView)findViewById(2131230981));
      this.mTextSleepRecord = ((TextView)findViewById(2131230993));
      this.mIsViewSetup = true;
    }
    LogUtil.d("SleepState", "SleepState is " + this.mTextSleepState);
    LogUtil.d("SleepState", "mTextSleepRecord is " + this.mTextSleepRecord);
    if (paramBoolean)
    {
      setViewVisibleOrInVisible(this.mSleepTimeView, false);
      setViewVisibleOrInVisible(this.mSleepImageView, false);
      setViewVisibleOrInVisible(this.mWakeImageView, false);
      setViewVisibleOrInVisible(this.mLinearSleepStatus, false);
      setViewVisibleOrInVisible(this.mTextSleepState, true);
      setViewVisibleOrInVisible(this.mTextSleepRecord, true);
      return;
    }
    setViewVisibleOrInVisible(this.mSleepTimeView, true);
    if (this.mSleep != null)
    {
      setViewVisibleOrInVisible(this.mSleepImageView, true);
      if (this.mSleep == null)
        break label306;
      setViewVisibleOrInVisible(this.mWakeImageView, true);
    }
    while (true)
    {
      setViewVisibleOrInVisible(this.mLinearSleepStatus, true);
      setViewVisibleOrInVisible(this.mTextSleepState, false);
      setViewVisibleOrInVisible(this.mTextSleepRecord, false);
      return;
      setViewVisibleOrInVisible(this.mSleepImageView, false);
      break;
      label306: setViewVisibleOrInVisible(this.mWakeImageView, false);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.SleepLayout
 * JD-Core Version:    0.6.2
 */