package com.baidu.wearable.ui.view;

import android.content.Context;
import android.util.Pair;
import android.view.View;
import com.baidu.wearable.ble.util.LogUtil;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.achartengine.GraphicalView;
import org.achartengine.chart.BarScatterChart;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

public class MyBarChart
{
  private static final SimpleDateFormat SDF = new SimpleDateFormat("HH:mm");
  private double mChartEndTime;
  private double mChartStartTime;
  private Context mContext;
  private List<Pair<Double, Double>> mDataList;
  private double mEndTime;
  private double mSleepEndTime;
  private double mSleepStartTime;
  private double mStartTime;

  public MyBarChart(Context paramContext, List<Pair<Double, Double>> paramList)
  {
    this.mContext = paramContext;
    this.mDataList = paramList;
  }

  private XYMultipleSeriesDataset getDemoDataset()
  {
    XYMultipleSeriesDataset localXYMultipleSeriesDataset = new XYMultipleSeriesDataset();
    XYSeries localXYSeries = new XYSeries("Demo series ");
    if (this.mDataList == null)
    {
      localXYSeries.add(0.0D, 0.0D);
      localXYSeries.add(0.0D, 0.0D);
      localXYSeries.add(0.0D, 0.0D);
    }
    while (true)
    {
      localXYMultipleSeriesDataset.addSeries(localXYSeries);
      return localXYMultipleSeriesDataset;
      this.mStartTime = ((Double)((Pair)this.mDataList.get(0)).first).doubleValue();
      this.mEndTime = ((Double)((Pair)this.mDataList.get(0)).second).doubleValue();
      this.mSleepStartTime = ((Double)((Pair)this.mDataList.get(1)).first).doubleValue();
      this.mSleepEndTime = ((Double)((Pair)this.mDataList.get(1)).second).doubleValue();
      localXYSeries.add(0.0D, 3.0D);
      localXYSeries.add(this.mSleepStartTime - 3600.0D * this.mChartStartTime, 3.0D);
      for (int i = 2; i < this.mDataList.size(); i++)
        localXYSeries.add(((Double)((Pair)this.mDataList.get(i)).second).doubleValue() + this.mSleepStartTime - 3600.0D * this.mChartStartTime, ((Double)((Pair)this.mDataList.get(i)).first).doubleValue());
    }
  }

  private XYMultipleSeriesRenderer getDemoRenderer()
  {
    XYMultipleSeriesRenderer localXYMultipleSeriesRenderer = new XYMultipleSeriesRenderer();
    double d2;
    double d1;
    String[] arrayOfString;
    int i;
    String str1;
    String str2;
    if (this.mDataList != null)
    {
      this.mStartTime = ((Double)((Pair)this.mDataList.get(0)).first).doubleValue();
      this.mEndTime = ((Double)((Pair)this.mDataList.get(0)).second).doubleValue();
      this.mSleepStartTime = ((Double)((Pair)this.mDataList.get(1)).first).doubleValue();
      this.mSleepEndTime = ((Double)((Pair)this.mDataList.get(1)).second).doubleValue();
      this.mChartStartTime = Math.floor(1000.0D * this.mStartTime / 3600000.0D);
      this.mChartEndTime = Math.ceil(1000.0D * this.mEndTime / 3600000.0D);
      d2 = this.mChartEndTime - this.mChartStartTime;
      d1 = 3600000.0D * (this.mChartEndTime - this.mChartStartTime) / 1000.0D;
      LogUtil.d("-----totalHours--" + d2, "------XAxisMax--" + d1 + "--start date--" + new Date(()(3600000.0D * this.mChartStartTime)).toString() + "--end date--" + new Date(()(3600000.0D * this.mChartEndTime)).toString() + "--mSleepStartTime-" + new Date(()(1000.0D * ((Double)((Pair)this.mDataList.get(1)).first).doubleValue())).toString() + "--mSleepEndTime-" + new Date(()(1000.0D * ((Double)((Pair)this.mDataList.get(1)).second).doubleValue())).toString());
      arrayOfString = new String[3];
      i = 0;
      if ((i >= arrayOfString.length) || (d2 < 4.0D))
      {
        localXYMultipleSeriesRenderer.setStartX((this.mStartTime - 3600.0D * this.mChartStartTime) / d1);
        localXYMultipleSeriesRenderer.setEndX(1.0D - (3600.0D * this.mChartEndTime - this.mEndTime) / d1);
        localXYMultipleSeriesRenderer.setXReferLabelContent(arrayOfString);
        str1 = getTimeBySec(this.mStartTime);
        str2 = getTimeBySec(this.mEndTime);
      }
    }
    while (true)
    {
      localXYMultipleSeriesRenderer.setShowLabels(true);
      localXYMultipleSeriesRenderer.setAxisTitleTextSize(16.0F);
      localXYMultipleSeriesRenderer.setChartTitleTextSize(20.0F);
      localXYMultipleSeriesRenderer.setLabelsTextSize(15.0F);
      localXYMultipleSeriesRenderer.setLegendTextSize(15.0F);
      localXYMultipleSeriesRenderer.setShowLegend(false);
      localXYMultipleSeriesRenderer.setPointSize(5.0F);
      int[] arrayOfInt1 = new int[4];
      arrayOfInt1[1] = 80;
      arrayOfInt1[2] = 80;
      arrayOfInt1[3] = 80;
      localXYMultipleSeriesRenderer.setMargins(arrayOfInt1);
      localXYMultipleSeriesRenderer.setShowGrid(true);
      localXYMultipleSeriesRenderer.setPanEnabled(false, false);
      localXYMultipleSeriesRenderer.setZoomEnabled(false, false);
      int[] arrayOfInt2 = new int[4];
      arrayOfInt2[0] = -25;
      arrayOfInt2[1] = 20;
      localXYMultipleSeriesRenderer.setXReferLabelMargin(arrayOfInt2);
      localXYMultipleSeriesRenderer.setStartXLabel(str1);
      localXYMultipleSeriesRenderer.setEndXLabel(str2);
      localXYMultipleSeriesRenderer.setXReferLabelColor(-12566464);
      localXYMultipleSeriesRenderer.setXReferLabelSize(36);
      XYSeriesRenderer localXYSeriesRenderer = new XYSeriesRenderer();
      localXYSeriesRenderer.setPointStyle(PointStyle.BAR);
      localXYSeriesRenderer.setColor(-16711936);
      localXYSeriesRenderer.setFillPoints(true);
      localXYMultipleSeriesRenderer.setXAxisMin(0.0D);
      localXYMultipleSeriesRenderer.setXAxisMax(d1);
      localXYMultipleSeriesRenderer.setYAxisMin(0.0D);
      localXYMultipleSeriesRenderer.setYAxisMax(2.0D);
      localXYMultipleSeriesRenderer.setXLabels(3);
      localXYMultipleSeriesRenderer.setXBackgroudCount((int)d2);
      localXYMultipleSeriesRenderer.addSeriesRenderer(localXYSeriesRenderer);
      localXYMultipleSeriesRenderer.setAxesColor(-3355444);
      localXYMultipleSeriesRenderer.setLabelsColor(-3355444);
      return localXYMultipleSeriesRenderer;
      arrayOfString[i] = getTimeByHour(this.mChartStartTime + d2 / 4.0D * (i + 1));
      LogUtil.d("---i---" + i, "-------xlabels[i]-" + arrayOfString[i]);
      i++;
      break;
      d1 = 12.0D;
      d2 = 10.0D;
      str1 = "22:00";
      str2 = "8:00";
      localXYMultipleSeriesRenderer.setStartX(0.0D);
      localXYMultipleSeriesRenderer.setEndX(1.0D);
      localXYMultipleSeriesRenderer.setXReferLabelContent(new String[] { "00:30", "3:00", "5:30" });
    }
  }

  private String getTimeByHour(double paramDouble)
  {
    return SDF.format(new Date(()(3600000.0D * paramDouble)));
  }

  private String getTimeBySec(double paramDouble)
  {
    return SDF.format(new Date(()(1000.0D * paramDouble)));
  }

  public View getXYChart()
  {
    XYMultipleSeriesRenderer localXYMultipleSeriesRenderer = getDemoRenderer();
    XYMultipleSeriesDataset localXYMultipleSeriesDataset = getDemoDataset();
    BarScatterChart localBarScatterChart = new BarScatterChart(this.mContext, localXYMultipleSeriesDataset, localXYMultipleSeriesRenderer, new int[] { 2130837563, 2130837673 });
    return new GraphicalView(this.mContext, localBarScatterChart);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.MyBarChart
 * JD-Core Version:    0.6.2
 */