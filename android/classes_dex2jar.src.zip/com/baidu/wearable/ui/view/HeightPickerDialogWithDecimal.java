package com.baidu.wearable.ui.view;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

public class HeightPickerDialogWithDecimal extends AlertDialog
{
  private Context mContext;
  private HeightPickerWithDecimal mHeightPicker;

  public HeightPickerDialogWithDecimal(Context paramContext, final OnHeightSetListener paramOnHeightSetListener)
  {
    super(paramContext);
    this.mContext = paramContext;
    setIcon(0);
    setTitle(2131296448);
    Context localContext = getContext();
    setButton(-1, localContext.getText(2131296453), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        if (paramOnHeightSetListener != null)
          paramOnHeightSetListener.onHeightSet(HeightPickerDialogWithDecimal.this.mHeightPicker, HeightPickerDialogWithDecimal.this.mHeightPicker.getCurrentInteger(), HeightPickerDialogWithDecimal.this.mHeightPicker.getCurrentDecimal());
      }
    });
    setButton(-2, localContext.getText(2131296454), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        Toast.makeText(HeightPickerDialogWithDecimal.this.mContext, "cancel", 0).show();
      }
    });
    View localView = ((LayoutInflater)localContext.getSystemService("layout_inflater")).inflate(2130903078, null);
    setView(localView);
    this.mHeightPicker = ((HeightPickerWithDecimal)localView.findViewById(2131231046));
    this.mHeightPicker.setOnHeightChangeListener(new HeightPickerWithDecimal.OnHeightChangedListener()
    {
      public void onHeightChanged(HeightPickerWithDecimal paramAnonymousHeightPickerWithDecimal, int paramAnonymousInt1, int paramAnonymousInt2)
      {
      }
    });
  }

  public static abstract interface OnHeightSetListener
  {
    public abstract void onHeightSet(HeightPickerWithDecimal paramHeightPickerWithDecimal, int paramInt1, int paramInt2);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.view.HeightPickerDialogWithDecimal
 * JD-Core Version:    0.6.2
 */