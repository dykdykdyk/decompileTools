package com.baidu.wearable.ui.bean;

public enum SportsChartFuncType
{
  static
  {
    CALORIE = new SportsChartFuncType("CALORIE", 1);
    DISTANCE = new SportsChartFuncType("DISTANCE", 2);
    SportsChartFuncType[] arrayOfSportsChartFuncType = new SportsChartFuncType[3];
    arrayOfSportsChartFuncType[0] = STEP;
    arrayOfSportsChartFuncType[1] = CALORIE;
    arrayOfSportsChartFuncType[2] = DISTANCE;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.bean.SportsChartFuncType
 * JD-Core Version:    0.6.2
 */