package com.baidu.wearable.ui.bean;

public enum SleepChartFuncType
{
  static
  {
    SLEEP_EFFI = new SleepChartFuncType("SLEEP_EFFI", 1);
    SLEEP_CONSUME = new SleepChartFuncType("SLEEP_CONSUME", 2);
    SleepChartFuncType[] arrayOfSleepChartFuncType = new SleepChartFuncType[3];
    arrayOfSleepChartFuncType[0] = TOTAL_SLEEP;
    arrayOfSleepChartFuncType[1] = SLEEP_EFFI;
    arrayOfSleepChartFuncType[2] = SLEEP_CONSUME;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.bean.SleepChartFuncType
 * JD-Core Version:    0.6.2
 */