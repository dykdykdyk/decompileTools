package com.baidu.wearable.ui.bean;

public enum ChartDateType
{
  static
  {
    MONTH = new ChartDateType("MONTH", 2);
    ChartDateType[] arrayOfChartDateType = new ChartDateType[3];
    arrayOfChartDateType[0] = DAY;
    arrayOfChartDateType[1] = WEEK;
    arrayOfChartDateType[2] = MONTH;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.bean.ChartDateType
 * JD-Core Version:    0.6.2
 */