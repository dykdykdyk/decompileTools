package com.baidu.wearable.ui.bean;

import com.baidu.wearable.util.MathUtil;

public class SportData
{
  public double[] calories;
  public double[] distances;
  private int mCount = 0;
  public double[] steps;

  public SportData(int paramInt)
  {
    this.mCount = paramInt;
    if (this.steps == null)
      this.steps = new double[paramInt];
    if (this.calories == null)
      this.calories = new double[paramInt];
    if (this.distances == null)
      this.distances = new double[paramInt];
  }

  private double avg(double[] paramArrayOfDouble)
  {
    return sum(paramArrayOfDouble) / this.mCount;
  }

  private double sum(double[] paramArrayOfDouble)
  {
    double d = 0.0D;
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfDouble.length)
        return d;
      d += paramArrayOfDouble[i];
    }
  }

  public int getCaloriesAvg()
  {
    return (int)avg(this.calories);
  }

  public int getCaloriesTotal()
  {
    return (int)sum(this.calories);
  }

  public double getDistancesAvg()
  {
    return MathUtil.convert(avg(this.distances));
  }

  public double getDistancesTotal()
  {
    return MathUtil.convert(sum(this.distances));
  }

  public int getStepsAvg()
  {
    return (int)avg(this.steps);
  }

  public int getStepsTotal()
  {
    return (int)sum(this.steps);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.bean.SportData
 * JD-Core Version:    0.6.2
 */