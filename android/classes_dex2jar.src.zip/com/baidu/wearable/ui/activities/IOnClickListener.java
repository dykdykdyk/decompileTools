package com.baidu.wearable.ui.activities;

public abstract interface IOnClickListener
{
  public abstract void onNegtiveButtonClicked();

  public abstract void onPositiveButtonClicked();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.IOnClickListener
 * JD-Core Version:    0.6.2
 */