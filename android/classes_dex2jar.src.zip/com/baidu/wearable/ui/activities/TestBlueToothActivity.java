package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SleepDao;
import com.baidu.wearable.sleep.Sleep;
import com.baidu.wearable.sleep.SleepController;
import com.baidu.wearable.sleep.SleepController.SleepDetailListener;
import com.baidu.wearable.sleep.SleepController.SleepDurationListener;
import com.baidu.wearable.sleep.SleepController.SleepListener;
import com.baidu.wearable.sleep.SleepDetail;
import com.baidu.wearable.sleep.SleepDuration;
import com.baidu.wearable.sleep.SleepSettingDetail;
import com.baidu.wearable.sleep.SleepSettingState;
import com.baidu.wearable.sleep.SleepSlot;
import com.baidu.wearable.sleep.SleepState;
import com.baidu.wearable.util.TimeUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class TestBlueToothActivity extends Activity
{
  private static final int DAYS = 32;
  private static final String TAG = "TestBlueToothActivity";
  private Button addDurationButton;
  private Button addSleepButton;
  private Button clearButton;
  private Button clearDbButton;
  private Button durationButton;
  private EditText endDay;
  private EditText endHour;
  private EditText endMinute;
  private EditText eventDay;
  private EditText eventHour;
  private EditText eventMinute;
  private Handler mHandler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      String str = (String)paramAnonymousMessage.getData().get("test");
      TestBlueToothActivity.this.sleepResultShow.setText(str);
    }
  };
  private String result = "";
  private Button resultButton;
  private Button sleepButton;
  private Button sleepDetailCommit;
  private Button sleepEndCommit;
  private TextView sleepResultShow;
  private Button sleepStartCommit;
  private EditText sleepState;
  private EditText startDay;
  private EditText startHour;
  private EditText startMinute;

  private void setupViewsForClear()
  {
    this.clearDbButton = ((Button)findViewById(2131230741));
    this.clearButton = ((Button)findViewById(2131230740));
    this.clearDbButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        SQLiteDatabase localSQLiteDatabase = Database.getDb(TestBlueToothActivity.this);
        SleepDao.clearSleepDetail(localSQLiteDatabase);
        SleepDao.clearSleepDuration(localSQLiteDatabase);
      }
    });
    this.clearButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        TestBlueToothActivity.this.result = "";
        Bundle localBundle = new Bundle();
        localBundle.putString("test", TestBlueToothActivity.this.result);
        Message localMessage = new Message();
        localMessage.setData(localBundle);
        TestBlueToothActivity.this.mHandler.sendMessage(localMessage);
      }
    });
  }

  private void setupViewsForSleepTestInput()
  {
    this.startDay = ((EditText)findViewById(2131230744));
    this.startHour = ((EditText)findViewById(2131230745));
    this.startMinute = ((EditText)findViewById(2131230746));
    this.endDay = ((EditText)findViewById(2131230750));
    this.endHour = ((EditText)findViewById(2131230751));
    this.endMinute = ((EditText)findViewById(2131230752));
    this.sleepStartCommit = ((Button)findViewById(2131230747));
    this.sleepEndCommit = ((Button)findViewById(2131230753));
    this.eventDay = ((EditText)findViewById(2131230756));
    this.eventHour = ((EditText)findViewById(2131230757));
    this.eventMinute = ((EditText)findViewById(2131230758));
    this.sleepState = ((EditText)findViewById(2131230759));
    this.sleepDetailCommit = ((Button)findViewById(2131230760));
    this.sleepStartCommit.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        String str1 = TestBlueToothActivity.this.startDay.getText().toString();
        String str2 = TestBlueToothActivity.this.startHour.getText().toString();
        String str3 = TestBlueToothActivity.this.startMinute.getText().toString();
        if ((str1.equals("")) || (str2.equals("")) || (str3.equals("")))
        {
          Toast.makeText(TestBlueToothActivity.this, "杈撳叆閿欒", 0).show();
          return;
        }
        int i = Integer.valueOf(str1).intValue();
        int j = Integer.valueOf(str2).intValue();
        int k = Integer.valueOf(str3).intValue();
        Calendar localCalendar = Calendar.getInstance();
        localCalendar.set(localCalendar.get(1), localCalendar.get(2), i, j, k, 0);
        ArrayList localArrayList = new ArrayList();
        long l = localCalendar.getTimeInMillis();
        String str4 = TimeUtil.getDate(l);
        localArrayList.add(new SleepSettingDetail(l / 1000L, str4, SleepSettingState.SLEEP_MODE));
        TestBlueToothActivity localTestBlueToothActivity = TestBlueToothActivity.this;
        String str5 = localTestBlueToothActivity.result;
        StringBuilder localStringBuilder = new StringBuilder(String.valueOf(str5));
        localTestBlueToothActivity.result = ("startTime:" + l / 1000L + "\n");
        Bundle localBundle = new Bundle();
        localBundle.putString("test", TestBlueToothActivity.this.result);
        Message localMessage = new Message();
        localMessage.setData(localBundle);
        TestBlueToothActivity.this.mHandler.sendMessage(localMessage);
        SleepController.addSleepSettingTask(TestBlueToothActivity.this, localArrayList);
      }
    });
    this.sleepEndCommit.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        String str1 = TestBlueToothActivity.this.endDay.getText().toString();
        String str2 = TestBlueToothActivity.this.endHour.getText().toString();
        String str3 = TestBlueToothActivity.this.endMinute.getText().toString();
        if ((str1.equals("")) || (str2.equals("")) || (str3.equals("")))
        {
          Toast.makeText(TestBlueToothActivity.this, "杈撳叆閿欒", 0).show();
          return;
        }
        int i = Integer.valueOf(str1).intValue();
        int j = Integer.valueOf(str2).intValue();
        int k = Integer.valueOf(str3).intValue();
        Calendar localCalendar = Calendar.getInstance();
        localCalendar.set(localCalendar.get(1), localCalendar.get(2), i, j, k, 0);
        ArrayList localArrayList = new ArrayList();
        long l = localCalendar.getTimeInMillis();
        String str4 = TimeUtil.getDate(l);
        localArrayList.add(new SleepSettingDetail(l / 1000L, str4, SleepSettingState.SPORT_MODE));
        TestBlueToothActivity localTestBlueToothActivity = TestBlueToothActivity.this;
        String str5 = localTestBlueToothActivity.result;
        StringBuilder localStringBuilder = new StringBuilder(String.valueOf(str5));
        localTestBlueToothActivity.result = ("endTime:" + l / 1000L + "\n");
        Bundle localBundle = new Bundle();
        localBundle.putString("test", TestBlueToothActivity.this.result);
        Message localMessage = new Message();
        localMessage.setData(localBundle);
        TestBlueToothActivity.this.mHandler.sendMessage(localMessage);
        SleepController.addSleepSettingTask(TestBlueToothActivity.this, localArrayList);
      }
    });
    this.sleepDetailCommit.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        String str1 = TestBlueToothActivity.this.eventDay.getText().toString();
        String str2 = TestBlueToothActivity.this.eventHour.getText().toString();
        String str3 = TestBlueToothActivity.this.eventMinute.getText().toString();
        if ((str1.equals("")) || (str2.equals("")) || (str3.equals("")))
        {
          Toast.makeText(TestBlueToothActivity.this, "杈撳叆閿欒", 0).show();
          return;
        }
        int i = Integer.valueOf(str1).intValue();
        int j = Integer.valueOf(str2).intValue();
        int k = Integer.valueOf(str3).intValue();
        Calendar localCalendar = Calendar.getInstance();
        localCalendar.set(localCalendar.get(1), localCalendar.get(2), i, j, k, 0);
        String str4 = TestBlueToothActivity.this.sleepState.getText().toString();
        ArrayList localArrayList = new ArrayList();
        long l = localCalendar.getTimeInMillis();
        String str5 = TimeUtil.getDate(l);
        int m = Integer.valueOf(str4).intValue();
        if ((m == 1) || (m == 2) || (m == 3))
        {
          localArrayList.add(new SleepDetail(l / 1000L, str5, SleepState.valueOf(m)));
          TestBlueToothActivity localTestBlueToothActivity = TestBlueToothActivity.this;
          String str6 = localTestBlueToothActivity.result;
          StringBuilder localStringBuilder = new StringBuilder(String.valueOf(str6));
          localTestBlueToothActivity.result = ("event time:" + l / 1000L + ", state:" + SleepState.valueOf(m) + "\n");
          Bundle localBundle = new Bundle();
          localBundle.putString("test", TestBlueToothActivity.this.result);
          Message localMessage = new Message();
          localMessage.setData(localBundle);
          TestBlueToothActivity.this.mHandler.sendMessage(localMessage);
          SleepController.saveSleepToDb(TestBlueToothActivity.this, localArrayList, true);
          return;
        }
        Toast.makeText(TestBlueToothActivity.this, "杈撳叆鏃堕棿鎴栫姸鎬佸�间笉瀵�", 0).show();
      }
    });
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903041);
    setupViewsForClear();
    setupViewsForSleepTestInput();
    this.sleepResultShow = ((TextView)findViewById(2131230761));
    this.durationButton = ((Button)findViewById(2131230735));
    this.sleepButton = ((Button)findViewById(2131230736));
    this.resultButton = ((Button)findViewById(2131230737));
    this.addDurationButton = ((Button)findViewById(2131230738));
    this.addSleepButton = ((Button)findViewById(2131230739));
    this.durationButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        long l1 = TimeUtil.getDayStartTimestamp(32) / 1000L;
        long l2 = 2764800L + TimeUtil.getDayStartTimestamp() / 1000L;
        SleepController.getSleepDurations(TestBlueToothActivity.this, l1, l2, new SleepController.SleepDurationListener()
        {
          public void onReceive(List<SleepDuration> paramAnonymous2List)
          {
            LogUtil.d("TestBlueToothActivity", "receive sleep duration, count:" + paramAnonymous2List.size());
            TestBlueToothActivity localTestBlueToothActivity1 = TestBlueToothActivity.this;
            localTestBlueToothActivity1.result += "===================sleep duration\n";
            TestBlueToothActivity localTestBlueToothActivity2 = TestBlueToothActivity.this;
            localTestBlueToothActivity2.result = (localTestBlueToothActivity2.result + "sleep db duration data count:" + paramAnonymous2List.size() + "\n");
            Iterator localIterator = paramAnonymous2List.iterator();
            while (true)
            {
              if (!localIterator.hasNext())
              {
                Bundle localBundle = new Bundle();
                localBundle.putString("test", TestBlueToothActivity.this.result);
                Message localMessage = new Message();
                localMessage.setData(localBundle);
                TestBlueToothActivity.this.mHandler.sendMessage(localMessage);
                return;
              }
              SleepDuration localSleepDuration = (SleepDuration)localIterator.next();
              TestBlueToothActivity localTestBlueToothActivity3 = TestBlueToothActivity.this;
              localTestBlueToothActivity3.result = (localTestBlueToothActivity3.result + "|startTime:" + localSleepDuration.getStartTime() + ", endTime:" + localSleepDuration.getEndTime() + "|\n");
            }
          }
        });
      }
    });
    this.sleepButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        long l1 = TimeUtil.getDayStartTimestamp(32) / 1000L;
        long l2 = 86400L + TimeUtil.getDayStartTimestamp() / 1000L;
        SleepController.getSleepDetails(TestBlueToothActivity.this, new SleepDuration(l1, l2), new SleepController.SleepDetailListener()
        {
          public void onReceive(List<SleepDetail> paramAnonymous2List)
          {
            LogUtil.d("TestBlueToothActivity", "receive sleep detail, count:" + paramAnonymous2List.size());
            TestBlueToothActivity localTestBlueToothActivity1 = TestBlueToothActivity.this;
            localTestBlueToothActivity1.result += "===================sleep detail\n";
            TestBlueToothActivity localTestBlueToothActivity2 = TestBlueToothActivity.this;
            localTestBlueToothActivity2.result = (localTestBlueToothActivity2.result + "sleep db detail data count:" + paramAnonymous2List.size() + "\n");
            Iterator localIterator = paramAnonymous2List.iterator();
            while (true)
            {
              if (!localIterator.hasNext())
              {
                Bundle localBundle = new Bundle();
                localBundle.putString("test", TestBlueToothActivity.this.result);
                Message localMessage = new Message();
                localMessage.setData(localBundle);
                TestBlueToothActivity.this.mHandler.sendMessage(localMessage);
                return;
              }
              SleepDetail localSleepDetail = (SleepDetail)localIterator.next();
              TestBlueToothActivity localTestBlueToothActivity3 = TestBlueToothActivity.this;
              localTestBlueToothActivity3.result = (localTestBlueToothActivity3.result + "|timestamp:" + localSleepDetail.getTimestampS() + ", date:" + localSleepDetail.getDate() + ", state:" + localSleepDetail.getState() + "|\n");
            }
          }
        });
      }
    });
    this.resultButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        SleepController.getMaxSleepSomeDays(TestBlueToothActivity.this, 32, new SleepController.SleepListener()
        {
          public void onReceive(List<Sleep> paramAnonymous2List)
          {
            LogUtil.d("TestBlueToothActivity", "receive sleep db, count:" + paramAnonymous2List.size());
            TestBlueToothActivity localTestBlueToothActivity1 = TestBlueToothActivity.this;
            localTestBlueToothActivity1.result += "===================sleep\n";
            TestBlueToothActivity localTestBlueToothActivity2 = TestBlueToothActivity.this;
            localTestBlueToothActivity2.result = (localTestBlueToothActivity2.result + "sleep db data count:" + paramAnonymous2List.size() + "\n");
            Iterator localIterator1 = paramAnonymous2List.iterator();
            Sleep localSleep;
            List localList1;
            do
            {
              if (!localIterator1.hasNext())
              {
                Bundle localBundle = new Bundle();
                localBundle.putString("test", TestBlueToothActivity.this.result);
                Message localMessage = new Message();
                localMessage.setData(localBundle);
                TestBlueToothActivity.this.mHandler.sendMessage(localMessage);
                return;
              }
              localSleep = (Sleep)localIterator1.next();
              SleepDuration localSleepDuration = localSleep.getSleepDuration();
              TestBlueToothActivity localTestBlueToothActivity3 = TestBlueToothActivity.this;
              localTestBlueToothActivity3.result += "===================\n";
              TestBlueToothActivity localTestBlueToothActivity4 = TestBlueToothActivity.this;
              localTestBlueToothActivity4.result = (localTestBlueToothActivity4.result + "|startTime:" + localSleepDuration.getStartTime() + ", endTime:" + localSleepDuration.getEndTime() + ", date:" + localSleep.getDate() + ", totalDurationTime:" + localSleep.getSleepDuration().getTotalTime() + ", totalTime:" + localSleep.getTotalSleepInSeconds() + ", fallTime:" + localSleep.getFallAsleepInSeconds() + ", wakeTime:" + localSleep.getWakeInSeconds() + ", totalDeepTime:" + localSleep.getTotalDeepSleepInSeconds() + ", totalLightTime:" + localSleep.getTotalLightSleepInSeconds() + ", sleepConsume:" + localSleep.getSleepConsumeInSeconds() + ", efficiency:" + localSleep.getSleepEfficiency() + ", 寮�濮嬫暡鍑绘墜鐜椂闂�:" + localSleep.getStartSleepInSeconds() + "鏃ユ湡" + new Date(1000L * localSleep.getStartSleepInSeconds()).toString() + ", 缁撴潫鏁插嚮鎵嬬幆鏃堕棿:" + localSleep.getEndSleepInSeconds() + "鏃ユ湡" + new Date(1000L * localSleep.getEndSleepInSeconds()).toString() + "|\n");
              localList1 = localSleep.getSleepDataFromFallAsleepToWake();
            }
            while (localList1 == null);
            Iterator localIterator2 = localList1.iterator();
            while (true)
            {
              if (!localIterator2.hasNext())
              {
                List localList2 = localSleep.getSleepDataFromFallAsleepToWake();
                if (localList2 == null)
                  break;
                Iterator localIterator3 = localList2.iterator();
                while (localIterator3.hasNext())
                {
                  SleepSlot localSleepSlot2 = (SleepSlot)localIterator3.next();
                  TestBlueToothActivity localTestBlueToothActivity7 = TestBlueToothActivity.this;
                  localTestBlueToothActivity7.result += "====asleep and wake slots\n";
                  TestBlueToothActivity localTestBlueToothActivity8 = TestBlueToothActivity.this;
                  localTestBlueToothActivity8.result = (localTestBlueToothActivity8.result + "|slotStartTime:" + localSleepSlot2.getStartTime() + ", slotDuration:" + localSleepSlot2.getDuration() + ", slotState:" + localSleepSlot2.getState().value() + "|\n");
                }
                break;
              }
              SleepSlot localSleepSlot1 = (SleepSlot)localIterator2.next();
              TestBlueToothActivity localTestBlueToothActivity5 = TestBlueToothActivity.this;
              localTestBlueToothActivity5.result += "====start and end slots\n";
              TestBlueToothActivity localTestBlueToothActivity6 = TestBlueToothActivity.this;
              localTestBlueToothActivity6.result = (localTestBlueToothActivity6.result + "|slotStartTime:" + localSleepSlot1.getStartTime() + ", slotDuration:" + localSleepSlot1.getDuration() + ", slotState:" + localSleepSlot1.getState().value() + "|\n");
            }
          }
        });
      }
    });
    this.addDurationButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("TestBlueToothActivity", "add duration data");
        SleepDao.clearSleepDuration(Database.getDb(TestBlueToothActivity.this));
        ArrayList localArrayList = new ArrayList();
        for (int i = 0; ; i++)
        {
          if (i >= 33)
          {
            SleepController.addSleepSettingTask(TestBlueToothActivity.this, localArrayList);
            return;
          }
          long l1 = TimeUtil.getDayStartTimestamp(i);
          String str = TimeUtil.getDate(l1);
          long l2 = l1 / 1000L;
          LogUtil.d("TestBlueToothActivity", "timestampS:" + l2 + ", date:" + str);
          localArrayList.add(new SleepSettingDetail(l2 - 14400L, str, SleepSettingState.SLEEP_MODE));
          localArrayList.add(new SleepSettingDetail(l2 + 14400L, str, SleepSettingState.SPORT_MODE));
        }
      }
    });
    this.addSleepButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("TestBlueToothActivity", "add sleep data");
        SleepDao.clearSleepDetail(Database.getDb(TestBlueToothActivity.this));
        ArrayList localArrayList = new ArrayList();
        for (int i = 0; ; i++)
        {
          if (i >= 33)
          {
            SleepController.addSleepTask(TestBlueToothActivity.this, localArrayList);
            return;
          }
          long l1 = TimeUtil.getDayStartTimestamp(i);
          String str1 = TimeUtil.getDate(l1);
          long l2 = l1 / 1000L;
          LogUtil.d("TestBlueToothActivity", "timestampS:" + l2 + ", date:" + str1);
          if (i > 0)
          {
            String str2 = TimeUtil.getDate(TimeUtil.getDayStartTimestamp(i - 1));
            localArrayList.add(new SleepDetail(l2 - 9000L, str2, SleepState.AWAKE));
            localArrayList.add(new SleepDetail(l2 - 7200L, str2, SleepState.DEEP_SLEEP));
          }
          localArrayList.add(new SleepDetail(900L + l2, str1, SleepState.LIGHT_SLEEP));
          localArrayList.add(new SleepDetail(3600L + l2, str1, SleepState.DEEP_SLEEP));
          localArrayList.add(new SleepDetail(1800L + l2, str1, SleepState.AWAKE));
          localArrayList.add(new SleepDetail(9000L + l2, str1, SleepState.LIGHT_SLEEP));
          localArrayList.add(new SleepDetail(8100L + l2, str1, SleepState.DEEP_SLEEP));
          localArrayList.add(new SleepDetail(10800L + l2, str1, SleepState.LIGHT_SLEEP));
          localArrayList.add(new SleepDetail(13500L + l2, str1, SleepState.LIGHT_SLEEP));
          localArrayList.add(new SleepDetail(18000L + l2, str1, SleepState.DEEP_SLEEP));
        }
      }
    });
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.TestBlueToothActivity
 * JD-Core Version:    0.6.2
 */