package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.os.Bundle;
import com.baidu.sapi2.View.CustomViewPager;
import com.baidu.sapi2.View.ImagePageItem;
import com.baidu.sapi2.View.ItemView;
import com.baidu.sapi2.View.PageIndexView;
import com.baidu.sapi2.View.ViewPagerManager;
import java.util.ArrayList;
import java.util.List;

public class UnderstandActivity extends Activity
{
  private static final String TAG = "UnderstandActivity";

  private void handleUELayout()
  {
    List localList = initPageItemList();
    int i = localList.size();
    (i - 1);
    new ViewPagerManager((CustomViewPager)findViewById(2131230951), (PageIndexView)findViewById(2131230953), localList, i);
  }

  private List<ItemView> initPageItemList()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(new ImagePageItem(2130837578, this));
    localArrayList.add(new ImagePageItem(2130837579, this));
    localArrayList.add(new ImagePageItem(2130837580, this));
    localArrayList.add(new ImagePageItem(2130837581, this));
    return localArrayList;
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903058);
    handleUELayout();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.UnderstandActivity
 * JD-Core Version:    0.6.2
 */