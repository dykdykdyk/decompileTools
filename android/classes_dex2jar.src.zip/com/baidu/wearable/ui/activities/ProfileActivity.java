package com.baidu.wearable.ui.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageLoader.ImageListener;
import com.android.volley.toolbox.Volley;
import com.baidu.mobstat.StatService;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.AppManager;
import com.baidu.wearable.alarm.completion.CompletionRateAlarm;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SleepDao;
import com.baidu.wearable.database.SportDao;
import com.baidu.wearable.plan.Plan;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.preference.ProfilePreference;
import com.baidu.wearable.profile.AvatarUtil;
import com.baidu.wearable.profile.Gender;
import com.baidu.wearable.profile.Profile;
import com.baidu.wearable.sleep.SleepDetail;
import com.baidu.wearable.sleep.SleepDuration;
import com.baidu.wearable.sport.SportDetail;
import com.baidu.wearable.sport.SportSummary;
import com.baidu.wearable.sync.NetDataSyncManager;
import com.baidu.wearable.sync.NetDataSyncManager.DownloadCallback;
import com.baidu.wearable.sync.SettingsSyncManager;
import com.baidu.wearable.tracker.Tracker;
import com.baidu.wearable.ui.view.BitmapCache;
import com.baidu.wearable.ui.view.NumberPicker;
import com.baidu.wearable.ui.widget.GenderPickerDialog;
import com.baidu.wearable.ui.widget.HeightPickerDialog;
import com.baidu.wearable.ui.widget.OnNumberPickerListener;
import com.baidu.wearable.ui.widget.WeightPickerDialog;
import com.baidu.wearable.util.PhoneCheck;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ProfileActivity extends Activity
{
  private static final String TAG = "ProfileActivity";
  public static final String TRACKER_LIST_KEY = "tracker_list_key";
  private static ProgressDialog mLoadDialog;
  private static AlertDialog mRepeatDialog;
  private static boolean mRepeatDialogFlag = false;
  private ImageView mAvataImageView;
  private boolean mBirthFlag;
  private TextView mBirthValue;
  private Context mContext;
  private DatePickerDialog mDatePickerDialog;
  private TextView mGenderValue;
  private boolean mHeightFlag;
  private HeightPickerDialog mHeightPickerDialog;
  private TextView mHeightValue;
  private ProfilePreference mProfileManager;
  private ArrayList<Tracker> mTrackerList;
  private boolean mWeightFlag;
  private WeightPickerDialog mWeightPickerDialog;
  private TextView mWeightValue;

  private void cancelLoadDialog()
  {
    if (mLoadDialog != null)
      mLoadDialog.cancel();
  }

  private void cancelRepeatDialog()
  {
    if (mRepeatDialog != null)
      mRepeatDialog.cancel();
  }

  private void initLoadDialog()
  {
    cancelLoadDialog();
    mLoadDialog = new ProgressDialog(this);
    mLoadDialog.setProgressStyle(0);
    mLoadDialog.setMessage(getString(2131296509));
    mLoadDialog.setCancelable(false);
  }

  private void initProfileData()
  {
    if (this.mProfileManager.getGender() == Gender.female)
      this.mGenderValue.setText(this.mContext.getString(2131296425));
    while (true)
    {
      int i = this.mProfileManager.getYear();
      if ((i != -1) && (i != 0))
      {
        this.mBirthFlag = true;
        int m = this.mProfileManager.getMonth();
        int n = this.mProfileManager.getDay();
        this.mBirthValue.setText(i + "/" + m + "/" + n);
      }
      int j = this.mProfileManager.getHeight();
      int k = this.mProfileManager.getWeight();
      if ((j != -1) && (j != 0))
      {
        this.mHeightFlag = true;
        this.mHeightValue.setText(j + "cm");
      }
      if ((k != -1) && (k != 0))
      {
        this.mWeightFlag = true;
        this.mWeightValue.setText(k + "kg");
      }
      return;
      this.mGenderValue.setText(this.mContext.getString(2131296424));
    }
  }

  private void initRepeatDialog()
  {
    cancelRepeatDialog();
    mRepeatDialog = new AlertDialog.Builder(this).setMessage(getString(2131296511)).setNegativeButton(2131296617, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        ProfileActivity.this.cancelLoadDialog();
        ProfileActivity.this.cancelRepeatDialog();
      }
    }).setPositiveButton(getString(2131296510), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        ProfileActivity.this.loadDataFromNet();
        ProfileActivity.this.cancelRepeatDialog();
        ProfileActivity.this.showLoadDialog();
      }
    }).create();
    mRepeatDialog.setCancelable(false);
  }

  private boolean isPhone(List<Tracker> paramList)
  {
    Iterator localIterator;
    if ((paramList != null) && (paramList.size() > 0))
      localIterator = paramList.iterator();
    do
      if (!localIterator.hasNext())
        return true;
    while (((Tracker)localIterator.next()).model.equals("App"));
    return false;
  }

  private void jumpToFlipActivity()
  {
    LogUtil.d("ProfileActivity", "mTrackerList:" + this.mTrackerList + ", support ble:" + PhoneCheck.isBleSupport(this));
    if (this.mTrackerList != null)
      LogUtil.d("ProfileActivity", "mTrackerList size:" + this.mTrackerList.size());
    if ((this.mTrackerList != null) && (this.mTrackerList.size() > 0) && ((PhoneCheck.isBleSupport(this)) || (isPhone(this.mTrackerList))))
    {
      Intent localIntent = new Intent(this, FlipActivity.class);
      localIntent.putParcelableArrayListExtra("tracker_list_key", this.mTrackerList);
      startActivity(localIntent);
    }
    while (true)
    {
      finish();
      return;
      startActivity(new Intent(this, ChooseDeviceActivity.class));
    }
  }

  private void loadAvataImage()
  {
    this.mAvataImageView = ((ImageView)findViewById(2131230873));
    RequestQueue localRequestQueue = Volley.newRequestQueue(getApplicationContext());
    ImageLoader.ImageListener localImageListener = ImageLoader.getImageListener(this.mAvataImageView, 0, 0);
    String str = AvatarUtil.getAvataImageUrl(BDAccountManager.getInstance().getUserData("uid"), BDAccountManager.getInstance().getUserData("username"));
    new ImageLoader(localRequestQueue, new BitmapCache()).get(str, localImageListener);
  }

  private void loadDataFromNet()
  {
    NetDataSyncManager.getInstance(this).download(new NetDataSyncManager.DownloadCallback()
    {
      public void onFail(int paramAnonymousInt, String paramAnonymousString)
      {
        LogUtil.e("ProfileActivity", "--getDataFromNet-onFailure-----" + paramAnonymousInt + "-----errMsg---" + paramAnonymousString);
        ProfileActivity.this.mTrackerList = new ArrayList();
        ProfileActivity.this.runOnUiThread(new Runnable()
        {
          public void run()
          {
            ProfileActivity.this.cancelLoadDialog();
            ProfileActivity.this.showRepeatDialog();
          }
        });
      }

      public void onSucceed(List<SportDetail> paramAnonymousList, List<SportSummary> paramAnonymousList1, List<SleepDuration> paramAnonymousList2, List<SleepDetail> paramAnonymousList3, Plan paramAnonymousPlan, Profile paramAnonymousProfile, List<Tracker> paramAnonymousList4, CompletionRateAlarm paramAnonymousCompletionRateAlarm)
      {
        SQLiteDatabase localSQLiteDatabase = Database.getDb(ProfileActivity.this);
        SleepDao.bulkReplaceSleepDetail(localSQLiteDatabase, paramAnonymousList3, false);
        SleepDao.bulkReplaceSleepDuration(localSQLiteDatabase, paramAnonymousList2, false);
        SportDao.bulkReplaceSportDetail(localSQLiteDatabase, paramAnonymousList, false);
        SportDao.bulkReplaceSportSummary(localSQLiteDatabase, paramAnonymousList1);
        PlanPreference.getInstance(ProfileActivity.this).saveAllTargetPlan(paramAnonymousPlan);
        ProfilePreference.getInstance(ProfileActivity.this).saveAllProfileInfo(paramAnonymousProfile);
        AlarmPreference.getInstance(ProfileActivity.this).saveCompletionRate(paramAnonymousCompletionRateAlarm);
        ProfileActivity.this.mTrackerList = ((ArrayList)paramAnonymousList4);
        ProfileActivity.this.runOnUiThread(new Runnable()
        {
          public void run()
          {
            ProfileActivity.this.initProfileData();
            if (ProfileActivity.this.mProfileManager.isAvaiable())
            {
              LogUtil.d("ProfileActivity", "profile manager is avaiable");
              ProfileActivity.this.cancelLoadDialog();
              if (AppManager.getAppManager().isRunningForeground(ProfileActivity.this))
                ProfileActivity.this.jumpToFlipActivity();
              return;
            }
            ProfileActivity.this.cancelLoadDialog();
          }
        });
      }
    });
  }

  private void setupViews()
  {
    ((TextView)findViewById(2131230874)).setText(BDAccountManager.getInstance().getUserData("displayname"));
    ((RelativeLayout)findViewById(2131230878)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        ProfileActivity.this.showGenderDialog();
      }
    });
    this.mGenderValue = ((TextView)findViewById(2131230880));
    this.mBirthValue = ((TextView)findViewById(2131230883));
    this.mHeightValue = ((TextView)findViewById(2131230886));
    this.mWeightValue = ((TextView)findViewById(2131230889));
    ((RelativeLayout)findViewById(2131230881)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        ProfileActivity.this.showBirthDialog();
      }
    });
    ((RelativeLayout)findViewById(2131230884)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        ProfileActivity.this.showHeightDialog();
      }
    });
    ((RelativeLayout)findViewById(2131230887)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        ProfileActivity.this.showWeightDialog();
      }
    });
    ((Button)findViewById(2131230890)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        if (!ProfileActivity.this.mBirthFlag)
        {
          Toast.makeText(ProfileActivity.this, 2131296467, 0).show();
          return;
        }
        if (!ProfileActivity.this.mHeightFlag)
        {
          Toast.makeText(ProfileActivity.this, 2131296468, 0).show();
          return;
        }
        if (!ProfileActivity.this.mWeightFlag)
        {
          Toast.makeText(ProfileActivity.this, 2131296469, 0).show();
          return;
        }
        ProfileActivity.this.jumpToFlipActivity();
      }
    });
  }

  @SuppressLint({"NewApi"})
  private void showBirthDialog()
  {
    int i = this.mProfileManager.getYear();
    int j = this.mProfileManager.getMonth();
    int k = this.mProfileManager.getDay();
    if (i == 0)
      i = 1988;
    if (j == 0)
      j = 5;
    if (k == 0)
      k = 15;
    this.mDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener()
    {
      public void onDateSet(DatePicker paramAnonymousDatePicker, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3)
      {
        int i = paramAnonymousInt2 + 1;
        ProfileActivity.this.mBirthValue.setText(paramAnonymousInt1 + "/" + i + "/" + paramAnonymousInt3);
        ProfileActivity.this.mProfileManager.saveBirth(paramAnonymousInt1, i, paramAnonymousInt3);
        ProfileActivity.this.mBirthFlag = true;
      }
    }
    , i, j - 1, k);
    this.mDatePickerDialog.setCanceledOnTouchOutside(false);
    this.mDatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
    this.mDatePickerDialog.show();
  }

  private void showGenderDialog()
  {
    new GenderPickerDialog(this, this.mProfileManager.getGender(), new OnNumberPickerListener()
    {
      public void onSet(NumberPicker paramAnonymousNumberPicker, int paramAnonymousInt)
      {
        if (paramAnonymousInt == 1)
        {
          ProfileActivity.this.mProfileManager.saveGender(Gender.female);
          ProfileActivity.this.mGenderValue.setText(ProfileActivity.this.mContext.getString(2131296425));
          return;
        }
        ProfileActivity.this.mProfileManager.saveGender(Gender.male);
        ProfileActivity.this.mGenderValue.setText(ProfileActivity.this.mContext.getString(2131296424));
      }
    }).show();
  }

  private void showHeightDialog()
  {
    int i = this.mProfileManager.getHeight();
    if (i == 0)
      if (this.mProfileManager.getGender() != Gender.male)
        break label58;
    label58: for (i = 170; ; i = 160)
    {
      this.mHeightPickerDialog = new HeightPickerDialog(this, i, new OnNumberPickerListener()
      {
        public void onSet(NumberPicker paramAnonymousNumberPicker, int paramAnonymousInt)
        {
          ProfileActivity.this.mHeightValue.setText(paramAnonymousInt + "cm");
          ProfileActivity.this.mProfileManager.saveHeight(paramAnonymousInt);
          ProfileActivity.this.mHeightFlag = true;
        }
      });
      this.mHeightPickerDialog.show();
      return;
    }
  }

  private void showLoadDialog()
  {
    mLoadDialog.show();
  }

  private void showRepeatDialog()
  {
    if (!isFinishing())
    {
      mRepeatDialog.show();
      return;
    }
    mRepeatDialogFlag = true;
  }

  private void showWeightDialog()
  {
    int i = this.mProfileManager.getWeight();
    if (i == 0)
      if (this.mProfileManager.getGender() != Gender.male)
        break label57;
    label57: for (i = 70; ; i = 50)
    {
      this.mWeightPickerDialog = new WeightPickerDialog(this, i, new OnNumberPickerListener()
      {
        public void onSet(NumberPicker paramAnonymousNumberPicker, int paramAnonymousInt)
        {
          ProfileActivity.this.mWeightValue.setText(paramAnonymousInt + "kg");
          ProfileActivity.this.mProfileManager.saveWeight(paramAnonymousInt);
          ProfileActivity.this.mWeightFlag = true;
        }
      });
      this.mWeightPickerDialog.show();
      return;
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    LogUtil.d("ProfileActivity", "onConfigurationChanged");
    if ((this.mDatePickerDialog != null) && (this.mDatePickerDialog.isShowing()))
    {
      this.mDatePickerDialog.cancel();
      showBirthDialog();
    }
    if ((this.mHeightPickerDialog != null) && (this.mHeightPickerDialog.isShowing()))
    {
      this.mHeightPickerDialog.cancel();
      showHeightDialog();
    }
    if ((this.mWeightPickerDialog != null) && (this.mWeightPickerDialog.isShowing()))
    {
      this.mWeightPickerDialog.cancel();
      showWeightDialog();
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    LogUtil.d("ProfileActivity", "onCreate");
    setContentView(2130903053);
    this.mProfileManager = ProfilePreference.getInstance(this);
    this.mContext = getApplicationContext();
    setupViews();
    initRepeatDialog();
    initLoadDialog();
    showLoadDialog();
    loadDataFromNet();
    loadAvataImage();
    SettingsSyncManager.getInstance(getApplicationContext()).reset();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    LogUtil.d("ProfileActivity", "onDestroy");
    cancelLoadDialog();
    cancelRepeatDialog();
    mLoadDialog = null;
    mRepeatDialog = null;
    if (this.mDatePickerDialog != null)
    {
      this.mDatePickerDialog.cancel();
      this.mDatePickerDialog = null;
    }
    if (this.mHeightPickerDialog != null)
    {
      this.mHeightPickerDialog.cancel();
      this.mHeightPickerDialog = null;
    }
    if (this.mWeightPickerDialog != null)
    {
      this.mWeightPickerDialog.cancel();
      this.mWeightPickerDialog = null;
    }
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    if (mRepeatDialogFlag)
    {
      mRepeatDialog.show();
      mRepeatDialogFlag = false;
    }
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.ProfileActivity
 * JD-Core Version:    0.6.2
 */