package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Pair;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.sleep.Sleep;
import com.baidu.wearable.sleep.SleepController;
import com.baidu.wearable.sleep.SleepController.SleepListener;
import com.baidu.wearable.sleep.SleepSlot;
import com.baidu.wearable.sleep.SleepState;
import com.baidu.wearable.ui.bean.ChartDateType;
import com.baidu.wearable.ui.bean.SleepChartFuncType;
import com.baidu.wearable.ui.view.MyBarChart;
import com.baidu.wearable.ui.view.SleepDetailChartView;
import com.baidu.wearable.ui.widget.ChartBoxTipView;
import com.baidu.wearable.util.TimeUtil;
import java.lang.ref.WeakReference;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class SleepChartActivity extends Activity
  implements View.OnClickListener
{
  public static final String CHART_FUNC_TYPE = "chart_type";
  public static final String DAY_INDEX = "day_index";
  private static final int MONTH_CHART_COUNT = 31;
  private static final int REFRESH_MESSAGE = 1;
  private static final double SLEEP_TARGET_EFFI = 0.92D;
  private static final double SLEEP_TARGET_TOTAL = 25200.0D;
  private static final String TAG = "SleepChartActivity";
  private Button mBtnDeepSleep;
  private Button mBtnReadySleep;
  private Button mBtnTotalSleep;
  private FrameLayout mChartLayout;
  private SleepDetailChartView mChartView;
  private RelativeLayout mChartViewLayout;
  private List<double[]> mCurrentDate = new ArrayList(1);
  public ChartDateType mCurrentDateType = ChartDateType.DAY;
  private RelativeLayout mCurrentDayDetail;
  private double mCurrentEfficiency = 0.0D;
  public SleepChartFuncType mCurrentFuncType = SleepChartFuncType.TOTAL_SLEEP;
  private long mCurrentSleepConsume = 0L;
  private long mCurrentTotalTime = 0L;
  private List<Pair<Double, Double>> mDataList;
  private ChartBoxTipView mDateLayout;
  private int mDayIndex;
  private ImageView mDottedImageView;
  private double[] mMonthEfficiency;
  private double[] mMonthSleepConsume;
  private double[] mMonthTotalTime;
  private TextView mSleepConsumeText;
  private View mSleepDetailBarView;
  private TextView mSleepEfficiencyText;
  private RelativeLayout mSleepFuncSwitcher;
  private View mSleepHistoryView;
  private LinearLayout mSleepLegend;
  private TextView mTab30Day;
  private TextView mTab7Day;
  private TextView mTabToday;
  private TextView mTotalSleepTimeText;
  private UIHandler mUIHhandler;

  private ChartDateType getCurrentChartDateType()
  {
    return this.mCurrentDateType;
  }

  private SleepChartFuncType getCurrentSleepChartFuncType()
  {
    return this.mCurrentFuncType;
  }

  private void initView()
  {
    this.mDateLayout = ((ChartBoxTipView)findViewById(2131230934));
    this.mDottedImageView = ((ImageView)findViewById(2131230937));
    this.mChartLayout = ((FrameLayout)findViewById(2131230933));
    ((ImageButton)findViewById(2131230763)).setOnClickListener(this);
    this.mTabToday = ((TextView)findViewById(2131230911));
    this.mTabToday.setOnClickListener(this);
    this.mTab7Day = ((TextView)findViewById(2131230912));
    this.mTab7Day.setOnClickListener(this);
    this.mTab30Day = ((TextView)findViewById(2131230913));
    this.mTab30Day.setOnClickListener(this);
    this.mBtnTotalSleep = ((Button)findViewById(2131230918));
    this.mBtnTotalSleep.setOnClickListener(this);
    this.mBtnDeepSleep = ((Button)findViewById(2131230917));
    this.mBtnDeepSleep.setOnClickListener(this);
    this.mBtnReadySleep = ((Button)findViewById(2131230916));
    this.mBtnReadySleep.setOnClickListener(this);
    this.mChartViewLayout = ((RelativeLayout)findViewById(2131230909));
    this.mCurrentDayDetail = ((RelativeLayout)findViewById(2131230919));
    this.mSleepFuncSwitcher = ((RelativeLayout)findViewById(2131230915));
    this.mSleepLegend = ((LinearLayout)findViewById(2131230926));
    this.mSleepEfficiencyText = ((TextView)findViewById(2131230923));
    this.mTotalSleepTimeText = ((TextView)findViewById(2131230921));
    this.mSleepConsumeText = ((TextView)findViewById(2131230925));
    refreshCurrentFuncView(this.mCurrentFuncType);
    refreshCurrentDateView(this.mCurrentDateType);
  }

  private void loadDayDetailData()
  {
    this.mMonthTotalTime = new double[31];
    this.mMonthEfficiency = new double[31];
    this.mMonthSleepConsume = new double[31];
    SleepController.getMaxSleepSomeDays(this, 31 + this.mDayIndex, new SleepController.SleepListener()
    {
      public void onReceive(List<Sleep> paramAnonymousList)
      {
        LogUtil.d("SleepChartActivity", "receive sleep db, count:" + paramAnonymousList.size());
        Calendar localCalendar1 = Calendar.getInstance();
        SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        localCalendar1.setTimeInMillis(localSimpleDateFormat.parse(localSimpleDateFormat.format(new Date(System.currentTimeMillis())), new ParsePosition(0)).getTime());
        Calendar localCalendar2 = (Calendar)localCalendar1.clone();
        Iterator localIterator1 = paramAnonymousList.iterator();
        while (true)
        {
          if (!localIterator1.hasNext())
          {
            SleepChartActivity.this.mUIHhandler.sendEmptyMessage(1);
            return;
          }
          Sleep localSleep = (Sleep)localIterator1.next();
          ParsePosition localParsePosition = new ParsePosition(0);
          localCalendar2.setTime(localSimpleDateFormat.parse(localSleep.getDate(), localParsePosition));
          int i = TimeUtil.daysBetween(localCalendar2, localCalendar1);
          LogUtil.d("SleepChartActivity", " index is " + i);
          if ((i >= SleepChartActivity.this.mDayIndex) && (i < 31))
          {
            SleepChartActivity.this.mMonthTotalTime[(30 - i + SleepChartActivity.this.mDayIndex)] = localSleep.getTotalSleepInSeconds();
            SleepChartActivity.this.mMonthEfficiency[(30 - i + SleepChartActivity.this.mDayIndex)] = localSleep.getSleepEfficiency();
            SleepChartActivity.this.mMonthSleepConsume[(30 - i + SleepChartActivity.this.mDayIndex)] = localSleep.getSleepConsumeInSeconds();
            if (i == SleepChartActivity.this.mDayIndex)
            {
              SleepChartActivity.this.mCurrentTotalTime = localSleep.getTotalSleepInSeconds();
              SleepChartActivity.this.mCurrentEfficiency = localSleep.getSleepEfficiency();
              SleepChartActivity.this.mCurrentSleepConsume = localSleep.getSleepConsumeInSeconds();
              List localList = localSleep.getSleepDataFromFallAsleepToWake();
              if (localList != null)
              {
                SleepChartActivity.this.mDataList = new ArrayList(2 + localList.size());
                double d1 = localSleep.getStartSleepInSeconds();
                double d2 = localSleep.getEndSleepInSeconds();
                double d3 = localSleep.getFallAsleepInSeconds();
                double d4 = localSleep.getWakeInSeconds();
                SleepChartActivity.this.mDataList.add(new Pair(Double.valueOf(d1), Double.valueOf(d2)));
                SleepChartActivity.this.mDataList.add(new Pair(Double.valueOf(d3), Double.valueOf(d4)));
                double d5 = 0.0D;
                Iterator localIterator2 = localList.iterator();
                while (localIterator2.hasNext())
                {
                  SleepSlot localSleepSlot = (SleepSlot)localIterator2.next();
                  double d6 = localSleepSlot.getState().value();
                  d5 += localSleepSlot.getDuration();
                  SleepChartActivity.this.mDataList.add(new Pair(Double.valueOf(d6), Double.valueOf(d5)));
                }
              }
            }
          }
        }
      }
    });
  }

  private void loadSleepData()
  {
    if (this.mSleepDetailBarView == null)
      this.mSleepDetailBarView = new MyBarChart(this, this.mDataList).getXYChart();
    if (this.mSleepHistoryView == null)
    {
      this.mChartView = new SleepDetailChartView(this, this.mDateLayout, this.mDottedImageView);
      refreshCurrentFuncView(getCurrentSleepChartFuncType());
      this.mSleepHistoryView = this.mChartView.execute(this.mCurrentDate, this.mDayIndex);
    }
    if (getCurrentChartDateType() == ChartDateType.DAY)
    {
      this.mChartLayout.removeAllViews();
      this.mChartLayout.addView(this.mSleepDetailBarView);
      this.mSleepLegend.setVisibility(0);
      return;
    }
    this.mSleepLegend.setVisibility(8);
    this.mChartLayout.removeAllViews();
    this.mChartLayout.addView(this.mSleepHistoryView);
  }

  private void refreshCurrentChartView(SleepChartFuncType paramSleepChartFuncType)
  {
    this.mCurrentDate.clear();
    double d = 0.0D;
    if (paramSleepChartFuncType == SleepChartFuncType.TOTAL_SLEEP)
    {
      this.mCurrentDate.add(this.mMonthTotalTime);
      d = 25200.0D;
    }
    while (true)
    {
      if (this.mChartView != null)
        this.mChartView.updateData(getCurrentChartDateType(), getCurrentSleepChartFuncType(), this.mCurrentDate, d, this.mDayIndex);
      this.mChartLayout.removeAllViews();
      if (this.mSleepHistoryView != null)
        this.mChartLayout.addView(this.mSleepHistoryView);
      this.mSleepLegend.setVisibility(8);
      return;
      if (paramSleepChartFuncType == SleepChartFuncType.SLEEP_CONSUME)
      {
        this.mCurrentDate.add(this.mMonthSleepConsume);
        d = 0.0D;
      }
      else if (paramSleepChartFuncType == SleepChartFuncType.SLEEP_EFFI)
      {
        this.mCurrentDate.add(this.mMonthEfficiency);
        d = 0.92D;
      }
    }
  }

  private void refreshCurrentDateView(ChartDateType paramChartDateType)
  {
    if (paramChartDateType == ChartDateType.DAY)
    {
      this.mTabToday.setTextColor(getResources().getColor(2131099663));
      this.mTab7Day.setTextColor(getResources().getColor(2131099658));
      this.mTab30Day.setTextColor(getResources().getColor(2131099658));
      this.mChartViewLayout.setBackgroundResource(2130837549);
    }
    do
    {
      return;
      if (paramChartDateType == ChartDateType.WEEK)
      {
        this.mTabToday.setTextColor(getResources().getColor(2131099658));
        this.mTab7Day.setTextColor(getResources().getColor(2131099663));
        this.mTab30Day.setTextColor(getResources().getColor(2131099658));
        this.mChartViewLayout.setBackgroundResource(2130837548);
        return;
      }
    }
    while (paramChartDateType != ChartDateType.MONTH);
    this.mTabToday.setTextColor(getResources().getColor(2131099658));
    this.mTab7Day.setTextColor(getResources().getColor(2131099658));
    this.mTab30Day.setTextColor(getResources().getColor(2131099663));
    this.mChartViewLayout.setBackgroundResource(2130837547);
  }

  private void refreshCurrentFuncView(SleepChartFuncType paramSleepChartFuncType)
  {
    this.mCurrentDate.clear();
    if (paramSleepChartFuncType == SleepChartFuncType.TOTAL_SLEEP)
    {
      this.mBtnTotalSleep.setBackgroundResource(2130837552);
      this.mBtnDeepSleep.setBackgroundResource(2130837553);
      this.mBtnReadySleep.setBackgroundResource(2130837555);
      this.mBtnTotalSleep.setTextColor(getResources().getColor(2131099663));
      this.mBtnDeepSleep.setTextColor(getResources().getColor(2131099658));
      this.mBtnReadySleep.setTextColor(getResources().getColor(2131099658));
      this.mCurrentDate.add(this.mMonthTotalTime);
    }
    do
    {
      return;
      if (paramSleepChartFuncType == SleepChartFuncType.SLEEP_EFFI)
      {
        this.mBtnTotalSleep.setBackgroundResource(2130837551);
        this.mBtnDeepSleep.setBackgroundResource(2130837554);
        this.mBtnReadySleep.setBackgroundResource(2130837555);
        this.mBtnTotalSleep.setTextColor(getResources().getColor(2131099658));
        this.mBtnDeepSleep.setTextColor(getResources().getColor(2131099663));
        this.mBtnReadySleep.setTextColor(getResources().getColor(2131099658));
        this.mCurrentDate.add(this.mMonthEfficiency);
        return;
      }
    }
    while (paramSleepChartFuncType != SleepChartFuncType.SLEEP_CONSUME);
    this.mBtnTotalSleep.setBackgroundResource(2130837551);
    this.mBtnDeepSleep.setBackgroundResource(2130837553);
    this.mBtnReadySleep.setBackgroundResource(2130837556);
    this.mBtnTotalSleep.setTextColor(getResources().getColor(2131099658));
    this.mBtnDeepSleep.setTextColor(getResources().getColor(2131099658));
    this.mBtnReadySleep.setTextColor(getResources().getColor(2131099663));
    this.mCurrentDate.add(this.mMonthSleepConsume);
  }

  private void setCurrentDateType(ChartDateType paramChartDateType)
  {
    this.mCurrentDateType = paramChartDateType;
  }

  private void setCurrentFuncType(SleepChartFuncType paramSleepChartFuncType)
  {
    this.mCurrentFuncType = paramSleepChartFuncType;
  }

  public static void startSleepChartActivity(Context paramContext, int paramInt)
  {
    paramContext.startActivity(new Intent(paramContext, SleepChartActivity.class).putExtra("day_index", paramInt));
  }

  private void updateTitle()
  {
    int i = (int)(100.0D * this.mCurrentEfficiency);
    this.mSleepEfficiencyText.setText(i + "%");
    int j = (int)(this.mCurrentTotalTime / 3600L);
    int k = (int)(this.mCurrentTotalTime % 3600L / 60L);
    TextView localTextView1 = this.mTotalSleepTimeText;
    Object[] arrayOfObject1 = new Object[2];
    arrayOfObject1[0] = Integer.valueOf(j);
    arrayOfObject1[1] = Integer.valueOf(k);
    localTextView1.setText(String.format("%d:%02d", arrayOfObject1));
    int m = (int)(this.mCurrentSleepConsume / 3600L);
    int n = (int)(this.mCurrentSleepConsume % 3600L / 60L);
    TextView localTextView2 = this.mSleepConsumeText;
    Object[] arrayOfObject2 = new Object[2];
    arrayOfObject2[0] = Integer.valueOf(m);
    arrayOfObject2[1] = Integer.valueOf(n);
    localTextView2.setText(String.format("%d:%02d", arrayOfObject2));
  }

  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
      return;
    case 2131230763:
      finish();
      return;
    case 2131230911:
      setCurrentDateType(ChartDateType.DAY);
      refreshCurrentDateView(this.mCurrentDateType);
      this.mCurrentDayDetail.setVisibility(0);
      this.mSleepFuncSwitcher.setVisibility(8);
      this.mChartLayout.removeAllViews();
      this.mChartLayout.addView(this.mSleepDetailBarView);
      this.mSleepLegend.setVisibility(0);
      return;
    case 2131230912:
      setCurrentDateType(ChartDateType.WEEK);
      refreshCurrentDateView(this.mCurrentDateType);
      this.mCurrentDayDetail.setVisibility(8);
      this.mSleepFuncSwitcher.setVisibility(0);
      refreshCurrentChartView(getCurrentSleepChartFuncType());
      return;
    case 2131230913:
      setCurrentDateType(ChartDateType.MONTH);
      refreshCurrentDateView(this.mCurrentDateType);
      this.mCurrentDayDetail.setVisibility(8);
      this.mSleepFuncSwitcher.setVisibility(0);
      refreshCurrentChartView(getCurrentSleepChartFuncType());
      return;
    case 2131230916:
      setCurrentFuncType(SleepChartFuncType.SLEEP_CONSUME);
      refreshCurrentFuncView(this.mCurrentFuncType);
      refreshCurrentChartView(getCurrentSleepChartFuncType());
      return;
    case 2131230917:
      setCurrentFuncType(SleepChartFuncType.SLEEP_EFFI);
      refreshCurrentFuncView(this.mCurrentFuncType);
      refreshCurrentChartView(getCurrentSleepChartFuncType());
      return;
    case 2131230918:
    }
    setCurrentFuncType(SleepChartFuncType.TOTAL_SLEEP);
    refreshCurrentFuncView(this.mCurrentFuncType);
    refreshCurrentChartView(getCurrentSleepChartFuncType());
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.mDayIndex = getIntent().getIntExtra("day_index", 0);
    setCurrentDateType(ChartDateType.DAY);
    setCurrentFuncType(SleepChartFuncType.TOTAL_SLEEP);
    requestWindowFeature(1);
    setContentView(2130903055);
    this.mUIHhandler = new UIHandler(this);
    initView();
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
    loadDayDetailData();
  }

  private static class UIHandler extends Handler
  {
    private WeakReference<SleepChartActivity> mWeakReference;

    public UIHandler(SleepChartActivity paramSleepChartActivity)
    {
      this.mWeakReference = new WeakReference(paramSleepChartActivity);
    }

    public void handleMessage(Message paramMessage)
    {
      super.handleMessage(paramMessage);
      SleepChartActivity localSleepChartActivity = (SleepChartActivity)this.mWeakReference.get();
      if (localSleepChartActivity == null);
      do
      {
        return;
        switch (paramMessage.what)
        {
        default:
          return;
        case 1:
        }
        localSleepChartActivity.updateTitle();
        localSleepChartActivity.loadSleepData();
      }
      while (localSleepChartActivity.getCurrentChartDateType() == ChartDateType.DAY);
      localSleepChartActivity.refreshCurrentChartView(SleepChartActivity.access$3(localSleepChartActivity));
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.SleepChartActivity
 * JD-Core Version:    0.6.2
 */