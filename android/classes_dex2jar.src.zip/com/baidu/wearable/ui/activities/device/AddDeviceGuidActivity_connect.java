package com.baidu.wearable.ui.activities.device;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.widget.ProgressBar;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;

public class AddDeviceGuidActivity_connect extends Activity
{
  private static final String TAG = "AddDeviceGuidActivity_connect";
  private String mDeviceAddress = null;
  private String mDeviceName = null;
  private boolean mHaveReceiveScanResult = false;
  private LocalBroadcastManager mLocalBroadcastManager;
  private ProgressBar mProgressBar;
  private Receiver mReceiver;

  private void handleCancel()
  {
    LogUtil.d("AddDeviceGuidActivity_connect", "handleCancel");
    if ((this.mReceiver != null) && (this.mLocalBroadcastManager != null))
    {
      this.mLocalBroadcastManager.unregisterReceiver(this.mReceiver);
      this.mReceiver = null;
    }
    Intent localIntent = new Intent("action.wearable.ble.connect.command");
    localIntent.putExtra("extra.wearable.ble.connect.command", 1);
    this.mLocalBroadcastManager.sendBroadcast(localIntent);
    finish();
  }

  private void handleConnected()
  {
    LogUtil.d("AddDeviceGuidActivity_connect", "handleConnected");
    startActivity(new Intent(this, AddDeviceGuidActivity_bind_success.class));
    finish();
  }

  private void handleFail()
  {
    LogUtil.d("AddDeviceGuidActivity_connect", "handleFail");
    startActivity(new Intent(this, AddDeviceGuidActivity_connect_fail.class));
    finish();
  }

  private void handleNeedBind(String paramString)
  {
    LogUtil.d("AddDeviceGuidActivity_connect", "handleNeedBind deviceAddress:" + paramString);
    Intent localIntent = new Intent(this, AddDeviceGuidActivity_bind.class);
    localIntent.putExtra("extra.baidu.wearable.activity.device.add.device.guide.bind", AddDeviceGuidActivity_bind.START_FROM_SCAN);
    localIntent.putExtra("extra.baidu.wearable.activity.device.add.device.guide.bind.device.address", paramString);
    startActivity(localIntent);
    finish();
  }

  private void initViews()
  {
    this.mProgressBar = ((ProgressBar)findViewById(2131231020));
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    handleCancel();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    LogUtil.d("AddDeviceGuidActivity_connect", "onCreate");
    setContentView(2130903066);
    initViews();
    this.mReceiver = new Receiver(this);
    this.mReceiver.registerAction("action.wearable.ble.connect.status");
    this.mReceiver.registerAction("action.wearable.ble.statemachine.scan.state");
    Intent localIntent1 = new Intent("action.wearable.ble.connect.command");
    localIntent1.putExtra("extra.wearable.ble.connect.command", 1);
    LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent1);
    Intent localIntent2 = new Intent("action.wearable.ble.connect.command");
    localIntent2.putExtra("extra.wearable.ble.connect.command", 0);
    LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent2);
  }

  protected void onDestroy()
  {
    if (this.mReceiver != null)
      this.mLocalBroadcastManager.unregisterReceiver(this.mReceiver);
    super.onDestroy();
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
    this.mDeviceAddress = null;
    this.mDeviceName = null;
  }

  class Receiver extends BroadcastReceiver
  {
    Context mContext;

    public Receiver(Context arg2)
    {
      Object localObject;
      this.mContext = localObject;
      AddDeviceGuidActivity_connect.this.mLocalBroadcastManager = LocalBroadcastManager.getInstance(this.mContext);
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      String str = paramIntent.getAction();
      if (str.equals("action.wearable.ble.connect.status"))
        switch (paramIntent.getIntExtra("extra.wearable.ble.connect.status", -1))
        {
        case 1:
        case 2:
        case 3:
        default:
        case 4:
        case 5:
        case 0:
        }
      while (!str.equals("action.wearable.ble.statemachine.scan.state"))
      {
        do
        {
          return;
          LogUtil.d("AddDeviceGuidActivity_connect", "CONNECT_STATE_CONNECTING_NEED_BIND");
          AddDeviceGuidActivity_connect.this.handleNeedBind(paramIntent.getStringExtra("extra.wearable.ble.need.bind.device.address"));
          return;
          LogUtil.d("AddDeviceGuidActivity_connect", "CONNECT_STATE_CONNECTED");
          AddDeviceGuidActivity_connect.this.handleConnected();
          return;
          LogUtil.d("AddDeviceGuidActivity_connect", "CONNECT_STATE_DISCONNECTED");
        }
        while (!AddDeviceGuidActivity_connect.this.mHaveReceiveScanResult);
        AddDeviceGuidActivity_connect.this.handleFail();
        return;
      }
      AddDeviceGuidActivity_connect.this.mHaveReceiveScanResult = true;
      switch (paramIntent.getIntExtra("extra.wearable.ble.statemachine.scan.state", -1))
      {
      default:
        return;
      case 0:
        LogUtil.d("AddDeviceGuidActivity_connect", "BLE_SCAN_RESULT_SUCCESS");
        AddDeviceGuidActivity_connect.this.mDeviceAddress = paramIntent.getStringExtra("extra.wearable.ble.statemachine.scan.state.device.address");
        AddDeviceGuidActivity_connect.this.mDeviceName = paramIntent.getStringExtra("extra.wearable.ble.statemachine.scan.state.device.name");
        LogUtil.d("AddDeviceGuidActivity_connect", "device address:" + AddDeviceGuidActivity_connect.this.mDeviceAddress + " device name:" + AddDeviceGuidActivity_connect.this.mDeviceName);
        return;
      case 1:
      }
      LogUtil.d("AddDeviceGuidActivity_connect", "BLE_SCAN_RESULT_ERROR");
      AddDeviceGuidActivity_connect.this.handleFail();
    }

    public void registerAction(String paramString)
    {
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction(paramString);
      AddDeviceGuidActivity_connect.this.mLocalBroadcastManager.registerReceiver(this, localIntentFilter);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_connect
 * JD-Core Version:    0.6.2
 */