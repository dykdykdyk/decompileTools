package com.baidu.wearable.ui.activities.device;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;

public class AddDeviceGuidActivity_bind extends Activity
{
  public static final String EXTRA_START_BIND_ACTIVITY = "extra.baidu.wearable.activity.device.add.device.guide.bind";
  public static final String EXTRA_START_BIND_ACTIVITY_DEVICE_ADDRESS = "extra.baidu.wearable.activity.device.add.device.guide.bind.device.address";
  public static int START_FROM_CONNECT = 0;
  public static int START_FROM_SCAN = 0;
  private static final String TAG = "AddDeviceGuidActivity_bind";
  private Button mBtnBind;
  private Button mBtnCancel;
  private boolean mIsFromConnect = false;
  private LocalBroadcastManager mLocalBroadcastManager;
  private Receiver mReceiver;
  private View mRelativeLayoutFromConnect;
  private View mRelativeLayoutFromScan;

  static
  {
    if (!AddDeviceGuidActivity_bind.class.desiredAssertionStatus());
    for (boolean bool = true; ; bool = false)
    {
      $assertionsDisabled = bool;
      START_FROM_SCAN = 0;
      START_FROM_CONNECT = 1 + START_FROM_SCAN;
      return;
    }
  }

  private void handleConnected()
  {
    LogUtil.d("AddDeviceGuidActivity_bind", "handleConnected");
    startActivity(new Intent(this, AddDeviceGuidActivity_bind_success.class));
    finish();
  }

  private void handleFail()
  {
    LogUtil.d("AddDeviceGuidActivity_bind", "handleFail");
    new Thread()
    {
      public void run()
      {
        try
        {
          Thread.sleep(2000L);
          Intent localIntent = new Intent(AddDeviceGuidActivity_bind.this, AddDeviceGuidActivity_bind_fail.class);
          AddDeviceGuidActivity_bind.this.startActivity(localIntent);
          AddDeviceGuidActivity_bind.this.finish();
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            localInterruptedException.printStackTrace();
        }
      }
    }
    .start();
  }

  private void initViews()
  {
    this.mRelativeLayoutFromConnect = findViewById(2131231006);
    this.mRelativeLayoutFromScan = findViewById(2131231005);
    this.mBtnCancel = ((Button)findViewById(2131231008));
    this.mBtnCancel.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_bind", "cancel button click");
        Intent localIntent = new Intent("action.wearable.ble.connect.command");
        localIntent.putExtra("extra.wearable.ble.connect.command", 1);
        LocalBroadcastManager.getInstance(AddDeviceGuidActivity_bind.this).sendBroadcast(localIntent);
        if (AddDeviceGuidActivity_bind.this.mReceiver != null)
        {
          AddDeviceGuidActivity_bind.this.mLocalBroadcastManager.unregisterReceiver(AddDeviceGuidActivity_bind.this.mReceiver);
          AddDeviceGuidActivity_bind.this.mReceiver = null;
        }
        AddDeviceGuidActivity_bind.this.finish();
      }
    });
    this.mBtnBind = ((Button)findViewById(2131231009));
    this.mBtnBind.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_bind", "next step button click");
        AddDeviceGuidActivity_bind.this.mRelativeLayoutFromConnect.setVisibility(8);
        AddDeviceGuidActivity_bind.this.mRelativeLayoutFromScan.setVisibility(0);
        AddDeviceGuidActivity_bind.this.doBind();
      }
    });
    if (this.mIsFromConnect)
    {
      this.mRelativeLayoutFromConnect.setVisibility(0);
      this.mRelativeLayoutFromScan.setVisibility(8);
      return;
    }
    this.mRelativeLayoutFromConnect.setVisibility(8);
    this.mRelativeLayoutFromScan.setVisibility(0);
  }

  public void doBind()
  {
    Intent localIntent = new Intent("action.wearable.ble.connect.command");
    localIntent.putExtra("extra.wearable.ble.connect.command", 3);
    LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
  }

  public void onBackPressed()
  {
    super.onBackPressed();
    if (this.mReceiver != null)
    {
      this.mLocalBroadcastManager.unregisterReceiver(this.mReceiver);
      this.mReceiver = null;
    }
    Intent localIntent = new Intent("action.wearable.ble.connect.command");
    localIntent.putExtra("extra.wearable.ble.connect.command", 1);
    LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
    finish();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    LogUtil.d("AddDeviceGuidActivity_bind", "onCreate");
    setContentView(2130903062);
    if (getIntent() != null)
      if (START_FROM_SCAN == getIntent().getIntExtra("extra.baidu.wearable.activity.device.add.device.guide.bind", START_FROM_SCAN))
      {
        LogUtil.d("AddDeviceGuidActivity_bind", "from scan");
        this.mIsFromConnect = false;
      }
    while ($assertionsDisabled)
      while (true)
      {
        initViews();
        this.mReceiver = new Receiver(this);
        this.mReceiver.registerAction("action.wearable.ble.connect.status");
        this.mReceiver.registerAction("action.wearable.ble.bind.result");
        if (!this.mIsFromConnect)
          doBind();
        return;
        LogUtil.d("AddDeviceGuidActivity_bind", "from connect");
        this.mIsFromConnect = true;
      }
    throw new AssertionError();
  }

  protected void onDestroy()
  {
    if ((this.mReceiver != null) && (this.mLocalBroadcastManager != null))
      this.mLocalBroadcastManager.unregisterReceiver(this.mReceiver);
    super.onDestroy();
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }

  class Receiver extends BroadcastReceiver
  {
    Context mContext;

    public Receiver(Context arg2)
    {
      Object localObject;
      this.mContext = localObject;
      AddDeviceGuidActivity_bind.this.mLocalBroadcastManager = LocalBroadcastManager.getInstance(this.mContext);
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      String str = paramIntent.getAction();
      if (str.equals("action.wearable.ble.connect.status"))
        switch (paramIntent.getIntExtra("extra.wearable.ble.connect.status", -1))
        {
        default:
        case 5:
        case 0:
        }
      while ((!str.equals("action.wearable.ble.bind.result")) || (paramIntent.getIntExtra("extra.wearable.ble.bind.result", -1) != 1))
      {
        return;
        LogUtil.d("AddDeviceGuidActivity_bind", "CONNECT_STATE_CONNECTED");
        AddDeviceGuidActivity_bind.this.handleConnected();
        return;
        LogUtil.d("AddDeviceGuidActivity_bind", "CONNECT_STATE_DISCONNECTED");
        AddDeviceGuidActivity_bind.this.handleFail();
        return;
      }
      LogUtil.d("AddDeviceGuidActivity_bind", "BLE_BIND_ERROR");
      AddDeviceGuidActivity_bind.this.handleFail();
    }

    public void registerAction(String paramString)
    {
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction(paramString);
      AddDeviceGuidActivity_bind.this.mLocalBroadcastManager.registerReceiver(this, localIntentFilter);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_bind
 * JD-Core Version:    0.6.2
 */