package com.baidu.wearable.ui.activities.device;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;

public class AddDeviceGuidActivity_doubleClick_tip extends Activity
{
  private static final String TAG = "AddDeviceGuidActivity_battery";
  private Button mBtnNextStep;
  private Button mBtnPrevStep;

  private void initViews()
  {
    this.mBtnPrevStep = ((Button)findViewById(2131231003));
    this.mBtnPrevStep.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_battery", "prev step button click");
        Intent localIntent = new Intent(AddDeviceGuidActivity_doubleClick_tip.this, AddDeviceGuidActivity_bind_success.class);
        AddDeviceGuidActivity_doubleClick_tip.this.startActivity(localIntent);
        AddDeviceGuidActivity_doubleClick_tip.this.finish();
      }
    });
    this.mBtnNextStep = ((Button)findViewById(2131231004));
    this.mBtnNextStep.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_battery", "next step button click");
        Intent localIntent = new Intent(AddDeviceGuidActivity_doubleClick_tip.this, AddDeviceGuidActivity_sleep_tip.class);
        AddDeviceGuidActivity_doubleClick_tip.this.startActivity(localIntent);
        AddDeviceGuidActivity_doubleClick_tip.this.finish();
      }
    });
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903068);
    initViews();
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramKeyEvent.getKeyCode() == 4)
    {
      startActivity(new Intent(this, AddDeviceGuidActivity_bind_success.class));
      finish();
    }
    return super.onKeyUp(paramInt, paramKeyEvent);
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_doubleClick_tip
 * JD-Core Version:    0.6.2
 */