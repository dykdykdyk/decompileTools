package com.baidu.wearable.ui.activities.device;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;

public class AddDeviceGuidActivity_bind_fail extends Activity
{
  private static final String TAG = "AddDeviceGuidActivity_bind_fail";
  private Button mBtnRetry;

  private void initViews()
  {
    this.mBtnRetry = ((Button)findViewById(2131231016));
    this.mBtnRetry.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_bind_fail", "retry button click");
        Intent localIntent = new Intent(AddDeviceGuidActivity_bind_fail.this, AddDeviceGuidActivity_charge.class);
        AddDeviceGuidActivity_bind_fail.this.startActivity(localIntent);
        AddDeviceGuidActivity_bind_fail.this.finish();
      }
    });
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903063);
    initViews();
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_bind_fail
 * JD-Core Version:    0.6.2
 */