package com.baidu.wearable.ui.activities.device;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.ui.activities.FlipActivity;

public class AddDeviceGuidActivity_sleep_tip extends Activity
{
  private static final String TAG = "AddDeviceGuidActivity_battery";
  private Button mBtnNextStep;
  private Button mBtnPrevStep;

  private void initViews()
  {
    this.mBtnPrevStep = ((Button)findViewById(2131231003));
    this.mBtnPrevStep.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_battery", "prev step button click");
        Intent localIntent = new Intent(AddDeviceGuidActivity_sleep_tip.this, AddDeviceGuidActivity_doubleClick_tip.class);
        AddDeviceGuidActivity_sleep_tip.this.startActivity(localIntent);
        AddDeviceGuidActivity_sleep_tip.this.finish();
      }
    });
    this.mBtnNextStep = ((Button)findViewById(2131231027));
    this.mBtnNextStep.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_battery", "next step button click");
        Intent localIntent = new Intent(AddDeviceGuidActivity_sleep_tip.this, FlipActivity.class);
        AddDeviceGuidActivity_sleep_tip.this.startActivity(localIntent);
        AddDeviceGuidActivity_sleep_tip.this.finish();
      }
    });
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903069);
    initViews();
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    if (paramKeyEvent.getKeyCode() == 4)
    {
      startActivity(new Intent(this, AddDeviceGuidActivity_doubleClick_tip.class));
      finish();
    }
    return super.onKeyUp(paramInt, paramKeyEvent);
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_sleep_tip
 * JD-Core Version:    0.6.2
 */