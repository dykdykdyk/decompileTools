package com.baidu.wearable.ui.activities.device;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;

public class AddDeviceGuidActivity_battery extends Activity
{
  private static final String TAG = "AddDeviceGuidActivity_battery";
  private Button mBtnNextStep;
  private Button mBtnPrevStep;

  private void initViews()
  {
    this.mBtnPrevStep = ((Button)findViewById(2131231003));
    this.mBtnPrevStep.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_battery", "prev step button click");
        Intent localIntent = new Intent(AddDeviceGuidActivity_battery.this, AddDeviceGuidActivity_charge.class);
        AddDeviceGuidActivity_battery.this.startActivity(localIntent);
        AddDeviceGuidActivity_battery.this.finish();
      }
    });
    this.mBtnNextStep = ((Button)findViewById(2131231004));
    this.mBtnNextStep.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_battery", "next step button click");
        Intent localIntent = new Intent(AddDeviceGuidActivity_battery.this, AddDeviceGuidActivity_connect.class);
        AddDeviceGuidActivity_battery.this.startActivity(localIntent);
        AddDeviceGuidActivity_battery.this.finish();
      }
    });
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903061);
    initViews();
  }

  protected void onDestroy()
  {
    super.onDestroy();
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_battery
 * JD-Core Version:    0.6.2
 */