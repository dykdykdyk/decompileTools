package com.baidu.wearable.ui.activities.device;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.tracker.TrackerHelper.TrackerType;
import com.baidu.wearable.ui.activities.ChooseDeviceActivity;

public class AddDeviceGuidActivity_charge extends Activity
{
  private static final String TAG = "AddDeviceGuidActivity_charge";
  private Button mBtnNextStep;
  private Button mBtnPrevStep;

  private void initViews()
  {
    this.mBtnPrevStep = ((Button)findViewById(2131231017));
    this.mBtnPrevStep.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_charge", "prev step button click");
        if ((TrackerHelper.getInstance(AddDeviceGuidActivity_charge.this).getTrackerType() != TrackerHelper.TrackerType.Phone) && (TrackerHelper.getInstance(AddDeviceGuidActivity_charge.this).getTrackerType() == TrackerHelper.TrackerType.handring))
          AddDeviceGuidActivity_charge.this.startActivity(new Intent(AddDeviceGuidActivity_charge.this, ChooseDeviceActivity.class));
        AddDeviceGuidActivity_charge.this.finish();
      }
    });
    this.mBtnNextStep = ((Button)findViewById(2131231018));
    this.mBtnNextStep.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_charge", "next step button click");
        Intent localIntent = new Intent(AddDeviceGuidActivity_charge.this, AddDeviceGuidActivity_battery.class);
        AddDeviceGuidActivity_charge.this.startActivity(localIntent);
        AddDeviceGuidActivity_charge.this.finish();
      }
    });
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903065);
    initViews();
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_charge
 * JD-Core Version:    0.6.2
 */