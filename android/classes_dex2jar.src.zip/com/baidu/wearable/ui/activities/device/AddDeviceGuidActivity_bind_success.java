package com.baidu.wearable.ui.activities.device;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;

public class AddDeviceGuidActivity_bind_success extends Activity
{
  private static final String TAG = "AddDeviceGuidActivity_bind_success";
  private Button mBtnCompelted;

  private void gotoDoubleTipActivity()
  {
    startActivity(new Intent(this, AddDeviceGuidActivity_doubleClick_tip.class));
    finish();
  }

  private void initViews()
  {
    this.mBtnCompelted = ((Button)findViewById(2131231018));
    this.mBtnCompelted.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AddDeviceGuidActivity_bind_success", "mBtnCompelted button click");
        AddDeviceGuidActivity_bind_success.this.gotoDoubleTipActivity();
      }
    });
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903064);
    initViews();
  }

  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent)
  {
    paramKeyEvent.getKeyCode();
    return false;
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_bind_success
 * JD-Core Version:    0.6.2
 */