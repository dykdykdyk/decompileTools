package com.baidu.wearable.ui.activities.device;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.baidu.wearable.ble.connectmanager.BluetoothState;
import com.baidu.wearable.ota.DFUVersionManager;

public class DeviceInformationFragment extends DialogFragment
{
  private static final String TAG = "DeviceInformationFragment";

  public static final DeviceInformationFragment newInstance()
  {
    return new DeviceInformationFragment();
  }

  public void onCancel(DialogInterface paramDialogInterface)
  {
  }

  public Dialog onCreateDialog(Bundle paramBundle)
  {
    View localView = View.inflate(getActivity(), 2130903072, null);
    TextView localTextView1 = (TextView)localView.findViewById(2131231033);
    TextView localTextView2 = (TextView)localView.findViewById(2131231034);
    TextView localTextView3 = (TextView)localView.findViewById(2131231035);
    TextView localTextView4 = (TextView)localView.findViewById(2131231036);
    if (BluetoothState.getInstance().getManufactureName() != null)
    {
      localTextView1.setText(BluetoothState.getInstance().getManufactureName());
      if (BluetoothState.getInstance().getModelNumber() == null)
        break label211;
      localTextView2.setText(BluetoothState.getInstance().getModelNumber());
      label93: if (BluetoothState.getInstance().getHardwareRevision() == null)
        break label250;
      localTextView3.setText(BluetoothState.getInstance().getHardwareRevision());
      label113: if (BluetoothState.getInstance().getSoftwareRevision() == null)
        break label289;
      localTextView4.setText(BluetoothState.getInstance().getSoftwareRevision());
    }
    while (true)
    {
      return new AlertDialog.Builder(getActivity()).setTitle(2131296591).setView(localView).setCancelable(false).setPositiveButton(2131296592, new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
        }
      }).create();
      if ((DFUVersionManager.getInstance() != null) && (DFUVersionManager.getInstance().getDeviceManufactory() != null))
      {
        localTextView1.setText(DFUVersionManager.getInstance().getDeviceManufactory());
        break;
      }
      localTextView1.setText(2131296597);
      break;
      label211: if ((DFUVersionManager.getInstance() != null) && (DFUVersionManager.getInstance().getDeviceModelName() != null))
      {
        localTextView2.setText(DFUVersionManager.getInstance().getDeviceModelName());
        break label93;
      }
      localTextView2.setText(2131296597);
      break label93;
      label250: if ((DFUVersionManager.getInstance() != null) && (DFUVersionManager.getInstance().getDeviceHWVersion() != null))
      {
        localTextView3.setText(DFUVersionManager.getInstance().getDeviceHWVersion());
        break label113;
      }
      localTextView3.setText(2131296597);
      break label113;
      label289: if ((DFUVersionManager.getInstance() != null) && (DFUVersionManager.getInstance().getDeviceSWVersion() != null))
        localTextView4.setText(DFUVersionManager.getInstance().getDeviceSWVersion());
      else
        localTextView4.setText(2131296597);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.device.DeviceInformationFragment
 * JD-Core Version:    0.6.2
 */