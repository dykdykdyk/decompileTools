package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.AppManager;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.net.TrackerTransport;
import com.baidu.wearable.net.Transport.CommonListener;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_charge;
import com.baidu.wearable.ui.activities.device.DeviceInformationFragment;
import com.baidu.wearable.util.PhoneCheck;
import com.baidu.wearable.util.SilentSleepManager;

public class MyDeviceSettingActivity extends Activity
{
  private static final String TAG = "MyDeviceSettingActivity";
  private RelativeLayout mAddNewDevices;
  private ImageButton mBackButton;
  private Context mContext;
  private RelativeLayout mDeviceLayout;
  private TextView mDeviceName;
  private TextView mDevicesName;
  private TextView mUnBind;

  private void setupViews()
  {
    this.mDeviceLayout = ((RelativeLayout)findViewById(2131230853));
    this.mDevicesName = ((TextView)findViewById(2131230854));
    this.mUnBind = ((TextView)findViewById(2131230855));
    this.mAddNewDevices = ((RelativeLayout)findViewById(2131230856));
    this.mBackButton = ((ImageButton)findViewById(2131230852));
    this.mBackButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyDeviceSettingActivity.this.finish();
      }
    });
    this.mDevicesName.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyDeviceSettingActivity.this.showDeviceInformation();
      }
    });
    this.mUnBind.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyDeviceSettingActivity.this.startDeleteDevice();
      }
    });
    this.mAddNewDevices.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        if (TrackerHelper.getInstance(MyDeviceSettingActivity.this.getApplicationContext()).isHandringMode())
        {
          MyDeviceSettingActivity.this.startRepleaceDevice();
          return;
        }
        MyDeviceSettingActivity.this.startAddDevice();
      }
    });
  }

  private void showDeviceInformation()
  {
    DeviceInformationFragment.newInstance().show(getFragmentManager(), "MyDeviceSettingActivity");
  }

  private void startAddDevice()
  {
    if (!PhoneCheck.isBleSupport(this))
    {
      AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(this);
      localBuilder1.setTitle(2131296674).setMessage(2131296675);
      localBuilder1.setPositiveButton(2131296607, new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
        }
      });
      localBuilder1.create().show();
      return;
    }
    if (BluetoothAdapter.getDefaultAdapter().getState() == 10)
    {
      AlertDialog.Builder localBuilder2 = new AlertDialog.Builder(this);
      localBuilder2.setTitle(2131296604).setMessage(2131296606);
      localBuilder2.setPositiveButton(2131296607, new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          BluetoothAdapter.getDefaultAdapter().enable();
          MyDeviceSettingActivity.this.startActivity(new Intent(MyDeviceSettingActivity.this, AddDeviceGuidActivity_charge.class));
          MyDeviceSettingActivity.this.finish();
        }
      });
      localBuilder2.setNegativeButton(2131296608, new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
        }
      });
      localBuilder2.create().show();
      return;
    }
    startActivity(new Intent(this, AddDeviceGuidActivity_charge.class));
    finish();
  }

  private void startDeleteDevice()
  {
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
    localBuilder.setTitle(2131296612).setMessage(2131296614);
    localBuilder.setPositiveButton(2131296607, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        final TrackerHelper localTrackerHelper = TrackerHelper.getInstance(MyDeviceSettingActivity.this.getApplicationContext());
        TrackerTransport.getInstance(MyDeviceSettingActivity.this.mContext).registerTracker(new Transport.CommonListener()
        {
          public void onFailure(int paramAnonymous2Int, String paramAnonymous2String)
          {
            Toast.makeText(MyDeviceSettingActivity.this.mContext, 2131296613, 0).show();
          }

          public void onSuccess()
          {
            localTrackerHelper.savePhoneRegisterInfo();
            localTrackerHelper.setRegisterState(true);
            MyDeviceSettingActivity.this.mDeviceLayout.setVisibility(8);
            MyDeviceSettingActivity.this.mAddNewDevices.setVisibility(0);
            LogUtil.v("MyDeviceSettingActivity", "send ACTION_CUT_OFF in setOnClickListener");
            Intent localIntent1 = new Intent("com.baidu.wearable.ACTION_CHANGE_TO_PHONE");
            LocalBroadcastManager.getInstance(MyDeviceSettingActivity.this).sendBroadcast(localIntent1);
            Intent localIntent2 = new Intent("action.wearable.ble.connect.command");
            localIntent2.putExtra("extra.wearable.ble.connect.command", 1);
            LocalBroadcastManager.getInstance(MyDeviceSettingActivity.this).sendBroadcast(localIntent2);
            SilentSleepManager localSilentSleepManager = SilentSleepManager.getInstance(MyDeviceSettingActivity.this.mContext);
            if (localSilentSleepManager != null)
            {
              localSilentSleepManager.setSilentMode(false);
              localSilentSleepManager.removeSharedPreference();
            }
          }
        }
        , localTrackerHelper.getPhoneTrackerList());
      }
    });
    localBuilder.setNegativeButton(2131296608, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
      }
    });
    localBuilder.create().show();
  }

  private void startRepleaceDevice()
  {
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
    localBuilder.setTitle(2131296615).setMessage(2131296616);
    localBuilder.setPositiveButton(2131296607, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        Intent localIntent = new Intent("action.wearable.ble.connect.command");
        localIntent.putExtra("extra.wearable.ble.connect.command", 1);
        LocalBroadcastManager.getInstance(MyDeviceSettingActivity.this).sendBroadcast(localIntent);
        MyDeviceSettingActivity.this.startAddDevice();
      }
    });
    localBuilder.setNegativeButton(2131296608, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
      }
    });
    localBuilder.create().show();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903050);
    setupViews();
    AppManager.getAppManager().addActivity(this);
    this.mContext = this;
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    if (TrackerHelper.getInstance(getApplicationContext()).isHandringMode())
    {
      this.mDeviceLayout.setVisibility(0);
      this.mDevicesName.setText(TrackerHelper.getInstance(getApplicationContext()).getDisplayName());
      this.mAddNewDevices.setVisibility(8);
    }
    while (true)
    {
      super.onResume();
      StatService.onResume(this);
      return;
      this.mDeviceLayout.setVisibility(8);
      this.mAddNewDevices.setVisibility(0);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.MyDeviceSettingActivity
 * JD-Core Version:    0.6.2
 */