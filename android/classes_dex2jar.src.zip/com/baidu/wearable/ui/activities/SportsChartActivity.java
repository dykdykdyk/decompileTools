package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SportDao;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.sport.SportDetail;
import com.baidu.wearable.sport.SportSummary;
import com.baidu.wearable.ui.bean.ChartDateType;
import com.baidu.wearable.ui.bean.SportData;
import com.baidu.wearable.ui.bean.SportsChartFuncType;
import com.baidu.wearable.ui.view.SportsDetailChartView;
import com.baidu.wearable.ui.widget.ChartBoxTipView;
import com.baidu.wearable.util.MathUtil;
import com.baidu.wearable.util.SportsIndexCalcUtil;
import com.baidu.wearable.util.TimeUtil;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class SportsChartActivity extends Activity
  implements View.OnClickListener
{
  public static final int CALORIES = 2;
  public static final String CHART_FUNC_TYPE = "chart_type";
  private static final int DAY_CHART_COUNT = 25;
  public static final String DAY_INDEX = "day_index";
  public static final int DISTANCES = 1;
  private static final int MONTH_CHART_COUNT = 31;
  public static final int STEPS = 0;
  private static final String TAG = "SportsChartActivity";
  private static final int WEEK_CHART_COUNT = 7;
  private Button mBtnCal;
  private Button mBtnMile;
  private Button mBtnStep;
  private View mChartContentView = null;
  private FrameLayout mChartLayout;
  private SportsDetailChartView mChartView = null;
  private RelativeLayout mChartViewLayout;
  private Context mContext;
  public ChartDateType mCurrentDateType = ChartDateType.DAY;
  public SportsChartFuncType mCurrentFuncType = SportsChartFuncType.STEP;
  private SportData mCurrentSportData = null;
  private ChartBoxTipView mDateLayout;
  private List<double[]> mDayDetailData = new ArrayList(1);
  private SportData mDayDetailSportData = null;
  private int mDayIndex;
  private ImageView mDottedImageView;
  private boolean mIsViewReady = false;
  private SportData mMonthSportData = null;
  private TextView mTab30Day;
  private TextView mTab7Day;
  private TextView mTabToday;
  private double mTarget;
  private int mTargetCals;
  private TextView mTargetContent;
  private float mTargetDistance;
  private LinearLayout mTargetLayout;
  private long mTargetStep;
  private TextView mTargetUnit;
  private SportData mWeekSportData = null;

  private ChartDateType getCurrentDateType()
  {
    return this.mCurrentDateType;
  }

  private SportsChartFuncType getCurrentFuncType()
  {
    return this.mCurrentFuncType;
  }

  private Pair<Long, Long> getStartTime(int paramInt)
  {
    Date localDate1 = new Date(System.currentTimeMillis() - 86400000L * paramInt);
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date localDate2 = localSimpleDateFormat.parse(localSimpleDateFormat.format(localDate1), new ParsePosition(0));
    long l1 = (localDate2.getTime() - 3600000L) / 1000L;
    long l2 = (86400000L + localDate2.getTime()) / 1000L;
    return new Pair(Long.valueOf(l1), Long.valueOf(l2));
  }

  private void initView()
  {
    this.mDateLayout = ((ChartBoxTipView)findViewById(2131230945));
    this.mDottedImageView = ((ImageView)findViewById(2131230937));
    this.mChartLayout = ((FrameLayout)findViewById(2131230933));
    ((ImageButton)findViewById(2131230763)).setOnClickListener(this);
    this.mTabToday = ((TextView)findViewById(2131230911));
    this.mTabToday.setOnClickListener(this);
    this.mTab7Day = ((TextView)findViewById(2131230912));
    this.mTab7Day.setOnClickListener(this);
    this.mTab30Day = ((TextView)findViewById(2131230913));
    this.mTab30Day.setOnClickListener(this);
    this.mBtnStep = ((Button)findViewById(2131230944));
    this.mBtnStep.setOnClickListener(this);
    this.mBtnCal = ((Button)findViewById(2131230943));
    this.mBtnCal.setOnClickListener(this);
    this.mBtnMile = ((Button)findViewById(2131230942));
    this.mBtnMile.setOnClickListener(this);
    this.mChartViewLayout = ((RelativeLayout)findViewById(2131230909));
    this.mTargetLayout = ((LinearLayout)findViewById(2131230938));
    this.mTargetContent = ((TextView)findViewById(2131230940));
    this.mTargetUnit = ((TextView)findViewById(2131230941));
    if (this.mChartView == null)
      this.mChartView = new SportsDetailChartView(this, this.mDateLayout, this.mDottedImageView);
  }

  private void loadData()
  {
    if (this.mDayDetailSportData == null)
      this.mDayDetailSportData = new SportData(25);
    if (this.mMonthSportData == null)
      this.mMonthSportData = new SportData(31);
    if (this.mWeekSportData == null)
      this.mWeekSportData = new SportData(7);
    if (this.mCurrentSportData == null)
    {
      if (getCurrentDateType() != ChartDateType.DAY)
        break label102;
      this.mCurrentSportData = this.mDayDetailSportData;
    }
    while (true)
    {
      new AsyncTask()
      {
        protected Void doInBackground(Void[] paramAnonymousArrayOfVoid)
        {
          SportsChartActivity.this.loadTargetData();
          SportsChartActivity.this.loadDayDetailData();
          SportsChartActivity.this.loadMonthData();
          return null;
        }

        protected void onPostExecute(Void paramAnonymousVoid)
        {
          SportsChartActivity.this.refreshCurrentFuncView(SportsChartActivity.this.mCurrentFuncType);
          SportsChartActivity.this.refreshCurrentDateView(SportsChartActivity.access$4(SportsChartActivity.this));
          SportsChartActivity.this.refreshChartView(SportsChartActivity.access$6(SportsChartActivity.this));
          if (SportsChartActivity.this.mChartContentView == null)
          {
            SportsChartActivity.this.mChartContentView = SportsChartActivity.this.mChartView.execute(SportsChartActivity.this.mCurrentFuncType, SportsChartActivity.this.mDayDetailData, SportsChartActivity.this.mDayIndex);
            SportsChartActivity.this.mChartLayout.removeAllViews();
            SportsChartActivity.this.mChartLayout.addView(SportsChartActivity.this.mChartContentView);
            SportsChartActivity.this.mIsViewReady = true;
          }
          while (true)
          {
            super.onPostExecute(paramAnonymousVoid);
            return;
            SportsChartActivity.this.updateChartView();
          }
        }
      }
      .execute(new Void[0]);
      return;
      label102: if (getCurrentDateType() == ChartDateType.WEEK)
        this.mCurrentSportData = this.mWeekSportData;
      else if (getCurrentDateType() == ChartDateType.MONTH)
        this.mCurrentSportData = this.mMonthSportData;
    }
  }

  private void loadDayDetailData()
  {
    SQLiteDatabase localSQLiteDatabase = Database.getDb(this.mContext);
    long l = ((Long)getStartTime(this.mDayIndex).first).longValue();
    Iterator localIterator = SportDao.selectSportDetail(localSQLiteDatabase, l, ((Long)getStartTime(this.mDayIndex).second).longValue()).iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      SportDetail localSportDetail = (SportDetail)localIterator.next();
      int i = (int)((localSportDetail.getTimestampS() - l) / 60L / 15L);
      int j = localSportDetail.getSteps();
      float f1 = localSportDetail.getCalories();
      float f2 = localSportDetail.getDistance() / 1000.0F;
      double[] arrayOfDouble1 = this.mDayDetailSportData.steps;
      int k = i / 4;
      arrayOfDouble1[k] += j;
      double[] arrayOfDouble2 = this.mDayDetailSportData.distances;
      int m = i / 4;
      arrayOfDouble2[m] += MathUtil.convert(f2);
      double[] arrayOfDouble3 = this.mDayDetailSportData.calories;
      int n = i / 4;
      arrayOfDouble3[n] += (int)f1;
    }
  }

  private void loadMonthData()
  {
    List localList = SportDao.selectSportSummary(Database.getDb(this), Integer.valueOf(String.valueOf((System.currentTimeMillis() - 86400000L * (31 + this.mDayIndex)) / 1000L)).intValue());
    Calendar localCalendar1 = Calendar.getInstance();
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    localCalendar1.setTimeInMillis(localSimpleDateFormat.parse(localSimpleDateFormat.format(new Date(System.currentTimeMillis())), new ParsePosition(0)).getTime());
    Calendar localCalendar2 = (Calendar)localCalendar1.clone();
    Iterator localIterator = localList.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      SportSummary localSportSummary = (SportSummary)localIterator.next();
      ParsePosition localParsePosition = new ParsePosition(0);
      localCalendar2.setTime(localSimpleDateFormat.parse(localSportSummary.getDate(), localParsePosition));
      int i = TimeUtil.daysBetween(localCalendar2, localCalendar1);
      if (i >= this.mDayIndex)
      {
        int j = 30 - i + this.mDayIndex;
        if ((j < 31) && (j >= 0))
        {
          this.mMonthSportData.steps[j] = localSportSummary.getSteps();
          this.mMonthSportData.calories[j] = ((int)localSportSummary.getCalories());
          this.mMonthSportData.distances[j] = MathUtil.convert(localSportSummary.getDistance() / 1000.0F);
        }
        int k = 6 - i + this.mDayIndex;
        if ((k < 7) && (k >= 0))
        {
          this.mWeekSportData.steps[k] = localSportSummary.getSteps();
          this.mWeekSportData.calories[k] = ((int)localSportSummary.getCalories());
          this.mWeekSportData.distances[k] = MathUtil.convert(localSportSummary.getDistance() / 1000.0F);
        }
      }
    }
  }

  private void loadTargetData()
  {
    this.mTargetStep = PlanPreference.getInstance(this.mContext).getTargetStep();
    this.mTargetCals = SportsIndexCalcUtil.getCaloriesFromSteps(this.mContext, (int)this.mTargetStep);
    float f = SportsIndexCalcUtil.getDistanceFromSteps(this.mContext, (int)this.mTargetStep);
    if (f > 0.0F)
      this.mTargetDistance = f;
    LogUtil.d("SportsChartActivity", "init target data: steps:" + this.mTargetStep + ", calories:" + this.mTargetCals + ", distance:" + this.mTargetDistance);
  }

  private void refreshChartView(SportsChartFuncType paramSportsChartFuncType)
  {
    this.mDayDetailData.clear();
    if (getCurrentFuncType() == SportsChartFuncType.STEP)
    {
      this.mDayDetailData.add(this.mCurrentSportData.steps);
      this.mTarget = this.mTargetStep;
    }
    do
    {
      return;
      if (getCurrentFuncType() == SportsChartFuncType.CALORIE)
      {
        this.mDayDetailData.add(this.mCurrentSportData.calories);
        this.mTarget = this.mTargetCals;
        return;
      }
    }
    while (getCurrentFuncType() != SportsChartFuncType.DISTANCE);
    this.mDayDetailData.add(this.mCurrentSportData.distances);
    this.mTarget = ((int)(10.0F * this.mTargetDistance) / 10.0D);
  }

  private void refreshCurrentDateView(ChartDateType paramChartDateType)
  {
    if (paramChartDateType == ChartDateType.DAY)
    {
      this.mTabToday.setTextColor(getResources().getColor(2131099663));
      this.mTab7Day.setTextColor(getResources().getColor(2131099658));
      this.mTab30Day.setTextColor(getResources().getColor(2131099658));
      this.mChartViewLayout.setBackgroundResource(2130837549);
      this.mTargetLayout.setVisibility(8);
      this.mCurrentSportData = this.mDayDetailSportData;
    }
    do
    {
      return;
      if (paramChartDateType == ChartDateType.WEEK)
      {
        this.mTabToday.setTextColor(getResources().getColor(2131099658));
        this.mTab7Day.setTextColor(getResources().getColor(2131099663));
        this.mTab30Day.setTextColor(getResources().getColor(2131099658));
        this.mChartViewLayout.setBackgroundResource(2130837548);
        this.mTargetLayout.setVisibility(0);
        this.mCurrentSportData = this.mWeekSportData;
        return;
      }
    }
    while (paramChartDateType != ChartDateType.MONTH);
    this.mTabToday.setTextColor(getResources().getColor(2131099658));
    this.mTab7Day.setTextColor(getResources().getColor(2131099658));
    this.mTab30Day.setTextColor(getResources().getColor(2131099663));
    this.mChartViewLayout.setBackgroundResource(2130837547);
    this.mTargetLayout.setVisibility(0);
    this.mCurrentSportData = this.mMonthSportData;
  }

  private void refreshCurrentFuncView(SportsChartFuncType paramSportsChartFuncType)
  {
    if (paramSportsChartFuncType == SportsChartFuncType.STEP)
    {
      this.mBtnStep.setBackgroundResource(2130837552);
      this.mBtnCal.setBackgroundResource(2130837553);
      this.mBtnMile.setBackgroundResource(2130837555);
      this.mBtnStep.setTextColor(getResources().getColor(2131099663));
      this.mBtnCal.setTextColor(getResources().getColor(2131099658));
      this.mBtnMile.setTextColor(getResources().getColor(2131099658));
      this.mTargetContent.setText(String.valueOf(this.mTargetStep));
      this.mTargetUnit.setText(2131296458);
    }
    do
    {
      return;
      if (paramSportsChartFuncType == SportsChartFuncType.CALORIE)
      {
        this.mBtnStep.setBackgroundResource(2130837551);
        this.mBtnCal.setBackgroundResource(2130837554);
        this.mBtnMile.setBackgroundResource(2130837555);
        this.mBtnStep.setTextColor(getResources().getColor(2131099658));
        this.mBtnCal.setTextColor(getResources().getColor(2131099663));
        this.mBtnMile.setTextColor(getResources().getColor(2131099658));
        this.mTargetContent.setText(String.valueOf(this.mTargetCals));
        this.mTargetUnit.setText(2131296462);
        return;
      }
    }
    while (paramSportsChartFuncType != SportsChartFuncType.DISTANCE);
    this.mBtnStep.setBackgroundResource(2130837551);
    this.mBtnCal.setBackgroundResource(2130837553);
    this.mBtnMile.setBackgroundResource(2130837556);
    this.mBtnStep.setTextColor(getResources().getColor(2131099658));
    this.mBtnCal.setTextColor(getResources().getColor(2131099658));
    this.mBtnMile.setTextColor(getResources().getColor(2131099663));
    float f = (int)(10.0F * this.mTargetDistance);
    this.mTargetContent.setText(f / 10.0F);
    this.mTargetUnit.setText(2131296463);
  }

  private void setCurrentDateType(ChartDateType paramChartDateType)
  {
    this.mCurrentDateType = paramChartDateType;
  }

  private void setCurrentFuncType(SportsChartFuncType paramSportsChartFuncType)
  {
    this.mCurrentFuncType = paramSportsChartFuncType;
  }

  public static void startSportsDetailActivity(Context paramContext, int paramInt, SportsChartFuncType paramSportsChartFuncType)
  {
    paramContext.startActivity(new Intent(paramContext, SportsChartActivity.class).putExtra("day_index", paramInt).putExtra("chart_type", paramSportsChartFuncType));
  }

  private void updateChartView()
  {
    this.mChartView.updateData(getCurrentDateType(), getCurrentFuncType(), this.mDayDetailData, this.mTarget, this.mDayIndex);
  }

  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131230763:
    case 2131230911:
    case 2131230912:
    case 2131230913:
    case 2131230942:
    case 2131230943:
    case 2131230944:
    }
    do
    {
      do
      {
        do
        {
          do
          {
            do
            {
              do
              {
                return;
                finish();
                return;
              }
              while (!this.mIsViewReady);
              setCurrentDateType(ChartDateType.DAY);
              refreshCurrentDateView(this.mCurrentDateType);
              refreshChartView(getCurrentFuncType());
              updateChartView();
              return;
            }
            while (!this.mIsViewReady);
            setCurrentDateType(ChartDateType.WEEK);
            refreshCurrentDateView(this.mCurrentDateType);
            refreshChartView(getCurrentFuncType());
            updateChartView();
            return;
          }
          while (!this.mIsViewReady);
          setCurrentDateType(ChartDateType.MONTH);
          refreshCurrentDateView(this.mCurrentDateType);
          refreshChartView(getCurrentFuncType());
          updateChartView();
          return;
        }
        while (!this.mIsViewReady);
        setCurrentFuncType(SportsChartFuncType.DISTANCE);
        refreshCurrentFuncView(this.mCurrentFuncType);
        refreshChartView(SportsChartFuncType.DISTANCE);
        updateChartView();
        return;
      }
      while (!this.mIsViewReady);
      setCurrentFuncType(SportsChartFuncType.CALORIE);
      refreshCurrentFuncView(this.mCurrentFuncType);
      refreshChartView(SportsChartFuncType.CALORIE);
      updateChartView();
      return;
    }
    while (!this.mIsViewReady);
    setCurrentFuncType(SportsChartFuncType.STEP);
    refreshCurrentFuncView(this.mCurrentFuncType);
    refreshChartView(SportsChartFuncType.STEP);
    updateChartView();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.mDayIndex = getIntent().getIntExtra("day_index", 0);
    SportsChartFuncType localSportsChartFuncType = (SportsChartFuncType)getIntent().getSerializableExtra("chart_type");
    if (localSportsChartFuncType == null)
      localSportsChartFuncType = SportsChartFuncType.STEP;
    setCurrentFuncType(localSportsChartFuncType);
    setCurrentDateType(ChartDateType.DAY);
    this.mContext = this;
    requestWindowFeature(1);
    setContentView(2130903056);
    initView();
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
    loadData();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.SportsChartActivity
 * JD-Core Version:    0.6.2
 */