package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.net.TrackerTransport;
import com.baidu.wearable.net.Transport.CommonListener;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_charge;
import com.baidu.wearable.util.PhoneCheck;

public class ChooseDeviceActivity extends Activity
{
  private static final String TAG = "ChooseDeviceActivity";
  private Button hasHandRingButton;
  private Button hasNoHandRingButton;
  private Context mContext;
  private boolean mEnableBluetooth = false;
  private Receiver mReceiver;

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903043);
    this.mContext = this;
    this.hasHandRingButton = ((Button)findViewById(2131230772));
    this.hasNoHandRingButton = ((Button)findViewById(2131230773));
    this.mReceiver = new Receiver(this);
    this.mReceiver.registerAction("android.bluetooth.adapter.action.STATE_CHANGED");
    this.hasHandRingButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        if (!PhoneCheck.isBleSupport(ChooseDeviceActivity.this))
        {
          AlertDialog.Builder localBuilder1 = new AlertDialog.Builder(ChooseDeviceActivity.this);
          localBuilder1.setTitle(2131296674).setMessage(2131296675);
          localBuilder1.setPositiveButton(2131296607, new DialogInterface.OnClickListener()
          {
            public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
            {
            }
          });
          localBuilder1.create().show();
          return;
        }
        if (BluetoothAdapter.getDefaultAdapter().getState() == 10)
        {
          AlertDialog.Builder localBuilder2 = new AlertDialog.Builder(ChooseDeviceActivity.this);
          localBuilder2.setTitle(2131296604).setMessage(2131296605);
          localBuilder2.setPositiveButton(2131296607, new DialogInterface.OnClickListener()
          {
            public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
            {
              BluetoothAdapter.getDefaultAdapter().enable();
              ChooseDeviceActivity.this.mEnableBluetooth = true;
            }
          });
          localBuilder2.setNegativeButton(2131296608, new DialogInterface.OnClickListener()
          {
            public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
            {
            }
          });
          localBuilder2.create().show();
          return;
        }
        ChooseDeviceActivity.this.startActivity(new Intent(ChooseDeviceActivity.this, AddDeviceGuidActivity_charge.class));
        ChooseDeviceActivity.this.finish();
      }
    });
    this.hasNoHandRingButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        TrackerTransport.getInstance(ChooseDeviceActivity.this.mContext).registerTracker(new Transport.CommonListener()
        {
          public void onFailure(int paramAnonymous2Int, String paramAnonymous2String)
          {
            LogUtil.e("ChooseDeviceActivity", "--startFlipActivity---registerTracker---onFailure-errCode=" + paramAnonymous2Int + "--errMsg--" + paramAnonymous2String);
          }

          public void onSuccess()
          {
            LogUtil.e("ChooseDeviceActivity", "---registerTracker--success---");
            TrackerHelper.getInstance(ChooseDeviceActivity.this.getApplicationContext()).savePhoneRegisterInfo();
            Intent localIntent = new Intent("com.baidu.wearable.ACTION_CHANGE_TO_PHONE");
            LocalBroadcastManager.getInstance(ChooseDeviceActivity.this).sendBroadcast(localIntent);
          }
        }
        , TrackerHelper.getInstance(ChooseDeviceActivity.this.getApplicationContext()).getPhoneTrackerList());
        Intent localIntent = new Intent(ChooseDeviceActivity.this, FlipActivity.class);
        localIntent.putExtra("action_connect_by", 1);
        ChooseDeviceActivity.this.startActivity(localIntent);
        ChooseDeviceActivity.this.finish();
      }
    });
  }

  protected void onDestroy()
  {
    if (this.mReceiver != null)
    {
      this.mReceiver.unregisterAction();
      this.mReceiver = null;
    }
    super.onDestroy();
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
    this.mEnableBluetooth = false;
  }

  class Receiver extends BroadcastReceiver
  {
    Context mContext;

    public Receiver(Context arg2)
    {
      Object localObject;
      this.mContext = localObject;
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      if ((paramIntent.getAction().equals("android.bluetooth.adapter.action.STATE_CHANGED")) && (BluetoothAdapter.getDefaultAdapter().getState() == 12) && (ChooseDeviceActivity.this.mEnableBluetooth))
        ChooseDeviceActivity.this.startActivity(new Intent(ChooseDeviceActivity.this, AddDeviceGuidActivity_charge.class));
    }

    public void registerAction(String paramString)
    {
      IntentFilter localIntentFilter = new IntentFilter();
      localIntentFilter.addAction(paramString);
      ChooseDeviceActivity.this.registerReceiver(this, localIntentFilter);
    }

    public void unregisterAction()
    {
      ChooseDeviceActivity.this.unregisterReceiver(ChooseDeviceActivity.this.mReceiver);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.ChooseDeviceActivity
 * JD-Core Version:    0.6.2
 */