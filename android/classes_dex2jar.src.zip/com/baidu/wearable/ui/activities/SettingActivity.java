package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageLoader.ImageListener;
import com.android.volley.toolbox.Volley;
import com.baidu.mobstat.StatService;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.sapi2.ITokenCallback;
import com.baidu.sapi2.activity.LoginActivity;
import com.baidu.wearable.AppManager;
import com.baidu.wearable.Destroy;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SleepDao;
import com.baidu.wearable.database.SportDao;
import com.baidu.wearable.net.TrackerTransport;
import com.baidu.wearable.net.Transport.CommonListener;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.preference.ProfilePreference;
import com.baidu.wearable.profile.AvatarUtil;
import com.baidu.wearable.sync.NetDataSyncManager;
import com.baidu.wearable.sync.NetDataSyncManager.LogoutCallback;
import com.baidu.wearable.sync.NetSync;
import com.baidu.wearable.sync.NetSync.NetSyncListener;
import com.baidu.wearable.sync.SettingNetSyncManager;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.ui.view.BitmapCache;
import java.lang.reflect.Field;
import java.util.List;

public class SettingActivity extends Activity
{
  public static final int MSG_BATTERY_UPDATE = 1;
  private static final String TAG = "SettingActivity";
  private AlarmPreference mAlarmStorage;
  private ImageView mAvataImageView;
  private SQLiteDatabase mDb;
  private RelativeLayout mDialogDoingLayout;
  private boolean mHasDirtyData;
  private AlertDialog mLogoutDialog;
  private PlanPreference mPlanStorage;
  private ProfilePreference mProfileStorage;

  private void dismissDialogAndLogout(DialogInterface paramDialogInterface, boolean paramBoolean)
  {
    try
    {
      Field localField = paramDialogInterface.getClass().getSuperclass().getDeclaredField("mShowing");
      localField.setAccessible(true);
      localField.set(paramDialogInterface, Boolean.valueOf(true));
      if ((this.mLogoutDialog != null) && (this.mLogoutDialog.isShowing()))
        this.mLogoutDialog.dismiss();
      if (paramBoolean)
        doLogout();
      return;
    }
    catch (Exception localException)
    {
      while (true)
        localException.printStackTrace();
    }
  }

  private void doLogout()
  {
    NetDataSyncManager.getInstance(this).logout(true, new NetDataSyncManager.LogoutCallback()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        Toast.makeText(SettingActivity.this, SettingActivity.this.getString(2131296603), 0).show();
      }

      public void onSuccess()
      {
        SettingActivity.this.runOnUiThread(new Runnable()
        {
          public void run()
          {
            SettingActivity.this.doLogoutSync();
          }
        });
      }
    });
  }

  private void doLogoutSync()
  {
    Destroy.executor(this);
    BDAccountManager.getInstance().getAuthTokenAsync(new ITokenCallback()
    {
      public void onResult(String paramAnonymousString)
      {
      }
    }
    , this, LoginActivity.class);
  }

  private static boolean isDirty(SQLiteDatabase paramSQLiteDatabase)
  {
    List localList1 = SportDao.selectDirtySportDetail(paramSQLiteDatabase);
    List localList2 = SleepDao.selectDirtySleepDetail(paramSQLiteDatabase);
    List localList3 = SleepDao.selectDirtySleepDuration(paramSQLiteDatabase);
    LogUtil.d("SettingActivity", "sportDetails count:" + localList1.size() + ", sleepDetails count:" + localList2.size() + ", sleepDurations count:" + localList3.size());
    return ((localList1 != null) && (localList1.size() > 0)) || ((localList1 != null) && (localList2.size() > 0)) || ((localList3 != null) && (localList3.size() > 0));
  }

  private void loadAvataImage()
  {
    RequestQueue localRequestQueue = Volley.newRequestQueue(getApplicationContext());
    ImageLoader.ImageListener localImageListener = ImageLoader.getImageListener(this.mAvataImageView, 0, 0);
    String str = AvatarUtil.getAvataImageUrl(BDAccountManager.getInstance().getUserData("uid"), BDAccountManager.getInstance().getUserData("username"));
    new ImageLoader(localRequestQueue, new BitmapCache()).get(str, localImageListener);
  }

  private void removeSettingNetSyncCmd()
  {
    SettingNetSyncManager.getInstance(this).removeProfileUpdateCmd();
    SettingNetSyncManager.getInstance(this).removePlanUpdateCmd();
  }

  private void setupViews()
  {
    this.mAvataImageView = ((ImageView)findViewById(2131230892));
    ((ImageButton)findViewById(2131230852)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        SettingActivity.this.finish();
      }
    });
    ((TextView)findViewById(2131230893)).setText(BDAccountManager.getInstance().getUserData("displayname"));
    ((RelativeLayout)findViewById(2131230896)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(SettingActivity.this, MyAlarmSettingActivity.class);
        SettingActivity.this.startActivity(localIntent);
      }
    });
    ((RelativeLayout)findViewById(2131230902)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
      }
    });
    ((RelativeLayout)findViewById(2131230900)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(SettingActivity.this, MyInfoSettingActivity.class);
        SettingActivity.this.startActivity(localIntent);
      }
    });
    ((RelativeLayout)findViewById(2131230904)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        SettingActivity.this.startActivity(new Intent(SettingActivity.this, FeedBackActivity.class));
      }
    });
    ((RelativeLayout)findViewById(2131230908)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(SettingActivity.this, AboutActivity.class);
        SettingActivity.this.startActivity(localIntent);
      }
    });
    ((RelativeLayout)findViewById(2131230898)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(SettingActivity.this, MyServiceSettingActivity.class);
        SettingActivity.this.startActivity(localIntent);
      }
    });
    ((Button)findViewById(2131230894)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        SettingActivity.this.mDb = Database.getDb(SettingActivity.this);
        LogUtil.d("SettingActivity", "dirty database:" + SettingActivity.isDirty(SettingActivity.this.mDb) + ", profile:" + SettingActivity.this.mProfileStorage.isDirty() + ", plan:" + SettingActivity.this.mPlanStorage.isDirty() + ", alarm:" + SettingActivity.this.mAlarmStorage.isDirty());
        SettingActivity localSettingActivity = SettingActivity.this;
        if ((!SettingActivity.isDirty(SettingActivity.this.mDb)) && (!SettingActivity.this.mProfileStorage.isDirty()) && (!SettingActivity.this.mPlanStorage.isDirty()) && (!SettingActivity.this.mAlarmStorage.isDirty()));
        for (boolean bool = false; ; bool = true)
        {
          localSettingActivity.mHasDirtyData = bool;
          LogUtil.d("SettingActivity", "logout has dirty data:" + SettingActivity.this.mHasDirtyData);
          SettingActivity.this.showQuitDialog(SettingActivity.this.mHasDirtyData);
          return;
        }
      }
    });
    ((RelativeLayout)findViewById(2131230895)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        SettingActivity.this.startActivity(new Intent(SettingActivity.this, MyDeviceSettingActivity.class));
      }
    });
    ((RelativeLayout)findViewById(2131230906)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        Intent localIntent = new Intent(SettingActivity.this, HelpActivity.class);
        SettingActivity.this.startActivity(localIntent);
      }
    });
  }

  private void showDialog(DialogInterface paramDialogInterface)
  {
    try
    {
      Field localField = paramDialogInterface.getClass().getSuperclass().getDeclaredField("mShowing");
      localField.setAccessible(true);
      localField.set(paramDialogInterface, Boolean.valueOf(false));
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }

  private void showQuitDialog(boolean paramBoolean)
  {
    View localView = LayoutInflater.from(this).inflate(2130903081, null);
    this.mDialogDoingLayout = ((RelativeLayout)localView.findViewById(2131231050));
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(this).setTitle(getString(2131296521)).setView(localView).setNegativeButton(getString(2131296454), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
      }
    }).setPositiveButton(getString(2131296453), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        SettingActivity.this.doLogout();
      }
    });
    if (paramBoolean)
    {
      localBuilder.setMessage(getString(2131296525));
      localBuilder.setNeutralButton(getString(2131296528), new DialogInterface.OnClickListener()
      {
        public void onClick(final DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          SettingActivity.this.mDialogDoingLayout.setVisibility(0);
          SettingActivity.this.mLogoutDialog.getButton(-1).setVisibility(8);
          SettingActivity.this.mLogoutDialog.getButton(-2).setVisibility(8);
          SettingActivity.this.mLogoutDialog.getButton(-3).setVisibility(8);
          SettingActivity.this.showDialog(paramAnonymousDialogInterface);
          final TrackerHelper localTrackerHelper = TrackerHelper.getInstance(SettingActivity.this);
          if (localTrackerHelper.isHandringMode());
          for (List localList = localTrackerHelper.getHandringTrackerList(); ; localList = localTrackerHelper.getPhoneTrackerList())
          {
            TrackerTransport.getInstance(SettingActivity.this).registerTracker(new Transport.CommonListener()
            {
              public void onFailure(int paramAnonymous2Int, String paramAnonymous2String)
              {
                localTrackerHelper.setRegisterState(false);
                Toast.makeText(SettingActivity.this, SettingActivity.this.getString(2131296523), 0).show();
                LogUtil.e("SettingActivity", " registHandringInfo onFailure errCode is " + paramAnonymous2Int + ",errMsg :" + paramAnonymous2String);
                SettingActivity.this.dismissDialogAndLogout(paramAnonymousDialogInterface, false);
              }

              public void onSuccess()
              {
                LogUtil.d("SettingActivity", "registerTracker onSuccess");
                localTrackerHelper.setRegisterState(true);
                SettingActivity.this.removeSettingNetSyncCmd();
                NetSync.sendDirtyDataToNet(SettingActivity.this, SettingActivity.this.mDb, TrackerHelper.getInstance(SettingActivity.this).getTrackerID(), false, new NetSync.NetSyncListener()
                {
                  public void onFailure(int paramAnonymous3Int, String paramAnonymous3String)
                  {
                    LogUtil.d("SettingActivity", "update sport or sleep to net failure");
                    SettingActivity.this.mDialogDoingLayout.setVisibility(8);
                    Toast.makeText(SettingActivity.this, SettingActivity.this.getString(2131296523), 0).show();
                    SettingActivity.this.dismissDialogAndLogout(this.val$dialog, false);
                  }

                  public void onSuccess()
                  {
                    LogUtil.d("SettingActivity", "update sport or sleep to net success");
                    SettingActivity.this.mDialogDoingLayout.setVisibility(8);
                    Toast.makeText(SettingActivity.this, SettingActivity.this.getString(2131296524), 0).show();
                    SettingActivity.this.dismissDialogAndLogout(this.val$dialog, true);
                  }
                });
              }
            }
            , localList);
            return;
          }
        }
      });
    }
    while (true)
    {
      this.mLogoutDialog = localBuilder.create();
      this.mLogoutDialog.show();
      this.mLogoutDialog.setCanceledOnTouchOutside(false);
      return;
      localBuilder.setMessage(getString(2131296522));
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    LogUtil.d("SettingActivity", "onConfigurationChanged");
    if ((this.mLogoutDialog != null) && (this.mLogoutDialog.isShowing()))
    {
      this.mLogoutDialog.cancel();
      showQuitDialog(this.mHasDirtyData);
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    LogUtil.d("SettingActivity", "onCreate");
    setContentView(2130903054);
    this.mProfileStorage = ProfilePreference.getInstance(this);
    this.mPlanStorage = PlanPreference.getInstance(this);
    this.mAlarmStorage = AlarmPreference.getInstance(this);
    setupViews();
    AppManager.getAppManager().addActivity(this);
    loadAvataImage();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    LogUtil.d("SettingActivity", "onDestroy");
    if (this.mLogoutDialog != null)
    {
      this.mLogoutDialog.cancel();
      this.mLogoutDialog = null;
    }
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.SettingActivity
 * JD-Core Version:    0.6.2
 */