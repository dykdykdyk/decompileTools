package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

public class MyServiceSettingActivity extends Activity
{
  private static final String TAG = "MyServiceSettingActivity";
  private String BAIDU_DOMAIN = ".baidu.com";
  private String MY_SERVICE_URL = "http://dulife.baidu.com/service/";
  private ImageButton mButton;
  private RelativeLayout mLayout;
  private WebView mWebView;

  private String getBduss(Context paramContext)
  {
    return paramContext.getSharedPreferences("usercount", 0).getString("usercount_bduss", "");
  }

  private void setupTitle()
  {
    this.mButton = ((ImageButton)findViewById(2131230801));
    this.mButton.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        if ((MyServiceSettingActivity.this.mWebView != null) && (MyServiceSettingActivity.this.mWebView.getOriginalUrl() != null))
        {
          if (MyServiceSettingActivity.this.mWebView.getOriginalUrl().startsWith(MyServiceSettingActivity.this.MY_SERVICE_URL))
            MyServiceSettingActivity.this.finish();
        }
        else
          return;
        MyServiceSettingActivity.this.setupWebView();
      }
    });
  }

  private void setupView()
  {
    setContentView(2130903052);
    this.mLayout = ((RelativeLayout)findViewById(2131230871));
    setupTitle();
    setupWebView();
  }

  private void setupWebSettings()
  {
    WebSettings localWebSettings = this.mWebView.getSettings();
    localWebSettings.setJavaScriptEnabled(true);
    localWebSettings.setDatabaseEnabled(true);
    localWebSettings.setDomStorageEnabled(true);
  }

  private void setupWebView()
  {
    if (this.mWebView != null)
    {
      this.mLayout.removeView(this.mWebView);
      this.mWebView.removeAllViews();
      this.mWebView.destroy();
    }
    this.mWebView = new WebView(this);
    this.mWebView.setLayoutParams(new ViewGroup.LayoutParams(-1, -1));
    this.mWebView.loadUrl(this.MY_SERVICE_URL);
    this.mLayout.addView(this.mWebView);
    WebViewClient local2 = new WebViewClient()
    {
      public boolean shouldOverrideUrlLoading(WebView paramAnonymousWebView, String paramAnonymousString)
      {
        paramAnonymousWebView.loadUrl(paramAnonymousString);
        return true;
      }
    };
    this.mWebView.setWebViewClient(local2);
    setupWebSettings();
  }

  private void syncCookies(Context paramContext, String paramString1, String paramString2)
  {
    CookieSyncManager.createInstance(paramContext);
    CookieManager.getInstance().setCookie(paramString1, "BDUSS=" + paramString2);
    CookieSyncManager.getInstance().sync();
  }

  public void onBackPressed()
  {
    if ((this.mWebView != null) && (this.mWebView.canGoBack()))
    {
      this.mWebView.goBack();
      return;
    }
    finish();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    syncCookies(this, this.BAIDU_DOMAIN, getBduss(this));
    setupView();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.MyServiceSettingActivity
 * JD-Core Version:    0.6.2
 */