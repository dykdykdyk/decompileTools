package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.ota.DFUVersionManager;
import com.baidu.wearable.util.RomDebugManager;
import com.baidu.wearable.util.VersionUtil;

public class AboutActivity extends Activity
{
  private static final long LOTTERY_CLICK_MAX_INTERVAL = 500L;
  private static final String TAG = "AboutActivity";
  private int mLotteryClickCount = 0;
  private long mPreLotteryClickTime = 0L;
  private int mRomDebugClickCount = 0;

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    ((ImageButton)findViewById(2131230730)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        AboutActivity.this.finish();
      }
    });
    ((RelativeLayout)findViewById(2131230732)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        LogUtil.d("AboutActivity", "dev lottery click");
        if ((AboutActivity.this.mLotteryClickCount == 0) || (System.currentTimeMillis() - AboutActivity.this.mPreLotteryClickTime < 500L))
        {
          AboutActivity localAboutActivity = AboutActivity.this;
          localAboutActivity.mLotteryClickCount = (1 + localAboutActivity.mLotteryClickCount);
          AboutActivity.this.mPreLotteryClickTime = System.currentTimeMillis();
          if (AboutActivity.this.mLotteryClickCount > 20)
          {
            AboutActivity.this.mLotteryClickCount = 0;
            LogUtil.d("AboutActivity", "dev mode change trigger");
            if (DFUVersionManager.getInstance() != null)
            {
              DFUVersionManager.getInstance().switchInDevMode();
              if (!DFUVersionManager.getInstance().isInDevMode())
                break label166;
            }
          }
        }
        label166: for (String str = "in Dev Mode"; ; str = "in Release Mode")
        {
          new AlertDialog.Builder(AboutActivity.this).setTitle("Switch Dev Mode").setMessage(str).setPositiveButton("yes", new DialogInterface.OnClickListener()
          {
            public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
            {
            }
          }).setCancelable(false).create().show();
          return;
          AboutActivity.this.mLotteryClickCount = 0;
          break;
        }
      }
    });
    ((TextView)findViewById(2131230734)).setText(VersionUtil.getApkVersionName(this));
    TextView localTextView = (TextView)findViewById(2131230731);
    if (LogUtil.isDebug())
      localTextView.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          LogUtil.d("AboutActivity", "dev lottery click");
          if ((AboutActivity.this.mRomDebugClickCount == 0) || (System.currentTimeMillis() - AboutActivity.this.mPreLotteryClickTime < 500L))
          {
            AboutActivity localAboutActivity = AboutActivity.this;
            localAboutActivity.mRomDebugClickCount = (1 + localAboutActivity.mRomDebugClickCount);
            AboutActivity.this.mPreLotteryClickTime = System.currentTimeMillis();
            if (AboutActivity.this.mRomDebugClickCount > 20)
            {
              AboutActivity.this.mRomDebugClickCount = 0;
              LogUtil.d("AboutActivity", "rom debug mode change trigger");
              if (RomDebugManager.getInstance(AboutActivity.this) != null)
              {
                RomDebugManager.getInstance(AboutActivity.this).switchRomDebug();
                if (!RomDebugManager.getInstance(AboutActivity.this).isRomDebug())
                  break label178;
              }
            }
          }
          label178: for (String str = "open rom debug Mode"; ; str = "close rom debug Mode")
          {
            new AlertDialog.Builder(AboutActivity.this).setTitle("switch rom debug Mode").setMessage(str).setPositiveButton("yes", new DialogInterface.OnClickListener()
            {
              public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
              {
              }
            }).setCancelable(false).create().show();
            return;
            AboutActivity.this.mRomDebugClickCount = 0;
            break;
          }
        }
      });
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.AboutActivity
 * JD-Core Version:    0.6.2
 */