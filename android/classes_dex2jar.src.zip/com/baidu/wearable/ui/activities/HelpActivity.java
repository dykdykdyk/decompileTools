package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.baidu.sapi2.View.CustomViewPager;
import com.baidu.sapi2.View.ImagePageItem;
import com.baidu.sapi2.View.ItemView;
import com.baidu.sapi2.View.PageIndexView;
import com.baidu.sapi2.View.ViewPagerManager;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.ArrayList;
import java.util.List;

public class HelpActivity extends Activity
  implements View.OnClickListener
{
  private ImageButton mButton;
  private RelativeLayout mCategoryLayout;
  private ImageView mMachine;
  private RelativeLayout mMachineLayout;
  private PageIndexView mPageIndexView;
  private ImageView mQuestion;
  private ScrollView mQuestionScroll;
  private TextView mTitle;
  private RelativeLayout mTroubleLayout;
  private RelativeLayout mUELayout;
  private CustomViewPager mViewPager;
  private WebView mWebView;

  private void handleBackPressed()
  {
    if (((this.mQuestionScroll.getVisibility() == 0) || (this.mMachine.getVisibility() == 0) || (this.mViewPager.getVisibility() == 0)) && (this.mCategoryLayout.getVisibility() == 8))
    {
      this.mWebView.setVisibility(8);
      this.mWebView.loadUrl("about:blank");
      this.mQuestionScroll.setVisibility(8);
      this.mMachine.setVisibility(8);
      this.mViewPager.setVisibility(8);
      this.mPageIndexView.setVisibility(8);
      this.mCategoryLayout.setVisibility(0);
      this.mTitle.setText(2131296433);
      return;
    }
    finish();
  }

  private void handleUELayout()
  {
    List localList = initPageItemList();
    int i = localList.size();
    this.mViewPager.setVisibility(0);
    this.mPageIndexView.setVisibility(0);
    new ViewPagerManager(this.mViewPager, this.mPageIndexView, localList, i);
  }

  private List<ItemView> initPageItemList()
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(new ImagePageItem(2130837578, this));
    localArrayList.add(new ImagePageItem(2130837579, this));
    localArrayList.add(new ImagePageItem(2130837580, this));
    localArrayList.add(new ImagePageItem(2130837581, this));
    return localArrayList;
  }

  private void setupView()
  {
    setContentView(2130903047);
    this.mTitle = ((TextView)findViewById(2131230802));
    this.mCategoryLayout = ((RelativeLayout)findViewById(2131230803));
    this.mUELayout = ((RelativeLayout)findViewById(2131230804));
    this.mMachineLayout = ((RelativeLayout)findViewById(2131230806));
    this.mTroubleLayout = ((RelativeLayout)findViewById(2131230807));
    this.mViewPager = ((CustomViewPager)findViewById(2131230816));
    this.mPageIndexView = ((PageIndexView)findViewById(2131230817));
    this.mUELayout.setOnClickListener(this);
    this.mMachineLayout.setOnClickListener(this);
    this.mTroubleLayout.setOnClickListener(this);
    this.mWebView = ((WebView)findViewById(2131230808));
    this.mButton = ((ImageButton)findViewById(2131230801));
    this.mButton.setOnClickListener(this);
    WebViewClient local1 = new WebViewClient()
    {
      public boolean shouldOverrideUrlLoading(WebView paramAnonymousWebView, String paramAnonymousString)
      {
        paramAnonymousWebView.loadUrl(paramAnonymousString);
        return true;
      }
    };
    this.mWebView.setWebViewClient(local1);
    this.mQuestionScroll = ((ScrollView)findViewById(2131230809));
    this.mMachine = ((ImageView)findViewById(2131230815));
    setupWebSettings(this);
  }

  private void setupWebSettings(Context paramContext)
  {
    WebSettings localWebSettings = this.mWebView.getSettings();
    localWebSettings.setBuiltInZoomControls(true);
    localWebSettings.setUseWideViewPort(false);
    localWebSettings.setLoadWithOverviewMode(false);
  }

  public void onBackPressed()
  {
    handleBackPressed();
  }

  public void onClick(View paramView)
  {
    LogUtil.d("test", "==================id:" + paramView.getId());
    switch (paramView.getId())
    {
    case 2131230802:
    case 2131230803:
    case 2131230805:
    default:
      return;
    case 2131230804:
      this.mTitle.setText(2131296640);
      this.mCategoryLayout.setVisibility(8);
      handleUELayout();
      return;
    case 2131230806:
      this.mTitle.setText(2131296641);
      this.mCategoryLayout.setVisibility(8);
      this.mMachine.setVisibility(0);
      return;
    case 2131230807:
      this.mTitle.setText(2131296642);
      this.mCategoryLayout.setVisibility(8);
      this.mQuestionScroll.setVisibility(0);
      return;
    case 2131230801:
    }
    handleBackPressed();
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setupView();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.HelpActivity
 * JD-Core Version:    0.6.2
 */