package com.baidu.wearable.ui.activities;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.preference.ProfilePreference;
import com.baidu.wearable.profile.Gender;
import com.baidu.wearable.ui.view.NumberPicker;
import com.baidu.wearable.ui.widget.GenderPickerDialog;
import com.baidu.wearable.ui.widget.HeightPickerDialog;
import com.baidu.wearable.ui.widget.OnNumberPickerListener;
import com.baidu.wearable.ui.widget.WeightPickerDialog;

public class MyInfoSettingActivity extends Activity
{
  private static final String TAG = "MyInfoSettingActivity";
  private TextView mBirthValue;
  private Context mContext;
  private DatePickerDialog mDatePickerDialog;
  private TextView mGenderValue;
  private HeightPickerDialog mHeightPickerDialog;
  private TextView mHeightValue;
  private ProfilePreference mProfileStorage;
  private WeightPickerDialog mWeightPickerDialog;
  private TextView mWeightValue;

  private void initProfileData()
  {
    if (this.mProfileStorage.getGender() == Gender.female)
      this.mGenderValue.setText(this.mContext.getString(2131296425));
    while (true)
    {
      int i = this.mProfileStorage.getYear();
      if (i != 0)
      {
        int m = this.mProfileStorage.getMonth();
        int n = this.mProfileStorage.getDay();
        this.mBirthValue.setText(i + "/" + m + "/" + n);
      }
      int j = this.mProfileStorage.getHeight();
      int k = this.mProfileStorage.getWeight();
      if (j != 0)
        this.mHeightValue.setText(j + "cm");
      if (k != 0)
        this.mWeightValue.setText(k + "kg");
      return;
      this.mGenderValue.setText(this.mContext.getString(2131296424));
    }
  }

  private void setupViews()
  {
    this.mBirthValue = ((TextView)findViewById(2131230864));
    this.mHeightValue = ((TextView)findViewById(2131230867));
    this.mWeightValue = ((TextView)findViewById(2131230870));
    ((ImageButton)findViewById(2131230858)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyInfoSettingActivity.this.finish();
      }
    });
    ((RelativeLayout)findViewById(2131230859)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyInfoSettingActivity.this.showGenderDialog();
      }
    });
    this.mGenderValue = ((TextView)findViewById(2131230861));
    ((RelativeLayout)findViewById(2131230862)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyInfoSettingActivity.this.showBirthDialog();
      }
    });
    ((RelativeLayout)findViewById(2131230865)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyInfoSettingActivity.this.showHeightDialog();
      }
    });
    ((RelativeLayout)findViewById(2131230868)).setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyInfoSettingActivity.this.showWeightDialog();
      }
    });
  }

  @SuppressLint({"NewApi"})
  private void showBirthDialog()
  {
    this.mDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener()
    {
      public void onDateSet(DatePicker paramAnonymousDatePicker, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3)
      {
        int i = paramAnonymousInt2 + 1;
        MyInfoSettingActivity.this.mBirthValue.setText(paramAnonymousInt1 + "/" + i + "/" + paramAnonymousInt3);
        MyInfoSettingActivity.this.mProfileStorage.saveBirth(paramAnonymousInt1, i, paramAnonymousInt3);
      }
    }
    , this.mProfileStorage.getYear(), -1 + this.mProfileStorage.getMonth(), this.mProfileStorage.getDay());
    this.mDatePickerDialog.setCanceledOnTouchOutside(false);
    this.mDatePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
    this.mDatePickerDialog.show();
  }

  private void showGenderDialog()
  {
    new GenderPickerDialog(this, this.mProfileStorage.getGender(), new OnNumberPickerListener()
    {
      public void onSet(NumberPicker paramAnonymousNumberPicker, int paramAnonymousInt)
      {
        if (paramAnonymousInt == 1)
        {
          MyInfoSettingActivity.this.mProfileStorage.saveGender(Gender.female);
          MyInfoSettingActivity.this.mGenderValue.setText(MyInfoSettingActivity.this.mContext.getString(2131296425));
          return;
        }
        MyInfoSettingActivity.this.mProfileStorage.saveGender(Gender.male);
        MyInfoSettingActivity.this.mGenderValue.setText(MyInfoSettingActivity.this.mContext.getString(2131296424));
      }
    }).show();
  }

  private void showHeightDialog()
  {
    int i = this.mProfileStorage.getHeight();
    if (i == 0)
      if (this.mProfileStorage.getGender() != Gender.male)
        break label58;
    label58: for (i = 170; ; i = 160)
    {
      this.mHeightPickerDialog = new HeightPickerDialog(this, i, new OnNumberPickerListener()
      {
        public void onSet(NumberPicker paramAnonymousNumberPicker, int paramAnonymousInt)
        {
          MyInfoSettingActivity.this.mHeightValue.setText(paramAnonymousInt + "cm");
          MyInfoSettingActivity.this.mProfileStorage.saveHeight(paramAnonymousInt);
        }
      });
      this.mHeightPickerDialog.show();
      return;
    }
  }

  private void showWeightDialog()
  {
    int i = this.mProfileStorage.getWeight();
    if (i == 0)
      if (this.mProfileStorage.getGender() != Gender.male)
        break label57;
    label57: for (i = 70; ; i = 50)
    {
      this.mWeightPickerDialog = new WeightPickerDialog(this, i, new OnNumberPickerListener()
      {
        public void onSet(NumberPicker paramAnonymousNumberPicker, int paramAnonymousInt)
        {
          MyInfoSettingActivity.this.mWeightValue.setText(paramAnonymousInt + "kg");
          MyInfoSettingActivity.this.mProfileStorage.saveWeight(paramAnonymousInt);
        }
      });
      this.mWeightPickerDialog.show();
      return;
    }
  }

  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    LogUtil.d("MyInfoSettingActivity", "onConfigurationChanged");
    if ((this.mDatePickerDialog != null) && (this.mDatePickerDialog.isShowing()))
    {
      this.mDatePickerDialog.cancel();
      showBirthDialog();
    }
    if ((this.mHeightPickerDialog != null) && (this.mHeightPickerDialog.isShowing()))
    {
      this.mHeightPickerDialog.cancel();
      showHeightDialog();
    }
    if ((this.mWeightPickerDialog != null) && (this.mWeightPickerDialog.isShowing()))
    {
      this.mWeightPickerDialog.cancel();
      showWeightDialog();
    }
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903051);
    this.mProfileStorage = ProfilePreference.getInstance(this);
    this.mContext = getApplicationContext();
    setupViews();
    initProfileData();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    if (this.mDatePickerDialog != null)
    {
      this.mDatePickerDialog.cancel();
      this.mDatePickerDialog = null;
    }
    if (this.mHeightPickerDialog != null)
    {
      this.mHeightPickerDialog.cancel();
      this.mHeightPickerDialog = null;
    }
    if (this.mWeightPickerDialog != null)
    {
      this.mWeightPickerDialog.cancel();
      this.mWeightPickerDialog = null;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.MyInfoSettingActivity
 * JD-Core Version:    0.6.2
 */