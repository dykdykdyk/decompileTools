package com.baidu.wearable.ui.activities;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TimePicker;
import android.widget.Toast;
import com.baidu.mobstat.StatService;
import com.baidu.wearable.alarm.clock.ClockAdapter;
import com.baidu.wearable.alarm.clock.ClockListener;
import com.baidu.wearable.alarm.clock.ClockManager;
import com.baidu.wearable.alarm.clock.ClockStorage.DeleteClockListener;
import com.baidu.wearable.alarm.clock.ClockStorage.InsertClockListener;
import com.baidu.wearable.alarm.clock.ClockStorage.SelectClockListener;
import com.baidu.wearable.alarm.clock.ClockStorage.UpdateClockListener;
import com.baidu.wearable.ble.model.Clock;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.sync.SettingsSyncManager;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class MyClockSettingActivity extends Activity
{
  private static final String TAG = "MyClockSettingActivity";
  private static Clock[] mAlarmIdClocks = new Clock[8];
  private ImageButton mAddClock;
  private boolean mAddFlag = false;
  private ImageButton mBack;
  private ClockAdapter mClockAdapter;
  private ClockListener mClockListener;
  private SQLiteDatabase mDb;
  private Handler mHandler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      Bundle localBundle = paramAnonymousMessage.getData();
      switch (paramAnonymousMessage.what)
      {
      default:
        return;
      case 0:
        Clock localClock3 = (Clock)localBundle.getParcelable("clock");
        MyClockSettingActivity.this.handleClockDelete(localClock3);
        return;
      case 1:
        Clock localClock2 = (Clock)localBundle.getParcelable("clock");
        MyClockSettingActivity.this.handleClockAdd(localClock2);
        return;
      case 2:
        Clock localClock1 = (Clock)localBundle.getParcelable("clock");
        MyClockSettingActivity.this.handleClockUpdate(localClock1);
        return;
      case 3:
      }
      ArrayList localArrayList = (ArrayList)paramAnonymousMessage.obj;
      MyClockSettingActivity.this.handleClockInit(localArrayList);
    }
  };
  private LocalBroadcastManager mLocalBroadcastManager;
  private ProgressBar mProgressBar;
  private SettingsSyncManager mSettingSyncMgr;
  private TimePickerDialog mTimeDialog;
  private LinkedList<Clock> mUIClocks;

  private int getAlarmId()
  {
    for (int i = 0; ; i++)
    {
      if (i >= 8)
        i = -1;
      do
      {
        return i;
        LogUtil.d("MyClockSettingActivity", "i:" + i + ", mAlarmIdClocks:" + mAlarmIdClocks[i]);
      }
      while (mAlarmIdClocks[i] == null);
    }
  }

  private void handleClockAdd(final Clock paramClock)
  {
    LogUtil.d("MyClockSettingActivity", "handleClockAdd");
    ClockManager.addClockFromDb(this, paramClock, new ClockStorage.InsertClockListener()
    {
      public void onFailure()
      {
        Toast.makeText(MyClockSettingActivity.this, "insert database failure", 0).show();
      }

      public void onSuccess(long paramAnonymousLong)
      {
        LogUtil.d("MyClockSettingActivity", "insertClock success");
        paramClock.setId(paramAnonymousLong);
        int i = paramClock.getAlarmId();
        LogUtil.d("MyClockSettingActivity", "CLOCK_WHAT_ADD alarmId:" + i);
        MyClockSettingActivity.mAlarmIdClocks[i] = paramClock;
        MyClockSettingActivity.this.mUIClocks.addFirst(paramClock);
        ClockAdapter.addFirst();
        MyClockSettingActivity.this.mClockAdapter.notifyDataSetChanged();
        ClockManager.startClock(MyClockSettingActivity.this, paramClock);
        ClockManager.setClockToRing(MyClockSettingActivity.this);
      }
    });
  }

  private void handleClockDelete(final Clock paramClock)
  {
    LogUtil.d("MyClockSettingActivity", "handleClockDelete id:" + paramClock.getId());
    ClockManager.deleteClockFromDb(this, paramClock, new ClockStorage.DeleteClockListener()
    {
      public void onFailure()
      {
        Toast.makeText(MyClockSettingActivity.this, "delete database failure", 0).show();
      }

      public void onSuccess(long paramAnonymousLong)
      {
        LogUtil.d("MyClockSettingActivity", "deleteClock success");
        if (paramClock.isOn())
          MyClockSettingActivity.this.mClockAdapter.declineClockCount();
        MyClockSettingActivity.this.mUIClocks.remove(paramClock);
        MyClockSettingActivity.mAlarmIdClocks[paramClock.getAlarmId()] = null;
        MyClockSettingActivity.this.mClockAdapter.notifyDataSetChanged();
        ClockManager.stopClock(MyClockSettingActivity.this, paramClock);
        ClockManager.setClockToRing(MyClockSettingActivity.this);
      }
    });
  }

  private void handleClockInit(List<Clock> paramList)
  {
    Iterator localIterator = paramList.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        this.mClockAdapter.notifyDataSetChanged();
        return;
      }
      Clock localClock = (Clock)localIterator.next();
      int i = getAlarmId();
      LogUtil.d("MyClockSettingActivity", "CLOCK_WHAT_INIT alarmId:" + i);
      localClock.setAlarmId(i);
      mAlarmIdClocks[i] = localClock;
      this.mUIClocks.addFirst(localClock);
      ClockAdapter.addFirst();
    }
  }

  private void handleClockUpdate(final Clock paramClock)
  {
    LogUtil.d("MyClockSettingActivity", "handleClockUpdate id:" + paramClock.getId() + ", on:" + paramClock.isOn() + ", year:" + paramClock.getYear() + ", month:" + paramClock.getMonth() + ", day:" + paramClock.getDay() + ", hour:" + paramClock.getHour() + ", minute:" + paramClock.getMinute());
    ClockManager.updateClockFromDb(this, paramClock, new ClockStorage.UpdateClockListener()
    {
      public void onFailure()
      {
        Toast.makeText(MyClockSettingActivity.this, "update database failure", 0).show();
      }

      public void onSuccess(long paramAnonymousLong)
      {
        LogUtil.d("MyClockSettingActivity", "updateClock success");
        ClockManager.startClock(MyClockSettingActivity.this, paramClock);
        ClockManager.stopClock(MyClockSettingActivity.this, paramClock);
        ClockManager.setClockToRing(MyClockSettingActivity.this);
      }
    });
  }

  private void initListView(int paramInt)
  {
    int i = getIntent().getIntExtra("key_clock_count", 0);
    LogUtil.d("MyClockSettingActivity", "init list view count:" + paramInt + ", openCount:" + i);
    this.mClockAdapter = new ClockAdapter(this, this.mHandler, this.mUIClocks, paramInt, i);
    ((ListView)findViewById(2131230849)).setAdapter(this.mClockAdapter);
    printClocksLog(this.mUIClocks);
  }

  private void loadData()
  {
    ClockManager.getClockFromDb(this, new ClockStorage.SelectClockListener()
    {
      public void onResult(List<Clock> paramAnonymousList)
      {
        if (MyClockSettingActivity.this.mUIClocks != null);
        for (int i = 0; ; i++)
        {
          if (i >= paramAnonymousList.size())
          {
            MyClockSettingActivity.this.mUIClocks = ((LinkedList)paramAnonymousList);
            MyClockSettingActivity.this.initListView(paramAnonymousList.size());
            return;
          }
          int j = ((Clock)paramAnonymousList.get(i)).getAlarmId();
          LogUtil.d("MyClockSettingActivity", "selectClock alarmId:" + j);
          if (-1 == j)
          {
            j = MyClockSettingActivity.this.getAlarmId();
            ((Clock)paramAnonymousList.get(i)).setAlarmId(j);
          }
          MyClockSettingActivity.mAlarmIdClocks[j] = ((Clock)paramAnonymousList.get(i));
          ClockManager.startClock(MyClockSettingActivity.this, (Clock)paramAnonymousList.get(i));
        }
      }
    });
  }

  private void printClocksLog(List<Clock> paramList)
  {
    for (int i = 0; ; i++)
    {
      if (i >= paramList.size())
        return;
      Clock localClock = (Clock)paramList.get(i);
      LogUtil.d("MyClockSettingActivity", "id:" + localClock.getId() + ", alarmId:" + localClock.getAlarmId() + ", year:" + localClock.getYear() + ", month:" + localClock.getMonth() + ", day:" + localClock.getDay() + ", onOrOff:" + localClock.isOn() + ", mon:" + localClock.isMon() + ", tue:" + localClock.isTue() + ", wed:" + localClock.isWed() + ", thu:" + localClock.isThu() + ", fri:" + localClock.isFri() + ", sat:" + localClock.isSat() + ", sun:" + localClock.isSun() + ", hour:" + localClock.getHour() + ", minute:" + localClock.getMinute());
    }
  }

  private void registerClockListener()
  {
    this.mClockListener = new ClockListener()
    {
      public void onResult(List<Clock> paramAnonymousList)
      {
        LogUtil.d("MyClockSettingActivity", Thread.currentThread().getName() + "-------mClockListener-----");
        MyClockSettingActivity.this.mProgressBar.setVisibility(4);
        MyClockSettingActivity.this.mAddClock.setEnabled(true);
        MyClockSettingActivity.this.sendInitCmd(paramAnonymousList);
      }
    };
    SettingsSyncManager.getInstance(this).registerClockListener(this.mClockListener);
  }

  private void setupViews()
  {
    setContentView(2130903049);
    this.mBack = ((ImageButton)findViewById(2131230847));
    this.mBack.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyClockSettingActivity.this.finish();
      }
    });
    this.mAddClock = ((ImageButton)findViewById(2131230848));
    this.mAddClock.setOnClickListener(new View.OnClickListener()
    {
      public void onClick(View paramAnonymousView)
      {
        MyClockSettingActivity.this.mAddFlag = false;
        Calendar.getInstance();
        MyClockSettingActivity.this.mTimeDialog = new TimePickerDialog(MyClockSettingActivity.this, new TimePickerDialog.OnTimeSetListener()
        {
          public void onTimeSet(TimePicker paramAnonymous2TimePicker, int paramAnonymous2Int1, int paramAnonymous2Int2)
          {
            if (!MyClockSettingActivity.this.mAddFlag)
            {
              MyClockSettingActivity.this.mAddFlag = true;
              if (MyClockSettingActivity.this.mUIClocks.size() >= 8)
                Toast.makeText(MyClockSettingActivity.this, MyClockSettingActivity.this.getString(2131296552), 0).show();
            }
            else
            {
              return;
            }
            Calendar localCalendar = Calendar.getInstance();
            int i = localCalendar.get(1);
            int j = 1 + localCalendar.get(2);
            int k = localCalendar.get(5);
            Clock localClock = new Clock();
            localClock.setYear(i);
            localClock.setMonth(j);
            localClock.setDay(k);
            localClock.setHour(paramAnonymous2Int1);
            localClock.setMinute(paramAnonymous2Int2);
            localClock.setOn(true);
            localClock.setAlarmId(MyClockSettingActivity.this.getAlarmId());
            ClockAdapter.parseDate(localClock);
            MyClockSettingActivity.this.sendAddCmd(localClock);
          }
        }
        , 8, 0, true);
        MyClockSettingActivity.this.mTimeDialog.setCanceledOnTouchOutside(false);
        MyClockSettingActivity.this.mTimeDialog.show();
      }
    });
    this.mProgressBar = ((ProgressBar)findViewById(2131230850));
    this.mUIClocks = new LinkedList();
    loadData();
  }

  private void unregisterClockListener()
  {
    if (this.mClockListener != null)
      SettingsSyncManager.getInstance(this).unregisterClockListener(this.mClockListener);
  }

  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    LogUtil.d("MyClockSettingActivity", "onCreate");
    this.mSettingSyncMgr = SettingsSyncManager.getInstance(this);
    this.mDb = Database.getDb(this);
    setupViews();
    registerClockListener();
  }

  protected void onDestroy()
  {
    super.onDestroy();
    LogUtil.d("MyClockSettingActivity", "onDestroy");
    if (this.mTimeDialog != null)
    {
      this.mTimeDialog.cancel();
      this.mTimeDialog = null;
    }
    if (this.mClockAdapter != null)
      this.mClockAdapter.clear();
    for (int i = 0; ; i++)
    {
      if (i >= 8)
      {
        this.mUIClocks = null;
        unregisterClockListener();
        return;
      }
      mAlarmIdClocks[i] = null;
    }
  }

  protected void onPause()
  {
    super.onPause();
    StatService.onPause(this);
  }

  protected void onResume()
  {
    super.onResume();
    StatService.onResume(this);
  }

  public void sendAddCmd(Clock paramClock)
  {
    Message localMessage = new Message();
    localMessage.what = 1;
    Bundle localBundle = new Bundle();
    localBundle.putParcelable("clock", paramClock);
    localMessage.setData(localBundle);
    this.mHandler.sendMessage(localMessage);
  }

  public void sendInitCmd(List<Clock> paramList)
  {
    Message localMessage = new Message();
    localMessage.what = 3;
    localMessage.obj = paramList;
    this.mHandler.sendMessage(localMessage);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ui.activities.MyClockSettingActivity
 * JD-Core Version:    0.6.2
 */