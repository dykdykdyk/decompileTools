package com.baidu.wearable.profile;

public class Profile
{
  public static final String AGE = "age";
  public static final String DAY = "birth_day";
  public static final String GENDER = "gender";
  public static final String HEIGHT = "height_cm";
  public static final String MONTH = "birth_month";
  public static final String MTIME = "_mtime";
  public static final String WEIGHT = "weight_kg";
  public static final String YEAR = "birth_year";
  public long _mtime;
  public int age;
  public int day;
  public Gender gender;
  public int height;
  public boolean lastest;
  public int month;
  public int weight;
  public int year;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.profile.Profile
 * JD-Core Version:    0.6.2
 */