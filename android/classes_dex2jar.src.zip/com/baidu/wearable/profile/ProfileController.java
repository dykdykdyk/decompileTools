package com.baidu.wearable.profile;

import android.content.Context;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.net.ProfileTransport;
import com.baidu.wearable.net.ProfileTransport.ProfileResult;
import com.baidu.wearable.net.Transport.CommonResult;
import com.baidu.wearable.preference.ProfilePreference;

public class ProfileController
{
  private static final String TAG = "ProfileController";

  public static Transport.CommonResult sendProfileToNetAndUpdateDb(Context paramContext)
  {
    ProfileTransport localProfileTransport = ProfileTransport.getInstance(paramContext);
    Profile localProfile = new Profile();
    localProfile.height = ProfilePreference.getInstance(paramContext).getHeight();
    localProfile.weight = ProfilePreference.getInstance(paramContext).getWeight();
    localProfile.gender = ProfilePreference.getInstance(paramContext).getGender();
    localProfile.year = ProfilePreference.getInstance(paramContext).getYear();
    localProfile.month = ProfilePreference.getInstance(paramContext).getMonth();
    localProfile.day = ProfilePreference.getInstance(paramContext).getDay();
    localProfile._mtime = ProfilePreference.getInstance(paramContext).getMTime();
    ProfileTransport.ProfileResult localProfileResult = localProfileTransport.updateProfileXSync(localProfile);
    if (localProfileResult.commonResult.errCode == 0)
    {
      LogUtil.d("ProfileController", "update profile to net success.");
      ProfilePreference.getInstance(paramContext).setDirty(false);
      if (!localProfileResult.profile.lastest)
        ProfilePreference.getInstance(paramContext).saveAllProfileInfo(localProfileResult.profile);
    }
    return localProfileResult.commonResult;
  }

  public static boolean sendProfileToNetAndUpdateDbSync(Context paramContext)
  {
    ProfileTransport localProfileTransport = ProfileTransport.getInstance(paramContext);
    Profile localProfile = new Profile();
    localProfile.height = ProfilePreference.getInstance(paramContext).getHeight();
    localProfile.weight = ProfilePreference.getInstance(paramContext).getWeight();
    localProfile.gender = ProfilePreference.getInstance(paramContext).getGender();
    localProfile.year = ProfilePreference.getInstance(paramContext).getYear();
    localProfile.month = ProfilePreference.getInstance(paramContext).getMonth();
    localProfile.day = ProfilePreference.getInstance(paramContext).getDay();
    localProfile._mtime = ProfilePreference.getInstance(paramContext).getMTime();
    ProfileTransport.ProfileResult localProfileResult = localProfileTransport.updateProfileXSync(localProfile);
    int i = localProfileResult.commonResult.errCode;
    boolean bool = false;
    if (i == 0)
    {
      LogUtil.d("ProfileController", "update profile to net success.");
      ProfilePreference.getInstance(paramContext).setDirty(false);
      if (!localProfileResult.profile.lastest)
        ProfilePreference.getInstance(paramContext).saveAllProfileInfo(localProfileResult.profile);
      bool = true;
    }
    return bool;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.profile.ProfileController
 * JD-Core Version:    0.6.2
 */