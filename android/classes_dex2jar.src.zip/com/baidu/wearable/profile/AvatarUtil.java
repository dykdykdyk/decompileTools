package com.baidu.wearable.profile;

import android.text.TextUtils;
import com.baidu.wearable.ble.util.LogUtil;
import java.io.UnsupportedEncodingException;

public class AvatarUtil
{
  private static final String AVATAR_URL = "http://himg.bdimg.com/sys/portrait/item/";
  private static final String CHARS = "0123456789abcdef";
  private static final String IMAGE_SUFFIX = ".jpg";
  private static final String TAG = "AvataUtil";

  private static String enCodeAvataString(int paramInt, String paramString)
  {
    int i = 0;
    int[] arrayOfInt = new int[4];
    arrayOfInt[0] = (paramInt & 0xFF);
    arrayOfInt[1] = ((0xFF00 & paramInt) >> 8);
    arrayOfInt[2] = ((0xFF0000 & paramInt) >> 16);
    arrayOfInt[3] = (0xFF & paramInt >> 24);
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(String.valueOf("0123456789abcdef".charAt(arrayOfInt[0] >> 4)));
    localStringBuilder.append(String.valueOf("0123456789abcdef".charAt(0xF & arrayOfInt[0])));
    localStringBuilder.append(String.valueOf("0123456789abcdef".charAt(arrayOfInt[1] >> 4)));
    localStringBuilder.append(String.valueOf("0123456789abcdef".charAt(0xF & arrayOfInt[1])));
    if (!TextUtils.isEmpty(paramString));
    try
    {
      byte[] arrayOfByte = paramString.getBytes("utf-8");
      int j = arrayOfByte.length;
      while (true)
      {
        if (i >= j)
        {
          localStringBuilder.append(String.valueOf("0123456789abcdef".charAt(arrayOfInt[2] >> 4)));
          localStringBuilder.append(String.valueOf("0123456789abcdef".charAt(0xF & arrayOfInt[2])));
          localStringBuilder.append(String.valueOf("0123456789abcdef".charAt(arrayOfInt[3] >> 4)));
          localStringBuilder.append(String.valueOf("0123456789abcdef".charAt(0xF & arrayOfInt[3])));
          return localStringBuilder.toString();
        }
        localStringBuilder.append(Integer.toHexString(0xFF & arrayOfByte[i]));
        i++;
      }
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      while (true)
        localUnsupportedEncodingException.printStackTrace();
    }
  }

  public static String getAvataImageUrl(String paramString1, String paramString2)
  {
    if (TextUtils.isEmpty(paramString1))
      return "";
    String str = enCodeAvataString(Integer.valueOf(paramString1).intValue(), paramString2);
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("http://himg.bdimg.com/sys/portrait/item/");
    localStringBuilder.append(str);
    localStringBuilder.append(".jpg");
    LogUtil.d("AvataUtil", "getAvataImageUrl is" + localStringBuilder.toString());
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.profile.AvatarUtil
 * JD-Core Version:    0.6.2
 */