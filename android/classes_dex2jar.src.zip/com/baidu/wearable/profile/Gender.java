package com.baidu.wearable.profile;

public enum Gender
{
  static
  {
    female = new Gender("female", 1);
    NA = new Gender("NA", 2);
    Gender[] arrayOfGender = new Gender[3];
    arrayOfGender[0] = male;
    arrayOfGender[1] = female;
    arrayOfGender[2] = NA;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.profile.Gender
 * JD-Core Version:    0.6.2
 */