package com.baidu.wearable.sport;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.support.v4.content.LocalBroadcastManager;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SportDao;
import com.baidu.wearable.util.TimeUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

public class SportController
{
  private static final String TAG = "SportController";

  private static SportSummary dealWithTodayData(SQLiteDatabase paramSQLiteDatabase)
  {
    long l1 = Calendar.getInstance().getTimeInMillis();
    List localList = SportDao.selectSportDetail(paramSQLiteDatabase, TimeUtil.getDayStart() / 1000L, 86400L + TimeUtil.getDayStart() / 1000L);
    LogUtil.d("SportController", "get today sportDetails count:" + localList.size());
    int i = 0;
    float f1 = 0.0F;
    float f2 = 0.0F;
    Iterator localIterator = localList.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        long l2 = Calendar.getInstance().getTimeInMillis();
        LogUtil.d("SportsSummaryPage", "time consumed in dealWithTodayData is " + (l2 - l1));
        return new SportSummary(i, f1, f2);
      }
      SportDetail localSportDetail = (SportDetail)localIterator.next();
      i += localSportDetail.getSteps();
      f1 += localSportDetail.getCalories();
      f2 += localSportDetail.getDistance();
    }
  }

  public static void saveSportData(Context paramContext, List<Sport> paramList)
  {
    new AsyncTask()
    {
      protected Integer doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        SportController.saveSportDataSync((Context)paramAnonymousArrayOfObject[0], (List)paramAnonymousArrayOfObject[1]);
        return null;
      }
    }
    .execute(new Object[] { paramContext, paramList });
  }

  public static List<Sport> saveSportDataSync(Context paramContext, List<Sport> paramList)
  {
    Iterator localIterator1 = paramList.iterator();
    SQLiteDatabase localSQLiteDatabase;
    String str2;
    ArrayList localArrayList;
    Iterator localIterator3;
    if (!localIterator1.hasNext())
    {
      localSQLiteDatabase = Database.getDb(paramContext);
      str2 = TimeUtil.getDate(System.currentTimeMillis());
      localArrayList = new ArrayList();
      localIterator3 = paramList.iterator();
    }
    Sport localSport2;
    List localList;
    do
    {
      if (!localIterator3.hasNext())
      {
        return localArrayList;
        Sport localSport1 = (Sport)localIterator1.next();
        String str1 = localSport1.getDate();
        Iterator localIterator2 = localSport1.getSportDetails().iterator();
        while (true)
        {
          if (!localIterator2.hasNext())
          {
            LogUtil.d("SportController", "saveSportDataSync:" + str1);
            break;
          }
          SportDetail localSportDetail1 = (SportDetail)localIterator2.next();
          str1 = str1 + ", steps:" + localSportDetail1.getSteps() + ", calories:" + localSportDetail1.getCalories() + ", distance:" + localSportDetail1.getDistance();
        }
      }
      localSport2 = (Sport)localIterator3.next();
      localList = localSport2.getSportDetails();
    }
    while (localList == null);
    Iterator localIterator4 = localList.iterator();
    label226: SportSummary localSportSummary;
    label264: String str3;
    Iterator localIterator5;
    if (!localIterator4.hasNext())
    {
      if (!localSport2.getDate().equals(str2))
        break label490;
      localSportSummary = dealWithTodayData(localSQLiteDatabase);
      SportDao.replaceSportSummary(localSQLiteDatabase, localSportSummary);
      if (localSportSummary != null)
      {
        Intent localIntent = new Intent("com.baidu.wearable.BRACELET_DATA_COLLECT");
        localIntent.putExtra("date", localSportSummary.getDate());
        localIntent.putExtra("sum_steps", localSportSummary.getSteps());
        localIntent.putExtra("sum_calories", localSportSummary.getCalories());
        localIntent.putExtra("sum_distance", localSportSummary.getDistance());
        LocalBroadcastManager.getInstance(paramContext).sendBroadcast(localIntent);
        LogUtil.d("SportsSummaryPage", "send broadcast BRACELET_DATA_COLLECT_INTENT with date " + localSportSummary.getDate() + " steps" + localSportSummary.getSteps() + " calories " + localSportSummary.getCalories() + " distance " + localSportSummary.getDistance());
      }
      str3 = localSport2.getDate();
      localIterator5 = localSport2.getSportDetails().iterator();
    }
    while (true)
    {
      if (!localIterator5.hasNext())
      {
        LogUtil.d("SportController", "======saveSportDataSync:" + str3);
        localArrayList.add(localSport2);
        break;
        SportDao.replaceSportDetail(localSQLiteDatabase, (SportDetail)localIterator4.next(), true);
        break label226;
        label490: localSportSummary = new SportSummary(localSport2.getDate(), localSport2.getTotalSteps(), localSport2.getTotalCalories(), localSport2.getTotalDistance());
        SportDao.putSportSummaryWithSummation(localSQLiteDatabase, localSportSummary);
        break label264;
      }
      SportDetail localSportDetail2 = (SportDetail)localIterator5.next();
      str3 = str3 + ", steps:" + localSportDetail2.getSteps() + ", calories:" + localSportDetail2.getCalories() + ", distance:" + localSportDetail2.getDistance();
    }
  }

  public static void saveSportPart(Context paramContext, SportPart paramSportPart, PhoneSportListener paramPhoneSportListener)
  {
    new AsyncTask()
    {
      protected SportPart doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return SportController.saveSportPartSync((Context)paramAnonymousArrayOfObject[0], (SportPart)paramAnonymousArrayOfObject[1]);
      }

      protected void onPostExecute(SportPart paramAnonymousSportPart)
      {
        super.onPostExecute(paramAnonymousSportPart);
        if (SportController.this != null)
          SportController.this.onReceive(paramAnonymousSportPart);
      }
    }
    .execute(new Object[] { paramContext, paramSportPart });
  }

  public static SportPart saveSportPartSync(Context paramContext, SportPart paramSportPart)
  {
    SQLiteDatabase localSQLiteDatabase = Database.getDb(paramContext);
    localSQLiteDatabase.beginTransaction();
    try
    {
      SportDao.putSportDetailWithSummation(localSQLiteDatabase, paramSportPart, true);
      SportDao.putSportSummaryWithSummation(localSQLiteDatabase, new SportSummary(paramSportPart.getSteps(), paramSportPart.getCalories(), paramSportPart.getDistance()));
      localSQLiteDatabase.setTransactionSuccessful();
      localSQLiteDatabase.endTransaction();
      return paramSportPart;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      localSQLiteDatabase.endTransaction();
    }
    return null;
  }

  public static abstract interface PhoneSportListener
  {
    public abstract void onReceive(SportPart paramSportPart);
  }

  public static abstract interface SportListener
  {
    public abstract void onReceive(List<Sport> paramList);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sport.SportController
 * JD-Core Version:    0.6.2
 */