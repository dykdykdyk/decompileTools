package com.baidu.wearable.sport;

import java.util.List;

public class NetSport
{
  private List<SportDetail> detailSlots;
  private long startTimeS;
  private long totalTimeS;

  public NetSport(long paramLong1, long paramLong2, List<SportDetail> paramList)
  {
    this.startTimeS = paramLong1;
    this.totalTimeS = paramLong2;
    this.detailSlots = paramList;
  }

  public List<SportDetail> getDetailSlots()
  {
    return this.detailSlots;
  }

  public long getStartTime()
  {
    return this.startTimeS;
  }

  public long getTotalTime()
  {
    return this.totalTimeS;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sport.NetSport
 * JD-Core Version:    0.6.2
 */