package com.baidu.wearable.sport;

import java.util.Iterator;
import java.util.List;

public class Sport
{
  private String date;
  private List<SportDetail> sportDetails;
  private float totalCalories;
  private float totalDistance;
  private int totalSteps;

  public Sport(String paramString, List<SportDetail> paramList)
  {
    this.date = paramString;
    this.sportDetails = paramList;
  }

  private void compute()
  {
    Iterator localIterator;
    if ((this.date != null) && (this.sportDetails != null))
      localIterator = this.sportDetails.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      SportDetail localSportDetail = (SportDetail)localIterator.next();
      this.totalSteps += localSportDetail.getSteps();
      this.totalCalories += localSportDetail.getCalories();
      this.totalDistance += localSportDetail.getDistance();
    }
  }

  public String getDate()
  {
    return this.date;
  }

  public List<SportDetail> getSportDetails()
  {
    return this.sportDetails;
  }

  public float getTotalCalories()
  {
    if (0.0F == this.totalCalories)
      compute();
    return this.totalCalories;
  }

  public float getTotalDistance()
  {
    if (0.0F == this.totalDistance)
      compute();
    return this.totalDistance;
  }

  public int getTotalSteps()
  {
    if (this.totalSteps == 0)
      compute();
    return this.totalSteps;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sport.Sport
 * JD-Core Version:    0.6.2
 */