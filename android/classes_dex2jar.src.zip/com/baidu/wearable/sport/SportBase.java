package com.baidu.wearable.sport;

public class SportBase
{
  private float calories;
  private float distance;
  private int steps;

  public float getCalories()
  {
    return this.calories;
  }

  public float getDistance()
  {
    return this.distance;
  }

  public int getSteps()
  {
    return this.steps;
  }

  public void setCalories(float paramFloat)
  {
    this.calories = paramFloat;
  }

  public void setDistance(float paramFloat)
  {
    this.distance = paramFloat;
  }

  public void setSteps(int paramInt)
  {
    this.steps = paramInt;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sport.SportBase
 * JD-Core Version:    0.6.2
 */