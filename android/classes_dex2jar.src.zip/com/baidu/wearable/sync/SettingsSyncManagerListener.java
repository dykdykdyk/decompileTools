package com.baidu.wearable.sync;

public abstract interface SettingsSyncManagerListener
{
  public abstract void onSettingsSyncComplete();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sync.SettingsSyncManagerListener
 * JD-Core Version:    0.6.2
 */