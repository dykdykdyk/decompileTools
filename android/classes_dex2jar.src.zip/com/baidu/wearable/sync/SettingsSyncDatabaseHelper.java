package com.baidu.wearable.sync;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.baidu.wearable.database.Database.ClockEnum;

public class SettingsSyncDatabaseHelper extends SQLiteOpenHelper
{
  public static final int version = 1;

  public SettingsSyncDatabaseHelper(Context paramContext, String paramString)
  {
    super(paramContext, paramString, null, 1);
  }

  public void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    paramSQLiteDatabase.execSQL("CREATE TABLE Clock (" + Database.ClockEnum.id.name() + " INTEGER NOT NULL PRIMARY KEY, " + Database.ClockEnum.year.name() + " INTEGER, " + Database.ClockEnum.month.name() + " INTEGER, " + Database.ClockEnum.day.name() + " INTEGER, " + Database.ClockEnum.hour.name() + " INTEGER, " + Database.ClockEnum.minute.name() + " INTEGER, " + Database.ClockEnum.sunday.name() + " INTEGER, " + Database.ClockEnum.monday.name() + " INTERGER, " + Database.ClockEnum.tuesday.name() + " INTERGER, " + Database.ClockEnum.wednesday.name() + " INTERGER, " + Database.ClockEnum.thursday.name() + " INTERGER, " + Database.ClockEnum.friday.name() + " INTERGER, " + Database.ClockEnum.saturday.name() + " INTERGER, " + Database.ClockEnum.onOrOff.name() + " INTERGER, " + Database.ClockEnum.netDirty.name() + " INTERGER, " + Database.ClockEnum.braceletDirty.name() + " INTERGER" + ");");
  }

  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
  {
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sync.SettingsSyncDatabaseHelper
 * JD-Core Version:    0.6.2
 */