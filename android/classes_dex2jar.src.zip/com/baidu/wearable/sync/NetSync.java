package com.baidu.wearable.sync;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import com.baidu.wearable.alarm.AlarmController;
import com.baidu.wearable.alarm.completion.CompletionRateAlarm;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SleepDao;
import com.baidu.wearable.database.SportDao;
import com.baidu.wearable.net.CompletionRateTransport;
import com.baidu.wearable.net.CompletionRateTransport.WarnFinishRateListener;
import com.baidu.wearable.net.PlanTransport;
import com.baidu.wearable.net.PlanTransport.PlanListener;
import com.baidu.wearable.net.ProfileTransport;
import com.baidu.wearable.net.ProfileTransport.ProfileListener;
import com.baidu.wearable.net.SleepTransport;
import com.baidu.wearable.net.SleepTransport.SleepDetailListener;
import com.baidu.wearable.net.SleepTransport.SleepDurationListener;
import com.baidu.wearable.net.SportTransport;
import com.baidu.wearable.net.SportTransport.SportDetailListener;
import com.baidu.wearable.net.SportTransport.SportSummaryListener;
import com.baidu.wearable.net.TrackerTransport;
import com.baidu.wearable.net.TrackerTransport.TrackerListener;
import com.baidu.wearable.net.Transport.CommonResult;
import com.baidu.wearable.plan.Plan;
import com.baidu.wearable.plan.PlanController;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.preference.ProfilePreference;
import com.baidu.wearable.profile.Profile;
import com.baidu.wearable.profile.ProfileController;
import com.baidu.wearable.sleep.SleepController;
import com.baidu.wearable.sleep.SleepDetail;
import com.baidu.wearable.sleep.SleepDuration;
import com.baidu.wearable.sport.SportDetail;
import com.baidu.wearable.sport.SportSummary;
import com.baidu.wearable.tracker.Tracker;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.util.ErrorUtil;
import com.baidu.wearable.util.NetworkCheck;
import com.baidu.wearable.util.TimeUtil;
import java.util.Iterator;
import java.util.List;

public class NetSync
{
  private static final int GET_DATA_NET_THREAD_COUNT = 8;
  private static final String TAG = "NetSync";
  private static int mCount = 0;
  private static CompletionRateAlarm mFinishWarn;
  private static Plan mPlan;
  private static Profile mProfile;
  private static List<SleepDetail> mSleepDetails;
  private static List<SleepDuration> mSleepDurations;
  private static List<SportDetail> mSportDetails;
  private static List<SportSummary> mSportSummarys;
  private static List<Tracker> mTrackerID;

  public static void getDataFromNet(Context paramContext, GetDataFromNetListener paramGetDataFromNetListener)
  {
    mCount = 0;
    String str = TimeUtil.getDateBeforeDays(31);
    LogUtil.d("NetSync", "getDataFromNet beforeDate:" + str);
    SportTransport.getInstance(paramContext).getSports(str, new SportTransport.SportDetailListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        NetSync.this.onFailure(paramAnonymousInt, "getSports:" + paramAnonymousString);
      }

      public void onSuccess(List<SportDetail> paramAnonymousList)
      {
        NetSync.mSportDetails = paramAnonymousList;
        try
        {
          NetSync.mCount = 1 + NetSync.mCount;
          if (NetSync.mCount == 8)
            NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
          return;
        }
        finally
        {
        }
      }
    });
    SportTransport.getInstance(paramContext).getSportSummary(str, new SportTransport.SportSummaryListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        NetSync.this.onFailure(paramAnonymousInt, "getSportSummary:" + paramAnonymousString);
      }

      public void onSuccess(List<SportSummary> paramAnonymousList)
      {
        NetSync.mSportSummarys = paramAnonymousList;
        try
        {
          NetSync.mCount = 1 + NetSync.mCount;
          if (NetSync.mCount == 8)
            NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
          return;
        }
        finally
        {
        }
      }
    });
    SleepTransport.getInstance(paramContext).getSleepDuration(str, new SleepTransport.SleepDurationListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        NetSync.this.onFailure(paramAnonymousInt, "getSleepDuration:" + paramAnonymousString);
      }

      public void onSuccess(List<SleepDuration> paramAnonymousList)
      {
        NetSync.mSleepDurations = paramAnonymousList;
        try
        {
          NetSync.mCount = 1 + NetSync.mCount;
          if (NetSync.mCount == 8)
            NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
          return;
        }
        finally
        {
        }
      }
    });
    SleepTransport.getInstance(paramContext).getSleepDetail(str, new SleepTransport.SleepDetailListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        NetSync.this.onFailure(paramAnonymousInt, "getSleepDetail:" + paramAnonymousString);
      }

      public void onSuccess(List<SleepDetail> paramAnonymousList)
      {
        NetSync.mSleepDetails = paramAnonymousList;
        try
        {
          NetSync.mCount = 1 + NetSync.mCount;
          if (NetSync.mCount == 8)
            NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
          return;
        }
        finally
        {
        }
      }
    });
    PlanTransport.getInstance(paramContext).getPlan(new PlanTransport.PlanListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        LogUtil.d("NetSync", "getPlan failed errCode is " + paramAnonymousInt + " errMsg is " + paramAnonymousString);
        NetSync.this.onFailure(paramAnonymousInt, "getPlan:" + paramAnonymousString);
      }

      public void onSuccess(Plan paramAnonymousPlan)
      {
        NetSync.mPlan = paramAnonymousPlan;
        try
        {
          NetSync.mCount = 1 + NetSync.mCount;
          if (NetSync.mCount == 8)
            NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
          return;
        }
        finally
        {
        }
      }
    });
    ProfileTransport.getInstance(paramContext).getProfile(new ProfileTransport.ProfileListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        LogUtil.d("NetSync", "getProfile failed errCode is " + paramAnonymousInt + " errMsg is " + paramAnonymousString);
        NetSync.this.onFailure(paramAnonymousInt, "getProfile:" + paramAnonymousString);
      }

      public void onSuccess(Profile paramAnonymousProfile)
      {
        NetSync.mProfile = paramAnonymousProfile;
        try
        {
          NetSync.mCount = 1 + NetSync.mCount;
          if (NetSync.mCount == 8)
            NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
          return;
        }
        finally
        {
        }
      }
    });
    TrackerTransport.getInstance(paramContext).listTracker(new TrackerTransport.TrackerListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        NetSync.this.onFailure(paramAnonymousInt, "getSportSummary:" + paramAnonymousString);
      }

      public void onSuccess(List<Tracker> paramAnonymousList)
      {
        NetSync.mTrackerID = paramAnonymousList;
        try
        {
          NetSync.mCount = 1 + NetSync.mCount;
          if (NetSync.mCount == 8)
            NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
          return;
        }
        finally
        {
        }
      }
    });
    CompletionRateTransport.getInstance(paramContext).getFinishWarn(new CompletionRateTransport.WarnFinishRateListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        if (paramAnonymousInt == 38911)
          try
          {
            NetSync.mCount = 1 + NetSync.mCount;
            if (NetSync.mCount == 8)
              NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
            return;
          }
          finally
          {
          }
        NetSync.this.onFailure(paramAnonymousInt, "getSportSummary:" + paramAnonymousString);
      }

      public void onSuccess(CompletionRateAlarm paramAnonymousCompletionRateAlarm)
      {
        NetSync.mFinishWarn = paramAnonymousCompletionRateAlarm;
        try
        {
          NetSync.mCount = 1 + NetSync.mCount;
          if (NetSync.mCount == 8)
            NetSync.this.onSuccess(NetSync.mSportDetails, NetSync.mSportSummarys, NetSync.mSleepDurations, NetSync.mSleepDetails, NetSync.mPlan, NetSync.mProfile, NetSync.mTrackerID, NetSync.mFinishWarn);
          return;
        }
        finally
        {
        }
      }
    });
  }

  public static void sendDirtyDataToNet(final Context paramContext, SQLiteDatabase paramSQLiteDatabase, String paramString, boolean paramBoolean, final NetSyncListener paramNetSyncListener)
  {
    new AsyncTask()
    {
      protected Transport.CommonResult doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        Context localContext = (Context)paramAnonymousArrayOfObject[0];
        Transport.CommonResult localCommonResult1 = NetSync.sendSportDirtyDataToNetSync(localContext, (SQLiteDatabase)paramAnonymousArrayOfObject[1], (String)paramAnonymousArrayOfObject[2]);
        boolean bool1 = SleepController.sendSleepToNetAndUpdateDbSync(localContext);
        boolean bool2 = SleepController.sendSleepDurationToNetAndUpdateDbSync(localContext);
        boolean bool3 = true;
        boolean bool4 = true;
        boolean bool5 = true;
        if (this.val$setting)
        {
          if (ProfilePreference.getInstance(localContext).isDirty())
            bool3 = ProfileController.sendProfileToNetAndUpdateDbSync(localContext);
          if (PlanPreference.getInstance(localContext).isDirty())
            bool4 = PlanController.sendPlanToNetAndUpdateDbSync(localContext);
          if (!AlarmPreference.getInstance(localContext).isDirty());
        }
        for (bool5 = AlarmController.sendAlarmToNetAndUpdateDbSync(localContext); (localCommonResult1 != null) && (localCommonResult1.errCode != 0); bool5 = AlarmController.sendAlarmToNetAndUpdateDbSync(localContext))
        {
          return localCommonResult1;
          bool3 = ProfileController.sendProfileToNetAndUpdateDbSync(localContext);
          bool4 = PlanController.sendPlanToNetAndUpdateDbSync(localContext);
        }
        Transport.CommonResult localCommonResult2 = new Transport.CommonResult();
        if ((bool1) && (bool2) && (bool3) && (bool4) && (bool5));
        for (localCommonResult2.errCode = 0; ; localCommonResult2.errCode = -1)
          return localCommonResult2;
      }

      protected void onPostExecute(Transport.CommonResult paramAnonymousCommonResult)
      {
        super.onPostExecute(paramAnonymousCommonResult);
        if (paramNetSyncListener != null)
        {
          if (paramAnonymousCommonResult == null)
            paramNetSyncListener.onFailure(-1, "no data to need send to net");
        }
        else
          return;
        ErrorUtil.resolveErrorResponse(paramContext, paramAnonymousCommonResult.errCode);
        if (paramAnonymousCommonResult.errCode == 0)
        {
          paramNetSyncListener.onSuccess();
          return;
        }
        paramNetSyncListener.onFailure(paramAnonymousCommonResult.errCode, paramAnonymousCommonResult.errMsg);
      }
    }
    .execute(new Object[] { paramContext, paramSQLiteDatabase, paramString });
  }

  private static Transport.CommonResult sendSleepDetailDataToNetSync(Context paramContext)
  {
    SleepTransport localSleepTransport = SleepTransport.getInstance(paramContext);
    List localList = SleepDao.selectDirtySleepDetail(Database.getDb(paramContext));
    if ((localList != null) && (localList.size() > 0))
      return localSleepTransport.updateSleepDetailSync(TrackerHelper.getInstance(paramContext).getTrackerID(), localList);
    return null;
  }

  private static Transport.CommonResult sendSleepDurationDataToNetSync(Context paramContext)
  {
    SleepTransport localSleepTransport = SleepTransport.getInstance(paramContext);
    List localList = SleepDao.selectDirtySleepDuration(Database.getDb(paramContext));
    if ((localList != null) && (localList.size() > 0))
      return localSleepTransport.updateSleepDurationSync(localList);
    return null;
  }

  private static Transport.CommonResult sendSportDirtyDataToNetForHundredSync(Context paramContext, SQLiteDatabase paramSQLiteDatabase, String paramString)
  {
    List localList = SportDao.selectDirtySportDetail(paramSQLiteDatabase, 100);
    LogUtil.d("NetSync", "sendSportDirtyDataToNetForHundredSync dirty data count:" + localList.size());
    if (localList.size() > 0)
    {
      Transport.CommonResult localCommonResult = SportTransport.getInstance(paramContext).updateSportsSync(paramString, localList);
      Iterator localIterator;
      if (localCommonResult.errCode == 0)
      {
        LogUtil.d("NetSync", "updateSports success.");
        localIterator = localList.iterator();
      }
      while (true)
      {
        if (!localIterator.hasNext())
          return localCommonResult;
        SportDao.updateSportDetailToNotDirty(paramSQLiteDatabase, ((SportDetail)localIterator.next()).getTimestampS());
      }
    }
    return null;
  }

  public static Transport.CommonResult sendSportDirtyDataToNetSync(Context paramContext, SQLiteDatabase paramSQLiteDatabase, String paramString)
  {
    List localList = SportDao.selectDirtySportDetail(paramSQLiteDatabase);
    LogUtil.d("NetSync", "sendSportDirtyDataToNetSync sport detail count:" + localList.size());
    if (localList.size() == 0)
    {
      Transport.CommonResult localCommonResult1 = new Transport.CommonResult();
      localCommonResult1.errCode = 0;
      localCommonResult1.errMsg = "sport detail count is 0";
      return localCommonResult1;
    }
    if (!NetworkCheck.isNetworkAvailable(paramContext))
    {
      Transport.CommonResult localCommonResult2 = new Transport.CommonResult();
      localCommonResult2.errMsg = "network is not available";
      return localCommonResult2;
    }
    Transport.CommonResult localCommonResult3 = sendSportDirtyDataToNetForHundredSync(paramContext, paramSQLiteDatabase, paramString);
    LogUtil.d("NetSync", "ret errCode:" + localCommonResult3.errCode);
    return localCommonResult3;
  }

  public static abstract interface GetDataFromNetListener
  {
    public abstract void onFailure(int paramInt, String paramString);

    public abstract void onSuccess(List<SportDetail> paramList, List<SportSummary> paramList1, List<SleepDuration> paramList2, List<SleepDetail> paramList3, Plan paramPlan, Profile paramProfile, List<Tracker> paramList4, CompletionRateAlarm paramCompletionRateAlarm);
  }

  public static abstract interface NetSyncListener
  {
    public abstract void onFailure(int paramInt, String paramString);

    public abstract void onSuccess();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sync.NetSync
 * JD-Core Version:    0.6.2
 */