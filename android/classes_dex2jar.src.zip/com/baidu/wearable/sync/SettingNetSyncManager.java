package com.baidu.wearable.sync;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.net.PlanTransport;
import com.baidu.wearable.net.PlanTransport.PlanListener;
import com.baidu.wearable.net.ProfileTransport;
import com.baidu.wearable.net.ProfileTransport.ProfileListener;
import com.baidu.wearable.plan.Plan;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.preference.ProfilePreference;
import com.baidu.wearable.profile.Profile;
import com.baidu.wearable.util.SportsIndexCalcUtil;

public class SettingNetSyncManager
{
  public static final int DELAY_TIME = 5000;
  public static final int MSG_PLAN_DO_SYNC = 3;
  public static final int MSG_PROFILE_DO_SYNC = 2;
  public static final int MSG_SYNC_INIT = 1;
  public static final int MSG_TRACKER_DO_SYNC = 4;
  private static final String TAG = "SettingNetSyncManager";
  public static final String THREAD_NAME = "setting_net_sync_thread";
  private static SettingNetSyncManager mInstance;
  private static boolean mPlanDirty;
  private static boolean mProfileDirty;
  private Context mContext;
  private MyHandler mHandler;
  private SettingNetSyncThread mThread;

  private SettingNetSyncManager(Context paramContext)
  {
    this.mContext = paramContext;
    this.mThread = new SettingNetSyncThread("setting_net_sync_thread");
    this.mThread.start();
  }

  public static SettingNetSyncManager getInstance(Context paramContext)
  {
    try
    {
      if (mInstance == null)
        mInstance = new SettingNetSyncManager(paramContext);
      SettingNetSyncManager localSettingNetSyncManager = mInstance;
      return localSettingNetSyncManager;
    }
    finally
    {
    }
  }

  private void initSync()
  {
    if (mProfileDirty)
    {
      LogUtil.d("SettingNetSyncManager", "initSync mProfileDirty:" + mProfileDirty);
      doProfileSync();
      mProfileDirty = false;
    }
    if (mPlanDirty)
    {
      LogUtil.d("SettingNetSyncManager", "initSync mPlanDirty:" + mPlanDirty);
      doPlanSync();
      mPlanDirty = false;
    }
  }

  public void doPlanSync()
  {
    Plan localPlan = new Plan();
    localPlan.steps = PlanPreference.getInstance(this.mContext).getTargetStep();
    int i;
    if (this.mContext != null)
    {
      i = SportsIndexCalcUtil.getCaloriesFromSteps(this.mContext, (int)localPlan.steps);
      localPlan.calories = i;
      if (this.mContext == null)
        break label102;
    }
    label102: for (float f = 1000.0F * SportsIndexCalcUtil.getDistanceFromSteps(this.mContext, (int)localPlan.steps); ; f = 6000.0F)
    {
      localPlan.distance = f;
      localPlan._mtime = PlanPreference.getInstance(this.mContext).getMTime();
      doPlanSync(localPlan);
      return;
      i = 100;
      break;
    }
  }

  public void doPlanSync(Plan paramPlan)
  {
    sendPlanToNet(paramPlan);
  }

  public void doProfileSync()
  {
    Profile localProfile = new Profile();
    localProfile.height = ProfilePreference.getInstance(this.mContext).getHeight();
    localProfile.weight = ProfilePreference.getInstance(this.mContext).getWeight();
    localProfile.gender = ProfilePreference.getInstance(this.mContext).getGender();
    localProfile.year = ProfilePreference.getInstance(this.mContext).getYear();
    localProfile.month = ProfilePreference.getInstance(this.mContext).getMonth();
    localProfile.day = ProfilePreference.getInstance(this.mContext).getDay();
    localProfile._mtime = ProfilePreference.getInstance(this.mContext).getMTime();
    doProfileSync(localProfile);
  }

  public void doProfileSync(Profile paramProfile)
  {
    sendProfileToNet(paramProfile);
  }

  public void removePlanUpdateCmd()
  {
    if (this.mHandler != null)
    {
      LogUtil.d("SettingNetSyncManager", "removePlanUpdateCmd mHandler:" + this.mHandler);
      this.mHandler.removeMessages(3);
    }
  }

  public void removeProfileUpdateCmd()
  {
    if (this.mHandler != null)
    {
      LogUtil.d("SettingNetSyncManager", "removeProfileUpdateCmd mHandler:" + this.mHandler);
      this.mHandler.removeMessages(2);
    }
  }

  public void sendPlanToNet(final Plan paramPlan)
  {
    LogUtil.v("SettingNetSyncManager", "send plan to net plan:" + paramPlan);
    if (this.mContext != null)
      PlanTransport.getInstance(this.mContext).updatePlanX(paramPlan, new PlanTransport.PlanListener()
      {
        public void onFailure(int paramAnonymousInt, String paramAnonymousString)
        {
          LogUtil.d("SettingNetSyncManager", "update plan to net failure, errCode:" + paramAnonymousInt + ", errMsg:" + paramAnonymousString);
          if (paramPlan._mtime > PlanPreference.getInstance(SettingNetSyncManager.this.mContext).getMTime())
            PlanPreference.getInstance(SettingNetSyncManager.this.mContext).saveAllTargetPlan(paramPlan);
        }

        public void onSuccess(Plan paramAnonymousPlan)
        {
          PlanPreference.getInstance(SettingNetSyncManager.this.mContext).setDirty(false);
          if (!paramAnonymousPlan.lastest)
            PlanPreference.getInstance(SettingNetSyncManager.this.mContext).saveAllTargetPlan(paramAnonymousPlan);
        }
      });
  }

  public void sendPlanUpdateCmdForDelay()
  {
    if (this.mHandler != null)
    {
      LogUtil.d("SettingNetSyncManager", "sendPlanUpdateCmdForDelay mHandler:" + this.mHandler);
      this.mHandler.removeMessages(3);
      this.mHandler.sendEmptyMessageDelayed(3, 5000L);
      return;
    }
    LogUtil.d("SettingNetSyncManager", "mPlanDirty = true");
    mPlanDirty = true;
  }

  public void sendProfileToNet(final Profile paramProfile)
  {
    LogUtil.v("SettingNetSyncManager", "send profile to net profile:" + paramProfile);
    if (this.mContext != null)
      ProfileTransport.getInstance(this.mContext).updateProfileX(paramProfile, new ProfileTransport.ProfileListener()
      {
        public void onFailure(int paramAnonymousInt, String paramAnonymousString)
        {
          LogUtil.d("SettingNetSyncManager", "update profile to net failure, errCode:" + paramAnonymousInt + ", errMsg:" + paramAnonymousString);
          if (paramProfile._mtime > ProfilePreference.getInstance(SettingNetSyncManager.this.mContext).getMTime())
            ProfilePreference.getInstance(SettingNetSyncManager.this.mContext).saveAllProfileInfo(paramProfile);
        }

        public void onSuccess(Profile paramAnonymousProfile)
        {
          LogUtil.d("SettingNetSyncManager", "update profile to net success.");
          ProfilePreference.getInstance(SettingNetSyncManager.this.mContext).setDirty(false);
          if (!paramAnonymousProfile.lastest)
            ProfilePreference.getInstance(SettingNetSyncManager.this.mContext).saveAllProfileInfo(paramAnonymousProfile);
        }
      });
  }

  public void sendProfileUpdateCmdForDelay(Profile paramProfile)
  {
    if (this.mHandler != null)
    {
      LogUtil.d("SettingNetSyncManager", "sendProfileUpdateCmdForDelay mHandler:" + this.mHandler);
      this.mHandler.removeMessages(2);
      Message localMessage = new Message();
      localMessage.what = 2;
      localMessage.obj = paramProfile;
      this.mHandler.sendMessageDelayed(localMessage, 5000L);
      return;
    }
    LogUtil.d("SettingNetSyncManager", "mProfileDirty = true");
    mProfileDirty = true;
  }

  private class MyHandler extends Handler
  {
    private MyHandler()
    {
    }

    public void handleMessage(Message paramMessage)
    {
      super.handleMessage(paramMessage);
      switch (paramMessage.what)
      {
      default:
        return;
      case 1:
        LogUtil.d("SettingNetSyncManager", "MyHandler::MSG_SYNC_INIT");
        SettingNetSyncManager.this.initSync();
        return;
      case 2:
        LogUtil.d("SettingNetSyncManager", "MSG_PROFILE_DO_SYNC");
        SettingNetSyncManager.this.doProfileSync((Profile)paramMessage.obj);
        return;
      case 3:
      }
      LogUtil.d("SettingNetSyncManager", "MSG_PLAN_DO_SYNC");
      SettingNetSyncManager.this.doPlanSync();
    }
  }

  private class SettingNetSyncThread extends Thread
  {
    public SettingNetSyncThread(String arg2)
    {
      super();
    }

    public void run()
    {
      Looper.prepare();
      SettingNetSyncManager.this.mHandler = new SettingNetSyncManager.MyHandler(SettingNetSyncManager.this, null);
      SettingNetSyncManager.this.mHandler.sendEmptyMessage(1);
      Looper.loop();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sync.SettingNetSyncManager
 * JD-Core Version:    0.6.2
 */