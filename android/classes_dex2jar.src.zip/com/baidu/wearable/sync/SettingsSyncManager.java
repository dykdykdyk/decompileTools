package com.baidu.wearable.sync;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.alarm.clock.ClockImpl;
import com.baidu.wearable.alarm.clock.ClockImpl.ClockCallback;
import com.baidu.wearable.alarm.clock.ClockListener;
import com.baidu.wearable.ble.connectmanager.BluetoothState;
import com.baidu.wearable.ble.model.Clock;
import com.baidu.wearable.ble.model.ClockList;
import com.baidu.wearable.ble.stack.BlueTooth;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothCommonListener;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database.ClockEnum;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SettingsSyncManager
{
  public static final int DELAY_RIGHT_NOW = 1000;
  public static final int DELAY_TIME = 30000;
  public static final String Database_Name = "setitng_sync";
  public static final int MSG_CLOCK_GET = 3;
  public static final int MSG_DO_SYNC = 2;
  public static final int MSG_SYNC_INIT = 1;
  public static final int SEND_EXPIRE_TIME = 30000;
  public static final String Shared_Preference_Key_Complete = "sync_complete";
  public static final String Shared_Preference_Key_Phone_Loss_Setting = "phone_loss_enable";
  public static final String Shared_Preference_Key_Profile_Age_Setting = "profile_age";
  public static final String Shared_Preference_Key_Profile_Height_Setting = "profile_height";
  public static final String Shared_Preference_Key_Profile_Male_Setting = "profile_male";
  public static final String Shared_Preference_Key_Profile_Weight_Setting = "profile_weight";
  public static final String Shared_Preference_Key_Sports_Target_Setting = "sports_target";
  public static final String Shared_Preference_Name = "settings_for_sync";
  public static final String TAG = "SettingsSyncManager";
  public static final String Thread_Name = "setting_sync_thread";
  private static SettingsSyncManager self;
  private int mAgeBuffer = -1;
  private long mAlarmBufferSendTime = -1L;
  private BlueTooth.BlueToothCommonListener mClockAlarmSettingListener = new BlueTooth.BlueToothCommonListener()
  {
    public void onFailure()
    {
      LogUtil.d("SettingsSyncManager", "Clock setting failed");
      SettingsSyncManager.this.mIsAlarmBufferSending = false;
      SettingsSyncManager.this.mIsAlarmBufferSending = false;
      SettingsSyncManager.this.mHandler.removeMessages(2);
      SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }

    public void onSuccess()
    {
      LogUtil.d("SettingsSyncManager", "Clock setting success");
      if (SettingsSyncManager.this.mIsAlarmBufferEmpty)
        SettingsSyncManager.this.removeAllRecords();
      SettingsSyncManager.this.mIsAlarmBufferSending = false;
      SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }
  };
  private ClockList mClockListBuffer;
  private List<ClockListener> mClockListeners;
  private Context mContext;
  private SettingsSyncDatabaseHelper mDatabaseHelper;
  private MyHandler mHandler;
  private int mHeightBuffer = -1;
  private boolean mIsAlarmBufferEmpty = true;
  private boolean mIsAlarmBufferSending = false;
  private boolean mIsMaleBuffer = false;
  private boolean mIsPhoneBufferEmpty = true;
  private boolean mIsPhoneBufferSending = false;
  private boolean mIsProfileBufferEmpty = true;
  private boolean mIsProfileBufferSending = false;
  private boolean mIsTargetBufferEmpty = true;
  private boolean mIsTargetBufferSending = false;
  private SettingsSyncManagerListener mListener = null;
  private long mPhoneBufferSendTime = -1L;
  private boolean mPhoneLossAlarmSetBuffer = false;
  private BlueTooth.BlueToothCommonListener mPhoneLossSettingListener = new BlueTooth.BlueToothCommonListener()
  {
    public void onFailure()
    {
      LogUtil.d("SettingsSyncManager", "Phone setting failed");
      SettingsSyncManager.this.mIsPhoneBufferEmpty = false;
      SettingsSyncManager.this.mIsPhoneBufferSending = false;
      SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }

    public void onSuccess()
    {
      LogUtil.d("SettingsSyncManager", "Phone setting success");
      if ((SettingsSyncManager.this.mIsPhoneBufferEmpty) && (SettingsSyncManager.this.mSP != null))
        SettingsSyncManager.this.mSP.edit().putBoolean("sync_complete", true).commit();
      SettingsSyncManager.this.mIsPhoneBufferSending = false;
      SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }
  };
  private long mProfileBufferSendTime = -1L;
  private SharedPreferences mSP;
  private int mSportsTargetBuffer = -1;
  private BlueTooth.BlueToothCommonListener mSportsTargetListener = new BlueTooth.BlueToothCommonListener()
  {
    public void onFailure()
    {
      LogUtil.d("SettingsSyncManager", "Sports target  failed");
      SettingsSyncManager.this.mIsTargetBufferSending = false;
      SettingsSyncManager.this.mIsTargetBufferEmpty = false;
      SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }

    public void onSuccess()
    {
      LogUtil.d("SettingsSyncManager", "Sports target setting success");
      if (SettingsSyncManager.this.mIsTargetBufferEmpty)
      {
        if (SettingsSyncManager.this.mSP != null)
          SettingsSyncManager.this.mSP.edit().remove("sports_target").commit();
        SettingsSyncManager.this.mIsTargetBufferSending = false;
        SettingsSyncManager.this.mHandler.removeMessages(2);
        SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 1000L);
      }
    }
  };
  private long mTargetBufferSendTime = -1L;
  private SettingSyncThread mThread;
  private String mUid;
  private BlueTooth.BlueToothCommonListener mUserProfileListener = new BlueTooth.BlueToothCommonListener()
  {
    public void onFailure()
    {
      LogUtil.d("SettingsSyncManager", "user profile  failed");
      SettingsSyncManager.this.mIsProfileBufferEmpty = false;
      SettingsSyncManager.this.mIsProfileBufferSending = false;
      SettingsSyncManager.this.mHandler.removeMessages(2);
      SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }

    public void onSuccess()
    {
      LogUtil.d("SettingsSyncManager", "user profile setting success");
      if ((SettingsSyncManager.this.mIsProfileBufferEmpty) && (SettingsSyncManager.this.mSP != null))
      {
        SettingsSyncManager.this.mSP.edit().remove("profile_male").commit();
        SettingsSyncManager.this.mSP.edit().remove("profile_age").commit();
        SettingsSyncManager.this.mSP.edit().remove("profile_height").commit();
        SettingsSyncManager.this.mSP.edit().remove("profile_weight").commit();
      }
      SettingsSyncManager.this.mIsProfileBufferSending = false;
      SettingsSyncManager.this.mHandler.removeMessages(2);
      SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }
  };
  private int mWeightBuffer = -1;

  private SettingsSyncManager(Context paramContext)
  {
    this.mContext = paramContext;
    if (this.mContext != null)
    {
      String str1 = "setitng_sync.db";
      String str2 = "settings_for_sync";
      BDAccountManager localBDAccountManager = BDAccountManager.getInstance();
      if (localBDAccountManager != null)
      {
        this.mUid = localBDAccountManager.getUserData("uid");
        if ((this.mUid != null) && (this.mUid.length() != 0))
        {
          str1 = "setitng_sync" + this.mUid + ".db";
          str2 = "settings_for_sync" + this.mUid;
          LogUtil.d("settingssync", "mUid is " + this.mUid);
          LogUtil.d("SettingsSyncManager", "mUid is " + this.mUid);
        }
      }
      this.mDatabaseHelper = new SettingsSyncDatabaseHelper(this.mContext, str1);
      this.mSP = this.mContext.getSharedPreferences(str2, 0);
    }
    this.mClockListBuffer = new ClockList();
    this.mThread = new SettingSyncThread("setting_sync_thread");
    this.mThread.start();
    this.mClockListeners = new ArrayList();
  }

  private void alarmSettingRestore()
  {
    SQLiteDatabase localSQLiteDatabase;
    int i;
    if ((this.mDatabaseHelper != null) && (this.mClockListBuffer != null))
    {
      removeAllRecords();
      localSQLiteDatabase = this.mDatabaseHelper.getWritableDatabase();
      if (localSQLiteDatabase != null)
      {
        i = 0;
        if (i < this.mClockListBuffer.getListSize())
          break label48;
        localSQLiteDatabase.close();
      }
    }
    return;
    label48: Clock localClock = this.mClockListBuffer.getClock(i);
    ContentValues localContentValues = new ContentValues();
    localContentValues.put(Database.ClockEnum.id.name(), Long.valueOf(localClock.getId()));
    localContentValues.put(Database.ClockEnum.year.name(), Integer.valueOf(localClock.getYear()));
    localContentValues.put(Database.ClockEnum.month.name(), Integer.valueOf(localClock.getMonth()));
    localContentValues.put(Database.ClockEnum.day.name(), Integer.valueOf(localClock.getDay()));
    localContentValues.put(Database.ClockEnum.hour.name(), Integer.valueOf(localClock.getHour()));
    localContentValues.put(Database.ClockEnum.minute.name(), Integer.valueOf(localClock.getMinute()));
    String str1 = Database.ClockEnum.monday.name();
    int j;
    label192: int k;
    label222: int m;
    label252: int n;
    label282: int i1;
    label312: int i2;
    label342: int i3;
    label372: String str8;
    if (localClock.isMon())
    {
      j = 1;
      localContentValues.put(str1, Integer.valueOf(j));
      String str2 = Database.ClockEnum.tuesday.name();
      if (!localClock.isTue())
        break label437;
      k = 1;
      localContentValues.put(str2, Integer.valueOf(k));
      String str3 = Database.ClockEnum.wednesday.name();
      if (!localClock.isWed())
        break label443;
      m = 1;
      localContentValues.put(str3, Integer.valueOf(m));
      String str4 = Database.ClockEnum.thursday.name();
      if (!localClock.isThu())
        break label449;
      n = 1;
      localContentValues.put(str4, Integer.valueOf(n));
      String str5 = Database.ClockEnum.friday.name();
      if (!localClock.isFri())
        break label455;
      i1 = 1;
      localContentValues.put(str5, Integer.valueOf(i1));
      String str6 = Database.ClockEnum.saturday.name();
      if (!localClock.isSat())
        break label461;
      i2 = 1;
      localContentValues.put(str6, Integer.valueOf(i2));
      String str7 = Database.ClockEnum.sunday.name();
      if (!localClock.isSun())
        break label467;
      i3 = 1;
      localContentValues.put(str7, Integer.valueOf(i3));
      str8 = Database.ClockEnum.onOrOff.name();
      if (!localClock.isOn())
        break label473;
    }
    label437: label443: label449: label455: label461: label467: label473: for (int i4 = 1; ; i4 = 0)
    {
      localContentValues.put(str8, Integer.valueOf(i4));
      localSQLiteDatabase.insert("Clock", null, localContentValues);
      i++;
      break;
      j = 0;
      break label192;
      k = 0;
      break label222;
      m = 0;
      break label252;
      n = 0;
      break label282;
      i1 = 0;
      break label312;
      i2 = 0;
      break label342;
      i3 = 0;
      break label372;
    }
  }

  private void alarmSettingUpdate()
  {
    LogUtil.d("SettingsSyncManager", "alarmSettingUpdate ");
    if ((!this.mIsAlarmBufferEmpty) && ((!this.mIsAlarmBufferSending) || (System.currentTimeMillis() - this.mAlarmBufferSendTime > 30000L)) && (BluetoothState.getInstance().getBleState() == 5))
    {
      LogUtil.d("SettingsSyncManager", "alarmSettingUpdate: " + this.mClockListBuffer);
      BlueTooth.getInstance().setAlarmList(this.mClockListBuffer, this.mClockAlarmSettingListener);
      this.mAlarmBufferSendTime = System.currentTimeMillis();
      this.mIsAlarmBufferSending = true;
      this.mIsAlarmBufferEmpty = true;
    }
  }

  private void checkSyncCompleted()
  {
    LogUtil.d("SettingsSyncManager", "checkSyncCompleted");
    LogUtil.d("SettingsSyncManager", "SyncInit  mIsPhoneBufferEmpty: " + this.mIsPhoneBufferEmpty + " mIsAlarmBufferEmpty: " + this.mIsAlarmBufferEmpty);
    LogUtil.d("SettingsSyncManager", "SyncInit  mIsTargetBufferEmpty: " + this.mIsTargetBufferEmpty + "  mIsProfileBufferEmpty: " + this.mIsProfileBufferEmpty);
    LogUtil.d("SettingsSyncManager", "SyncInit  mIsPhoneBufferSending: " + this.mIsPhoneBufferSending + " mIsAlarmBufferSending: " + this.mIsAlarmBufferSending);
    LogUtil.d("SettingsSyncManager", "SyncInit  mIsTargetBufferSending: " + this.mIsTargetBufferSending + "  mIsProfileBufferSending: " + this.mIsProfileBufferSending);
    if ((this.mIsPhoneBufferEmpty) && (!this.mIsPhoneBufferSending) && (this.mIsAlarmBufferEmpty) && (!this.mIsAlarmBufferSending) && (this.mIsTargetBufferEmpty) && (!this.mIsTargetBufferSending) && (this.mIsProfileBufferEmpty) && (!this.mIsProfileBufferSending) && (this.mListener != null))
      this.mListener.onSettingsSyncComplete();
  }

  private void doSync()
  {
    LogUtil.d("SettingsSyncManager", "doSync ");
    LogUtil.d("SettingsSyncManager", "ble state: " + BluetoothState.getInstance().getBleState());
    phoneSettingUpdate();
    alarmSettingUpdate();
    sportsTargetUpdate();
    userProfileUpdate();
  }

  public static SettingsSyncManager getInstance()
  {
    return self;
  }

  public static SettingsSyncManager getInstance(Context paramContext)
  {
    try
    {
      if (self == null)
        self = new SettingsSyncManager(paramContext);
      SettingsSyncManager localSettingsSyncManager = self;
      return localSettingsSyncManager;
    }
    finally
    {
    }
  }

  private void handleGetClock()
  {
    ClockImpl.getClock(this.mContext, new ClockImpl.ClockCallback()
    {
      public void onResult(List<Clock> paramAnonymousList)
      {
        SettingsSyncManager.this.informGetClock(paramAnonymousList);
      }
    });
  }

  private void informGetClock(List<Clock> paramList)
  {
    Iterator localIterator;
    if (this.mClockListeners != null)
      localIterator = this.mClockListeners.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      ClockListener localClockListener = (ClockListener)localIterator.next();
      if (localClockListener != null)
        localClockListener.onResult(paramList);
    }
  }

  private void phoneSettingRestore()
  {
    if (this.mSP != null)
    {
      this.mSP.edit().putBoolean("sync_complete", false).commit();
      this.mSP.edit().putBoolean("phone_loss_enable", this.mPhoneLossAlarmSetBuffer).commit();
    }
  }

  private void phoneSettingUpdate()
  {
    LogUtil.d("SettingsSyncManager", "phoneSettingUpdate ");
    if ((!this.mIsPhoneBufferEmpty) && ((!this.mIsPhoneBufferSending) || (System.currentTimeMillis() - this.mPhoneBufferSendTime > 30000L)) && (BluetoothState.getInstance().getBleState() == 5))
      if (!this.mPhoneLossAlarmSetBuffer)
        break label107;
    label107: for (int i = 2; ; i = 0)
    {
      LogUtil.d("SettingsSyncManager", "setLinklost with level " + i);
      BlueTooth.getInstance().setLinklost(this.mPhoneLossSettingListener, i);
      this.mPhoneBufferSendTime = System.currentTimeMillis();
      this.mIsPhoneBufferSending = true;
      this.mIsPhoneBufferEmpty = true;
      return;
    }
  }

  private void removeAllRecords()
  {
    if (this.mDatabaseHelper != null)
    {
      SQLiteDatabase localSQLiteDatabase = this.mDatabaseHelper.getWritableDatabase();
      localSQLiteDatabase.delete("Clock", null, null);
      localSQLiteDatabase.close();
    }
  }

  private void sportsTargetRestore()
  {
    if (this.mSP != null)
      this.mSP.edit().putInt("sports_target", this.mSportsTargetBuffer).commit();
  }

  private void sportsTargetUpdate()
  {
    LogUtil.d("SettingsSyncManager", "sportsTargetUpdate ");
    if ((!this.mIsTargetBufferEmpty) && ((!this.mIsTargetBufferSending) || (System.currentTimeMillis() - this.mTargetBufferSendTime > 30000L)) && (BluetoothState.getInstance().getBleState() == 5))
    {
      LogUtil.d("SettingsSyncManager", "sportsTargetUpdate");
      BlueTooth.getInstance().setSportTarget(this.mSportsTargetListener, this.mSportsTargetBuffer);
      this.mTargetBufferSendTime = System.currentTimeMillis();
      this.mIsTargetBufferSending = true;
      this.mIsTargetBufferEmpty = true;
    }
  }

  private void syncInit()
  {
    label173: SQLiteDatabase localSQLiteDatabase;
    if ((this.mSP != null) && (this.mUid != null) && (this.mUid.length() != 0))
    {
      this.mIsPhoneBufferEmpty = this.mSP.getBoolean("sync_complete", true);
      if (!this.mIsPhoneBufferEmpty)
        this.mPhoneLossAlarmSetBuffer = this.mSP.getBoolean("phone_loss_enable", false);
      int i = this.mSP.getInt("sports_target", -1);
      if (-1 != i)
      {
        this.mSportsTargetBuffer = i;
        this.mIsTargetBufferEmpty = false;
        int j = this.mSP.getInt("profile_age", -1);
        if (-1 == j)
          break label373;
        this.mAgeBuffer = j;
        this.mHeightBuffer = this.mSP.getInt("profile_height", -1);
        this.mWeightBuffer = this.mSP.getInt("profile_height", -1);
        this.mIsMaleBuffer = this.mSP.getBoolean("profile_male", true);
        this.mIsProfileBufferEmpty = false;
      }
    }
    else if ((this.mDatabaseHelper != null) && (this.mUid != null) && (this.mUid.length() != 0))
    {
      localSQLiteDatabase = this.mDatabaseHelper.getReadableDatabase();
    }
    while (true)
    {
      try
      {
        while (true)
        {
          Cursor localCursor = localSQLiteDatabase.query("Clock", null, null, null, null, null, null);
          if (localCursor != null);
          try
          {
            if (localCursor.getCount() == 0)
              this.mIsAlarmBufferEmpty = true;
            while (true)
            {
              localCursor.close();
              localSQLiteDatabase.close();
              LogUtil.d("SettingsSyncManager", "SyncInit with mIsPhoneBufferEmpty " + this.mIsPhoneBufferEmpty + "with mIsAlarmBufferEmpty " + this.mIsAlarmBufferEmpty);
              LogUtil.d("SettingsSyncManager", "SyncInit with mIsTargetBufferEmpty " + this.mIsTargetBufferEmpty + " with mIsProfileBufferEmpty " + this.mIsProfileBufferEmpty);
              if ((this.mUid != null) && (this.mUid.length() != 0))
              {
                this.mHandler.removeMessages(2);
                this.mHandler.sendEmptyMessageDelayed(2, 30000L);
              }
              return;
              this.mIsTargetBufferEmpty = true;
              break;
              label373: this.mIsProfileBufferEmpty = true;
              break label173;
              this.mIsAlarmBufferEmpty = false;
              this.mClockListBuffer.clocks.clear();
              while (localCursor.moveToNext())
              {
                Clock localClock = new Clock();
                localClock.setYear(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.year.name())));
                localClock.setMonth(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.month.name())));
                localClock.setDay(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.day.name())));
                localClock.setHour(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.hour.name())));
                localClock.setMinute(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.minute.name())));
                localClock.setId(localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.id.name())));
                if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.monday.name())) != 1)
                  break label871;
                bool1 = true;
                localClock.setMon(bool1);
                if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.tuesday.name())) != 1)
                  break label877;
                bool2 = true;
                localClock.setTue(bool2);
                if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.wednesday.name())) != 1)
                  break label883;
                bool3 = true;
                localClock.setWed(bool3);
                if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.thursday.name())) != 1)
                  break label889;
                bool4 = true;
                localClock.setThu(bool4);
                if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.friday.name())) != 1)
                  break label895;
                bool5 = true;
                localClock.setFri(bool5);
                if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.saturday.name())) != 1)
                  break label901;
                bool6 = true;
                localClock.setSat(bool6);
                if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.sunday.name())) != 1)
                  break label907;
                bool7 = true;
                localClock.setSun(bool7);
                if (localCursor.getInt(localCursor.getColumnIndex(Database.ClockEnum.onOrOff.name())) != 1)
                  break label913;
                bool8 = true;
                localClock.setOn(bool8);
                this.mClockListBuffer.addClock(localClock);
              }
            }
          }
          finally
          {
            localCursor.close();
          }
        }
      }
      finally
      {
        localSQLiteDatabase.close();
      }
      label871: boolean bool1 = false;
      continue;
      label877: boolean bool2 = false;
      continue;
      label883: boolean bool3 = false;
      continue;
      label889: boolean bool4 = false;
      continue;
      label895: boolean bool5 = false;
      continue;
      label901: boolean bool6 = false;
      continue;
      label907: boolean bool7 = false;
      continue;
      label913: boolean bool8 = false;
    }
  }

  private void userProfileRestore()
  {
    if (this.mSP != null)
    {
      this.mSP.edit().putBoolean("profile_male", this.mIsMaleBuffer).commit();
      this.mSP.edit().putInt("profile_age", this.mAgeBuffer).commit();
      this.mSP.edit().putInt("profile_height", this.mHeightBuffer).commit();
      this.mSP.edit().putInt("profile_weight", this.mWeightBuffer).commit();
    }
  }

  private void userProfileUpdate()
  {
    LogUtil.d("SettingsSyncManager", "userProfileUpdate ");
    if ((!this.mIsProfileBufferEmpty) && ((!this.mIsProfileBufferSending) || (System.currentTimeMillis() - this.mProfileBufferSendTime > 30000L)) && (BluetoothState.getInstance().getBleState() == 5))
    {
      LogUtil.d("SettingsSyncManager", "userProfileUpdate");
      BlueTooth.getInstance().setUserProfile(this.mUserProfileListener, this.mIsMaleBuffer, this.mAgeBuffer, this.mHeightBuffer, this.mWeightBuffer);
      this.mProfileBufferSendTime = System.currentTimeMillis();
      this.mIsProfileBufferSending = true;
      this.mIsProfileBufferEmpty = true;
    }
  }

  public void getClock()
  {
    LogUtil.d("SettingsSyncManager", "getClock");
    if (this.mHandler != null)
    {
      this.mHandler.removeMessages(3);
      this.mHandler.sendEmptyMessage(3);
    }
  }

  public boolean getIsSyncCompleted()
  {
    return (this.mIsPhoneBufferEmpty) && (!this.mIsPhoneBufferSending) && (this.mIsAlarmBufferEmpty) && (!this.mIsAlarmBufferSending) && (this.mIsTargetBufferEmpty) && (!this.mIsTargetBufferSending) && (this.mIsProfileBufferEmpty) && (!this.mIsProfileBufferSending);
  }

  public void registerClockListener(ClockListener paramClockListener)
  {
    if ((paramClockListener != null) && (!this.mClockListeners.contains(paramClockListener)))
      this.mClockListeners.add(paramClockListener);
  }

  public void reset()
  {
    LogUtil.d("settingssync", "reset called");
    LogUtil.d("SettingsSyncManager", "reset called");
    if (this.mHandler != null)
    {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
    }
    String str = BDAccountManager.getInstance().getUserData("uid");
    LogUtil.d("settingssync", "mUid is " + this.mUid + " uid is " + str);
    LogUtil.d("SettingsSyncManager", "mUid is " + this.mUid + " uid is " + str);
    if ((this.mUid == null) || ((str != null) && (str.compareTo(this.mUid) != 0)))
    {
      this.mUid = str;
      this.mSP = this.mContext.getSharedPreferences("settings_for_sync" + this.mUid, 0);
      this.mDatabaseHelper = new SettingsSyncDatabaseHelper(this.mContext, "setitng_sync" + this.mUid + ".db");
      LogUtil.d("settingssync", "mUid in reset is" + this.mUid);
      LogUtil.d("SettingsSyncManager", "mUid in reset is" + this.mUid);
    }
    this.mIsPhoneBufferEmpty = true;
    this.mIsAlarmBufferEmpty = true;
    this.mIsTargetBufferEmpty = true;
    this.mIsProfileBufferEmpty = true;
    this.mIsPhoneBufferSending = false;
    this.mIsAlarmBufferSending = false;
    this.mIsTargetBufferSending = false;
    this.mIsProfileBufferSending = false;
    this.mPhoneBufferSendTime = -1L;
    this.mAlarmBufferSendTime = -1L;
    this.mTargetBufferSendTime = -1L;
    this.mProfileBufferSendTime = -1L;
    if (this.mHandler != null)
    {
      this.mHandler.removeMessages(2);
      this.mHandler.sendEmptyMessageDelayed(2, 30000L);
    }
  }

  public void setSyncCompleteListener(SettingsSyncManagerListener paramSettingsSyncManagerListener)
  {
    this.mListener = paramSettingsSyncManagerListener;
  }

  public void turnOffSync()
  {
    LogUtil.d("settingssync", "turn off sync called");
    LogUtil.d("SettingsSyncManager", "turn off sync called");
    if (this.mHandler != null)
      this.mHandler.removeMessages(2);
    this.mIsPhoneBufferEmpty = true;
    this.mIsAlarmBufferEmpty = true;
    this.mIsTargetBufferEmpty = true;
    this.mIsProfileBufferEmpty = true;
    removeAllRecords();
    if (this.mSP != null)
    {
      SharedPreferences.Editor localEditor = this.mSP.edit();
      localEditor.remove("phone_loss_enable").commit();
      localEditor.remove("sync_complete").commit();
      localEditor.remove("profile_age").commit();
      localEditor.remove("profile_height").commit();
      localEditor.remove("profile_weight").commit();
      localEditor.remove("profile_male").commit();
      localEditor.remove("sports_target").commit();
    }
  }

  public void unregisterClockListener(ClockListener paramClockListener)
  {
    if ((paramClockListener != null) && (this.mClockListeners.contains(paramClockListener)))
      this.mClockListeners.remove(paramClockListener);
  }

  public void updateAlarmList(ClockList paramClockList)
  {
    LogUtil.d("SettingsSyncManager", "updateAlarmList with aClockList " + paramClockList);
    if (paramClockList != null)
      LogUtil.d("SettingsSyncManager", "the length of clock list is " + paramClockList.getListSize());
    this.mClockListBuffer = paramClockList;
    this.mIsAlarmBufferEmpty = false;
    alarmSettingRestore();
    if (this.mHandler != null)
    {
      this.mHandler.removeMessages(2);
      this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }
  }

  public void updatePhoneLossSetting(boolean paramBoolean)
  {
    LogUtil.d("SettingsSyncManager", "updatePhoneLossSetting with aValue " + paramBoolean);
    this.mPhoneLossAlarmSetBuffer = paramBoolean;
    this.mIsPhoneBufferEmpty = false;
    phoneSettingRestore();
    if (this.mHandler != null)
    {
      this.mHandler.removeMessages(2);
      this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }
  }

  public void updateSportsTarget(int paramInt)
  {
    LogUtil.d("SettingsSyncManager", "updateSportsTarget aSportsTarget " + paramInt);
    this.mSportsTargetBuffer = paramInt;
    this.mIsTargetBufferEmpty = false;
    sportsTargetRestore();
    if (this.mHandler != null)
    {
      this.mHandler.removeMessages(2);
      this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }
  }

  public void updateUserProfile(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3)
  {
    LogUtil.d("SettingsSyncManager", "updateUserProfile mIsMale " + paramBoolean + " aAge" + paramInt1 + " aHeight " + paramInt2);
    this.mIsMaleBuffer = paramBoolean;
    this.mAgeBuffer = paramInt1;
    this.mHeightBuffer = paramInt2;
    this.mWeightBuffer = paramInt3;
    this.mIsProfileBufferEmpty = false;
    userProfileRestore();
    if (this.mHandler != null)
    {
      this.mHandler.removeMessages(2);
      this.mHandler.sendEmptyMessageDelayed(2, 1000L);
    }
  }

  private class MyHandler extends Handler
  {
    private MyHandler()
    {
    }

    public void handleMessage(Message paramMessage)
    {
      super.handleMessage(paramMessage);
      switch (paramMessage.what)
      {
      default:
        return;
      case 1:
        LogUtil.d("SettingsSyncManager", "MyHandler::MSG_SYNC_INIT");
        SettingsSyncManager.this.syncInit();
        return;
      case 2:
        LogUtil.d("SettingsSyncManager", "MSG_DO_SYNC");
        SettingsSyncManager.this.doSync();
        SettingsSyncManager.this.checkSyncCompleted();
        SettingsSyncManager.this.mHandler.removeMessages(2);
        SettingsSyncManager.this.mHandler.sendEmptyMessageDelayed(2, 30000L);
        return;
      case 3:
      }
      LogUtil.d("SettingsSyncManager", "MSG_CLOCK_GET");
      SettingsSyncManager.this.handleGetClock();
    }
  }

  private class SettingSyncThread extends Thread
  {
    public SettingSyncThread(String arg2)
    {
      super();
    }

    public void run()
    {
      Looper.prepare();
      SettingsSyncManager.this.mHandler = new SettingsSyncManager.MyHandler(SettingsSyncManager.this, null);
      SettingsSyncManager.this.mHandler.sendEmptyMessage(1);
      Looper.loop();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sync.SettingsSyncManager
 * JD-Core Version:    0.6.2
 */