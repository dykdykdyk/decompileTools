package com.baidu.wearable.sync;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.agent.Agent;
import com.baidu.wearable.agent.AgentManager;
import com.baidu.wearable.alarm.AlarmController;
import com.baidu.wearable.alarm.completion.CompletionRateAlarm;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.net.AgentTransport;
import com.baidu.wearable.net.AgentTransport.AgentResult;
import com.baidu.wearable.net.CompletionRateTransport;
import com.baidu.wearable.net.CompletionRateTransport.CompletionRateAlarmResult;
import com.baidu.wearable.net.PlanTransport;
import com.baidu.wearable.net.PlanTransport.PlanResult;
import com.baidu.wearable.net.ProfileTransport;
import com.baidu.wearable.net.ProfileTransport.ProfileResult;
import com.baidu.wearable.net.SleepTransport;
import com.baidu.wearable.net.SleepTransport.SleepDetailResult;
import com.baidu.wearable.net.SleepTransport.SleepDurationResult;
import com.baidu.wearable.net.SportTransport;
import com.baidu.wearable.net.SportTransport.SportDetailResult;
import com.baidu.wearable.net.SportTransport.SportSummaryResult;
import com.baidu.wearable.net.TrackerTransport;
import com.baidu.wearable.net.TrackerTransport.TrackerResult;
import com.baidu.wearable.net.Transport.CommonResult;
import com.baidu.wearable.plan.Plan;
import com.baidu.wearable.plan.PlanController;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.preference.ProfilePreference;
import com.baidu.wearable.profile.Profile;
import com.baidu.wearable.profile.ProfileController;
import com.baidu.wearable.sleep.SleepController;
import com.baidu.wearable.sleep.SleepDetail;
import com.baidu.wearable.sleep.SleepDuration;
import com.baidu.wearable.sport.SportDetail;
import com.baidu.wearable.sport.SportSummary;
import com.baidu.wearable.tracker.Tracker;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.util.ErrorUtil;
import com.baidu.wearable.util.NetworkCheck;
import com.baidu.wearable.util.TimeUtil;
import java.util.ArrayList;
import java.util.List;

public class NetDataSyncManager
{
  private static final int DATA_SYNC_INTERVAL = 900000;
  private static final String Data_Sync_Thread_Name = "DataSyncThread";
  private static final int Err_Code_DataSync_AlarmUpdateFail = 8;
  private static final int Err_Code_DataSync_GetPhoneIDFail = 10;
  private static final int Err_Code_DataSync_LoginOnOtherPhone = 9;
  private static final int Err_Code_DataSync_NetworkOut = 2;
  private static final int Err_Code_DataSync_NotInit = 1;
  private static final int Err_Code_DataSync_PlanUpdateFail = 7;
  private static final int Err_Code_DataSync_ProfileUpdateFail = 6;
  private static final int Err_Code_DataSync_SleepUpdateFail = 5;
  private static final int Err_Code_DataSync_SportsUpdateFail = 4;
  private static final int Err_Code_DataSync_TrackSUpdateFail = 3;
  private static final int Err_Code_Login_GetServerDataFail = 2;
  private static final int Err_Code_Login_NetworkOut = 1;
  private static final int Err_Code_Login_NoUserID = 3;
  private static final int Err_Code_Plan_GetServerDataFail = 2;
  private static final int Err_Code_Plan_NetworkOut = 1;
  private static final int Err_Code_Plan_NoUserID = 3;
  private static final int Err_Code_Profile_GetServerDataFail = 2;
  private static final int Err_Code_Profile_NetworkOut = 1;
  private static final int Err_Code_Profile_NoUserID = 3;
  private static final int IsLoginOnOtherPhone_Err = -1;
  private static final int IsLoginOnOtherPhone_No = 1;
  private static final int IsLoginOnOtherPhone_YES = 0;
  private static final String Key_Data_Init = "key_data_init";
  private static final int Listener_OnDataSyncFail_Index = 2;
  private static final int Listener_OnDataSyncSucceed_Index = 1;
  private static final int MSG_DOWNLOAD_DATA = 6;
  private static final int MSG_FORCE_LOGIN = 7;
  private static final int MSG_LOGIN = 4;
  private static final int MSG_LOGOUT = 5;
  private static final int MSG_SYNC_DATA = 1;
  private static final int MSG_SYNC_PLAN = 3;
  private static final int MSG_SYNC_PROFILE = 2;
  private static final int SETTING_DATA_SYNC_INTERVAL = 5000;
  private static final String Shared_Pref_Name = "data_sync_shared_pref";
  private static final String TAG = "NetDataSyncManager";
  private static NetDataSyncManager sSelf;
  private Context mContext;
  private DownloadCallback mDownloadCallback;
  private SharedPreferences.Editor mEditor;
  private ForceLoginCallback mForceLoginCallback;
  private Handler mHandler;
  private boolean mIsDataInit = false;
  private boolean mIsForceStop = false;
  private List<DataSyncListener> mListeners;
  private LoginCallback mLoginCallback;
  private LogoutCallback mLogoutCallback;
  private PlanCallback mPlanCallback;
  private ProfileCallback mProfileCallback;
  private SharedPreferences mSP;
  private TSyncState mState = TSyncState.ENotYetInit;
  private DataSyncThread mThread;
  private String mUserID;

  private NetDataSyncManager(Context paramContext)
  {
    this.mContext = paramContext;
    this.mUserID = getUserID();
    this.mSP = this.mContext.getSharedPreferences("data_sync_shared_pref", 0);
    this.mEditor = this.mSP.edit();
    this.mIsDataInit = this.mSP.getBoolean("key_data_init", false);
    this.mListeners = new ArrayList();
    this.mThread = new DataSyncThread("DataSyncThread");
    this.mThread.start();
    this.mHandler = new MyHandler(this.mThread.getLooper());
  }

  private int downloadAllData()
  {
    this.mUserID = getUserID();
    SportTransport.SportDetailResult localSportDetailResult;
    SportTransport.SportSummaryResult localSportSummaryResult;
    SleepTransport.SleepDurationResult localSleepDurationResult;
    SleepTransport.SleepDetailResult localSleepDetailResult;
    PlanTransport.PlanResult localPlanResult;
    ProfileTransport.ProfileResult localProfileResult;
    TrackerTransport.TrackerResult localTrackerResult;
    CompletionRateTransport.CompletionRateAlarmResult localCompletionRateAlarmResult;
    CompletionRateAlarm localCompletionRateAlarm;
    int i;
    if (this.mUserID != null)
      if (NetworkCheck.isNetworkAvailable(this.mContext))
      {
        String str = TimeUtil.getDateBeforeDays(31);
        localSportDetailResult = SportTransport.getInstance(this.mContext).getSportsSync(str);
        if ((localSportDetailResult != null) && (localSportDetailResult.commonResult.errCode == 0) && (!this.mIsForceStop))
        {
          List localList1 = localSportDetailResult.sportDetails;
          localSportSummaryResult = SportTransport.getInstance(this.mContext).getSportSummarySync(str);
          if ((localSportSummaryResult == null) || (localSportSummaryResult.commonResult.errCode != 0) || (this.mIsForceStop))
            break label429;
          List localList2 = localSportSummaryResult.sportSummarys;
          localSleepDurationResult = SleepTransport.getInstance(this.mContext).getSleepDurationSync(str);
          if ((localSleepDurationResult == null) || (localSleepDurationResult.commonResult.errCode != 0) || (this.mIsForceStop))
            break label446;
          List localList3 = localSleepDurationResult.sleepDurations;
          localSleepDetailResult = SleepTransport.getInstance(this.mContext).getSleepDetailSync(str);
          if ((localSleepDetailResult == null) || (localSleepDetailResult.commonResult.errCode != 0) || (this.mIsForceStop))
            break label463;
          List localList4 = localSleepDetailResult.sleepDetails;
          localPlanResult = PlanTransport.getInstance(this.mContext).getPlanSync();
          if ((localPlanResult == null) || (localPlanResult.commonResult.errCode != 0) || (this.mIsForceStop))
            break label480;
          Plan localPlan = localPlanResult.plan;
          localProfileResult = ProfileTransport.getInstance(this.mContext).getProfileSync();
          if ((localProfileResult == null) || (localProfileResult.commonResult.errCode != 0) || (this.mIsForceStop))
            break label497;
          Profile localProfile = localProfileResult.profile;
          localTrackerResult = TrackerTransport.getInstance(this.mContext).listTrackerSync();
          if ((localTrackerResult == null) || (localTrackerResult.commonResult.errCode != 0) || (this.mIsForceStop))
            break label514;
          List localList5 = localTrackerResult.trackers;
          localCompletionRateAlarmResult = CompletionRateTransport.getInstance(this.mContext).getFinishWarnSync();
          if ((localCompletionRateAlarmResult == null) || (localCompletionRateAlarmResult.commonResult.errCode != 0) || (this.mIsForceStop))
            break label531;
          localCompletionRateAlarm = localCompletionRateAlarmResult.completionRateAlarm;
          i = 0;
          if (0 == 0)
          {
            DownloadCallback localDownloadCallback = this.mDownloadCallback;
            i = 0;
            if (localDownloadCallback != null)
              this.mDownloadCallback.onSucceed(localList1, localList2, localList3, localList4, localPlan, localProfile, localList5, localCompletionRateAlarm);
          }
        }
      }
    while (true)
    {
      return i;
      ErrorUtil.resolveErrorResponse(this.mContext, localSportDetailResult.commonResult.errCode);
      return 2;
      label429: ErrorUtil.resolveErrorResponse(this.mContext, localSportSummaryResult.commonResult.errCode);
      return 2;
      label446: ErrorUtil.resolveErrorResponse(this.mContext, localSleepDurationResult.commonResult.errCode);
      return 2;
      label463: ErrorUtil.resolveErrorResponse(this.mContext, localSleepDetailResult.commonResult.errCode);
      return 2;
      label480: ErrorUtil.resolveErrorResponse(this.mContext, localPlanResult.commonResult.errCode);
      return 2;
      label497: ErrorUtil.resolveErrorResponse(this.mContext, localProfileResult.commonResult.errCode);
      return 2;
      label514: ErrorUtil.resolveErrorResponse(this.mContext, localTrackerResult.commonResult.errCode);
      return 2;
      label531: if ((localCompletionRateAlarmResult != null) && (localCompletionRateAlarmResult.commonResult.errCode == 38911))
      {
        boolean bool = this.mIsForceStop;
        localCompletionRateAlarm = null;
        if (!bool)
          break;
      }
      ErrorUtil.resolveErrorResponse(this.mContext, localCompletionRateAlarmResult.commonResult.errCode);
      return 2;
      i = 1;
      continue;
      i = 3;
    }
  }

  public static NetDataSyncManager getInstance(Context paramContext)
  {
    try
    {
      if ((sSelf == null) && (paramContext != null))
        sSelf = new NetDataSyncManager(paramContext);
      NetDataSyncManager localNetDataSyncManager = sSelf;
      return localNetDataSyncManager;
    }
    finally
    {
    }
  }

  private String getUserID()
  {
    BDAccountManager localBDAccountManager = BDAccountManager.getInstance();
    Object localObject = null;
    if (localBDAccountManager != null)
    {
      String str = localBDAccountManager.getUserData("uid");
      localObject = null;
      if (str != null)
      {
        int i = str.length();
        localObject = null;
        if (i > 0)
          localObject = str;
      }
    }
    return localObject;
  }

  private void handleDownload()
  {
    LogUtil.d("NetDataSyncManager", "handleDownload");
    int i = downloadAllData();
    if (i == 0)
    {
      this.mIsDataInit = true;
      if (this.mEditor != null)
        this.mEditor.putBoolean("key_data_init", true).commit();
    }
    while (true)
    {
      removeDataMsg();
      this.mHandler.sendEmptyMessageDelayed(1, 900000L);
      return;
      this.mIsDataInit = false;
      if (this.mEditor != null)
        this.mEditor.putBoolean("key_data_init", false).commit();
      if (this.mDownloadCallback != null)
        this.mDownloadCallback.onFail(i, null);
    }
  }

  private void handleFirstLogin(LoginCallback paramLoginCallback)
  {
    LogUtil.d("NetDataSyncManager", "handleFirstLogin");
    Transport.CommonResult localCommonResult = AgentTransport.register(this.mContext);
    if ((localCommonResult != null) && (localCommonResult.errCode == 0))
      if (paramLoginCallback != null)
        paramLoginCallback.onSuccess();
    while (paramLoginCallback == null)
      return;
    paramLoginCallback.onFailure(11, localCommonResult.errMsg);
  }

  private void handleForceLogin()
  {
    LogUtil.d("NetDataSyncManager", "handleForceLogin");
    Transport.CommonResult localCommonResult = AgentTransport.register(this.mContext);
    if ((localCommonResult != null) && (localCommonResult.errCode == 0))
      if (this.mForceLoginCallback != null)
        this.mForceLoginCallback.onSuccess();
    while (this.mForceLoginCallback == null)
      return;
    this.mForceLoginCallback.onFailure(localCommonResult.errCode, localCommonResult.errMsg);
  }

  private void handleLogin()
  {
    LogUtil.d("NetDataSyncManager", "handleLogin");
    AgentTransport.AgentResult localAgentResult = AgentTransport.get(this.mContext);
    if ((localAgentResult != null) && (localAgentResult.commonResult.errCode == 0))
    {
      localAgent = localAgentResult.agent;
      if (localAgent == null)
        if (this.mLoginCallback != null)
          handleFirstLogin(this.mLoginCallback);
    }
    while (this.mLoginCallback == null)
    {
      do
      {
        do
        {
          Agent localAgent;
          return;
          if (!localAgent.getId().equals(AgentManager.getLocalId(this.mContext)))
            break;
        }
        while (this.mLoginCallback == null);
        this.mLoginCallback.onSuccess();
        return;
      }
      while (this.mLoginCallback == null);
      this.mLoginCallback.onFailure(9, null);
      return;
    }
    this.mLoginCallback.onFailure(11, localAgentResult.commonResult.errMsg);
  }

  private void handleLogout()
  {
    LogUtil.d("NetDataSyncManager", "handleLogout");
    Transport.CommonResult localCommonResult = AgentTransport.unregister(this.mContext);
    if ((localCommonResult != null) && (localCommonResult.errCode == 0))
      if (this.mLogoutCallback != null)
        this.mLogoutCallback.onSuccess();
    while (this.mLogoutCallback == null)
      return;
    this.mLogoutCallback.onFailure(localCommonResult.errCode, localCommonResult.errMsg);
  }

  private void handleSyncData()
  {
    LogUtil.d("NetDataSyncManager", "handleSyncData");
    this.mUserID = getUserID();
    int i;
    if (this.mUserID != null)
      if (this.mIsDataInit)
        if (NetworkCheck.isNetworkAvailable(this.mContext))
        {
          i = updateAllData();
          if (i == 0)
            break label96;
          informDataSyncFail(i, null);
        }
    while (true)
    {
      this.mHandler.removeMessages(1);
      this.mHandler.sendEmptyMessageDelayed(1, 900000L);
      return;
      i = 2;
      break;
      download(null);
      i = 1;
      break;
      i = 1;
      break;
      label96: informDataSyncSuc();
    }
  }

  private void handleSyncPlan()
  {
    LogUtil.d("NetDataSyncManager", "handleSyncPlan");
    if (PlanController.sendPlanToNetAndUpdateDbSync(this.mContext))
    {
      PlanPreference localPlanPreference = PlanPreference.getInstance(this.mContext);
      if (localPlanPreference != null)
      {
        Plan localPlan = new Plan();
        localPlan._mtime = localPlanPreference.getMTime();
        localPlan.distance = localPlanPreference.getTargetDistance();
        localPlan.steps = localPlanPreference.getTargetStep();
        localPlan.calories = localPlanPreference.getTargetCalorie();
        if (this.mPlanCallback != null)
          this.mPlanCallback.onPlanReceivedSuc(localPlan);
      }
    }
    while (true)
    {
      this.mHandler.removeMessages(1);
      this.mHandler.sendEmptyMessageDelayed(1, 900000L);
      return;
      if (this.mPlanCallback != null)
        this.mPlanCallback.onPlanReceivedFail(2, null);
    }
  }

  private void handleSyncProfile()
  {
    LogUtil.d("NetDataSyncManager", "handleSyncProfile");
    Transport.CommonResult localCommonResult = ProfileController.sendProfileToNetAndUpdateDb(this.mContext);
    if (localCommonResult.errCode == 0)
    {
      Profile localProfile = ProfilePreference.getInstance(this.mContext).getCurrentProfile();
      if (this.mProfileCallback != null)
        this.mProfileCallback.onProfileReceivedSuc(localProfile);
    }
    while (true)
    {
      this.mHandler.removeMessages(1);
      this.mHandler.sendEmptyMessageDelayed(1, 900000L);
      return;
      if (this.mProfileCallback != null)
        this.mProfileCallback.onProfileReceivedFail(2, localCommonResult.errMsg);
    }
  }

  private void informDataSyncFail(int paramInt, String paramString)
  {
    if (this.mListeners != null);
    for (int i = 0; ; i++)
    {
      if (i >= this.mListeners.size())
        return;
      DataSyncListener localDataSyncListener = (DataSyncListener)this.mListeners.get(i);
      if (localDataSyncListener != null)
        localDataSyncListener.onDataSyncFail(paramInt, paramString);
    }
  }

  private void informDataSyncForPlan(Plan paramPlan)
  {
    if (this.mListeners != null);
    for (int i = 0; ; i++)
    {
      if (i >= this.mListeners.size())
        return;
      DataSyncListener localDataSyncListener = (DataSyncListener)this.mListeners.get(i);
      if (localDataSyncListener != null)
        localDataSyncListener.onPlanReceivedSuc(paramPlan);
    }
  }

  private void informDataSyncForProfile(Profile paramProfile)
  {
    if (this.mListeners != null);
    for (int i = 0; ; i++)
    {
      if (i >= this.mListeners.size())
        return;
      DataSyncListener localDataSyncListener = (DataSyncListener)this.mListeners.get(i);
      if (localDataSyncListener != null)
        localDataSyncListener.onProfileReceivedSuc(paramProfile);
    }
  }

  private void informDataSyncSuc()
  {
    if (this.mListeners != null);
    for (int i = 0; ; i++)
    {
      if (i >= this.mListeners.size())
        return;
      DataSyncListener localDataSyncListener = (DataSyncListener)this.mListeners.get(i);
      if (localDataSyncListener != null)
        localDataSyncListener.onDataSyncSuc(System.currentTimeMillis() / 1000L);
    }
  }

  private void removeDataMsg()
  {
    LogUtil.d("NetDataSyncManager", "removeDataMsg");
    this.mHandler.removeMessages(1);
    this.mHandler.removeMessages(2);
    this.mHandler.removeMessages(3);
    this.mHandler.removeMessages(6);
  }

  private int updateAllData()
  {
    int i = -1;
    TrackerHelper localTrackerHelper = TrackerHelper.getInstance(this.mContext);
    List localList = localTrackerHelper.getTrackerList();
    if (localList != null)
    {
      TrackerTransport localTrackerTransport = TrackerTransport.getInstance(this.mContext);
      if (localTrackerTransport != null)
      {
        Transport.CommonResult localCommonResult2 = localTrackerTransport.registerTrackerSync(localList);
        if ((localCommonResult2 != null) && (localCommonResult2.errCode == 0) && (!this.mIsForceStop))
        {
          i = 0;
          localTrackerHelper.setRegisterState(true);
        }
      }
    }
    if (i != 0)
      return 3;
    int j = -1;
    String str = localTrackerHelper.getTrackerID();
    SQLiteDatabase localSQLiteDatabase = Database.getDb(this.mContext);
    if ((str != null) && (localSQLiteDatabase != null))
    {
      Transport.CommonResult localCommonResult1 = NetSync.sendSportDirtyDataToNetSync(this.mContext, localSQLiteDatabase, str);
      if ((localCommonResult1 != null) && (localCommonResult1.errCode == 0) && (!this.mIsForceStop))
        j = 0;
    }
    if (j != 0)
      return 4;
    int k = -1;
    boolean bool1 = SleepController.sendSleepToNetAndUpdateDbSync(this.mContext);
    boolean bool2 = SleepController.sendSleepDurationToNetAndUpdateDbSync(this.mContext);
    if ((bool1) && (bool2) && (!this.mIsForceStop))
      k = 0;
    if (k != 0)
      return 5;
    if (ProfilePreference.getInstance(this.mContext).isDirty())
    {
      k = -1;
      if ((ProfileController.sendProfileToNetAndUpdateDbSync(this.mContext)) && (!this.mIsForceStop))
      {
        k = 0;
        informDataSyncForProfile(ProfilePreference.getInstance(this.mContext).getCurrentProfile());
      }
      if (k != 0)
        return 6;
    }
    if (PlanPreference.getInstance(this.mContext).isDirty())
    {
      k = -1;
      if ((PlanController.sendPlanToNetAndUpdateDbSync(this.mContext)) && (!this.mIsForceStop))
      {
        PlanPreference localPlanPreference = PlanPreference.getInstance(this.mContext);
        k = 0;
        if (localPlanPreference != null)
        {
          Plan localPlan = new Plan();
          localPlan._mtime = localPlanPreference.getMTime();
          localPlan.distance = localPlanPreference.getTargetDistance();
          localPlan.steps = localPlanPreference.getTargetStep();
          localPlan.calories = localPlanPreference.getTargetCalorie();
          informDataSyncForPlan(localPlan);
        }
      }
      if (k != 0)
        return 7;
    }
    if (AlarmPreference.getInstance(this.mContext).isDirty())
    {
      k = -1;
      if ((AlarmController.sendAlarmToNetAndUpdateDbSync(this.mContext)) && (!this.mIsForceStop))
        k = 0;
      if (k != 0)
        return 8;
    }
    return k;
  }

  public void download(DownloadCallback paramDownloadCallback)
  {
    LogUtil.d("NetDataSyncManager", "download");
    this.mIsForceStop = false;
    int i = 0;
    this.mUserID = getUserID();
    this.mDownloadCallback = paramDownloadCallback;
    if (this.mUserID != null)
      if (NetworkCheck.isNetworkAvailable(this.mContext))
      {
        this.mHandler.removeMessages(6);
        this.mHandler.sendEmptyMessage(6);
      }
    while (true)
    {
      if ((i != 0) && (this.mDownloadCallback != null))
        this.mDownloadCallback.onFail(i, null);
      return;
      i = 1;
      continue;
      i = 3;
    }
  }

  public void forceLogin(ForceLoginCallback paramForceLoginCallback)
  {
    LogUtil.d("NetDataSyncManager", "forceLogin");
    this.mIsForceStop = false;
    int i = 0;
    this.mUserID = getUserID();
    this.mForceLoginCallback = paramForceLoginCallback;
    if (this.mUserID != null)
      if (NetworkCheck.isNetworkAvailable(this.mContext))
      {
        this.mHandler.removeMessages(7);
        this.mHandler.sendEmptyMessage(7);
      }
    while (true)
    {
      if ((i != 0) && (this.mForceLoginCallback != null))
        this.mForceLoginCallback.onFailure(i, null);
      return;
      i = 1;
      continue;
      i = 3;
    }
  }

  public void login(LoginCallback paramLoginCallback)
  {
    LogUtil.d("NetDataSyncManager", "login");
    this.mIsForceStop = false;
    int i = 0;
    this.mUserID = getUserID();
    this.mLoginCallback = paramLoginCallback;
    if (this.mUserID != null)
      if (NetworkCheck.isNetworkAvailable(this.mContext))
      {
        removeDataMsg();
        this.mHandler.sendEmptyMessage(4);
      }
    while (true)
    {
      if ((i != 0) && (this.mLoginCallback != null))
        this.mLoginCallback.onFailure(i, null);
      return;
      i = 1;
      continue;
      i = 3;
    }
  }

  public void logout(boolean paramBoolean, LogoutCallback paramLogoutCallback)
  {
    LogUtil.d("NetDataSyncManager", "logout");
    this.mUserID = null;
    this.mLogoutCallback = paramLogoutCallback;
    this.mIsDataInit = false;
    this.mEditor.putBoolean("key_data_init", false).commit();
    stopDataSync();
    if (paramBoolean)
      this.mHandler.sendEmptyMessage(5);
    while (paramLogoutCallback == null)
      return;
    paramLogoutCallback.onSuccess();
  }

  public void registerDataSyncListener(DataSyncListener paramDataSyncListener)
  {
    if ((paramDataSyncListener != null) && (!this.mListeners.contains(paramDataSyncListener)))
      this.mListeners.add(paramDataSyncListener);
  }

  public void startDataSync()
  {
    LogUtil.d("NetDataSyncManager", "startDataSync");
    this.mIsForceStop = false;
    this.mHandler.removeMessages(1);
    this.mHandler.sendEmptyMessage(1);
  }

  public void stopDataSync()
  {
    LogUtil.d("NetDataSyncManager", "stopDataSync");
    this.mHandler.removeMessages(1);
    this.mHandler.removeMessages(2);
    this.mHandler.removeMessages(3);
    this.mHandler.removeMessages(6);
    this.mHandler.removeMessages(4);
    this.mHandler.removeMessages(5);
    this.mIsForceStop = true;
  }

  public void unregisterDataSyncListener(DataSyncListener paramDataSyncListener)
  {
    if ((paramDataSyncListener != null) && (this.mListeners.contains(paramDataSyncListener)))
      this.mListeners.remove(paramDataSyncListener);
  }

  public void updatePlan(Plan paramPlan, PlanCallback paramPlanCallback)
  {
    LogUtil.d("NetDataSyncManager", "updatePlan");
    int i = 0;
    this.mUserID = getUserID();
    this.mPlanCallback = paramPlanCallback;
    if (this.mUserID != null)
      if (NetworkCheck.isNetworkAvailable(this.mContext))
      {
        this.mHandler.removeMessages(3);
        this.mHandler.removeMessages(1);
        LogUtil.d("NetDataSyncManager", "send plan to net 5s later");
        this.mHandler.sendEmptyMessageDelayed(3, 5000L);
      }
    while (true)
    {
      if ((i != 0) && (this.mPlanCallback != null))
        this.mPlanCallback.onPlanReceivedFail(i, null);
      return;
      i = 1;
      continue;
      i = 3;
    }
  }

  public void updateProfile(Profile paramProfile, ProfileCallback paramProfileCallback)
  {
    LogUtil.d("NetDataSyncManager", "updateProfile");
    int i = 0;
    this.mUserID = getUserID();
    this.mProfileCallback = paramProfileCallback;
    if (this.mUserID != null)
      if (NetworkCheck.isNetworkAvailable(this.mContext))
      {
        this.mHandler.removeMessages(2);
        this.mHandler.removeMessages(1);
        LogUtil.d("NetDataSyncManager", "send profile to net 5s later");
        this.mHandler.sendEmptyMessageDelayed(2, 5000L);
      }
    while (true)
    {
      if ((i != 0) && (this.mProfileCallback != null))
        this.mProfileCallback.onProfileReceivedFail(i, null);
      return;
      i = 1;
      continue;
      i = 3;
    }
  }

  public static abstract interface DataSyncListener
  {
    public abstract void onDataSyncFail(int paramInt, String paramString);

    public abstract void onDataSyncSuc(long paramLong);

    public abstract void onPlanReceivedFail(int paramInt, String paramString);

    public abstract void onPlanReceivedSuc(Plan paramPlan);

    public abstract void onProfileReceivedFail(int paramInt, String paramString);

    public abstract void onProfileReceivedSuc(Profile paramProfile);
  }

  private class DataSyncThread extends HandlerThread
  {
    public DataSyncThread(String arg2)
    {
      super();
    }
  }

  public static abstract interface DownloadCallback
  {
    public abstract void onFail(int paramInt, String paramString);

    public abstract void onSucceed(List<SportDetail> paramList, List<SportSummary> paramList1, List<SleepDuration> paramList2, List<SleepDetail> paramList3, Plan paramPlan, Profile paramProfile, List<Tracker> paramList4, CompletionRateAlarm paramCompletionRateAlarm);
  }

  public static abstract interface ForceLoginCallback
  {
    public abstract void onFailure(int paramInt, String paramString);

    public abstract void onSuccess();
  }

  public static abstract interface LoginCallback
  {
    public abstract void onFailure(int paramInt, String paramString);

    public abstract void onSuccess();
  }

  public static abstract interface LogoutCallback
  {
    public abstract void onFailure(int paramInt, String paramString);

    public abstract void onSuccess();
  }

  private class MyHandler extends Handler
  {
    public MyHandler(Looper arg2)
    {
      super();
    }

    public void handleMessage(Message paramMessage)
    {
      switch (paramMessage.what)
      {
      default:
        return;
      case 1:
        NetDataSyncManager.this.handleSyncData();
        return;
      case 2:
        NetDataSyncManager.this.handleSyncProfile();
        return;
      case 3:
        NetDataSyncManager.this.handleSyncPlan();
        return;
      case 4:
        NetDataSyncManager.this.handleLogin();
        return;
      case 5:
        NetDataSyncManager.this.handleLogout();
        return;
      case 6:
        NetDataSyncManager.this.handleDownload();
        return;
      case 7:
      }
      NetDataSyncManager.this.handleForceLogin();
    }
  }

  public static abstract interface PlanCallback
  {
    public abstract void onPlanReceivedFail(int paramInt, String paramString);

    public abstract void onPlanReceivedSuc(Plan paramPlan);
  }

  public static abstract interface ProfileCallback
  {
    public abstract void onProfileReceivedFail(int paramInt, String paramString);

    public abstract void onProfileReceivedSuc(Profile paramProfile);
  }

  public static enum TSyncState
  {
    static
    {
      ENetworkOut = new TSyncState("ENetworkOut", 1);
      ESyncForData = new TSyncState("ESyncForData", 2);
      ESyncingForData = new TSyncState("ESyncingForData", 3);
      ESyncForTrackers = new TSyncState("ESyncForTrackers", 4);
      ESyncingForTrackers = new TSyncState("ESyncingForTrackers", 5);
      TSyncState[] arrayOfTSyncState = new TSyncState[6];
      arrayOfTSyncState[0] = ENotYetInit;
      arrayOfTSyncState[1] = ENetworkOut;
      arrayOfTSyncState[2] = ESyncForData;
      arrayOfTSyncState[3] = ESyncingForData;
      arrayOfTSyncState[4] = ESyncForTrackers;
      arrayOfTSyncState[5] = ESyncingForTrackers;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.sync.NetDataSyncManager
 * JD-Core Version:    0.6.2
 */