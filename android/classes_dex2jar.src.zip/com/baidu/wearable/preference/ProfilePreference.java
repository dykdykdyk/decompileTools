package com.baidu.wearable.preference;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.support.v4.content.LocalBroadcastManager;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.profile.Gender;
import com.baidu.wearable.profile.Profile;
import com.baidu.wearable.sync.NetDataSyncManager;
import com.baidu.wearable.sync.SettingsSyncManager;
import java.util.Calendar;

public class ProfilePreference
{
  private static final String KEY_PROFILE_DIRTY = "profile_dirty";
  private static final String TAG = "ProfileManager";
  private static ProfilePreference mInstance;
  private static String mUid;
  private Context mContext;
  private SharedPreferences.Editor mEditor;
  private SharedPreferences mPreferences;

  private ProfilePreference(Context paramContext)
  {
    this.mPreferences = paramContext.getSharedPreferences("basic_info_" + mUid, 0);
    this.mEditor = this.mPreferences.edit();
    this.mContext = paramContext;
  }

  public static void close()
  {
    LogUtil.d("ProfileManager", "close");
    if (mInstance != null)
      mInstance = null;
  }

  public static ProfilePreference getInstance(Context paramContext)
  {
    mUid = BDAccountManager.getInstance().getUserData("uid");
    if (mInstance == null)
      mInstance = new ProfilePreference(paramContext);
    return mInstance;
  }

  public boolean clear()
  {
    LogUtil.d("ProfileManager", "clear");
    return this.mEditor.clear().commit();
  }

  public int getAge(int paramInt)
  {
    if (paramInt <= 0)
      return 0;
    return Calendar.getInstance().get(1) - paramInt;
  }

  public Profile getCurrentProfile()
  {
    Profile localProfile = new Profile();
    localProfile.year = getYear();
    localProfile.month = getMonth();
    localProfile.day = getDay();
    localProfile.gender = getGender();
    localProfile.height = getHeight();
    localProfile.weight = getWeight();
    localProfile._mtime = getMTime();
    return localProfile;
  }

  public int getDay()
  {
    int i = this.mPreferences.getInt("birth_day", 0);
    LogUtil.d("ProfileManager", "get day:" + i);
    return i;
  }

  public Gender getGender()
  {
    int i = this.mPreferences.getInt("gender", 0);
    LogUtil.d("ProfileManager", "get gender value:" + i);
    if (i == 0)
      return Gender.male;
    if (i == 1)
      return Gender.female;
    if (i == -1)
      return Gender.NA;
    return null;
  }

  public int getHeight()
  {
    int i = this.mPreferences.getInt("height_cm", 0);
    LogUtil.d("ProfileManager", "get height:" + i);
    return i;
  }

  public long getMTime()
  {
    return this.mPreferences.getLong("_mtime", System.currentTimeMillis() / 1000L);
  }

  public int getMonth()
  {
    int i = this.mPreferences.getInt("birth_month", 0);
    LogUtil.d("ProfileManager", "get month:" + i);
    return i;
  }

  public String getUserId()
  {
    return mUid;
  }

  public int getWeight()
  {
    int i = this.mPreferences.getInt("weight_kg", 0);
    LogUtil.d("ProfileManager", "get weight:" + i);
    return i;
  }

  public int getYear()
  {
    int i = this.mPreferences.getInt("birth_year", 0);
    LogUtil.d("ProfileManager", "get year:" + i);
    return i;
  }

  public boolean isAvaiable()
  {
    int i = getHeight();
    int j = getWeight();
    int k = getYear();
    return (i != 0) && (j != 0) && (k != 0);
  }

  public boolean isDirty()
  {
    return this.mPreferences.getBoolean("profile_dirty", false);
  }

  public boolean saveAllProfileInfo(Profile paramProfile)
  {
    int i = 1;
    Gender localGender = getGender();
    int j = getHeight();
    int k = getWeight();
    int m = getYear();
    int n = getMonth();
    int i1 = getDay();
    if ((paramProfile.gender == localGender) && (paramProfile.height == j) && (paramProfile.weight == k) && (paramProfile.year == m) && (paramProfile.month == n) && (paramProfile.day == i1))
      return i;
    if (paramProfile.gender == Gender.female)
      this.mEditor.putInt("gender", i);
    while (true)
    {
      this.mEditor.putInt("height_cm", paramProfile.height);
      this.mEditor.putInt("weight_kg", paramProfile.weight);
      this.mEditor.putInt("birth_year", paramProfile.year);
      this.mEditor.putInt("birth_month", paramProfile.month);
      this.mEditor.putInt("birth_day", paramProfile.day);
      this.mEditor.putLong("_mtime", paramProfile._mtime);
      boolean bool = this.mEditor.commit();
      if (!bool)
        break;
      LogUtil.d("ProfileManager", "saveAllProfileInfo gender:" + paramProfile.gender + ", height:" + paramProfile.height + ", weight:" + paramProfile.weight + ", year:" + paramProfile.year + ", mongth:" + paramProfile.month + ", day:" + paramProfile.day);
      sendProfileBroadcast();
      sendProfileToBlueTooth();
      return bool;
      if (paramProfile.gender == Gender.female)
        this.mEditor.putInt("gender", 0);
    }
  }

  public void saveBirth(int paramInt1, int paramInt2, int paramInt3)
  {
    this.mEditor.putInt("birth_year", paramInt1);
    this.mEditor.putInt("birth_month", paramInt2);
    this.mEditor.putInt("birth_day", paramInt3);
    this.mEditor.putLong("_mtime", System.currentTimeMillis() / 1000L);
    if (this.mEditor.commit())
    {
      LogUtil.d("ProfileManager", "save birth to preference success");
      setDirty(true);
      sendProfileToNet(getCurrentProfile());
      sendProfileBroadcast();
      sendProfileToBlueTooth();
      return;
    }
    LogUtil.d("ProfileManager", "save birth to preference failure");
  }

  public void saveGender(Gender paramGender)
  {
    if (paramGender == Gender.male)
      this.mEditor.putInt("gender", 0).commit();
    while (true)
    {
      this.mEditor.putLong("_mtime", System.currentTimeMillis() / 1000L);
      if (!this.mEditor.commit())
        break;
      LogUtil.d("ProfileManager", "save gender to preference success");
      setDirty(true);
      sendProfileToNet(getCurrentProfile());
      sendProfileBroadcast();
      sendProfileToBlueTooth();
      return;
      this.mEditor.putInt("gender", 1).commit();
    }
    LogUtil.d("ProfileManager", "save gender to preference failure");
  }

  public void saveHeight(int paramInt)
  {
    this.mEditor.putInt("height_cm", paramInt).commit();
    this.mEditor.putLong("_mtime", System.currentTimeMillis() / 1000L);
    if (this.mEditor.commit())
    {
      LogUtil.d("ProfileManager", "save height to preference success");
      setDirty(true);
      sendProfileToNet(getCurrentProfile());
      sendProfileBroadcast();
      sendProfileToBlueTooth();
      return;
    }
    LogUtil.d("ProfileManager", "save height to preference failure");
  }

  public void saveWeight(int paramInt)
  {
    this.mEditor.putInt("weight_kg", paramInt).commit();
    this.mEditor.putLong("_mtime", System.currentTimeMillis() / 1000L);
    if (this.mEditor.commit())
    {
      LogUtil.d("ProfileManager", "save weight to preference success");
      setDirty(true);
      sendProfileToNet(getCurrentProfile());
      sendProfileBroadcast();
      sendProfileToBlueTooth();
      return;
    }
    LogUtil.d("ProfileManager", "save weight to preference failure");
  }

  public void sendProfileBroadcast()
  {
    Intent localIntent = new Intent("com.baidu.wearable.ACTION_PROFILE_CHANGE");
    LocalBroadcastManager.getInstance(this.mContext).sendBroadcast(localIntent);
  }

  public void sendProfileToBlueTooth()
  {
    boolean bool = true;
    if (getGender() == Gender.female)
      bool = false;
    int i = getAge(getYear());
    int j = getHeight();
    int k = getWeight();
    SettingsSyncManager.getInstance(this.mContext).updateUserProfile(bool, i, j, k);
  }

  public void sendProfileToNet(Profile paramProfile)
  {
    NetDataSyncManager.getInstance(this.mContext).updateProfile(null, null);
  }

  public void setDirty(boolean paramBoolean)
  {
    LogUtil.d("ProfileManager", "setDirty:" + paramBoolean);
    this.mEditor.putBoolean("profile_dirty", paramBoolean).commit();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.preference.ProfilePreference
 * JD-Core Version:    0.6.2
 */