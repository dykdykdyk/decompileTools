package com.baidu.wearable.preference;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.support.v4.content.LocalBroadcastManager;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.plan.Plan;
import com.baidu.wearable.sync.NetDataSyncManager;
import com.baidu.wearable.sync.SettingsSyncManager;

public class PlanPreference
{
  private static final String KEY_PLAN_DIRTY = "plan_dirty";
  private static final String TAG = "PlanPreference";
  private static PlanPreference mInstance;
  private static String mUid;
  private Context mContext;
  private SharedPreferences.Editor mEditor;
  private SharedPreferences mPreferences;

  private PlanPreference(Context paramContext)
  {
    this.mPreferences = paramContext.getSharedPreferences("target_info_" + mUid, 0);
    this.mEditor = this.mPreferences.edit();
    this.mContext = paramContext;
  }

  public static void close()
  {
    if (mInstance != null)
      mInstance = null;
  }

  public static PlanPreference getInstance(Context paramContext)
  {
    mUid = BDAccountManager.getInstance().getUserData("uid");
    LogUtil.d("PlanPreference", "mUid:" + mUid);
    if (mInstance == null)
      mInstance = new PlanPreference(paramContext);
    return mInstance;
  }

  public boolean clear()
  {
    return this.mEditor.clear().commit();
  }

  public long getMTime()
  {
    return this.mPreferences.getLong("_mtime", System.currentTimeMillis() / 1000L);
  }

  public float getTargetCalorie()
  {
    return this.mPreferences.getFloat("daily_calories", 100.0F);
  }

  public float getTargetDistance()
  {
    return this.mPreferences.getFloat("daily_distance_m", 6.0F);
  }

  public long getTargetStep()
  {
    return this.mPreferences.getLong("daily_steps", 10000L);
  }

  public boolean isDirty()
  {
    return this.mPreferences.getBoolean("plan_dirty", false);
  }

  public boolean saveAllTargetPlan(Plan paramPlan)
  {
    boolean bool;
    if ((paramPlan.steps == 0L) || (paramPlan.calories == 0.0F) || (paramPlan.distance == 0.0F))
      bool = true;
    do
    {
      return bool;
      this.mEditor.putLong("daily_steps", paramPlan.steps);
      this.mEditor.putFloat("daily_calories", paramPlan.calories);
      this.mEditor.putFloat("daily_distance_m", paramPlan.distance);
      this.mEditor.putLong("_mtime", paramPlan._mtime);
      bool = this.mEditor.commit();
    }
    while (!bool);
    sendPlanToBlueTooth();
    sendPlanBroadcast();
    return bool;
  }

  public boolean saveTargetCalorie(float paramFloat)
  {
    boolean bool;
    if (paramFloat == 0.0F)
      bool = false;
    do
    {
      return bool;
      bool = this.mEditor.putFloat("daily_calories", paramFloat).commit();
    }
    while (!bool);
    setDirty(true);
    sendPlanToNet();
    return bool;
  }

  public boolean saveTargetDistance(float paramFloat)
  {
    boolean bool;
    if (paramFloat == 0.0F)
      bool = false;
    do
    {
      return bool;
      bool = this.mEditor.putFloat("daily_distance_m", paramFloat).commit();
    }
    while (!bool);
    setDirty(true);
    sendPlanToNet();
    return bool;
  }

  public boolean saveTargetStep(long paramLong)
  {
    boolean bool;
    if (paramLong == 0L)
      bool = false;
    do
    {
      return bool;
      this.mEditor.putLong("daily_steps", paramLong);
      this.mEditor.putLong("_mtime", System.currentTimeMillis() / 1000L);
      bool = this.mEditor.commit();
    }
    while (!bool);
    setDirty(true);
    sendPlanToNet();
    sendPlanToBlueTooth();
    return bool;
  }

  public void sendPlanBroadcast()
  {
    Intent localIntent = new Intent("com.baidu.wearable.ACTION_PLAN_INIT_CHANGE");
    if (this.mContext != null)
      LocalBroadcastManager.getInstance(this.mContext).sendBroadcast(localIntent);
  }

  public void sendPlanToBlueTooth()
  {
    SettingsSyncManager.getInstance(this.mContext).updateSportsTarget((int)getTargetStep());
  }

  public void sendPlanToNet()
  {
    NetDataSyncManager.getInstance(this.mContext).updatePlan(null, null);
  }

  public void setDirty(boolean paramBoolean)
  {
    this.mEditor.putBoolean("plan_dirty", paramBoolean).commit();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.preference.PlanPreference
 * JD-Core Version:    0.6.2
 */