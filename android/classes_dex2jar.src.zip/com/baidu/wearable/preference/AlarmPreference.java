package com.baidu.wearable.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.alarm.completion.CompletionRateAlarm;
import com.baidu.wearable.alarm.completion.CompletionRateAlarmTime;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.net.CompletionRateTransport;
import com.baidu.wearable.net.Transport.CommonListener;
import java.util.Set;

public class AlarmPreference
{
  public static final String DIRTY = "warn_finish_rate_dirty";
  private static final String KEY_CLOCK_INIT_STATUS = "key_clock_init_status";
  public static final String NAME_ = "@name_";
  public static final String NUMBER_ = "@number_";
  private static AlarmPreference mInstance;
  private static String mUid;
  private final String TAG = "WarnManager";
  private SharedPreferences.Editor mEditor;
  private SharedPreferences mPreferences;
  private CompletionRateTransport mTransport;

  private AlarmPreference(Context paramContext)
  {
    this.mPreferences = paramContext.getSharedPreferences("alarm_info_" + mUid, 0);
    this.mEditor = this.mPreferences.edit();
    this.mTransport = CompletionRateTransport.getInstance(paramContext);
  }

  public static void close()
  {
    if (mInstance != null)
      mInstance = null;
  }

  public static AlarmPreference getInstance(Context paramContext)
  {
    if (mInstance == null);
    try
    {
      mUid = BDAccountManager.getInstance().getUserData("uid");
      mInstance = new AlarmPreference(paramContext);
      return mInstance;
    }
    finally
    {
    }
  }

  public boolean clear()
  {
    return this.mEditor.clear().commit();
  }

  public boolean getCallingAlarmState()
  {
    return this.mPreferences.getBoolean("key_calling_alarm_alerted", false);
  }

  public boolean getCallingAlarmSwitcher()
  {
    return this.mPreferences.getBoolean("key_calling_alarm_switcher", false);
  }

  public boolean getClockInitStatus()
  {
    return this.mPreferences.getBoolean("key_clock_init_status", true);
  }

  public boolean getCompletionRateSwitch()
  {
    boolean bool = this.mPreferences.getBoolean("warn_finish_rate_switch", true);
    LogUtil.d("WarnManager", "getFinishWarnSwitch onOrOff:" + bool);
    return bool;
  }

  public CompletionRateAlarmTime getCompletionRateTime()
  {
    String str = this.mPreferences.getString("warn_finish_rate_time", "22:0");
    LogUtil.d("WarnManager", "warnStr:" + str);
    String[] arrayOfString = str.split(":");
    CompletionRateAlarmTime localCompletionRateAlarmTime = new CompletionRateAlarmTime();
    localCompletionRateAlarmTime.hour = Integer.valueOf(arrayOfString[0]).intValue();
    localCompletionRateAlarmTime.minute = Integer.valueOf(arrayOfString[1]).intValue();
    LogUtil.d("WarnManager", "getFinishWarnTime hour:" + localCompletionRateAlarmTime.hour + ", minute:" + localCompletionRateAlarmTime.minute);
    return localCompletionRateAlarmTime;
  }

  public Set<String> getContactIDs()
  {
    return this.mPreferences.getStringSet("key_calling_contact_ids", null);
  }

  public boolean getMyphoneAntiDialogShowed()
  {
    return this.mPreferences.getBoolean("key_my_phone_anti_lost_dialog_showed", false);
  }

  public boolean getMyphoneAntiLostState()
  {
    return this.mPreferences.getBoolean("key_my_phone_anti_lost_alerted", false);
  }

  public boolean getSilentSleepState()
  {
    return this.mPreferences.getBoolean("key_silent_sleep", false);
  }

  public boolean isCallingAlarmGuided()
  {
    return this.mPreferences.getBoolean("key_calling_alarm_guided", false);
  }

  public boolean isDirty()
  {
    return this.mPreferences.getBoolean("warn_finish_rate_dirty", false);
  }

  public void saveClockInitStatus()
  {
    this.mEditor.putBoolean("key_clock_init_status", false).commit();
  }

  public void saveCompletionRate(CompletionRateAlarm paramCompletionRateAlarm)
  {
    if (paramCompletionRateAlarm == null)
      return;
    LogUtil.d("WarnManager", "saveFinishWarnTime hour:" + paramCompletionRateAlarm.time.hour + ", minute:" + paramCompletionRateAlarm.time.minute + ", onOrOff:" + paramCompletionRateAlarm.onOrOff);
    String str = paramCompletionRateAlarm.time.hour + ":" + paramCompletionRateAlarm.time.minute;
    this.mEditor.putString("warn_finish_rate_time", str).commit();
    this.mEditor.putBoolean("warn_finish_rate_switch", paramCompletionRateAlarm.onOrOff).commit();
  }

  public void saveCompletionRateSwitch(boolean paramBoolean)
  {
    LogUtil.d("WarnManager", "saveFinishWarnSwitch onOrOff:" + paramBoolean);
    this.mEditor.putBoolean("warn_finish_rate_switch", paramBoolean).commit();
    setDirty(true);
    sendToNet();
  }

  public void saveCompletionRateTime(CompletionRateAlarmTime paramCompletionRateAlarmTime)
  {
    if (paramCompletionRateAlarmTime == null)
      return;
    LogUtil.d("WarnManager", "saveFinishWarnTime hour:" + paramCompletionRateAlarmTime.hour + ", minute:" + paramCompletionRateAlarmTime.minute);
    String str = paramCompletionRateAlarmTime.hour + ":" + paramCompletionRateAlarmTime.minute;
    this.mEditor.putString("warn_finish_rate_time", str).commit();
    setDirty(true);
    sendToNet();
  }

  public void sendToNet()
  {
    this.mTransport.updateCompletionRateAlarm(getCompletionRateTime(), getCompletionRateSwitch(), new Transport.CommonListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        AlarmPreference.this.mEditor.putBoolean("warn_finish_rate_dirty", true).commit();
      }

      public void onSuccess()
      {
        AlarmPreference.this.mEditor.putBoolean("warn_finish_rate_dirty", false).commit();
      }
    });
  }

  public void setCallingAlarmGuided(boolean paramBoolean)
  {
    this.mEditor.putBoolean("key_calling_alarm_guided", paramBoolean).commit();
  }

  public void setCallingAlarmStateAlerted()
  {
    this.mEditor.putBoolean("key_calling_alarm_alerted", true).commit();
  }

  public void setCallingAlarmSwitcher(boolean paramBoolean)
  {
    this.mEditor.putBoolean("key_calling_alarm_switcher", paramBoolean).commit();
  }

  public void setContactIDs(Set<String> paramSet)
  {
    this.mEditor.remove("key_calling_contact_ids");
    this.mEditor.commit();
    this.mEditor.putStringSet("key_calling_contact_ids", paramSet).commit();
  }

  public void setDirty(boolean paramBoolean)
  {
    LogUtil.d("WarnManager", "setDirty:" + paramBoolean);
    this.mEditor.putBoolean("warn_finish_rate_dirty", paramBoolean).commit();
  }

  public void setMyphoneAntiLostDialogShowed(boolean paramBoolean)
  {
    this.mEditor.putBoolean("key_my_phone_anti_lost_dialog_showed", paramBoolean);
  }

  public void setMyphoneAntiLostStateAlerted(boolean paramBoolean)
  {
    this.mEditor.putBoolean("key_my_phone_anti_lost_alerted", paramBoolean).commit();
  }

  public void setSilentSleepState(boolean paramBoolean)
  {
    this.mEditor.putBoolean("key_silent_sleep", paramBoolean).commit();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.preference.AlarmPreference
 * JD-Core Version:    0.6.2
 */