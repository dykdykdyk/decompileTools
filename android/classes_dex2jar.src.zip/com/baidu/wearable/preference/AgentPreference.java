package com.baidu.wearable.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.baidu.wearable.Config;

public class AgentPreference
{
  private static final String AGENT_ID = "id";
  private static final String AGENT_STATUS = "status";
  private static final String AGENT_TIME = "time";

  public static String getAgentId(Context paramContext)
  {
    return paramContext.getSharedPreferences("agent_info", 0).getString("id", "-1");
  }

  public static boolean getAgentStatus(Context paramContext)
  {
    return paramContext.getSharedPreferences("agent_info", 0).getBoolean("status", true);
  }

  public static long getAgentTime(Context paramContext)
  {
    return paramContext.getSharedPreferences("agent_info", 0).getLong("time", 0L);
  }

  public static void saveAgentStatus(Context paramContext, boolean paramBoolean, long paramLong)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("agent_info", 0).edit();
    localEditor.putBoolean("status", paramBoolean);
    localEditor.putLong("time", paramLong);
    localEditor.commit();
  }

  public static void setAgentId(Context paramContext)
  {
    paramContext.getSharedPreferences("agent_info", 0).edit().putString("id", Config.DEVICE_ID).commit();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.preference.AgentPreference
 * JD-Core Version:    0.6.2
 */