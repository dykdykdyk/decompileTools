package com.baidu.wearable.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.baidu.sapi2.BDAccountManager;

public class SleepPreference
{
  public static final long INIT_STATE = -1L;
  private static final String LAST_START_TIME_KEY = "last_start_time";
  public static final long NO_LAST_START_TIME_STATE;
  private static SleepPreference mInstance;
  private static String mUid;
  private SharedPreferences.Editor mEditor;
  private SharedPreferences mPreferences;

  private SleepPreference(Context paramContext)
  {
    this.mPreferences = paramContext.getSharedPreferences("target_info_" + mUid, 0);
    this.mEditor = this.mPreferences.edit();
  }

  public static void close()
  {
    if (mInstance != null)
      mInstance = null;
  }

  public static SleepPreference getInstance(Context paramContext)
  {
    mUid = BDAccountManager.getInstance().getUserData("uid");
    if (mInstance == null)
      mInstance = new SleepPreference(paramContext);
    return mInstance;
  }

  public boolean clear()
  {
    return this.mEditor.clear().commit();
  }

  public long getLastStartTimeS()
  {
    return this.mPreferences.getLong("last_start_time", -1L);
  }

  public boolean saveLastStartTimeS(long paramLong)
  {
    if (paramLong == 0L)
      return false;
    return this.mEditor.putLong("last_start_time", paramLong).commit();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.preference.SleepPreference
 * JD-Core Version:    0.6.2
 */