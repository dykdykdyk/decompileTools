package com.baidu.wearable;

public final class Manifest
{
  public static final class permission
  {
    public static final String ACCESS_DOWNLOAD_MANAGER = "android.permission.ACCESS_DOWNLOAD_MANAGER";
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.Manifest
 * JD-Core Version:    0.6.2
 */