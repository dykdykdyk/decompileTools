package com.baidu.wearable.alarm.clock;

import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import com.baidu.wearable.ble.model.Clock;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.ClockDao;
import java.util.ArrayList;
import java.util.List;

public class ClockStorage
{
  static final String TAG = "ClockStorage";

  public static void deleteClock(SQLiteDatabase paramSQLiteDatabase, long paramLong, DeleteClockListener paramDeleteClockListener)
  {
    AsyncTask local5 = new AsyncTask()
    {
      protected Long doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return Long.valueOf(ClockDao.deleteClock((SQLiteDatabase)paramAnonymousArrayOfObject[0], ((Long)paramAnonymousArrayOfObject[1]).longValue()));
      }

      protected void onPostExecute(Long paramAnonymousLong)
      {
        super.onPostExecute(paramAnonymousLong);
        if (ClockStorage.this != null)
        {
          if (paramAnonymousLong.longValue() == 0L)
            ClockStorage.this.onFailure();
        }
        else
          return;
        ClockStorage.this.onSuccess(paramAnonymousLong.longValue());
      }
    };
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = paramSQLiteDatabase;
    arrayOfObject[1] = Long.valueOf(paramLong);
    local5.execute(arrayOfObject);
  }

  public static void insertClock(SQLiteDatabase paramSQLiteDatabase, Clock paramClock, InsertClockListener paramInsertClockListener)
  {
    new AsyncTask()
    {
      protected Long doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return Long.valueOf(ClockDao.insertClock((SQLiteDatabase)paramAnonymousArrayOfObject[0], (Clock)paramAnonymousArrayOfObject[1]));
      }

      protected void onPostExecute(Long paramAnonymousLong)
      {
        super.onPostExecute(paramAnonymousLong);
        if (ClockStorage.this != null)
        {
          if (paramAnonymousLong.longValue() == -1L)
            ClockStorage.this.onFailure();
        }
        else
          return;
        ClockStorage.this.onSuccess(paramAnonymousLong.longValue());
      }
    }
    .execute(new Object[] { paramSQLiteDatabase, paramClock });
  }

  public static void insertClocks(SQLiteDatabase paramSQLiteDatabase, List<Clock> paramList, InsertBatchClockListener paramInsertBatchClockListener)
  {
    new AsyncTask()
    {
      protected List<Long> doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        List localList = (List)paramAnonymousArrayOfObject[1];
        ArrayList localArrayList = new ArrayList();
        LogUtil.d("ClockStorage", "insert clock count:" + localList.size());
        for (int i = 0; ; i++)
        {
          if (i >= localList.size())
            return localArrayList;
          long l = ClockDao.insertClock((SQLiteDatabase)paramAnonymousArrayOfObject[0], (Clock)localList.get(i));
          LogUtil.d("ClockStorage", "batch insert clock:" + i + " ret:" + l);
          localArrayList.add(Long.valueOf(l));
        }
      }

      protected void onPostExecute(List<Long> paramAnonymousList)
      {
        super.onPostExecute(paramAnonymousList);
        if (ClockStorage.this != null)
          ClockStorage.this.onResult(paramAnonymousList);
      }
    }
    .execute(new Object[] { paramSQLiteDatabase, paramList });
  }

  public static void selectClock(SQLiteDatabase paramSQLiteDatabase, SelectClockListener paramSelectClockListener)
  {
    new AsyncTask()
    {
      protected List<Clock> doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return ClockDao.selectClock((SQLiteDatabase)paramAnonymousArrayOfObject[0]);
      }

      protected void onPostExecute(List<Clock> paramAnonymousList)
      {
        super.onPostExecute(paramAnonymousList);
        if (ClockStorage.this != null)
          ClockStorage.this.onResult(paramAnonymousList);
      }
    }
    .execute(new Object[] { paramSQLiteDatabase });
  }

  public static void selectOpenClock(SQLiteDatabase paramSQLiteDatabase, SelectClockListener paramSelectClockListener)
  {
    new AsyncTask()
    {
      protected List<Clock> doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return ClockDao.selectOpenClock((SQLiteDatabase)paramAnonymousArrayOfObject[0]);
      }

      protected void onPostExecute(List<Clock> paramAnonymousList)
      {
        super.onPostExecute(paramAnonymousList);
        if (ClockStorage.this != null)
          ClockStorage.this.onResult(paramAnonymousList);
      }
    }
    .execute(new Object[] { paramSQLiteDatabase });
  }

  public static void updateClock(SQLiteDatabase paramSQLiteDatabase, Clock paramClock, UpdateClockListener paramUpdateClockListener)
  {
    new AsyncTask()
    {
      protected Long doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return Long.valueOf(ClockDao.updateClock((SQLiteDatabase)paramAnonymousArrayOfObject[0], (Clock)paramAnonymousArrayOfObject[1]));
      }

      protected void onPostExecute(Long paramAnonymousLong)
      {
        super.onPostExecute(paramAnonymousLong);
        if (ClockStorage.this != null)
        {
          if (paramAnonymousLong.longValue() == 0L)
            ClockStorage.this.onFailure();
        }
        else
          return;
        ClockStorage.this.onSuccess(paramAnonymousLong.longValue());
      }
    }
    .execute(new Object[] { paramSQLiteDatabase, paramClock });
  }

  public static void updateClockToClose(SQLiteDatabase paramSQLiteDatabase, int paramInt, UpdateClockListener paramUpdateClockListener)
  {
    AsyncTask local4 = new AsyncTask()
    {
      protected Long doInBackground(Object[] paramAnonymousArrayOfObject)
      {
        return Long.valueOf(ClockDao.updateClockToClose((SQLiteDatabase)paramAnonymousArrayOfObject[0], ((Integer)paramAnonymousArrayOfObject[1]).intValue()));
      }

      protected void onPostExecute(Long paramAnonymousLong)
      {
        super.onPostExecute(paramAnonymousLong);
        if (ClockStorage.this != null)
        {
          if (paramAnonymousLong.longValue() == 0L)
            ClockStorage.this.onFailure();
        }
        else
          return;
        ClockStorage.this.onSuccess(paramAnonymousLong.longValue());
      }
    };
    Object[] arrayOfObject = new Object[2];
    arrayOfObject[0] = paramSQLiteDatabase;
    arrayOfObject[1] = Integer.valueOf(paramInt);
    local4.execute(arrayOfObject);
  }

  public static abstract interface DeleteClockListener
  {
    public abstract void onFailure();

    public abstract void onSuccess(long paramLong);
  }

  public static abstract interface InsertBatchClockListener
  {
    public abstract void onResult(List<Long> paramList);
  }

  public static abstract interface InsertClockListener
  {
    public abstract void onFailure();

    public abstract void onSuccess(long paramLong);
  }

  public static abstract interface SelectClockListener
  {
    public abstract void onResult(List<Clock> paramList);
  }

  public static abstract interface UpdateClockListener
  {
    public abstract void onFailure();

    public abstract void onSuccess(long paramLong);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.clock.ClockStorage
 * JD-Core Version:    0.6.2
 */