package com.baidu.wearable.alarm.clock;

public class ClockIntent
{
  public static final String ACTION_CLOCK_CLOSE_INTENT = "com.baidu.wearable.ACTION_CLOCK_CLOSE";
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.clock.ClockIntent
 * JD-Core Version:    0.6.2
 */