package com.baidu.wearable.alarm.clock;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import com.baidu.wearable.ble.model.Clock;
import com.baidu.wearable.ble.model.ClockList;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.sync.SettingsSyncManager;
import java.util.Calendar;
import java.util.List;

public class ClockManager
{
  private static final String TAG = "ClockManager";

  public static void addClockFromDb(Context paramContext, Clock paramClock, ClockStorage.InsertClockListener paramInsertClockListener)
  {
    ClockStorage.insertClock(Database.getDb(paramContext), paramClock, paramInsertClockListener);
  }

  public static void deleteClockFromDb(Context paramContext, Clock paramClock, ClockStorage.DeleteClockListener paramDeleteClockListener)
  {
    ClockStorage.deleteClock(Database.getDb(paramContext), paramClock.getId(), paramDeleteClockListener);
  }

  public static void getClockFromDb(Context paramContext, ClockStorage.SelectClockListener paramSelectClockListener)
  {
    ClockStorage.selectClock(Database.getDb(paramContext), paramSelectClockListener);
  }

  public static void init(Context paramContext)
  {
    AlarmPreference.getInstance(paramContext).saveClockInitStatus();
  }

  public static boolean isInit(Context paramContext)
  {
    return AlarmPreference.getInstance(paramContext).getClockInitStatus();
  }

  public static void registerClockListener(Context paramContext, ClockListener paramClockListener)
  {
    SettingsSyncManager.getInstance(paramContext).registerClockListener(paramClockListener);
  }

  public static void requestClockFromRing(Context paramContext)
  {
    SettingsSyncManager.getInstance(paramContext).getClock();
  }

  private static void sendClockToBlueTooth(Context paramContext)
  {
    ClockStorage.selectOpenClock(Database.getDb(paramContext), new ClockStorage.SelectClockListener()
    {
      public void onResult(List<Clock> paramAnonymousList)
      {
        ClockList localClockList = new ClockList();
        localClockList.setClocks(paramAnonymousList);
        LogUtil.d("ClockManager", "send data to sync manager clock count:" + localClockList.getListSize());
        SettingsSyncManager.getInstance(ClockManager.this).updateAlarmList(localClockList);
      }
    });
  }

  public static void setClockToRing(Context paramContext)
  {
    sendClockToBlueTooth(paramContext);
  }

  private static void startClock(Context paramContext, int paramInt, long paramLong)
  {
    LogUtil.d("ClockManager", "startClockAlarm alarmId:" + paramInt + ", triggerAtMillis:" + paramLong);
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    Intent localIntent = new Intent("com.baidu.wearable.ACTION_CLOCK_CLOSE");
    localIntent.putExtra("alarm_id", paramInt);
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, paramInt, localIntent, 0);
    localAlarmManager.cancel(localPendingIntent);
    localAlarmManager.set(0, paramLong, localPendingIntent);
  }

  public static void startClock(Context paramContext, Clock paramClock)
  {
    LogUtil.d("ClockManager", "setAlarmManager on:" + paramClock.isOn() + ", repeat:" + paramClock.isRepeat() + ", expire:" + paramClock.isExpire() + ", year:" + paramClock.getYear() + ", month:" + paramClock.getMonth() + ", day:" + paramClock.getDay() + ", hour:" + paramClock.getHour() + ", minute:" + paramClock.getMinute() + ", alarmId:" + paramClock.getAlarmId());
    if ((paramClock.isOn()) && (!paramClock.isRepeat()) && (!paramClock.isExpire()))
    {
      Calendar localCalendar = Calendar.getInstance();
      LogUtil.d("ClockManager", "time:" + localCalendar.getTimeInMillis());
      localCalendar.set(paramClock.getYear(), -1 + paramClock.getMonth(), paramClock.getDay(), paramClock.getHour(), paramClock.getMinute(), 0);
      startClock(paramContext, paramClock.getAlarmId(), localCalendar.getTimeInMillis());
    }
  }

  private static void stopClock(Context paramContext, int paramInt)
  {
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    Intent localIntent = new Intent("com.baidu.wearable.ACTION_CLOCK_CLOSE");
    localIntent.putExtra("alarm_id", paramInt);
    localAlarmManager.cancel(PendingIntent.getBroadcast(paramContext, paramInt, localIntent, 0));
  }

  public static void stopClock(Context paramContext, Clock paramClock)
  {
    LogUtil.d("ClockManager", "cancelAlarmManager on:" + paramClock.isOn() + ", repeat:" + paramClock.isRepeat() + ", expire:" + paramClock.isExpire() + ", year:" + paramClock.getYear() + ", month:" + paramClock.getMonth() + ", day:" + paramClock.getDay() + ", hour:" + paramClock.getHour() + ", minute:" + paramClock.getMinute() + ", alarmId:" + paramClock.getAlarmId());
    if ((paramClock.isOn()) && (paramClock.isRepeat()) && (!paramClock.isExpire()))
    {
      LogUtil.d("ClockManager", "stop clock alarm:" + paramClock.getAlarmId());
      stopClock(paramContext, paramClock.getAlarmId());
    }
  }

  public static void unregisterClockListener(Context paramContext, ClockListener paramClockListener)
  {
    SettingsSyncManager.getInstance(paramContext).unregisterClockListener(paramClockListener);
  }

  public static void updateClockFromDb(Context paramContext, Clock paramClock, ClockStorage.UpdateClockListener paramUpdateClockListener)
  {
    ClockStorage.updateClock(Database.getDb(paramContext), paramClock, paramUpdateClockListener);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.clock.ClockManager
 * JD-Core Version:    0.6.2
 */