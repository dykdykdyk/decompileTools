package com.baidu.wearable.alarm.clock;

import android.content.Context;
import com.baidu.wearable.ble.model.Clock;
import com.baidu.wearable.ble.model.ClockBlueTooth;
import com.baidu.wearable.ble.model.ClockBlueTooth.GetClockListListener;
import com.baidu.wearable.ble.model.ClockList;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ClockImpl
{
  private static final String TAG = "ClockImpl";

  public static void getClock(Context paramContext, final ClockCallback paramClockCallback)
  {
    ClockBlueTooth.getInstance().getClockList(new ClockBlueTooth.GetClockListListener()
    {
      public void onFailure()
      {
        LogUtil.d("ClockImpl", "ClockBlueTooth getClockList failure");
        ClockImpl.handleGetClockFailure(ClockImpl.this, paramClockCallback);
      }

      public void onSuccess(ClockList paramAnonymousClockList)
      {
        LogUtil.d("ClockImpl", "ClockBlueTooth getClockList success, clock count:" + paramAnonymousClockList.getListSize());
        ClockImpl.handleGetClockSuccess(ClockImpl.this, paramClockCallback, paramAnonymousClockList);
      }
    });
  }

  private static void handleClockOnOrOff(List<Clock> paramList)
  {
    Iterator localIterator = paramList.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      Clock localClock = (Clock)localIterator.next();
      if (localClock.isExpire())
        localClock.setOn(false);
      else
        localClock.setOn(true);
    }
  }

  private static void handleGetClockFailure(Context paramContext, ClockCallback paramClockCallback)
  {
    storeAndSetDefaultClock(paramContext, paramClockCallback);
  }

  private static void handleGetClockSuccess(Context paramContext, ClockCallback paramClockCallback, ClockList paramClockList)
  {
    List localList = paramClockList.getClocks();
    handleClockOnOrOff(localList);
    if (paramClockList.getListSize() > 0)
    {
      storeAndSetClock(paramContext, paramClockCallback, localList);
      return;
    }
    storeAndSetDefaultClock(paramContext, paramClockCallback);
  }

  private static void storeAndSetClock(final Context paramContext, final ClockCallback paramClockCallback, List<Clock> paramList)
  {
    ClockStorage.insertClocks(Database.getDb(paramContext), paramList, new ClockStorage.InsertBatchClockListener()
    {
      public void onResult(List<Long> paramAnonymousList)
      {
        int i = 0;
        if (i >= paramAnonymousList.size())
        {
          if (paramClockCallback != null)
            paramClockCallback.onResult(ClockImpl.this);
          return;
        }
        long l = ((Long)paramAnonymousList.get(i)).longValue();
        if (l == -1L)
          ClockImpl.this.remove(i);
        while (true)
        {
          i++;
          break;
          Clock localClock = (Clock)ClockImpl.this.get(i);
          localClock.setId(l);
          ClockManager.startClock(paramContext, localClock);
        }
      }
    });
  }

  private static void storeAndSetDefaultClock(Context paramContext, final ClockCallback paramClockCallback)
  {
    ArrayList localArrayList = new ArrayList();
    Clock localClock1 = new Clock();
    localClock1.setHour(8);
    localClock1.setMinute(0);
    localClock1.setMon(true);
    localClock1.setTue(true);
    localClock1.setWed(true);
    localClock1.setThu(true);
    localClock1.setFri(true);
    localArrayList.add(localClock1);
    Clock localClock2 = new Clock();
    localClock2.setHour(9);
    localClock2.setMinute(0);
    localClock2.setSat(true);
    localClock2.setSun(true);
    localArrayList.add(localClock2);
    ClockStorage.insertClocks(Database.getDb(paramContext), localArrayList, new ClockStorage.InsertBatchClockListener()
    {
      public void onResult(List<Long> paramAnonymousList)
      {
        int i = 0;
        if (i >= paramAnonymousList.size())
        {
          if (paramClockCallback != null)
            paramClockCallback.onResult(ClockImpl.this);
          return;
        }
        if (((Long)paramAnonymousList.get(i)).longValue() == -1L)
          ClockImpl.this.remove(i);
        while (true)
        {
          i++;
          break;
          ((Clock)ClockImpl.this.get(i)).setId(((Long)paramAnonymousList.get(i)).longValue());
        }
      }
    });
  }

  public static abstract interface ClockCallback
  {
    public abstract void onResult(List<Clock> paramList);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.clock.ClockImpl
 * JD-Core Version:    0.6.2
 */