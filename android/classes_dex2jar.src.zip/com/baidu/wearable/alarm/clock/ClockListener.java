package com.baidu.wearable.alarm.clock;

import com.baidu.wearable.ble.model.Clock;
import java.util.List;

public abstract interface ClockListener
{
  public abstract void onResult(List<Clock> paramList);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.clock.ClockListener
 * JD-Core Version:    0.6.2
 */