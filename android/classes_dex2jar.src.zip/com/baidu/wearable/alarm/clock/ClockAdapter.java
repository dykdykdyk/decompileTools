package com.baidu.wearable.alarm.clock;

import android.app.TimePickerDialog;
import android.app.TimePickerDialog.OnTimeSetListener;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ToggleButton;
import com.baidu.wearable.ble.model.Clock;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

public class ClockAdapter extends BaseAdapter
{
  public static final int CLOCK_MAX_COUNT = 8;
  public static final int CLOCK_WHAT_ADD = 1;
  public static final int CLOCK_WHAT_DELETE = 0;
  public static final int CLOCK_WHAT_INIT = 3;
  public static final int CLOCK_WHAT_UPDATE = 2;
  public static final String KEY_CLOCK = "clock";
  private static final String TAG = "ClockAdapter";
  private static LinkedList<Boolean> mCloseFlagList = new LinkedList();
  private static int mOpenClockCount;
  private static LinkedList<Boolean> mRepeatCheckedList = new LinkedList();
  private List<Clock> mClockList;
  private Context mContext;
  private boolean mFirstTimeForTimeDialog;
  private Handler mHandler;
  private LayoutInflater mInflater;

  public ClockAdapter(Context paramContext, Handler paramHandler, List<Clock> paramList, int paramInt1, int paramInt2)
  {
    this.mHandler = paramHandler;
    this.mClockList = paramList;
    this.mInflater = LayoutInflater.from(paramContext);
    this.mContext = paramContext;
    for (int i = 0; ; i++)
    {
      if (i >= paramInt1)
      {
        mOpenClockCount = paramInt2;
        return;
      }
      mCloseFlagList.add(i, Boolean.valueOf(true));
      mRepeatCheckedList.add(i, Boolean.valueOf(false));
    }
  }

  public static void addFirst()
  {
    mCloseFlagList.addFirst(Boolean.valueOf(false));
    mRepeatCheckedList.addFirst(Boolean.valueOf(false));
    LogUtil.d("ClockAdapter", "addFirst close list count:" + mCloseFlagList.size() + ", repeat list count:" + mRepeatCheckedList.size());
  }

  public static void parseDate(Clock paramClock)
  {
    printClockLog("parseData before", paramClock);
    if (paramClock.isExpire())
    {
      Calendar localCalendar2 = Calendar.getInstance();
      localCalendar2.set(6, 1 + localCalendar2.get(6));
      localCalendar2.set(11, paramClock.getHour());
      localCalendar2.set(12, paramClock.getMinute());
      localCalendar2.set(13, 0);
      int i2 = localCalendar2.get(1);
      int i3 = 1 + localCalendar2.get(2);
      int i4 = localCalendar2.get(5);
      int i5 = localCalendar2.get(11);
      int i6 = localCalendar2.get(12);
      paramClock.setYear(i2);
      paramClock.setMonth(i3);
      paramClock.setDay(i4);
      paramClock.setHour(i5);
      paramClock.setMinute(i6);
    }
    while (true)
    {
      printClockLog("parseData after", paramClock);
      return;
      if (!paramClock.isRepeat())
      {
        Calendar localCalendar1 = Calendar.getInstance();
        long l1 = localCalendar1.getTimeInMillis();
        localCalendar1.set(paramClock.getYear(), -1 + paramClock.getMonth(), paramClock.getDay(), paramClock.getHour(), paramClock.getMinute(), 0);
        long l2 = localCalendar1.getTimeInMillis();
        int i = localCalendar1.get(6);
        if (86400000L + l1 < l2)
        {
          localCalendar1.set(6, i - 1);
          localCalendar1.set(11, paramClock.getHour());
          localCalendar1.set(12, paramClock.getMinute());
          localCalendar1.set(13, 0);
          int j = localCalendar1.get(1);
          int k = 1 + localCalendar1.get(2);
          int m = localCalendar1.get(5);
          int n = localCalendar1.get(11);
          int i1 = localCalendar1.get(12);
          paramClock.setYear(j);
          paramClock.setMonth(k);
          paramClock.setDay(m);
          paramClock.setHour(n);
          paramClock.setMinute(i1);
        }
      }
    }
  }

  private static void printClockLog(String paramString, Clock paramClock)
  {
    LogUtil.d("ClockAdapter", paramString + " id:" + paramClock.getId() + ", alarmId:" + paramClock.getAlarmId() + ", year:" + paramClock.getYear() + ", month:" + paramClock.getMonth() + ", day:" + paramClock.getDay() + ", onOrOff:" + paramClock.isOn() + ", mon:" + paramClock.isMon() + ", tue:" + paramClock.isTue() + ", wed:" + paramClock.isWed() + ", thu:" + paramClock.isThu() + ", fri:" + paramClock.isFri() + ", sat:" + paramClock.isSat() + ", sun:" + paramClock.isSun() + ", hour:" + paramClock.getHour() + ", minute:" + paramClock.getMinute());
  }

  private void setOnceMode(Clock paramClock)
  {
    LogUtil.d("ClockAdapter", "setOnceMode");
    Calendar localCalendar = Calendar.getInstance();
    int i = localCalendar.get(1);
    int j = 1 + localCalendar.get(2);
    int k = localCalendar.get(5);
    paramClock.setYear(i);
    paramClock.setMonth(j);
    paramClock.setDay(k);
    paramClock.setSun(false);
    paramClock.setMon(false);
    paramClock.setTue(false);
    paramClock.setWed(false);
    paramClock.setThu(false);
    paramClock.setFri(false);
    paramClock.setSat(false);
    parseDate(paramClock);
    sendUpdateCmd(paramClock);
  }

  private void setRepeatMode(Clock paramClock)
  {
    paramClock.setYear(0);
    paramClock.setMonth(0);
    paramClock.setDay(0);
    sendUpdateCmd(paramClock);
    printClockLog("setRepeatMode", paramClock);
  }

  public void clear()
  {
    mCloseFlagList.clear();
    mRepeatCheckedList.clear();
    mOpenClockCount = 0;
  }

  public void declineClockCount()
  {
    mOpenClockCount = -1 + mOpenClockCount;
  }

  public int getCount()
  {
    return this.mClockList.size();
  }

  public Object getItem(int paramInt)
  {
    return this.mClockList.get(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return paramInt;
  }

  public View getView(final int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    LogUtil.d("ClockAdapter", "getView position:" + paramInt);
    RelativeLayout localRelativeLayout1 = (RelativeLayout)this.mInflater.inflate(2130903084, null);
    final TextView localTextView1 = (TextView)localRelativeLayout1.findViewById(2131231061);
    final ToggleButton localToggleButton1 = (ToggleButton)localRelativeLayout1.findViewById(2131231062);
    final RelativeLayout localRelativeLayout2 = (RelativeLayout)localRelativeLayout1.findViewById(2131231063);
    final CheckBox localCheckBox = (CheckBox)localRelativeLayout1.findViewById(2131231064);
    final LinearLayout localLinearLayout = (LinearLayout)localRelativeLayout1.findViewById(2131231065);
    final ToggleButton localToggleButton2 = (ToggleButton)localRelativeLayout1.findViewById(2131231066);
    final ToggleButton localToggleButton3 = (ToggleButton)localRelativeLayout1.findViewById(2131231067);
    final ToggleButton localToggleButton4 = (ToggleButton)localRelativeLayout1.findViewById(2131231068);
    final ToggleButton localToggleButton5 = (ToggleButton)localRelativeLayout1.findViewById(2131231069);
    final ToggleButton localToggleButton6 = (ToggleButton)localRelativeLayout1.findViewById(2131231070);
    final ToggleButton localToggleButton7 = (ToggleButton)localRelativeLayout1.findViewById(2131231071);
    final ToggleButton localToggleButton8 = (ToggleButton)localRelativeLayout1.findViewById(2131231072);
    RelativeLayout localRelativeLayout3 = (RelativeLayout)localRelativeLayout1.findViewById(2131231073);
    final ImageView localImageView1 = (ImageView)localRelativeLayout1.findViewById(2131231074);
    final TextView localTextView2 = (TextView)localRelativeLayout1.findViewById(2131231075);
    ImageView localImageView2 = (ImageView)localRelativeLayout1.findViewById(2131231076);
    final Clock localClock = (Clock)this.mClockList.get(paramInt);
    label346: String str;
    if ((localClock.getMinute() <= 9) && (localClock.getMinute() >= 0))
    {
      localTextView1.setText(localClock.getHour() + ":0" + localClock.getMinute());
      localTextView1.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Calendar localCalendar = Calendar.getInstance();
          ClockAdapter.this.mFirstTimeForTimeDialog = true;
          TimePickerDialog localTimePickerDialog = new TimePickerDialog(ClockAdapter.this.mContext, new TimePickerDialog.OnTimeSetListener()
          {
            public void onTimeSet(TimePicker paramAnonymous2TimePicker, int paramAnonymous2Int1, int paramAnonymous2Int2)
            {
              Clock localClock;
              if (ClockAdapter.this.mFirstTimeForTimeDialog)
              {
                localClock = (Clock)ClockAdapter.this.mClockList.get(this.val$position);
                localClock.setHour(paramAnonymous2Int1);
                localClock.setMinute(paramAnonymous2Int2);
                ClockAdapter.printClockLog("time onClick", localClock);
                ClockAdapter.parseDate(localClock);
                if ((localClock.getMinute() > 9) || (localClock.getMinute() < 0))
                  break label171;
                this.val$time.setText(localClock.getHour() + ":0" + localClock.getMinute());
              }
              while (true)
              {
                LogUtil.d("ClockAdapter", "update time:" + paramAnonymous2Int1 + ":" + paramAnonymous2Int2);
                ClockAdapter.this.sendUpdateCmd(localClock);
                ClockAdapter.this.mFirstTimeForTimeDialog = false;
                return;
                label171: this.val$time.setText(localClock.getHour() + ":" + localClock.getMinute());
              }
            }
          }
          , localCalendar.get(11), localCalendar.get(12), true);
          localTimePickerDialog.setCanceledOnTouchOutside(false);
          localTimePickerDialog.show();
        }
      });
      if (!localClock.isOn())
        break label1129;
      localToggleButton1.setChecked(true);
      localToggleButton1.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          if (localToggleButton1.isChecked())
          {
            ClockAdapter.mOpenClockCount = 1 + ClockAdapter.mOpenClockCount;
            LogUtil.d("ClockAdapter", "open clock count:" + ClockAdapter.mOpenClockCount + ", position:" + paramInt);
            ClockAdapter.parseDate(localClock);
            if (ClockAdapter.mOpenClockCount > 8)
            {
              Toast.makeText(ClockAdapter.this.mContext, ClockAdapter.this.mContext.getString(2131296552), 0).show();
              localToggleButton1.setChecked(false);
              ClockAdapter.mOpenClockCount = -1 + ClockAdapter.mOpenClockCount;
              return;
            }
            localClock.setOn(true);
            LogUtil.d("ClockAdapter", "update switch true");
            ClockAdapter.this.sendUpdateCmd(localClock);
            return;
          }
          ClockAdapter.mOpenClockCount = -1 + ClockAdapter.mOpenClockCount;
          localClock.setOn(false);
          LogUtil.d("ClockAdapter", "update switch false");
          ClockAdapter.this.sendUpdateCmd(localClock);
        }
      });
      LogUtil.d("ClockAdapter", "repeat list count:" + mRepeatCheckedList.size());
      localCheckBox.setChecked(((Boolean)mRepeatCheckedList.get(paramInt)).booleanValue());
      localCheckBox.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          boolean bool = localCheckBox.isChecked();
          LogUtil.d("ClockAdapter", "position:" + paramInt + ", repeat checked:" + bool);
          ClockAdapter.mRepeatCheckedList.set(paramInt, Boolean.valueOf(bool));
          if (bool)
          {
            ClockAdapter.mRepeatCheckedList.set(paramInt, Boolean.valueOf(true));
            localLinearLayout.setVisibility(0);
            localToggleButton2.setVisibility(0);
            localToggleButton3.setVisibility(0);
            localToggleButton4.setVisibility(0);
            localToggleButton5.setVisibility(0);
            localToggleButton6.setVisibility(0);
            localToggleButton7.setVisibility(0);
            localToggleButton8.setVisibility(0);
            Clock localClock2 = (Clock)ClockAdapter.this.mClockList.get(paramInt);
            if (localClock2.isRepeat())
              ClockAdapter.this.setRepeatMode(localClock2);
            return;
          }
          ClockAdapter.mRepeatCheckedList.set(paramInt, Boolean.valueOf(false));
          localLinearLayout.setVisibility(8);
          localToggleButton2.setVisibility(8);
          localToggleButton3.setVisibility(8);
          localToggleButton4.setVisibility(8);
          localToggleButton5.setVisibility(8);
          localToggleButton6.setVisibility(8);
          localToggleButton7.setVisibility(8);
          localToggleButton8.setVisibility(8);
          Clock localClock1 = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          ClockAdapter.this.setOnceMode(localClock1);
          localToggleButton2.setChecked(false);
          localToggleButton3.setChecked(false);
          localToggleButton4.setChecked(false);
          localToggleButton5.setChecked(false);
          localToggleButton6.setChecked(false);
          localToggleButton7.setChecked(false);
          localToggleButton8.setChecked(false);
        }
      });
      localToggleButton2.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          if (localToggleButton2.isChecked())
          {
            localClock.setSun(true);
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          localClock.setSun(false);
          if (localClock.isRepeat())
          {
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          ClockAdapter.this.setOnceMode(localClock);
        }
      });
      localToggleButton3.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          if (localToggleButton3.isChecked())
          {
            localClock.setMon(true);
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          localClock.setMon(false);
          if (localClock.isRepeat())
          {
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          ClockAdapter.this.setOnceMode(localClock);
        }
      });
      localToggleButton4.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          if (localToggleButton4.isChecked())
          {
            localClock.setTue(true);
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          localClock.setTue(false);
          if (localClock.isRepeat())
          {
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          ClockAdapter.this.setOnceMode(localClock);
        }
      });
      localToggleButton5.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          if (localToggleButton5.isChecked())
          {
            localClock.setWed(true);
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          localClock.setWed(false);
          if (localClock.isRepeat())
          {
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          ClockAdapter.this.setOnceMode(localClock);
        }
      });
      localToggleButton6.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          if (localToggleButton6.isChecked())
          {
            localClock.setThu(true);
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          localClock.setThu(false);
          if (localClock.isRepeat())
          {
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          ClockAdapter.this.setOnceMode(localClock);
        }
      });
      localToggleButton7.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          if (localToggleButton7.isChecked())
          {
            localClock.setFri(true);
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          localClock.setFri(false);
          if (localClock.isRepeat())
          {
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          ClockAdapter.this.setOnceMode(localClock);
        }
      });
      localToggleButton8.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          if (localToggleButton8.isChecked())
          {
            localClock.setSat(true);
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          localClock.setSat(false);
          if (localClock.isRepeat())
          {
            ClockAdapter.this.setRepeatMode(localClock);
            return;
          }
          ClockAdapter.this.setOnceMode(localClock);
        }
      });
      str = "";
      if (localClock.isRepeat())
      {
        if (localClock.isSun())
        {
          localToggleButton2.setChecked(true);
          str = str + this.mContext.getString(2131296555) + " ";
        }
        if (localClock.isMon())
        {
          localToggleButton3.setChecked(true);
          str = str + this.mContext.getString(2131296556) + " ";
        }
        if (localClock.isTue())
        {
          localToggleButton4.setChecked(true);
          str = str + this.mContext.getString(2131296557) + " ";
        }
        if (localClock.isWed())
        {
          localToggleButton5.setChecked(true);
          str = str + this.mContext.getString(2131296558) + " ";
        }
        if (localClock.isThu())
        {
          localToggleButton6.setChecked(true);
          str = str + this.mContext.getString(2131296559) + " ";
        }
        if (localClock.isFri())
        {
          localToggleButton7.setChecked(true);
          str = str + this.mContext.getString(2131296560) + " ";
        }
        if (localClock.isSat())
        {
          localToggleButton8.setChecked(true);
          str = str + this.mContext.getString(2131296561) + " ";
        }
        localCheckBox.setChecked(true);
        mRepeatCheckedList.set(paramInt, Boolean.valueOf(true));
      }
      if (((Boolean)mCloseFlagList.get(paramInt)).booleanValue())
        break label1197;
      localImageView1.setBackgroundResource(2130837659);
      localCheckBox.setVisibility(0);
      localRelativeLayout2.setVisibility(0);
      if (!((Boolean)mRepeatCheckedList.get(paramInt)).booleanValue())
        break label1138;
      localLinearLayout.setVisibility(0);
      localToggleButton2.setVisibility(0);
      localToggleButton3.setVisibility(0);
      localToggleButton4.setVisibility(0);
      localToggleButton5.setVisibility(0);
      localToggleButton6.setVisibility(0);
      localToggleButton7.setVisibility(0);
      localToggleButton8.setVisibility(0);
    }
    while (true)
    {
      localRelativeLayout3.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          boolean bool1 = ((Boolean)ClockAdapter.mRepeatCheckedList.get(paramInt)).booleanValue();
          boolean bool2 = ((Boolean)ClockAdapter.mCloseFlagList.get(paramInt)).booleanValue();
          LogUtil.d("ClockAdapter", "isClosed:" + bool2);
          String str;
          if (!bool2)
          {
            localImageView1.setBackgroundResource(2130837626);
            localCheckBox.setVisibility(8);
            localRelativeLayout2.setVisibility(8);
            if (bool1)
            {
              localLinearLayout.setVisibility(8);
              localToggleButton2.setVisibility(8);
              localToggleButton3.setVisibility(8);
              localToggleButton4.setVisibility(8);
              localToggleButton5.setVisibility(8);
              localToggleButton6.setVisibility(8);
              localToggleButton7.setVisibility(8);
              localToggleButton8.setVisibility(8);
            }
            ClockAdapter.mCloseFlagList.set(paramInt, Boolean.valueOf(true));
            if (localClock.isRepeat())
            {
              str = "";
              if (localToggleButton2.isChecked())
                str = str + ClockAdapter.this.mContext.getString(2131296555) + " ";
              if (localToggleButton3.isChecked())
                str = str + ClockAdapter.this.mContext.getString(2131296556) + " ";
              if (localToggleButton4.isChecked())
                str = str + ClockAdapter.this.mContext.getString(2131296557) + " ";
              if (localToggleButton5.isChecked())
                str = str + ClockAdapter.this.mContext.getString(2131296558) + " ";
              if (localToggleButton6.isChecked())
                str = str + ClockAdapter.this.mContext.getString(2131296559) + " ";
              if (localToggleButton7.isChecked())
                str = str + ClockAdapter.this.mContext.getString(2131296560) + " ";
              if (localToggleButton8.isChecked())
                str = str + ClockAdapter.this.mContext.getString(2131296561) + " ";
              if (!localClock.isEveryDay())
                break label601;
              localTextView2.setText(ClockAdapter.this.mContext.getString(2131296562));
            }
          }
          while (true)
          {
            LogUtil.d("ClockAdapter", "position:" + paramInt + ", isChecked:" + bool1 + ", isClose:" + ClockAdapter.mCloseFlagList.get(paramInt));
            return;
            label601: localTextView2.setText(str);
            continue;
            localImageView1.setBackgroundResource(2130837659);
            localRelativeLayout2.setVisibility(0);
            localCheckBox.setVisibility(0);
            if (bool1)
            {
              localLinearLayout.setVisibility(0);
              localToggleButton2.setVisibility(0);
              localToggleButton3.setVisibility(0);
              localToggleButton4.setVisibility(0);
              localToggleButton5.setVisibility(0);
              localToggleButton6.setVisibility(0);
              localToggleButton7.setVisibility(0);
              localToggleButton8.setVisibility(0);
            }
            ClockAdapter.mCloseFlagList.set(paramInt, Boolean.valueOf(false));
            localTextView2.setText("");
          }
        }
      });
      localImageView2.setOnClickListener(new View.OnClickListener()
      {
        public void onClick(View paramAnonymousView)
        {
          Clock localClock = (Clock)ClockAdapter.this.mClockList.get(paramInt);
          ClockAdapter.this.sendDeleteCmd(localClock);
          ClockAdapter.mCloseFlagList.remove(paramInt);
          ClockAdapter.mRepeatCheckedList.remove(paramInt);
        }
      });
      return localRelativeLayout1;
      localTextView1.setText(localClock.getHour() + ":" + localClock.getMinute());
      break;
      label1129: localToggleButton1.setChecked(false);
      break label346;
      label1138: localLinearLayout.setVisibility(8);
      localToggleButton2.setVisibility(8);
      localToggleButton3.setVisibility(8);
      localToggleButton4.setVisibility(8);
      localToggleButton5.setVisibility(8);
      localToggleButton6.setVisibility(8);
      localToggleButton7.setVisibility(8);
      localToggleButton8.setVisibility(8);
    }
    label1197: if (localClock.isEveryDay())
      localTextView2.setText(this.mContext.getString(2131296562));
    while (true)
    {
      localRelativeLayout2.setVisibility(8);
      localLinearLayout.setVisibility(8);
      localToggleButton2.setVisibility(8);
      localToggleButton3.setVisibility(8);
      localToggleButton4.setVisibility(8);
      localToggleButton5.setVisibility(8);
      localToggleButton6.setVisibility(8);
      localToggleButton7.setVisibility(8);
      localToggleButton8.setVisibility(8);
      break;
      localTextView2.setText(str);
    }
  }

  public void increaseClockCount()
  {
    mOpenClockCount = 1 + mOpenClockCount;
  }

  public void sendDeleteCmd(Clock paramClock)
  {
    Message localMessage = new Message();
    localMessage.what = 0;
    Bundle localBundle = new Bundle();
    localBundle.putParcelable("clock", paramClock);
    localMessage.setData(localBundle);
    this.mHandler.sendMessage(localMessage);
  }

  public void sendUpdateCmd(Clock paramClock)
  {
    Message localMessage = new Message();
    localMessage.what = 2;
    Bundle localBundle = new Bundle();
    localBundle.putParcelable("clock", paramClock);
    localMessage.setData(localBundle);
    this.mHandler.sendMessage(localMessage);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.clock.ClockAdapter
 * JD-Core Version:    0.6.2
 */