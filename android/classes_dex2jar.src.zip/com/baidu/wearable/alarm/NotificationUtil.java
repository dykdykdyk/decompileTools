package com.baidu.wearable.alarm;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import com.baidu.wearable.alarm.completion.CompletionRate;
import com.baidu.wearable.ui.activities.FlipActivity;
import java.util.ArrayList;

public class NotificationUtil
{
  private static final Integer COMPLETION_RATE_NOTIFICATION_ID = Integer.valueOf(10001);
  private static final int COMPLETION_RATE_NOTIFICATION_REQUEST_CODE = 12;
  private static final Integer UNUSED_NOTIFICAITON_ID = Integer.valueOf(10000);
  private static ArrayList<Integer> mNotificationIDList = new ArrayList();

  public static void cancelAllNotification(Context paramContext)
  {
    NotificationManager localNotificationManager;
    int i;
    if (mNotificationIDList != null)
    {
      localNotificationManager = (NotificationManager)paramContext.getSystemService("notification");
      i = mNotificationIDList.size();
    }
    for (int j = 0; ; j++)
    {
      if (j >= i)
      {
        mNotificationIDList.clear();
        return;
      }
      localNotificationManager.cancel(((Integer)mNotificationIDList.get(j)).intValue());
    }
  }

  public static void cancelCompletionRateNotification(Context paramContext)
  {
    ((NotificationManager)paramContext.getSystemService("notification")).cancel(COMPLETION_RATE_NOTIFICATION_ID.intValue());
    if (mNotificationIDList.contains(COMPLETION_RATE_NOTIFICATION_ID))
      mNotificationIDList.remove(COMPLETION_RATE_NOTIFICATION_ID);
  }

  public static void cancelUnusedNotification(Context paramContext)
  {
    ((NotificationManager)paramContext.getSystemService("notification")).cancel(UNUSED_NOTIFICAITON_ID.intValue());
    if (mNotificationIDList.contains(UNUSED_NOTIFICAITON_ID))
      mNotificationIDList.remove(UNUSED_NOTIFICAITON_ID);
  }

  public static void showCompletionRateNotification(Context paramContext)
  {
    NotificationManager localNotificationManager = (NotificationManager)paramContext.getSystemService("notification");
    PendingIntent localPendingIntent = PendingIntent.getActivity(paramContext, 12, new Intent(paramContext, FlipActivity.class), 0);
    Notification localNotification = new Notification(2130837702, paramContext.getString(2131296539), System.currentTimeMillis());
    localNotification.setLatestEventInfo(paramContext, paramContext.getString(2131296539), paramContext.getString(2131296540) + CompletionRate.getFinishRateWarnPercent(paramContext) + paramContext.getString(2131296541), localPendingIntent);
    localNotification.flags = (0x10 | localNotification.flags);
    localNotificationManager.notify(COMPLETION_RATE_NOTIFICATION_ID.intValue(), localNotification);
    if (!mNotificationIDList.contains(COMPLETION_RATE_NOTIFICATION_ID))
      mNotificationIDList.add(COMPLETION_RATE_NOTIFICATION_ID);
  }

  public static void showUnusedNotification(Context paramContext, String paramString)
  {
    NotificationManager localNotificationManager = (NotificationManager)paramContext.getSystemService("notification");
    Notification localNotification = new Notification(2130837702, paramString, System.currentTimeMillis());
    localNotification.flags = 16;
    PendingIntent localPendingIntent = PendingIntent.getActivity(paramContext, 0, new Intent(paramContext, FlipActivity.class), 134217728);
    localNotification.setLatestEventInfo(paramContext, paramContext.getString(2131296539), paramString, localPendingIntent);
    localNotificationManager.notify(UNUSED_NOTIFICAITON_ID.intValue(), localNotification);
    if (!mNotificationIDList.contains(UNUSED_NOTIFICAITON_ID))
      mNotificationIDList.add(UNUSED_NOTIFICAITON_ID);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.NotificationUtil
 * JD-Core Version:    0.6.2
 */