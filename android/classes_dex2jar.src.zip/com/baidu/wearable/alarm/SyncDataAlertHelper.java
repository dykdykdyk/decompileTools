package com.baidu.wearable.alarm;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Window;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.ui.activities.FlipActivity;
import java.util.Calendar;

public class SyncDataAlertHelper
{
  private static final String SYNC_DATE_KEY = "sync_date";
  private static final String SYNC_PREFERENCES_INFO = "sync_preferences_info";
  private static final String SYNC_STATE_KEY = "sync_state";
  private static final String TAG = "HandringSyncDataHelper";
  private static final int UNUSED_LIMIT = 30;
  private Context mContext;
  private SharedPreferences.Editor mEditor;
  private SharedPreferences mPreferences;
  private String mUid;

  public SyncDataAlertHelper(Context paramContext)
  {
    this.mContext = paramContext;
  }

  private long getDaysInterval()
  {
    long l1 = getLastSyncDate();
    long l2 = 0L;
    Calendar localCalendar2;
    Calendar localCalendar3;
    if (l1 > 0L)
    {
      Calendar localCalendar1 = Calendar.getInstance();
      localCalendar1.setTimeInMillis(l1);
      localCalendar2 = (Calendar)localCalendar1.clone();
      localCalendar2.setTimeInMillis(System.currentTimeMillis());
      localCalendar3 = (Calendar)localCalendar1.clone();
    }
    while (true)
    {
      if (!localCalendar3.before(localCalendar2))
        return l2;
      localCalendar3.add(5, 1);
      l2 += 1L;
    }
  }

  private long getLastSyncDate()
  {
    if (this.mPreferences == null)
    {
      this.mUid = BDAccountManager.getInstance().getUserData("uid");
      this.mPreferences = this.mContext.getSharedPreferences("sync_preferences_info" + this.mUid, 0);
    }
    return this.mPreferences.getLong("sync_date", 0L);
  }

  private boolean isDialogAlerted()
  {
    if (this.mPreferences == null)
    {
      this.mUid = BDAccountManager.getInstance().getUserData("uid");
      this.mPreferences = this.mContext.getSharedPreferences("sync_preferences_info" + this.mUid, 0);
    }
    return this.mPreferences.getBoolean("sync_state", false);
  }

  private void setDialogAlerted()
  {
    if (this.mPreferences == null)
    {
      this.mUid = BDAccountManager.getInstance().getUserData("uid");
      this.mPreferences = this.mContext.getSharedPreferences("sync_preferences_info" + this.mUid, 0);
    }
    this.mEditor = this.mPreferences.edit();
    this.mEditor.putBoolean("sync_state", true).commit();
  }

  private void showDialog()
  {
    NotificationUtil.cancelUnusedNotification(this.mContext);
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(this.mContext);
    localBuilder.setTitle(2131296537).setMessage(2131296536);
    localBuilder.setNeutralButton(2131296538, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        SyncDataAlertHelper.this.mContext.startActivity(new Intent(SyncDataAlertHelper.this.mContext, FlipActivity.class).setFlags(268435456));
      }
    });
    AlertDialog localAlertDialog = localBuilder.create();
    localAlertDialog.setCanceledOnTouchOutside(false);
    localAlertDialog.getWindow().setType(2003);
    localAlertDialog.show();
  }

  public boolean saveSyncDate(long paramLong)
  {
    this.mUid = BDAccountManager.getInstance().getUserData("uid");
    this.mPreferences = this.mContext.getSharedPreferences("sync_preferences_info" + this.mUid, 0);
    this.mEditor = this.mPreferences.edit();
    return this.mEditor.putLong("sync_date", paramLong).commit();
  }

  public void showUnusedAlert()
  {
    long l = getDaysInterval();
    LogUtil.d("HandringSyncDataHelper", "闂撮殧 " + l + " 澶╂病鏈夎繘琛屽悓姝ヤ簡");
    if ((l > 4L) && (l < 21L))
      if (l % 5L == 0L)
      {
        Context localContext = this.mContext;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Long.valueOf(l);
        String str2 = localContext.getString(2131296534, arrayOfObject);
        NotificationUtil.showUnusedNotification(this.mContext, str2);
      }
    do
    {
      do
      {
        return;
        if ((l < 21L) || (l >= 30L))
          break;
      }
      while ((l - 20L) % 3L != 0L);
      String str1 = this.mContext.getString(2131296535);
      NotificationUtil.showUnusedNotification(this.mContext, str1);
      return;
    }
    while ((l < 30L) || (isDialogAlerted()));
    setDialogAlerted();
    showDialog();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.SyncDataAlertHelper
 * JD-Core Version:    0.6.2
 */