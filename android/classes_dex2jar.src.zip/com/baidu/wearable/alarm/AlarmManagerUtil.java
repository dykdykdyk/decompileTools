package com.baidu.wearable.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import com.baidu.wearable.alarm.completion.CompletionRateAlarmTime;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.services.WearableService;
import java.util.Calendar;

public class AlarmManagerUtil
{
  private static int COMPLETION_RATE_ALARM_ID = 0;
  private static int NET_ALARM_ID = 0;
  private static int SENSOR_SERVICE_ALARM_ID = 0;
  private static final String TAG = "AlarmManagerUtil";

  public static void startCompletionRateAlarm(Context paramContext)
  {
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, COMPLETION_RATE_ALARM_ID, new Intent("com.baidu.wearable.ACTION_COMPLETION_RECEIVE"), 0);
    localAlarmManager.cancel(localPendingIntent);
    AlarmPreference localAlarmPreference = AlarmPreference.getInstance(paramContext);
    int i = localAlarmPreference.getCompletionRateTime().hour;
    int j = localAlarmPreference.getCompletionRateTime().minute;
    Calendar localCalendar = Calendar.getInstance();
    long l = localCalendar.getTimeInMillis();
    localCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), i, j, 0);
    if (l > localCalendar.getTimeInMillis())
    {
      localCalendar.set(6, 1 + localCalendar.get(6));
      localCalendar.set(11, i);
      localCalendar.set(12, j);
      localCalendar.set(13, 0);
    }
    LogUtil.d("AlarmManagerUtil", "time:" + localCalendar.getTimeInMillis());
    localAlarmManager.setRepeating(0, localCalendar.getTimeInMillis(), 86400000L, localPendingIntent);
  }

  public static void startNetAlarm(Context paramContext)
  {
    LogUtil.d("AlarmManagerUtil", "startNetAlarm");
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, NET_ALARM_ID, new Intent("action.wearable.start.net.command"), 0);
    localAlarmManager.cancel(localPendingIntent);
    localAlarmManager.setRepeating(2, SystemClock.elapsedRealtime(), 900000L, localPendingIntent);
  }

  public static void startServiceAlarm(Context paramContext)
  {
    LogUtil.d("AlarmManagerUtil", "startServiceAlarm");
    AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
    PendingIntent localPendingIntent = PendingIntent.getService(paramContext, SENSOR_SERVICE_ALARM_ID, new Intent(paramContext, WearableService.class), 0);
    localAlarmManager.cancel(localPendingIntent);
    localAlarmManager.setRepeating(2, SystemClock.elapsedRealtime(), 900000L, localPendingIntent);
  }

  public static void stopAllAlarm(Context paramContext)
  {
    stopServiceAlarm(paramContext);
    stopCompletionRateAlarm(paramContext);
    stopNetAlarm(paramContext);
  }

  public static void stopCompletionRateAlarm(Context paramContext)
  {
    ((AlarmManager)paramContext.getSystemService("alarm")).cancel(PendingIntent.getBroadcast(paramContext, COMPLETION_RATE_ALARM_ID, new Intent("com.baidu.wearable.ACTION_COMPLETION_RECEIVE"), 0));
  }

  public static void stopNetAlarm(Context paramContext)
  {
    LogUtil.d("AlarmManagerUtil", "stopNetAlarm");
    ((AlarmManager)paramContext.getSystemService("alarm")).cancel(PendingIntent.getBroadcast(paramContext, NET_ALARM_ID, new Intent("action.wearable.start.net.command"), 0));
  }

  public static void stopServiceAlarm(Context paramContext)
  {
    LogUtil.d("AlarmManagerUtil", "stopServiceAlarm");
    ((AlarmManager)paramContext.getSystemService("alarm")).cancel(PendingIntent.getService(paramContext, SENSOR_SERVICE_ALARM_ID, new Intent(paramContext, WearableService.class), 0));
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.AlarmManagerUtil
 * JD-Core Version:    0.6.2
 */