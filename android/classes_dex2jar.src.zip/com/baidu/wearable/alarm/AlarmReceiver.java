package com.baidu.wearable.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver
{
  public static final String ALARM_SYNC_DATE_ACTION = "com.baidu.wearable.alarm_sync_date_action";
  private static final String TAG = "AlarmReceiver";
  private Context mContext;

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    if (paramIntent == null);
    while (paramIntent.getAction() == null)
      return;
    this.mContext = paramContext;
    new SyncDataAlertHelper(paramContext).showUnusedAlert();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.AlarmReceiver
 * JD-Core Version:    0.6.2
 */