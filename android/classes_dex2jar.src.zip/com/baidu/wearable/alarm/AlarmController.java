package com.baidu.wearable.alarm;

import android.content.Context;
import com.baidu.wearable.alarm.completion.CompletionRateAlarmTime;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.net.CompletionRateTransport;
import com.baidu.wearable.net.Transport.CommonResult;
import com.baidu.wearable.preference.AlarmPreference;

public class AlarmController
{
  private static final String TAG = "AlarmController";

  public static boolean sendAlarmToNetAndUpdateDbSync(Context paramContext)
  {
    CompletionRateTransport localCompletionRateTransport = CompletionRateTransport.getInstance(paramContext);
    AlarmPreference localAlarmPreference = AlarmPreference.getInstance(paramContext);
    if (localCompletionRateTransport.updateCompletionRateAlarmSync(localAlarmPreference.getCompletionRateTime().hour, localAlarmPreference.getCompletionRateTime().minute, localAlarmPreference.getCompletionRateSwitch()).errCode == 0)
    {
      LogUtil.d("AlarmController", "update completion rate to net success.");
      return true;
    }
    LogUtil.d("AlarmController", "update completion rate to net failure.");
    return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.AlarmController
 * JD-Core Version:    0.6.2
 */