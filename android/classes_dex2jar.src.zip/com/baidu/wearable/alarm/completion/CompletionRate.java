package com.baidu.wearable.alarm.completion;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SportDao;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.sport.SportSummary;
import com.baidu.wearable.util.TimeUtil;
import java.util.Iterator;
import java.util.List;

public class CompletionRate
{
  private static final String TAG = "WarnManagerHelper";

  public static int getFinishRateWarnPercent(Context paramContext)
  {
    long l = PlanPreference.getInstance(paramContext).getTargetStep();
    LogUtil.d("WarnManagerHelper", "planStep:" + l);
    SQLiteDatabase localSQLiteDatabase = Database.getDb(paramContext);
    int i = 0;
    Iterator localIterator = SportDao.selectSportSummary(localSQLiteDatabase, TimeUtil.getDayStart() / 1000L).iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        LogUtil.d("WarnManagerHelper", "actualStep:" + i);
        return (int)(i * 100 / l);
      }
      i = ((SportSummary)localIterator.next()).getSteps();
    }
  }

  public static boolean isOn(Context paramContext)
  {
    AlarmPreference localAlarmPreference = AlarmPreference.getInstance(paramContext);
    return (BDAccountManager.getInstance().isLogin()) && (localAlarmPreference.getCompletionRateSwitch());
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.completion.CompletionRate
 * JD-Core Version:    0.6.2
 */