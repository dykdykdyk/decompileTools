package com.baidu.wearable.alarm.completion;

public class CompletionIntent
{
  public static final String ACTION_COMPLETION_RECEIVE_INTENT = "com.baidu.wearable.ACTION_COMPLETION_RECEIVE";
  public static final String ACTION_UPDATE_WARN_ACTIVITY_INTENT = "com.baidu.wearable.ACTION_UPDATE_WARN_ACTIVITY";
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.completion.CompletionIntent
 * JD-Core Version:    0.6.2
 */