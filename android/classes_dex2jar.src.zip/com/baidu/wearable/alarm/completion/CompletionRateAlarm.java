package com.baidu.wearable.alarm.completion;

public class CompletionRateAlarm
{
  public static final String DEFAULT_TIME = "22:0";
  public static final String HOUR = "warn_finish_rate_hour";
  public static final String MINUTE = "warn_finish_rate_minute";
  public static final String SWITCH = "warn_finish_rate_switch";
  public static final String TIME = "warn_finish_rate_time";
  public boolean onOrOff = true;
  public CompletionRateAlarmTime time = new CompletionRateAlarmTime();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.completion.CompletionRateAlarm
 * JD-Core Version:    0.6.2
 */