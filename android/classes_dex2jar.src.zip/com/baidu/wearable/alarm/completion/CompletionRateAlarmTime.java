package com.baidu.wearable.alarm.completion;

public class CompletionRateAlarmTime
{
  public int hour;
  public int minute;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.alarm.completion.CompletionRateAlarmTime
 * JD-Core Version:    0.6.2
 */