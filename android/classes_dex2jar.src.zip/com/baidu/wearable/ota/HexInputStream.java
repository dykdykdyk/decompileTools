package com.baidu.wearable.ota;

import com.baidu.wearable.ble.util.LogUtil;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class HexInputStream extends FilterInputStream
{
  private static final String TAG = "HexInputStream";
  private final int LINE_LENGTH = 16;
  private final byte[] localBuf = new byte[16];
  private int localPos = 16;
  private boolean mIsHex = false;
  private int pack_size = -1;
  private int pos = 0;
  private int real_size = -1;

  protected HexInputStream(String paramString)
    throws FileNotFoundException
  {
    super(new FileInputStream(paramString));
    if (paramString.endsWith(".hex"))
    {
      LogUtil.d("HexInputStream", "is hex file");
      this.mIsHex = true;
      return;
    }
    LogUtil.d("HexInputStream", "is bin file");
    this.mIsHex = false;
  }

  private int asciiToInt(int paramInt)
  {
    if (paramInt >= 65)
      return paramInt - 55;
    if (paramInt >= 48)
      return paramInt - 48;
    return -1;
  }

  private void checkComma(int paramInt)
    throws IOException
  {
    if (paramInt != 58)
      throw new IOException("Not a HEX file");
  }

  private int readBuffer()
    throws IOException
  {
    if (this.mIsHex)
    {
      if (this.pos == -1)
        return 0;
      if (this.pos == 0)
        this.pos = ((int)(this.pos + this.in.skip(15L)));
      int k;
      do
      {
        k = this.in.read();
        this.pos = (1 + this.pos);
      }
      while ((k == 10) || (k == 13));
      checkComma(k);
      int m = readByte();
      this.pos = (2 + this.pos);
      this.pos = ((int)(this.pos + this.in.skip(4L)));
      int n = readByte();
      this.pos = (2 + this.pos);
      if (n != 0)
      {
        this.pos = -1;
        return 0;
      }
      for (int i1 = 0; ; i1++)
      {
        if ((i1 >= this.localBuf.length) || (i1 >= m))
        {
          this.pos = ((int)(this.pos + this.in.skip(2L)));
          this.localPos = 0;
          return m;
        }
        int i2 = readByte();
        this.pos = (2 + this.pos);
        this.localBuf[i1] = ((byte)i2);
      }
    }
    for (int i = 0; ; i++)
    {
      if ((i >= this.localBuf.length) || (this.in.available() <= 0))
      {
        this.localPos = 0;
        LogUtil.d("HexInputStream", "pos:" + this.pos);
        return i;
      }
      int j = this.in.read();
      this.pos = (1 + this.pos);
      this.localBuf[i] = ((byte)j);
    }
  }

  private int readByte()
    throws IOException
  {
    int i = asciiToInt(this.in.read());
    return asciiToInt(this.in.read()) | i << 4;
  }

  public int available()
    throws IOException
  {
    int i1;
    if (this.mIsHex)
    {
      int j = -34 + (-17 + this.in.available());
      int k = j / 45;
      int m = j % 45;
      int n = k * 32;
      if (m > 0)
      {
        i1 = m - 13;
        this.real_size = ((i1 + n) / 2);
        if (this.real_size % 4 != 0)
          this.pack_size = (4 + (this.real_size - this.real_size % 4));
      }
    }
    while (true)
    {
      LogUtil.d("HexInputStream", "real_size:" + this.real_size + " pack_size:" + this.pack_size);
      return this.pack_size;
      i1 = 0;
      break;
      int i = this.in.available();
      this.pack_size = i;
      this.real_size = i;
    }
  }

  public int read()
    throws IOException
  {
    throw new UnsupportedOperationException("Please, use readPacket() method instead");
  }

  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return readPacket(paramArrayOfByte);
  }

  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    throw new UnsupportedOperationException("Please, use readPacket() method instead");
  }

  public int readPacket(byte[] paramArrayOfByte)
    throws IOException
  {
    int i = 0;
    int j = this.localBuf.length;
    do
    {
      while (true)
      {
        if (i >= paramArrayOfByte.length)
          return i;
        if (this.localPos >= j)
          break;
        int k = i + 1;
        byte[] arrayOfByte = this.localBuf;
        int m = this.localPos;
        this.localPos = (m + 1);
        paramArrayOfByte[i] = arrayOfByte[m];
        i = k;
      }
      j = readBuffer();
    }
    while (j != 0);
    return i;
  }

  public void reset()
    throws IOException
  {
    try
    {
      super.reset();
      this.pos = 0;
      this.localPos = 0;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ota.HexInputStream
 * JD-Core Version:    0.6.2
 */