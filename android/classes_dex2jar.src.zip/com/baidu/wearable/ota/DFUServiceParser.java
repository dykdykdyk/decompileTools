package com.baidu.wearable.ota;

public class DFUServiceParser
{
  private static DFUServiceParser mParserInstance;
  private final String DFU_SERVICE_UUID = "2148";
  private final int SERVICE_CLASS_128BIT_UUID = 6;
  private final String TAG = "DFUServiceParser";
  private boolean isValidDFUSensor = false;
  private int packetLength = 0;

  private void decodeService128BitUUID(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws Exception
  {
    DFUManager.log("DFUServiceParser", "StartPosition: " + paramInt1 + " Data length: " + paramInt2);
    String str = Byte.toString(paramArrayOfByte[(-3 + (paramInt1 + paramInt2))]) + Byte.toString(paramArrayOfByte[(-4 + (paramInt1 + paramInt2))]);
    if (str.equals("2148"))
    {
      DFUManager.log("DFUServiceParser", "Service UUID: " + str);
      DFUManager.log("DFUServiceParser", "DFU service exist!");
      this.isValidDFUSensor = true;
    }
  }

  public static DFUServiceParser getDFUParser()
  {
    try
    {
      if (mParserInstance == null)
        mParserInstance = new DFUServiceParser();
      DFUServiceParser localDFUServiceParser = mParserInstance;
      return localDFUServiceParser;
    }
    finally
    {
    }
  }

  public void decodeDFUAdvData(byte[] paramArrayOfByte)
    throws Exception
  {
    this.isValidDFUSensor = false;
    if (paramArrayOfByte != null)
    {
      this.packetLength = paramArrayOfByte.length;
      int i = 0;
      if (i >= this.packetLength)
        return;
      int j = paramArrayOfByte[i];
      if (j == 0)
      {
        DFUManager.log("DFUServiceParser", "index: " + i + " No more data exist in Advertisement packet");
        return;
      }
      int k = i + 1;
      int m = paramArrayOfByte[k];
      DFUManager.log("DFUServiceParser", "fieldName: " + m + " Filed Length: " + j);
      if (m == 6)
      {
        DFUManager.log("DFUServiceParser", "index: " + k + " Service class 128 bit UUID exist");
        decodeService128BitUUID(paramArrayOfByte, k + 1, j - 1);
      }
      for (int n = k + (j - 1); ; n = k + (j - 1))
      {
        i = n + 1;
        break;
      }
    }
    DFUManager.log("DFUServiceParser", "data is null!");
  }

  public boolean isValidDFUSensor()
  {
    return this.isValidDFUSensor;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ota.DFUServiceParser
 * JD-Core Version:    0.6.2
 */