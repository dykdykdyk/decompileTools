package com.baidu.wearable.ota;

public abstract interface DFUManagerCallbacks
{
  public abstract void onDFUServiceFound();

  public abstract void onDeviceConnected();

  public abstract void onDeviceDisconnected();

  public abstract void onDeviceFound();

  public abstract void onError(String paramString, int paramInt);

  public abstract void onFileTranfering(long paramLong);

  public abstract void onFileTransferCompleted();

  public abstract void onFileTransferStarted();

  public abstract void onFileTransferValidation();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ota.DFUManagerCallbacks
 * JD-Core Version:    0.6.2
 */