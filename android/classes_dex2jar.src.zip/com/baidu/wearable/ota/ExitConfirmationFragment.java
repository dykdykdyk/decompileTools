package com.baidu.wearable.ota;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;

public class ExitConfirmationFragment extends DialogFragment
{
  private static DFUManager mDFUManager;
  private Context mContext = null;
  private AlertDialog mDialog = null;

  public static ExitConfirmationFragment getInstance(Context paramContext, DFUManager paramDFUManager)
  {
    ExitConfirmationFragment localExitConfirmationFragment = new ExitConfirmationFragment();
    mDFUManager = paramDFUManager;
    localExitConfirmationFragment.setConetxt(paramContext);
    return localExitConfirmationFragment;
  }

  public Dialog onCreateDialog(Bundle paramBundle)
  {
    this.mDialog = new AlertDialog.Builder(getActivity()).setTitle(2131296696).setMessage(2131296697).setPositiveButton(2131296698, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        ExitConfirmationFragment.mDFUManager.systemReset();
        DFUVersionManager.getInstance(ExitConfirmationFragment.this.mContext).NotifyNextTime();
        try
        {
          Thread.sleep(1000L);
          label25: ExitConfirmationFragment.mDFUManager.close();
          ExitConfirmationFragment.mDFUManager = null;
          ExitConfirmationFragment.this.getActivity().finish();
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          break label25;
        }
      }
    }).setNegativeButton(2131296699, null).create();
    this.mDialog.setCanceledOnTouchOutside(false);
    return this.mDialog;
  }

  public void setConetxt(Context paramContext)
  {
    this.mContext = paramContext;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ota.ExitConfirmationFragment
 * JD-Core Version:    0.6.2
 */