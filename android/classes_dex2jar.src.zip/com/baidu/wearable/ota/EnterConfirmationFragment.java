package com.baidu.wearable.ota;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.ui.activities.DfuActivity;

public class EnterConfirmationFragment extends DialogFragment
{
  private static final String TAG = "EnterConfirmationFragment";
  private EnterConfirmationFragmentCallbacks mCallback = null;
  private Context mContext = null;
  private String mDeviceAddress = null;
  private AlertDialog mDialog = null;

  public static EnterConfirmationFragment getInstance(Context paramContext, String paramString, EnterConfirmationFragmentCallbacks paramEnterConfirmationFragmentCallbacks)
  {
    EnterConfirmationFragment localEnterConfirmationFragment = new EnterConfirmationFragment();
    localEnterConfirmationFragment.setDeviceAddress(paramString);
    localEnterConfirmationFragment.setConetxt(paramContext);
    localEnterConfirmationFragment.setCallback(paramEnterConfirmationFragmentCallbacks);
    return localEnterConfirmationFragment;
  }

  public void onCancel(DialogInterface paramDialogInterface)
  {
    LogUtil.d("EnterConfirmationFragment", "onCancel");
    DFUVersionManager.getInstance(this.mContext).NotifyNextTime();
  }

  public Dialog onCreateDialog(Bundle paramBundle)
  {
    this.mDialog = new AlertDialog.Builder(getActivity()).setTitle(2131296683).setMessage(2131296684).setCancelable(false).setPositiveButton(2131296686, new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        EnterConfirmationFragment.this.startDfuActivity();
      }
    }).create();
    this.mDialog.setCanceledOnTouchOutside(false);
    this.mDialog.setOnKeyListener(new DialogInterface.OnKeyListener()
    {
      public boolean onKey(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt, KeyEvent paramAnonymousKeyEvent)
      {
        return paramAnonymousKeyEvent.getKeyCode() == 4;
      }
    });
    return this.mDialog;
  }

  public void onDestroy()
  {
    super.onDestroy();
    if (this.mCallback != null)
      this.mCallback.onDestory();
  }

  public void setCallback(EnterConfirmationFragmentCallbacks paramEnterConfirmationFragmentCallbacks)
  {
    this.mCallback = paramEnterConfirmationFragmentCallbacks;
    LogUtil.d("EnterConfirmationFragment", "setCallback");
  }

  public void setConetxt(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public void setDeviceAddress(String paramString)
  {
    this.mDeviceAddress = paramString;
    LogUtil.d("EnterConfirmationFragment", "device address:" + this.mDeviceAddress);
  }

  public void startDfuActivity()
  {
    Intent localIntent = new Intent(this.mContext, DfuActivity.class);
    localIntent.putExtra("device_address_extra", this.mDeviceAddress);
    this.mContext.startActivity(localIntent);
  }

  public static abstract interface EnterConfirmationFragmentCallbacks
  {
    public abstract void onDestory();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ota.EnterConfirmationFragment
 * JD-Core Version:    0.6.2
 */