package com.baidu.wearable.ota;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.WearableApplication;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.net.RomUpdateTransport;
import com.baidu.wearable.net.RomUpdateTransport.RomUpdateResult;
import java.io.File;

public class DFUVersionManager
{
  public static final int DEVICE_IN_DEV_MODE_TRIGGER_CLICK_COUNT = 20;
  public static final String DFU_APP = "app";
  public static final String DFU_BUILD_TYPE = "build";
  public static final String DFU_BUILD_TYPE_DEV = "dev";
  public static final String DFU_CHANGE_LOG = "change_log";
  public static final String DFU_CHANNEL_ID = "channel_id";
  public static final String DFU_HW_VERSION = "hw_version";
  public static final String DFU_MANUFACTORY = "manufacturer";
  public static final String DFU_MODEL_NAME = "model_name";
  private static final int DFU_NOTIFY_TIME_INTERVAL = 86400000;
  public static final String DFU_OS = "os";
  public static final String DFU_OS_TYPE = "type";
  public static final String DFU_ROM_FILE_CRC16 = "rom_file_crc16";
  public static final String DFU_ROM_FILE_URL = "rom_url";
  public static final String DFU_ROM_UPDATE = "rom_update";
  public static final String DFU_SDK_VERSION = "sdk_version";
  public static final String DFU_SW_VERSION = "sw_version";
  public static final String DFU_VERSION = "version";
  public static final String KEY_DFU_DEVICE_HW_VERSION = "dfu_device_hw_version_key";
  public static final String KEY_DFU_DEVICE_IN_DEV_MODE = "dfu_device_in_dev_mode_key";
  public static final String KEY_DFU_DEVICE_MANUFACTORY = "dfu_device_manufactory_key";
  public static final String KEY_DFU_DEVICE_MODEL_NAME = "dfu_device_model_name";
  public static final String KEY_DFU_DEVICE_SW_VERSION = "dfu_device_sw_version_key";
  public static final String KEY_DFU_IGNORE_VERSION = "dfu_ignore_version_key";
  public static final String KEY_DFU_NOTIFY_TIME = "dfu_notify_time_key";
  public static final String KEY_DFU_SERVER_CHANGE_LOG = "dfu_server_change_log_key";
  public static final String KEY_DFU_SERVER_HW_VERSION = "dfu_server_hw_version_key";
  public static final String KEY_DFU_SERVER_MANUFACTORY = "dfu_server_manufactory_key";
  public static final String KEY_DFU_SERVER_MODEL_NAME = "dfu_server_model_name_key";
  public static final String KEY_DFU_SERVER_ROM_FILE_PATH = "dfu_server_rom_file_path";
  public static final String KEY_DFU_SERVER_SW_VERSION = "dfu_server_sw_version_key";
  public static final String METHOD_GET_ROM_UPDATE = "update";
  private static final long NOTIFY_TIME_NO_VALID_VALUE = -86400000L;
  private static final String ROM_FILE_DIR = "rom-update/";
  private static final String STRING_INVALID_VALUE = null;
  private static final String TAG = "DFUVersionManager";
  private static DFUVersionManager mInstance = null;
  private static String mUid = null;
  private Context mContext = null;
  private String mDeviceHWVersion = STRING_INVALID_VALUE;
  private String mDeviceManufactory = STRING_INVALID_VALUE;
  private String mDeviceModelName = STRING_INVALID_VALUE;
  private String mDeviceSWVersion = STRING_INVALID_VALUE;
  private SharedPreferences.Editor mEditor = null;
  private String mIgnoreVersion = STRING_INVALID_VALUE;
  private boolean mIsInDevMode = false;
  private long mNotifyTimer = -86400000L;
  private SharedPreferences mPreferences;
  private String mServerChangeLog = STRING_INVALID_VALUE;
  private String mServerHWVersion = STRING_INVALID_VALUE;
  private String mServerManufactory = STRING_INVALID_VALUE;
  private String mServerModelName = STRING_INVALID_VALUE;
  private String mServerRomFilePath = STRING_INVALID_VALUE;
  private String mServerSWVersion = STRING_INVALID_VALUE;

  private DFUVersionManager(Context paramContext)
  {
    LogUtil.d("DFUVersionManager", "DFUVersionManager");
    this.mContext = paramContext;
    this.mPreferences = paramContext.getSharedPreferences("target_info_" + mUid, 0);
    this.mEditor = this.mPreferences.edit();
  }

  // ERROR //
  private int DownloadRomFromUrl(String paramString1, int paramInt, String paramString2)
  {
    // Byte code:
    //   0: lconst_0
    //   1: lstore 4
    //   3: aconst_null
    //   4: astore 6
    //   6: aconst_null
    //   7: astore 7
    //   9: aconst_null
    //   10: astore 8
    //   12: ldc 111
    //   14: new 184	java/lang/StringBuilder
    //   17: dup
    //   18: ldc 219
    //   20: invokespecial 189	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   23: aload_1
    //   24: invokevirtual 193	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   27: invokevirtual 197	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   30: invokestatic 182	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   33: new 221	java/net/URL
    //   36: dup
    //   37: aload_1
    //   38: invokespecial 222	java/net/URL:<init>	(Ljava/lang/String;)V
    //   41: invokevirtual 226	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   44: checkcast 228	java/net/HttpURLConnection
    //   47: astore 8
    //   49: aload 8
    //   51: invokevirtual 231	java/net/HttpURLConnection:connect	()V
    //   54: aload 8
    //   56: invokevirtual 235	java/net/HttpURLConnection:getResponseCode	()I
    //   59: sipush 200
    //   62: if_icmpeq +69 -> 131
    //   65: ldc 111
    //   67: new 184	java/lang/StringBuilder
    //   70: dup
    //   71: ldc 237
    //   73: invokespecial 189	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   76: aload 8
    //   78: invokevirtual 235	java/net/HttpURLConnection:getResponseCode	()I
    //   81: invokevirtual 240	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   84: ldc 242
    //   86: invokevirtual 193	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: aload 8
    //   91: invokevirtual 245	java/net/HttpURLConnection:getResponseMessage	()Ljava/lang/String;
    //   94: invokevirtual 193	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: invokevirtual 197	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   100: invokestatic 248	com/baidu/wearable/ble/util/LogUtil:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   103: iconst_0
    //   104: ifeq +7 -> 111
    //   107: aconst_null
    //   108: invokevirtual 253	java/io/OutputStream:close	()V
    //   111: iconst_0
    //   112: ifeq +7 -> 119
    //   115: aconst_null
    //   116: invokevirtual 256	java/io/InputStream:close	()V
    //   119: aload 8
    //   121: ifnull +8 -> 129
    //   124: aload 8
    //   126: invokevirtual 259	java/net/HttpURLConnection:disconnect	()V
    //   129: iconst_m1
    //   130: ireturn
    //   131: aload 8
    //   133: invokevirtual 263	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   136: astore 6
    //   138: new 265	java/io/FileOutputStream
    //   141: dup
    //   142: aload_3
    //   143: invokespecial 266	java/io/FileOutputStream:<init>	(Ljava/lang/String;)V
    //   146: astore 13
    //   148: sipush 4096
    //   151: newarray byte
    //   153: astore 14
    //   155: aload 6
    //   157: aload 14
    //   159: invokevirtual 270	java/io/InputStream:read	([B)I
    //   162: istore 15
    //   164: iload 15
    //   166: iconst_m1
    //   167: if_icmpne +111 -> 278
    //   170: aload 13
    //   172: ifnull +8 -> 180
    //   175: aload 13
    //   177: invokevirtual 253	java/io/OutputStream:close	()V
    //   180: aload 6
    //   182: ifnull +8 -> 190
    //   185: aload 6
    //   187: invokevirtual 256	java/io/InputStream:close	()V
    //   190: aload 8
    //   192: ifnull +8 -> 200
    //   195: aload 8
    //   197: invokevirtual 259	java/net/HttpURLConnection:disconnect	()V
    //   200: ldc 111
    //   202: new 184	java/lang/StringBuilder
    //   205: dup
    //   206: ldc_w 272
    //   209: invokespecial 189	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   212: lload 4
    //   214: invokevirtual 275	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   217: invokevirtual 197	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   220: invokestatic 182	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   223: aload_0
    //   224: iload_2
    //   225: aload_3
    //   226: invokespecial 279	com/baidu/wearable/ota/DFUVersionManager:checkCRC16	(ILjava/lang/String;)Z
    //   229: ifne +169 -> 398
    //   232: ldc 111
    //   234: new 184	java/lang/StringBuilder
    //   237: dup
    //   238: ldc_w 281
    //   241: invokespecial 189	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   244: aload_3
    //   245: invokevirtual 193	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   248: ldc_w 283
    //   251: invokevirtual 193	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   254: iload_2
    //   255: invokevirtual 240	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   258: invokevirtual 197	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   261: invokestatic 248	com/baidu/wearable/ble/util/LogUtil:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   264: new 285	java/io/File
    //   267: dup
    //   268: aload_3
    //   269: invokespecial 286	java/io/File:<init>	(Ljava/lang/String;)V
    //   272: invokevirtual 290	java/io/File:delete	()Z
    //   275: pop
    //   276: iconst_m1
    //   277: ireturn
    //   278: lload 4
    //   280: iload 15
    //   282: i2l
    //   283: ladd
    //   284: lstore 4
    //   286: aload 13
    //   288: aload 14
    //   290: iconst_0
    //   291: iload 15
    //   293: invokevirtual 294	java/io/OutputStream:write	([BII)V
    //   296: goto -141 -> 155
    //   299: astore 9
    //   301: aload 13
    //   303: astore 7
    //   305: ldc 111
    //   307: new 184	java/lang/StringBuilder
    //   310: dup
    //   311: ldc_w 296
    //   314: invokespecial 189	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   317: aload 9
    //   319: invokevirtual 297	java/lang/Exception:toString	()Ljava/lang/String;
    //   322: invokevirtual 193	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: invokevirtual 197	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   328: invokestatic 182	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   331: aload 7
    //   333: ifnull +8 -> 341
    //   336: aload 7
    //   338: invokevirtual 253	java/io/OutputStream:close	()V
    //   341: aload 6
    //   343: ifnull +8 -> 351
    //   346: aload 6
    //   348: invokevirtual 256	java/io/InputStream:close	()V
    //   351: aload 8
    //   353: ifnull +8 -> 361
    //   356: aload 8
    //   358: invokevirtual 259	java/net/HttpURLConnection:disconnect	()V
    //   361: iconst_m1
    //   362: ireturn
    //   363: astore 10
    //   365: aload 7
    //   367: ifnull +8 -> 375
    //   370: aload 7
    //   372: invokevirtual 253	java/io/OutputStream:close	()V
    //   375: aload 6
    //   377: ifnull +8 -> 385
    //   380: aload 6
    //   382: invokevirtual 256	java/io/InputStream:close	()V
    //   385: aload 8
    //   387: ifnull +8 -> 395
    //   390: aload 8
    //   392: invokevirtual 259	java/net/HttpURLConnection:disconnect	()V
    //   395: aload 10
    //   397: athrow
    //   398: iconst_0
    //   399: ireturn
    //   400: astore 16
    //   402: goto -212 -> 190
    //   405: astore 11
    //   407: goto -22 -> 385
    //   410: astore 10
    //   412: aload 13
    //   414: astore 7
    //   416: goto -51 -> 365
    //   419: astore 12
    //   421: goto -70 -> 351
    //   424: astore 9
    //   426: aconst_null
    //   427: astore 7
    //   429: goto -124 -> 305
    //   432: astore 18
    //   434: goto -315 -> 119
    //
    // Exception table:
    //   from	to	target	type
    //   148	155	299	java/lang/Exception
    //   155	164	299	java/lang/Exception
    //   286	296	299	java/lang/Exception
    //   33	103	363	finally
    //   131	148	363	finally
    //   305	331	363	finally
    //   175	180	400	java/io/IOException
    //   185	190	400	java/io/IOException
    //   370	375	405	java/io/IOException
    //   380	385	405	java/io/IOException
    //   148	155	410	finally
    //   155	164	410	finally
    //   286	296	410	finally
    //   336	341	419	java/io/IOException
    //   346	351	419	java/io/IOException
    //   33	103	424	java/lang/Exception
    //   131	148	424	java/lang/Exception
    //   107	111	432	java/io/IOException
    //   115	119	432	java/io/IOException
  }

  // ERROR //
  private boolean checkCRC16(int paramInt, String paramString)
  {
    // Byte code:
    //   0: ldc 111
    //   2: ldc_w 332
    //   5: invokestatic 182	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   8: aload_2
    //   9: ifnonnull +13 -> 22
    //   12: ldc 111
    //   14: ldc_w 334
    //   17: invokestatic 248	com/baidu/wearable/ble/util/LogUtil:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   20: iconst_0
    //   21: ireturn
    //   22: new 336	java/io/FileInputStream
    //   25: dup
    //   26: aload_2
    //   27: invokespecial 337	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
    //   30: astore_3
    //   31: aload_3
    //   32: invokevirtual 340	java/io/FileInputStream:available	()I
    //   35: istore 6
    //   37: iload 6
    //   39: newarray byte
    //   41: astore 7
    //   43: aload_3
    //   44: aload 7
    //   46: iconst_0
    //   47: iload 6
    //   49: invokevirtual 343	java/io/FileInputStream:read	([BII)I
    //   52: istore 10
    //   54: aload_3
    //   55: invokevirtual 344	java/io/FileInputStream:close	()V
    //   58: iload 10
    //   60: iload 6
    //   62: if_icmpeq +76 -> 138
    //   65: ldc 111
    //   67: ldc_w 346
    //   70: invokestatic 248	com/baidu/wearable/ble/util/LogUtil:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   73: iconst_0
    //   74: ireturn
    //   75: astore 13
    //   77: aload 13
    //   79: invokevirtual 349	java/io/FileNotFoundException:printStackTrace	()V
    //   82: iconst_0
    //   83: ireturn
    //   84: astore 4
    //   86: aload 4
    //   88: invokevirtual 350	java/io/IOException:printStackTrace	()V
    //   91: aload_3
    //   92: invokevirtual 344	java/io/FileInputStream:close	()V
    //   95: iconst_0
    //   96: ireturn
    //   97: astore 5
    //   99: aload 5
    //   101: invokevirtual 350	java/io/IOException:printStackTrace	()V
    //   104: iconst_0
    //   105: ireturn
    //   106: astore 8
    //   108: aload 8
    //   110: invokevirtual 350	java/io/IOException:printStackTrace	()V
    //   113: aload_3
    //   114: invokevirtual 344	java/io/FileInputStream:close	()V
    //   117: iconst_0
    //   118: ireturn
    //   119: astore 9
    //   121: aload 9
    //   123: invokevirtual 350	java/io/IOException:printStackTrace	()V
    //   126: iconst_0
    //   127: ireturn
    //   128: astore 11
    //   130: aload 11
    //   132: invokevirtual 350	java/io/IOException:printStackTrace	()V
    //   135: goto -77 -> 58
    //   138: new 352	com/baidu/wearable/ota/CRC16
    //   141: dup
    //   142: invokespecial 353	com/baidu/wearable/ota/CRC16:<init>	()V
    //   145: astore 12
    //   147: iload_1
    //   148: aload 12
    //   150: aload 7
    //   152: invokevirtual 356	com/baidu/wearable/ota/CRC16:crc16	([B)I
    //   155: if_icmpeq +43 -> 198
    //   158: ldc 111
    //   160: new 184	java/lang/StringBuilder
    //   163: dup
    //   164: ldc_w 358
    //   167: invokespecial 189	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   170: aload 12
    //   172: aload 7
    //   174: invokevirtual 356	com/baidu/wearable/ota/CRC16:crc16	([B)I
    //   177: invokevirtual 240	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   180: ldc_w 360
    //   183: invokevirtual 193	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   186: iload_1
    //   187: invokevirtual 240	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   190: invokevirtual 197	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   193: invokestatic 248	com/baidu/wearable/ble/util/LogUtil:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   196: iconst_0
    //   197: ireturn
    //   198: iconst_1
    //   199: ireturn
    //
    // Exception table:
    //   from	to	target	type
    //   22	31	75	java/io/FileNotFoundException
    //   31	43	84	java/io/IOException
    //   91	95	97	java/io/IOException
    //   43	54	106	java/io/IOException
    //   113	117	119	java/io/IOException
    //   54	58	128	java/io/IOException
  }

  private int compareVersion(String paramString1, String paramString2)
  {
    if ((paramString1 == null) || (paramString2 == null))
      return -1;
    LogUtil.d("DFUVersionManager", "version_a: " + paramString1);
    LogUtil.d("DFUVersionManager", "version_b: " + paramString2);
    int i = paramString1.indexOf(".");
    if (i == -1)
      return -1;
    int j = paramString1.indexOf(".", i + 1);
    if (j == -1)
      return -1;
    String str1 = paramString1.substring(0, i);
    String str2 = paramString1.substring(i + 1, j);
    String str3 = paramString1.substring(j + 1);
    if ((str1 == null) || (str2 == null) || (str3 == null))
      return -1;
    LogUtil.d("DFUVersionManager", "a1: " + str1 + " a2: " + str2 + " a2: " + str3);
    int k = paramString2.indexOf(".");
    if (k == -1)
      return -1;
    int m = paramString2.indexOf(".", k + 1);
    if (m == -1)
      return -1;
    String str4 = paramString2.substring(0, k);
    String str5 = paramString2.substring(k + 1, m);
    String str6 = paramString2.substring(m + 1);
    if ((str4 == null) || (str5 == null) || (str6 == null))
      return -1;
    LogUtil.d("DFUVersionManager", "b1: " + str4 + " b2: " + str5 + " b2: " + str6);
    int n = Integer.valueOf(str1).intValue();
    int i1 = Integer.valueOf(str2).intValue();
    int i2 = Integer.valueOf(str3).intValue();
    int i3 = Integer.valueOf(str4).intValue();
    int i4 = Integer.valueOf(str5).intValue();
    int i5 = Integer.valueOf(str6).intValue();
    if (n > i3)
      return 1;
    if (n < i3)
      return 2;
    if (i1 > i4)
      return 1;
    if (i1 < i4)
      return 2;
    if (i2 > i5)
      return 1;
    if (i2 < i5)
      return 2;
    return 0;
  }

  public static DFUVersionManager getInstance()
  {
    try
    {
      LogUtil.d("DFUVersionManager", "getInstance without context");
      DFUVersionManager localDFUVersionManager = mInstance;
      return localDFUVersionManager;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public static DFUVersionManager getInstance(Context paramContext)
  {
    try
    {
      LogUtil.d("DFUVersionManager", "getInstance");
      if (mInstance == null)
        mUid = BDAccountManager.getInstance().getUserData("uid");
      for (mInstance = new DFUVersionManager(paramContext); ; mInstance = new DFUVersionManager(paramContext))
      {
        do
        {
          DFUVersionManager localDFUVersionManager = mInstance;
          return localDFUVersionManager;
        }
        while ((mUid == null) || (mUid.equals(BDAccountManager.getInstance().getUserData("uid"))));
        mUid = BDAccountManager.getInstance().getUserData("uid");
      }
    }
    finally
    {
    }
  }

  public void NotifyNextTime()
  {
    this.mNotifyTimer = System.currentTimeMillis();
    LogUtil.d("DFUVersionManager", "NotifyNextTime mNotifyTimer:" + this.mNotifyTimer);
    saveVersionLocal();
  }

  public boolean checkNeedUpdateRom()
  {
    LogUtil.d("DFUVersionManager", "checkNeedUpdateRom  mDeviceManufactory:" + this.mDeviceManufactory + " mDeviceModelName:" + this.mDeviceModelName + " mDeviceSWVersion:" + this.mDeviceSWVersion + " mDeviceHWVersion:" + this.mDeviceHWVersion);
    LogUtil.d("DFUVersionManager", "checkNeedUpdateRom  mServerManufactory:" + this.mServerManufactory + " mServerModelName:" + this.mServerModelName + " mServerSWVersion:" + this.mServerSWVersion + " mServerHWVersion:" + this.mServerHWVersion);
    LogUtil.d("DFUVersionManager", "checkNeedUpdateRom mIgnoreVersion:" + this.mIgnoreVersion);
    LogUtil.d("DFUVersionManager", "checkNeedUpdateRom mNotifyTimer:" + this.mNotifyTimer);
    long l = System.currentTimeMillis();
    LogUtil.d("DFUVersionManager", "checkNeedUpdateRom now time:" + l);
    if ((STRING_INVALID_VALUE != this.mDeviceManufactory) && (STRING_INVALID_VALUE != this.mDeviceModelName) && (STRING_INVALID_VALUE != this.mDeviceSWVersion) && (STRING_INVALID_VALUE != this.mDeviceHWVersion) && (STRING_INVALID_VALUE != this.mServerManufactory) && (STRING_INVALID_VALUE != this.mServerModelName) && (STRING_INVALID_VALUE != this.mServerSWVersion) && (STRING_INVALID_VALUE != this.mServerHWVersion) && (this.mDeviceManufactory.equals(this.mServerManufactory)) && (this.mDeviceModelName.equals(this.mServerModelName)) && (this.mDeviceHWVersion.equals(this.mServerHWVersion)) && (compareVersion(this.mServerSWVersion, this.mDeviceSWVersion) == 1) && ((STRING_INVALID_VALUE == this.mIgnoreVersion) || (compareVersion(this.mServerSWVersion, this.mIgnoreVersion) == 1)) && (l - this.mNotifyTimer > 86400000L))
    {
      LogUtil.d("DFUVersionManager", "need to update the rom ");
      return true;
    }
    return false;
  }

  public void clearAll()
  {
    LogUtil.d("DFUVersionManager", "clearAll");
    this.mDeviceManufactory = STRING_INVALID_VALUE;
    this.mDeviceModelName = STRING_INVALID_VALUE;
    this.mDeviceSWVersion = STRING_INVALID_VALUE;
    this.mDeviceHWVersion = STRING_INVALID_VALUE;
    this.mServerManufactory = STRING_INVALID_VALUE;
    this.mServerModelName = STRING_INVALID_VALUE;
    this.mServerSWVersion = STRING_INVALID_VALUE;
    this.mServerHWVersion = STRING_INVALID_VALUE;
    this.mServerChangeLog = STRING_INVALID_VALUE;
    if (this.mServerRomFilePath != STRING_INVALID_VALUE)
    {
      File localFile = new File(this.mServerRomFilePath);
      if (localFile.exists())
        localFile.delete();
    }
    this.mServerRomFilePath = STRING_INVALID_VALUE;
    this.mNotifyTimer = -86400000L;
    this.mIgnoreVersion = STRING_INVALID_VALUE;
    saveVersionLocal();
  }

  public String getDeviceHWVersion()
  {
    return this.mDeviceHWVersion;
  }

  public String getDeviceManufactory()
  {
    return this.mDeviceManufactory;
  }

  public String getDeviceModelName()
  {
    return this.mDeviceModelName;
  }

  public String getDeviceSWVersion()
  {
    return this.mDeviceSWVersion;
  }

  public String getRomFilePath()
  {
    return this.mServerRomFilePath;
  }

  public void ignoreThisVersion()
  {
    LogUtil.d("DFUVersionManager", "ignoreThisVersion");
    this.mIgnoreVersion = this.mServerSWVersion;
  }

  public boolean isInDevMode()
  {
    return this.mIsInDevMode;
  }

  public void loadVersionLocal()
  {
    this.mServerManufactory = this.mPreferences.getString("dfu_server_manufactory_key", STRING_INVALID_VALUE);
    this.mServerModelName = this.mPreferences.getString("dfu_server_model_name_key", STRING_INVALID_VALUE);
    this.mServerSWVersion = this.mPreferences.getString("dfu_server_sw_version_key", STRING_INVALID_VALUE);
    this.mServerHWVersion = this.mPreferences.getString("dfu_server_hw_version_key", STRING_INVALID_VALUE);
    this.mServerChangeLog = this.mPreferences.getString("dfu_server_change_log_key", STRING_INVALID_VALUE);
    this.mServerRomFilePath = this.mPreferences.getString("dfu_server_rom_file_path", STRING_INVALID_VALUE);
    this.mDeviceManufactory = this.mPreferences.getString("dfu_device_manufactory_key", STRING_INVALID_VALUE);
    this.mDeviceModelName = this.mPreferences.getString("dfu_device_model_name", STRING_INVALID_VALUE);
    this.mDeviceSWVersion = this.mPreferences.getString("dfu_device_sw_version_key", STRING_INVALID_VALUE);
    this.mDeviceHWVersion = this.mPreferences.getString("dfu_device_hw_version_key", STRING_INVALID_VALUE);
    this.mNotifyTimer = this.mPreferences.getLong("dfu_notify_time_key", -86400000L);
    this.mIgnoreVersion = this.mPreferences.getString("dfu_ignore_version_key", STRING_INVALID_VALUE);
    this.mIsInDevMode = this.mPreferences.getBoolean("dfu_device_in_dev_mode_key", false);
    LogUtil.d("DFUVersionManager", "loadVersionLocal  mDeviceManufactory:" + this.mDeviceManufactory + " mDeviceModelName:" + this.mDeviceModelName + " mDeviceSWVersion:" + this.mDeviceSWVersion + " mDeviceHWVersion:" + this.mDeviceHWVersion);
    LogUtil.d("DFUVersionManager", "loadVersionLocal  mServerManufactory:" + this.mServerManufactory + " mServerModelName:" + this.mServerModelName + " mServerSWVersion:" + this.mServerSWVersion + " mServerHWVersion:" + this.mServerHWVersion + " mServerRomFilePath:" + this.mServerRomFilePath);
    LogUtil.d("DFUVersionManager", "loadVersionLocal mNotifyTimer:" + this.mNotifyTimer);
    LogUtil.d("DFUVersionManager", "loadVersionLocal mIgnoreVersion:" + this.mIgnoreVersion);
    LogUtil.d("DFUVersionManager", "loadVersionLocal mIsInDevMode:" + this.mIsInDevMode);
  }

  public void loadVersionNetAsync()
  {
    LogUtil.d("DFUVersionManager", "loadVersionNetAsync");
    new Thread()
    {
      public void run()
      {
        LogUtil.d("DFUVersionManager", "loadVersionNetAsync  doInBackground  mDeviceManufactory:" + DFUVersionManager.this.mDeviceManufactory + " mDeviceModelName:" + DFUVersionManager.this.mDeviceModelName + " mDeviceSWVersion:" + DFUVersionManager.this.mDeviceSWVersion + " mDeviceHWVersion:" + DFUVersionManager.this.mDeviceHWVersion + "WearableApplication.channel_ID=" + WearableApplication.getChannelID());
        LogUtil.d("DFUVersionManager", "loadVersionNetAsync mIsInDevMode:" + DFUVersionManager.this.mIsInDevMode);
        String str1;
        if ((DFUVersionManager.STRING_INVALID_VALUE != DFUVersionManager.this.mDeviceManufactory) && (DFUVersionManager.STRING_INVALID_VALUE != DFUVersionManager.this.mDeviceModelName) && (DFUVersionManager.STRING_INVALID_VALUE != DFUVersionManager.this.mDeviceSWVersion) && (DFUVersionManager.STRING_INVALID_VALUE != DFUVersionManager.this.mDeviceHWVersion))
        {
          if ((DFUVersionManager.this.mServerSWVersion == null) || (DFUVersionManager.this.compareVersion(DFUVersionManager.this.mServerSWVersion, DFUVersionManager.this.mDeviceSWVersion) != 1))
            break label626;
          str1 = DFUVersionManager.this.mServerSWVersion;
        }
        while (true)
        {
          if ((DFUVersionManager.this.mIgnoreVersion != null) && (DFUVersionManager.this.compareVersion(DFUVersionManager.this.mIgnoreVersion, str1) == 1))
            str1 = DFUVersionManager.this.mIgnoreVersion;
          PackageManager localPackageManager = DFUVersionManager.this.mContext.getPackageManager();
          try
          {
            str2 = localPackageManager.getPackageInfo(DFUVersionManager.this.mContext.getPackageName(), 0).versionName;
            localRomUpdateResult = RomUpdateTransport.getInstance(DFUVersionManager.this.mContext).getRomUpdateSync(DFUVersionManager.this.mDeviceManufactory, DFUVersionManager.this.mDeviceModelName, str1, DFUVersionManager.this.mDeviceHWVersion, DFUVersionManager.this.mIsInDevMode, WearableApplication.getChannelID(), str2, "android", String.valueOf(Build.VERSION.SDK_INT));
            if ((localRomUpdateResult.romUpdate != null) && (DFUVersionManager.this.compareVersion(localRomUpdateResult.romUpdate.sw_version, DFUVersionManager.this.mDeviceSWVersion) == 1) && (localRomUpdateResult.romUpdate.rom_url != null))
            {
              LogUtil.d("DFUVersionManager", "mDeviceSWVersion:" + DFUVersionManager.this.mDeviceSWVersion + " new sw_version" + localRomUpdateResult.romUpdate.sw_version);
              File localFile1 = new File(DFUVersionManager.this.mContext.getFilesDir(), "rom-update/");
              if (!localFile1.exists())
              {
                LogUtil.d("DFUVersionManager", "create dir " + localFile1.getName());
                localFile1.mkdir();
              }
              str3 = localFile1.getPath() + "/" + System.currentTimeMillis() + ".bin";
              LogUtil.d("DFUVersionManager", "rom_url:  " + localRomUpdateResult.romUpdate.rom_url);
              LogUtil.d("DFUVersionManager", "romFilePath:  " + str3);
              if (DFUVersionManager.this.DownloadRomFromUrl(localRomUpdateResult.romUpdate.rom_url, localRomUpdateResult.romUpdate.crc_16, str3) < 0)
              {
                LogUtil.e("DFUVersionManager", "DownloadRomFromUrl url: " + localRomUpdateResult.romUpdate.rom_url + " error");
                return;
                label626: str1 = DFUVersionManager.this.mDeviceSWVersion;
              }
            }
          }
          catch (PackageManager.NameNotFoundException localNameNotFoundException)
          {
            RomUpdateTransport.RomUpdateResult localRomUpdateResult;
            String str3;
            while (true)
            {
              localNameNotFoundException.printStackTrace();
              String str2 = null;
            }
            if (DFUVersionManager.this.compareVersion(localRomUpdateResult.romUpdate.sw_version, DFUVersionManager.this.mServerSWVersion) == 1)
              DFUVersionManager.this.mNotifyTimer = -86400000L;
            DFUVersionManager.this.mServerManufactory = localRomUpdateResult.romUpdate.manufactory;
            DFUVersionManager.this.mServerModelName = localRomUpdateResult.romUpdate.model_name;
            DFUVersionManager.this.mServerSWVersion = localRomUpdateResult.romUpdate.sw_version;
            DFUVersionManager.this.mServerHWVersion = localRomUpdateResult.romUpdate.hw_version;
            DFUVersionManager.this.mServerChangeLog = localRomUpdateResult.romUpdate.change_log;
            if (DFUVersionManager.this.mServerRomFilePath != DFUVersionManager.STRING_INVALID_VALUE)
            {
              File localFile2 = new File(DFUVersionManager.this.mServerRomFilePath);
              if (localFile2.exists())
                localFile2.delete();
            }
            DFUVersionManager.this.mServerRomFilePath = str3;
            DFUVersionManager.this.saveVersionLocal();
            DFUVersionManager.this.saveVersionLocal();
          }
        }
      }
    }
    .start();
  }

  public void saveVersionLocal()
  {
    LogUtil.d("DFUVersionManager", "saveVersionLocal  mDeviceManufactory:" + this.mDeviceManufactory + " mDeviceModelName:" + this.mDeviceModelName + " mDeviceSWVersion:" + this.mDeviceSWVersion + " mDeviceHWVersion:" + this.mDeviceHWVersion);
    LogUtil.d("DFUVersionManager", "saveVersionLocal  mServerManufactory:" + this.mServerManufactory + " mServerModelName:" + this.mServerModelName + " mServerSWVersion:" + this.mServerSWVersion + " mServerHWVersion:" + this.mServerHWVersion + " mServerRomFilePath:" + this.mServerRomFilePath);
    LogUtil.d("DFUVersionManager", "saveVersionLocal mNotifyTimer:" + this.mNotifyTimer);
    LogUtil.d("DFUVersionManager", "saveVersionLocal mIgnoreVersion:" + this.mIgnoreVersion);
    LogUtil.d("DFUVersionManager", "saveVersionLocal mIsInDevMode:" + this.mIsInDevMode);
    this.mEditor.putString("dfu_server_manufactory_key", this.mServerManufactory);
    this.mEditor.putString("dfu_server_model_name_key", this.mServerModelName);
    this.mEditor.putString("dfu_server_sw_version_key", this.mServerSWVersion);
    this.mEditor.putString("dfu_server_hw_version_key", this.mServerHWVersion);
    this.mEditor.putString("dfu_server_change_log_key", this.mServerChangeLog);
    this.mEditor.putString("dfu_server_rom_file_path", this.mServerRomFilePath);
    this.mEditor.putString("dfu_device_manufactory_key", this.mDeviceManufactory);
    this.mEditor.putString("dfu_device_model_name", this.mDeviceModelName);
    this.mEditor.putString("dfu_device_sw_version_key", this.mDeviceSWVersion);
    this.mEditor.putString("dfu_device_hw_version_key", this.mDeviceHWVersion);
    this.mEditor.putLong("dfu_notify_time_key", this.mNotifyTimer);
    this.mEditor.putString("dfu_ignore_version_key", this.mIgnoreVersion);
    this.mEditor.putBoolean("dfu_device_in_dev_mode_key", this.mIsInDevMode);
    this.mEditor.commit();
  }

  public void setDeviceInfo(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    LogUtil.d("DFUVersionManager", "-----setDeviceInfo- manufactory:" + paramString1 + " model_name:" + paramString2 + " version:" + paramString4 + " hw_version" + paramString3);
    this.mDeviceManufactory = paramString1;
    this.mDeviceModelName = paramString2;
    this.mDeviceSWVersion = paramString4;
    this.mDeviceHWVersion = paramString3;
    saveVersionLocal();
  }

  public void switchInDevMode()
  {
    if (this.mIsInDevMode);
    for (boolean bool = false; ; bool = true)
    {
      this.mIsInDevMode = bool;
      saveVersionLocal();
      return;
    }
  }

  public void updateRomSuccess()
  {
    LogUtil.d("DFUVersionManager", "updateRomSuccess");
    this.mDeviceSWVersion = STRING_INVALID_VALUE;
    this.mServerManufactory = STRING_INVALID_VALUE;
    this.mServerModelName = STRING_INVALID_VALUE;
    this.mServerSWVersion = STRING_INVALID_VALUE;
    this.mServerHWVersion = STRING_INVALID_VALUE;
    this.mServerChangeLog = STRING_INVALID_VALUE;
    if (this.mServerRomFilePath != STRING_INVALID_VALUE)
    {
      File localFile = new File(this.mServerRomFilePath);
      if (localFile.exists())
        localFile.delete();
    }
    this.mServerRomFilePath = STRING_INVALID_VALUE;
    saveVersionLocal();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ota.DFUVersionManager
 * JD-Core Version:    0.6.2
 */