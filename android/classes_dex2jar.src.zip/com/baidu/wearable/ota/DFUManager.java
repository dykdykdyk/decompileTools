package com.baidu.wearable.ota;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.util.PhoneCheck;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

@SuppressLint({"NewApi"})
public class DFUManager
{
  public static final UUID CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID;
  public static final UUID DFU_CONTROLPOINT_CHARACTERISTIC_UUID;
  public static final UUID DFU_PACKET_CHARACTERISTIC_UUID;
  public static final UUID DFU_SERVICE_UUID = UUID.fromString("00001530-1212-efde-1523-785feabcd123");
  public static final UUID DFU_STATUS_REPORT_CHARACTERISTIC_UUID;
  public static final String ERROR_CONNECT_DEVICE = "Error on  connect for device";
  public static final String ERROR_DISCOVERY_SERVICE = "Error on discovering services";
  public static final String ERROR_FILE_CLOSE = "Error on closing file";
  public static final String ERROR_FILE_CRC16 = "Invalid File CRC16";
  public static final String ERROR_FILE_LENGTH = "Invalid File Length";
  public static final String ERROR_FILE_OPEN = "Error on openning file";
  public static final String ERROR_FILE_READ = "Error on reading file";
  public static final String ERROR_FILE_TRANSFER = "File transfer failed";
  public static final String ERROR_FILE_VALIDATION = "File validation failed";
  public static final String ERROR_SCAN_DEVICE = "Error on  scan for device";
  public static final String ERROR_WRITE_CHARACTERISTIC = "Error on writing characteristic";
  public static final String ERROR_WRITE_DESCRIPTOR = "Error on writing descriptor";
  private static final byte[] OP_CODE_PACKET_RECEIPT_NOTIF_REQ = arrayOfByte;
  private static final int PACKET_RECEIVED_NOTIFICATION_REQUEST = 8;
  private static final String ROM_VERSION_TO_FRESH = "1.1.7";
  private static final String TAG = "DFUManager";
  private static BluetoothAdapter mBluetoothAdapter;
  private static final int mNormalPacketsBeforeNotification = 10;
  private static final int mTCLPacketsBeforeNotification = 3;
  private static DFUManager managerInstance;
  private final int ACTIVATE_FIRMWARE_AND_RESET;
  private final int BYTES_IN_ONE_PACKET = 20;
  private final long CONNECT_DURATION = 30000L;
  private final int INITIALIZE_DFU = 2;
  private final int NUMBER_OF_PACKETS;
  private final int PACKET_RECEIVED_NOTIFICATION;
  private final int RECEIVED_OPCODE;
  private final int RECEIVE_FIRMWARE_IMAGE;
  private final int REPORT_RECEIVED_IMAGE_SIZE;
  private final int RESPONSE;
  private final long SCAN_DURATION = 20000L;
  private final int START_DFU = 1;
  private final int SYSTEM_RESET;
  private final int VALIDATE_FIRMWARE_IMAGE;
  private boolean isCRC16Written = false;
  private boolean isDFUServiceFound = false;
  private boolean isEnablePacketNotificationWritten = false;
  private boolean isFileSizeWritten = false;
  private boolean isLastPacket = false;
  private boolean isNotificationEnable = false;
  private boolean isReceiveFirmwareImageWritten = false;
  private boolean isStartSendPacket;
  private BluetoothGatt mBluetoothGatt;
  private byte[] mBuffer;
  private DFUManagerCallbacks mCallbacks;
  private Timer mConnectTimer;
  private Context mContext;
  private BluetoothGattCharacteristic mDFUControlPointCharacteristic;
  private BluetoothGattCharacteristic mDFUPacketCharacteristic;
  private DFUServiceParser mDFUServiceParser;
  private BluetoothDevice mDevice;
  private String mDeviceAddress;
  private int mFileCRC16 = 0;
  private long mFileSize = 0L;
  private HexInputStream mFileStream;
  private final BluetoothGattCallback mGattCallback;
  private boolean mIsClosed;
  private boolean mIsScanning;
  private BluetoothAdapter.LeScanCallback mLEScanCallback;
  private int mPacketBeforeNotification;
  private long mPacketNumber = 0L;
  private int mPacketsSendSinceNotification;
  private Timer mScanTimer;
  private boolean mStopSendingPacket = false;
  private long mTotalPackets = 0L;

  static
  {
    DFU_CONTROLPOINT_CHARACTERISTIC_UUID = UUID.fromString("00001531-1212-efde-1523-785feabcd123");
    DFU_PACKET_CHARACTERISTIC_UUID = UUID.fromString("00001532-1212-efde-1523-785feabcd123");
    DFU_STATUS_REPORT_CHARACTERISTIC_UUID = UUID.fromString("00001533-1212-efde-1523-785feabcd123");
    CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    managerInstance = null;
    byte[] arrayOfByte = new byte[3];
    arrayOfByte[0] = 8;
  }

  private DFUManager(Context paramContext, BluetoothAdapter paramBluetoothAdapter)
  {
    this.RECEIVE_FIRMWARE_IMAGE = i;
    this.VALIDATE_FIRMWARE_IMAGE = 4;
    this.ACTIVATE_FIRMWARE_AND_RESET = 5;
    this.SYSTEM_RESET = 6;
    this.REPORT_RECEIVED_IMAGE_SIZE = 7;
    this.RESPONSE = 16;
    this.NUMBER_OF_PACKETS = 0;
    this.PACKET_RECEIVED_NOTIFICATION = 17;
    this.RECEIVED_OPCODE = 16;
    this.mDeviceAddress = null;
    this.mIsScanning = false;
    this.mScanTimer = null;
    this.mConnectTimer = null;
    this.mContext = null;
    this.mIsClosed = false;
    this.mPacketsSendSinceNotification = 0;
    this.mPacketBeforeNotification = 0;
    this.mGattCallback = new BluetoothGattCallback()
    {
      public void onCharacteristicChanged(BluetoothGatt paramAnonymousBluetoothGatt, BluetoothGattCharacteristic paramAnonymousBluetoothGattCharacteristic)
      {
        int i = paramAnonymousBluetoothGattCharacteristic.getValue()[0];
        int j = paramAnonymousBluetoothGattCharacteristic.getValue()[1];
        if ((i == 16) && (j == 1))
        {
          LogUtil.d("DFUManager", "Received notification for StartDFU");
          if (paramAnonymousBluetoothGattCharacteristic.getValue()[2] == 1)
          {
            LogUtil.d("DFUManager", "File length is valid: " + paramAnonymousBluetoothGattCharacteristic.getValue()[2]);
            DFUManager.this.initializeDFU();
          }
        }
        else
        {
          if ((i != 16) || (j != 2))
            break label246;
          LogUtil.d("DFUManager", "Received notification for initializeDFU");
          if (paramAnonymousBluetoothGattCharacteristic.getValue()[2] != 1)
            break label194;
          LogUtil.d("DFUManager", "crc16 is valid: " + paramAnonymousBluetoothGattCharacteristic.getValue()[2]);
          DFUManager.this.enablePacketNotification();
        }
        label194: label246: 
        do
        {
          return;
          int i5 = paramAnonymousBluetoothGattCharacteristic.getValue()[2];
          LogUtil.e("DFUManager", "Invalid File Length (" + i5 + ")");
          DFUManager.this.mCallbacks.onError("Invalid File Length", i5);
          break;
          int i4 = paramAnonymousBluetoothGattCharacteristic.getValue()[2];
          LogUtil.e("DFUManager", "Invalid File CRC16 (" + i4 + ")");
          DFUManager.this.mCallbacks.onError("Invalid File CRC16", i4);
          return;
          if (i == 17)
          {
            DFUManager.this.mPacketsSendSinceNotification = 0;
            LogUtil.d("DFUManager", "Received Notification for sent Packet");
            int n = 0xFF & paramAnonymousBluetoothGattCharacteristic.getValue()[1];
            int i1 = 0xFF & paramAnonymousBluetoothGattCharacteristic.getValue()[2];
            int i2 = 0xFF & paramAnonymousBluetoothGattCharacteristic.getValue()[3];
            int i3 = 0xFF & paramAnonymousBluetoothGattCharacteristic.getValue()[4];
            long l = 0xFFFFFFFF & (n | i1 << 8 | i2 << 16 | i3 << 24);
            LogUtil.d("DFUManager", "Bytes received in Packet: " + l);
            DFUManager.this.mCallbacks.onFileTranfering(l);
            if ((!DFUManager.this.isLastPacket) && (!DFUManager.this.mStopSendingPacket))
            {
              DFUManager localDFUManager = DFUManager.this;
              localDFUManager.mPacketsSendSinceNotification = (1 + localDFUManager.mPacketsSendSinceNotification);
              DFUManager.this.sendPacket();
              return;
            }
            LogUtil.d("DFUManager", "last packet notification received");
            return;
          }
          if ((i == 16) && (j == 3))
          {
            LogUtil.d("DFUManager", "File has been transfered");
            if (paramAnonymousBluetoothGattCharacteristic.getValue()[2] == 1)
            {
              LogUtil.d("DFUManager", "Successful File transfer!");
              DFUManager.this.mCallbacks.onFileTransferCompleted();
              DFUManager.this.validateFirmware();
              return;
            }
            int m = paramAnonymousBluetoothGattCharacteristic.getValue()[2];
            LogUtil.e("DFUManager", "File transfer failed" + m);
            DFUManager.this.mCallbacks.onError("File transfer failed", m);
            return;
          }
        }
        while ((i != 16) || (j != 4));
        LogUtil.d("DFUManager", "Transfered file has been validated");
        if (paramAnonymousBluetoothGattCharacteristic.getValue()[2] == 1)
        {
          LogUtil.d("DFUManager", "Successful File Transfer Validation!");
          DFUManager.this.mCallbacks.onFileTransferValidation();
          DFUManager.this.activateAndReset();
          DFUManager.this.isNotificationEnable = false;
          return;
        }
        int k = paramAnonymousBluetoothGattCharacteristic.getValue()[2];
        LogUtil.e("DFUManager", "File validation failed" + k);
        DFUManager.this.mCallbacks.onError("File validation failed", k);
      }

      public void onCharacteristicWrite(BluetoothGatt paramAnonymousBluetoothGatt, BluetoothGattCharacteristic paramAnonymousBluetoothGattCharacteristic, int paramAnonymousInt)
      {
        if (paramAnonymousInt == 0)
        {
          if ((paramAnonymousBluetoothGattCharacteristic.getUuid().equals(DFUManager.DFU_CONTROLPOINT_CHARACTERISTIC_UUID)) && (!DFUManager.this.isFileSizeWritten))
          {
            LogUtil.d("DFUManager", "successfully written startDFU and now writing file size");
            DFUManager.this.writeFileSize();
            DFUManager.this.isFileSizeWritten = true;
          }
          do
          {
            return;
            if ((paramAnonymousBluetoothGattCharacteristic.getUuid().equals(DFUManager.DFU_CONTROLPOINT_CHARACTERISTIC_UUID)) && (!DFUManager.this.isCRC16Written))
            {
              LogUtil.d("DFUManager", "successfully written initializeDFU and now writing file crc16");
              DFUManager.this.writeCRC16();
              DFUManager.this.isCRC16Written = true;
              return;
            }
            if ((paramAnonymousBluetoothGattCharacteristic.getUuid().equals(DFUManager.DFU_CONTROLPOINT_CHARACTERISTIC_UUID)) && (!DFUManager.this.isEnablePacketNotificationWritten))
            {
              LogUtil.d("DFUManager", "successfully written Packet received notification and now writing receive firmware image");
              DFUManager.this.receiveFirmwareImage();
              DFUManager.this.isEnablePacketNotificationWritten = true;
              return;
            }
            if ((paramAnonymousBluetoothGattCharacteristic.getUuid().equals(DFUManager.DFU_CONTROLPOINT_CHARACTERISTIC_UUID)) && (!DFUManager.this.isReceiveFirmwareImageWritten))
            {
              LogUtil.d("DFUManager", "successfully written ReceiveFirmwareImage and now writing file");
              DFUManager.this.startUploadingFile();
              DFUManager.this.isReceiveFirmwareImageWritten = true;
              return;
            }
          }
          while ((!paramAnonymousBluetoothGattCharacteristic.getUuid().equals(DFUManager.DFU_PACKET_CHARACTERISTIC_UUID)) || (!DFUManager.this.isStartSendPacket) || (DFUManager.this.mPacketsSendSinceNotification >= DFUManager.this.mPacketBeforeNotification));
          DFUManager localDFUManager = DFUManager.this;
          localDFUManager.mPacketsSendSinceNotification = (1 + localDFUManager.mPacketsSendSinceNotification);
          DFUManager.this.sendPacket();
          return;
        }
        LogUtil.e("DFUManager", "Error on writing characteristic [" + paramAnonymousBluetoothGattCharacteristic.getUuid() + "] Error code: " + paramAnonymousInt);
        DFUManager.this.mCallbacks.onError("Error on writing characteristic", paramAnonymousInt);
      }

      public void onConnectionStateChange(BluetoothGatt paramAnonymousBluetoothGatt, int paramAnonymousInt1, int paramAnonymousInt2)
      {
        if (DFUManager.this.mConnectTimer != null)
        {
          DFUManager.this.mConnectTimer.cancel();
          DFUManager.this.mConnectTimer.purge();
          DFUManager.this.mConnectTimer = null;
        }
        if (paramAnonymousInt2 == 2)
        {
          LogUtil.d("DFUManager", "Device connected");
          if ((PhoneCheck.isTCLPhone()) || (DFUVersionManager.getInstance().getDeviceSWVersion().equals("1.1.7")))
            DFUManager.this.refreshGatt(paramAnonymousBluetoothGatt);
          if (!paramAnonymousBluetoothGatt.discoverServices())
          {
            LogUtil.e("DFUManager", "call discoverServices error");
            DFUManager.this.mCallbacks.onError("Error on discovering services", paramAnonymousInt1);
          }
          DFUManager.this.mCallbacks.onDeviceConnected();
        }
        while (paramAnonymousInt2 != 0)
          return;
        LogUtil.d("DFUManager", "Device disconnected");
        DFUManager.this.mCallbacks.onDeviceDisconnected();
      }

      public void onDescriptorWrite(BluetoothGatt paramAnonymousBluetoothGatt, BluetoothGattDescriptor paramAnonymousBluetoothGattDescriptor, int paramAnonymousInt)
      {
        if (paramAnonymousInt == 0)
        {
          if (DFUManager.this.isNotificationEnable)
          {
            DFUManager.this.startDFU();
            return;
          }
          LogUtil.d("DFUManager", "Notification is disabled!");
          return;
        }
        LogUtil.e("DFUManager", "Error on writing descriptor (" + paramAnonymousInt + ")");
        DFUManager.this.mCallbacks.onError("Error on writing descriptor", paramAnonymousInt);
      }

      public void onServicesDiscovered(BluetoothGatt paramAnonymousBluetoothGatt, int paramAnonymousInt)
      {
        LogUtil.d("DFUManager", "onServicesDiscovered status: " + paramAnonymousInt);
        DFUManager.this.isDFUServiceFound = false;
        if (paramAnonymousInt == 0)
        {
          Iterator localIterator = paramAnonymousBluetoothGatt.getServices().iterator();
          while (true)
          {
            if (!localIterator.hasNext())
            {
              if (!DFUManager.this.isDFUServiceFound)
                break;
              DFUManager.this.mCallbacks.onDFUServiceFound();
              DFUManager.this.enableNotification();
              return;
            }
            BluetoothGattService localBluetoothGattService = (BluetoothGattService)localIterator.next();
            LogUtil.d("DFUManager", "Found Service: " + localBluetoothGattService.getUuid());
            if (localBluetoothGattService.getUuid().equals(DFUManager.DFU_SERVICE_UUID))
            {
              LogUtil.d("DFUManager", "DFU Service found!");
              DFUManager.this.isDFUServiceFound = true;
              DFUManager.this.mDFUControlPointCharacteristic = localBluetoothGattService.getCharacteristic(DFUManager.DFU_CONTROLPOINT_CHARACTERISTIC_UUID);
              DFUManager.this.mDFUPacketCharacteristic = localBluetoothGattService.getCharacteristic(DFUManager.DFU_PACKET_CHARACTERISTIC_UUID);
            }
          }
          LogUtil.e("DFUManager", "Service is not right ");
          DFUManager.this.mCallbacks.onError("Error on discovering services", paramAnonymousInt);
          return;
        }
        DFUManager.this.mCallbacks.onError("Error on discovering services", paramAnonymousInt);
      }
    };
    this.isStartSendPacket = false;
    this.mBuffer = new byte[20];
    this.mLEScanCallback = new BluetoothAdapter.LeScanCallback()
    {
      public void onLeScan(BluetoothDevice paramAnonymousBluetoothDevice, int paramAnonymousInt, byte[] paramAnonymousArrayOfByte)
      {
        DFUManager.log("DFUManager", "onLeScan");
        if ((paramAnonymousBluetoothDevice != null) && (paramAnonymousBluetoothDevice.getAddress().equals(DFUManager.this.mDeviceAddress)))
        {
          DFUManager.log("DFUManager", "Device scanned address: " + paramAnonymousBluetoothDevice.getAddress() + " name: " + paramAnonymousBluetoothDevice.getName() + " RSSI: " + paramAnonymousInt);
          DFUManager.this.mCallbacks.onDeviceFound();
          DFUManager.this.stopScan();
          DFUManager.this.connect(paramAnonymousBluetoothDevice);
        }
      }
    };
    this.mContext = paramContext;
    mBluetoothAdapter = paramBluetoothAdapter;
    if (PhoneCheck.isTCLPhone());
    while (true)
    {
      this.mPacketBeforeNotification = i;
      return;
      i = 10;
    }
  }

  private void activateAndReset()
  {
    this.mDFUControlPointCharacteristic.setValue(5, 17, 0);
    LogUtil.d("DFUManager", "writing activate and reset value");
    this.mBluetoothGatt.writeCharacteristic(this.mDFUControlPointCharacteristic);
  }

  private void closeBluetoothGatt()
  {
    if (this.mBluetoothGatt != null)
    {
      this.mBluetoothGatt.disconnect();
      this.mBluetoothGatt.close();
      this.mBluetoothGatt = null;
    }
  }

  private void closeFile()
  {
    if (this.mFileStream != null);
    try
    {
      this.mFileStream.close();
      this.mFileStream = null;
      return;
    }
    catch (IOException localIOException)
    {
      LogUtil.e("DFUManager", "Error on closing file " + localIOException.toString());
      this.mCallbacks.onError("Error on closing file", 0);
    }
  }

  @SuppressLint({"NewApi"})
  private void connect(BluetoothDevice paramBluetoothDevice)
  {
    LogUtil.d("DFUManager", "Connecting device");
    this.mDevice = paramBluetoothDevice;
    new Thread()
    {
      public void run()
      {
        try
        {
          sleep(2000L);
          if (!DFUManager.this.mIsClosed)
          {
            DFUManager.this.mBluetoothGatt = DFUManager.this.mDevice.connectGatt(DFUManager.this.mContext, false, DFUManager.this.mGattCallback);
            DFUManager.this.mConnectTimer = new Timer();
            DFUManager.this.mConnectTimer.schedule(new DFUManager.ConnectTimeoutTask(DFUManager.this), 30000L);
            return;
          }
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            localInterruptedException.printStackTrace();
          LogUtil.d("DFUManager", "have been closed,cancel the  connect");
        }
      }
    }
    .start();
  }

  private void disconnect()
  {
    LogUtil.d("DFUManager", "Disconnecting device");
    if (this.mBluetoothGatt != null)
      this.mBluetoothGatt.disconnect();
  }

  private void enablePacketNotification()
  {
    LogUtil.d("DFUManager", "Enable Packet Notification");
    byte[] arrayOfByte = new byte[3];
    arrayOfByte[0] = 8;
    arrayOfByte[1] = ((byte)this.mPacketBeforeNotification);
    this.mDFUControlPointCharacteristic.setValue(arrayOfByte);
    this.mBluetoothGatt.writeCharacteristic(this.mDFUControlPointCharacteristic);
  }

  private int getBytesInLastPacket()
  {
    if (0L == this.mFileSize % 20L);
    for (int i = 20; ; i = (int)(this.mFileSize % 20L))
    {
      LogUtil.d("DFUManager", "getBytesInLastPacket :" + i);
      return i;
    }
  }

  public static DFUManager getDFUManager(Context paramContext, BluetoothAdapter paramBluetoothAdapter)
  {
    try
    {
      if (managerInstance == null)
        managerInstance = new DFUManager(paramContext, paramBluetoothAdapter);
      DFUManager localDFUManager = managerInstance;
      return localDFUManager;
    }
    finally
    {
    }
  }

  private byte[] getNextPacket()
  {
    try
    {
      byte[] arrayOfByte = new byte[20];
      this.mFileStream.readPacket(arrayOfByte);
      return arrayOfByte;
    }
    catch (IOException localIOException)
    {
      LogUtil.e("DFUManager", "Error on reading file");
      this.mCallbacks.onError("Error on reading file", 0);
    }
    return null;
  }

  private int getNumberOfPackets()
  {
    int i = (int)(this.mFileSize / 20L);
    if (this.mFileSize % 20L > 0L)
      i++;
    return i;
  }

  private void initializeDFU()
  {
    LogUtil.d("DFUManager", "initializeDFU");
    if (this.isFileSizeWritten)
    {
      this.mDFUControlPointCharacteristic.setValue(2, 17, 0);
      LogUtil.d("DFUManager", "writing initialize DFU value");
      this.mBluetoothGatt.writeCharacteristic(this.mDFUControlPointCharacteristic);
      this.isCRC16Written = false;
    }
  }

  public static void log(String paramString1, String paramString2)
  {
    LogUtil.d(paramString1, paramString2);
  }

  public static void logE(String paramString1, String paramString2)
  {
    LogUtil.e(paramString1, paramString2);
  }

  private void receiveFirmwareImage()
  {
    LogUtil.d("DFUManager", "sending Receive Firmware Image message");
    this.mDFUControlPointCharacteristic.setValue(3, 17, 0);
    this.mBluetoothGatt.writeCharacteristic(this.mDFUControlPointCharacteristic);
  }

  private boolean refreshGatt(BluetoothGatt paramBluetoothGatt)
  {
    Boolean localBoolean = Boolean.valueOf(false);
    LogUtil.d("DFUManager", "refreshGatt");
    try
    {
      localBoolean = (Boolean)BluetoothGatt.class.getMethod("refresh", new Class[0]).invoke(paramBluetoothGatt, new Object[0]);
      LogUtil.d("DFUManager", "refresh ret:" + localBoolean);
      return localBoolean.booleanValue();
    }
    catch (NoSuchMethodException localNoSuchMethodException)
    {
      while (true)
        localNoSuchMethodException.printStackTrace();
    }
    catch (IllegalAccessException localIllegalAccessException)
    {
      while (true)
        localIllegalAccessException.printStackTrace();
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      while (true)
        localIllegalArgumentException.printStackTrace();
    }
    catch (InvocationTargetException localInvocationTargetException)
    {
      while (true)
        localInvocationTargetException.printStackTrace();
    }
  }

  private void resetStatus()
  {
    this.isFileSizeWritten = false;
    this.isCRC16Written = false;
    this.isEnablePacketNotificationWritten = false;
    this.isReceiveFirmwareImageWritten = false;
    this.isDFUServiceFound = false;
    this.isNotificationEnable = false;
    this.isLastPacket = false;
    this.mStopSendingPacket = false;
  }

  private void sendPacket()
  {
    this.isStartSendPacket = true;
    this.mPacketNumber = (1L + this.mPacketNumber);
    if (this.mPacketNumber == this.mTotalPackets)
    {
      LogUtil.d("DFUManager", "This is last packet");
      LogUtil.d("DFUManager", "sendPacket: " + this.mPacketNumber);
      this.isLastPacket = true;
      arrayOfByte2 = getNextPacket();
      arrayOfByte3 = new byte[getBytesInLastPacket()];
      i = 0;
      if (i >= getBytesInLastPacket())
      {
        this.mDFUPacketCharacteristic.setValue(arrayOfByte3);
        this.mBluetoothGatt.writeCharacteristic(this.mDFUPacketCharacteristic);
        LogUtil.d("DFUManager", "sent last packet");
      }
    }
    while (this.mPacketNumber >= this.mTotalPackets)
      while (true)
      {
        byte[] arrayOfByte2;
        byte[] arrayOfByte3;
        int i;
        return;
        arrayOfByte3[i] = arrayOfByte2[i];
        i++;
      }
    LogUtil.d("DFUManager", "sendPacket: " + this.mPacketNumber);
    byte[] arrayOfByte1 = getNextPacket();
    if (arrayOfByte1 == null)
      LogUtil.e("DFUManager", "buffer == null");
    this.mDFUPacketCharacteristic.setValue(arrayOfByte1);
    this.mBluetoothGatt.writeCharacteristic(this.mDFUPacketCharacteristic);
  }

  private void setNumberOfPackets(byte[] paramArrayOfByte, int paramInt)
  {
    paramArrayOfByte[1] = ((byte)(paramInt & 0xFF));
    paramArrayOfByte[2] = ((byte)(0xFF & paramInt >> 8));
  }

  private void startDFU()
  {
    LogUtil.d("DFUManager", "startDFU");
    if (this.isDFUServiceFound)
    {
      this.mDFUControlPointCharacteristic.setValue(1, 17, 0);
      LogUtil.d("DFUManager", "writing start DFU value");
      this.mBluetoothGatt.writeCharacteristic(this.mDFUControlPointCharacteristic);
      this.isFileSizeWritten = false;
    }
  }

  private void startUploadingFile()
  {
    LogUtil.d("DFUManager", "Preparing to send file");
    this.mPacketsSendSinceNotification = (1 + this.mPacketsSendSinceNotification);
    sendPacket();
    this.mCallbacks.onFileTransferStarted();
  }

  private void stopScan()
  {
    if (this.mIsScanning)
    {
      log("DFUManager", "stopScan");
      mBluetoothAdapter.stopLeScan(this.mLEScanCallback);
      this.mIsScanning = false;
    }
    if (this.mScanTimer != null)
    {
      this.mScanTimer.cancel();
      this.mScanTimer.purge();
      this.mScanTimer = null;
    }
  }

  private void validateFirmware()
  {
    this.mDFUControlPointCharacteristic.setValue(4, 17, 0);
    LogUtil.d("DFUManager", "writing validate Firmware value");
    this.mBluetoothGatt.writeCharacteristic(this.mDFUControlPointCharacteristic);
  }

  private void writeCRC16()
  {
    LogUtil.d("DFUManager", "writeCRC16");
    if (this.isFileSizeWritten)
    {
      this.mDFUPacketCharacteristic.setWriteType(1);
      this.mDFUPacketCharacteristic.setValue(this.mFileCRC16, 18, 0);
      LogUtil.d("DFUManager", "writing File CRC16:" + this.mFileCRC16);
      this.mBluetoothGatt.writeCharacteristic(this.mDFUPacketCharacteristic);
    }
  }

  private void writeFileSize()
  {
    LogUtil.d("DFUManager", "writeFileSize");
    if (this.isDFUServiceFound)
    {
      this.mDFUPacketCharacteristic.setWriteType(1);
      this.mDFUPacketCharacteristic.setValue((int)this.mFileSize, 20, 0);
      LogUtil.e("DFUManager", "writing File size:" + this.mFileSize);
      this.mBluetoothGatt.writeCharacteristic(this.mDFUPacketCharacteristic);
    }
  }

  public void close()
  {
    this.mIsClosed = true;
    if (this.mIsScanning)
      stopScan();
    closeFile();
    closeBluetoothGatt();
    resetStatus();
    managerInstance = null;
  }

  // ERROR //
  int crc16_compute(String paramString)
  {
    // Byte code:
    //   0: ldc_w 582
    //   3: istore_2
    //   4: ldc 61
    //   6: ldc_w 583
    //   9: invokestatic 383	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   12: aload_1
    //   13: ifnonnull +13 -> 26
    //   16: ldc 61
    //   18: ldc_w 585
    //   21: invokestatic 423	com/baidu/wearable/ble/util/LogUtil:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   24: iconst_m1
    //   25: ireturn
    //   26: new 587	java/io/FileInputStream
    //   29: dup
    //   30: aload_1
    //   31: invokespecial 588	java/io/FileInputStream:<init>	(Ljava/lang/String;)V
    //   34: astore_3
    //   35: aload_3
    //   36: invokevirtual 591	java/io/FileInputStream:available	()I
    //   39: istore 6
    //   41: iload 6
    //   43: newarray byte
    //   45: astore 7
    //   47: aload_3
    //   48: aload 7
    //   50: iconst_0
    //   51: iload 6
    //   53: invokevirtual 595	java/io/FileInputStream:read	([BII)I
    //   56: istore 10
    //   58: aload_3
    //   59: invokevirtual 596	java/io/FileInputStream:close	()V
    //   62: iload 10
    //   64: iload 6
    //   66: if_icmpeq +76 -> 142
    //   69: ldc 61
    //   71: ldc_w 598
    //   74: invokestatic 423	com/baidu/wearable/ble/util/LogUtil:e	(Ljava/lang/String;Ljava/lang/String;)V
    //   77: iconst_m1
    //   78: ireturn
    //   79: astore 16
    //   81: aload 16
    //   83: invokevirtual 599	java/io/FileNotFoundException:printStackTrace	()V
    //   86: iconst_m1
    //   87: ireturn
    //   88: astore 4
    //   90: aload 4
    //   92: invokevirtual 600	java/io/IOException:printStackTrace	()V
    //   95: aload_3
    //   96: invokevirtual 596	java/io/FileInputStream:close	()V
    //   99: iconst_m1
    //   100: ireturn
    //   101: astore 5
    //   103: aload 5
    //   105: invokevirtual 600	java/io/IOException:printStackTrace	()V
    //   108: iconst_m1
    //   109: ireturn
    //   110: astore 8
    //   112: aload 8
    //   114: invokevirtual 600	java/io/IOException:printStackTrace	()V
    //   117: aload_3
    //   118: invokevirtual 596	java/io/FileInputStream:close	()V
    //   121: iconst_m1
    //   122: ireturn
    //   123: astore 9
    //   125: aload 9
    //   127: invokevirtual 600	java/io/IOException:printStackTrace	()V
    //   130: iconst_m1
    //   131: ireturn
    //   132: astore 11
    //   134: aload 11
    //   136: invokevirtual 600	java/io/IOException:printStackTrace	()V
    //   139: goto -77 -> 62
    //   142: iconst_0
    //   143: istore 12
    //   145: iload 12
    //   147: iload 6
    //   149: if_icmplt +27 -> 176
    //   152: ldc 61
    //   154: new 406	java/lang/StringBuilder
    //   157: dup
    //   158: ldc_w 602
    //   161: invokespecial 411	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   164: iload_2
    //   165: invokevirtual 455	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   168: invokevirtual 420	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   171: invokestatic 383	com/baidu/wearable/ble/util/LogUtil:d	(Ljava/lang/String;Ljava/lang/String;)V
    //   174: iload_2
    //   175: ireturn
    //   176: ldc_w 582
    //   179: ldc_w 582
    //   182: iload_2
    //   183: ldc_w 582
    //   186: iand
    //   187: bipush 8
    //   189: ishr
    //   190: iload_2
    //   191: ldc_w 582
    //   194: iand
    //   195: bipush 8
    //   197: ishl
    //   198: ior
    //   199: iand
    //   200: sipush 255
    //   203: aload 7
    //   205: iload 12
    //   207: baload
    //   208: iand
    //   209: ixor
    //   210: iand
    //   211: istore 13
    //   213: ldc_w 582
    //   216: iload 13
    //   218: iload 13
    //   220: sipush 255
    //   223: iand
    //   224: iconst_4
    //   225: ishr
    //   226: ixor
    //   227: iand
    //   228: istore 14
    //   230: ldc_w 582
    //   233: iload 14
    //   235: iload 14
    //   237: ldc_w 582
    //   240: iand
    //   241: bipush 8
    //   243: ishl
    //   244: iconst_4
    //   245: ishl
    //   246: ixor
    //   247: iand
    //   248: istore 15
    //   250: ldc_w 582
    //   253: iload 15
    //   255: iload 15
    //   257: sipush 255
    //   260: iand
    //   261: iconst_4
    //   262: ishl
    //   263: iconst_1
    //   264: ishl
    //   265: ixor
    //   266: iand
    //   267: istore_2
    //   268: iinc 12 1
    //   271: goto -126 -> 145
    //
    // Exception table:
    //   from	to	target	type
    //   26	35	79	java/io/FileNotFoundException
    //   35	47	88	java/io/IOException
    //   95	99	101	java/io/IOException
    //   47	58	110	java/io/IOException
    //   117	121	123	java/io/IOException
    //   58	62	132	java/io/IOException
  }

  public void disableNotification()
  {
    if (this.isNotificationEnable)
    {
      LogUtil.d("DFUManager", "Disable Notification");
      this.mBluetoothGatt.setCharacteristicNotification(this.mDFUControlPointCharacteristic, false);
      BluetoothGattDescriptor localBluetoothGattDescriptor = this.mDFUControlPointCharacteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID);
      localBluetoothGattDescriptor.setValue(BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
      this.mBluetoothGatt.writeDescriptor(localBluetoothGattDescriptor);
      this.isNotificationEnable = false;
    }
  }

  public void enableNotification()
  {
    LogUtil.d("DFUManager", "Enable Notification");
    this.mBluetoothGatt.setCharacteristicNotification(this.mDFUControlPointCharacteristic, true);
    BluetoothGattDescriptor localBluetoothGattDescriptor = this.mDFUControlPointCharacteristic.getDescriptor(CLIENT_CHARACTERISTIC_CONFIG_DESCRIPTOR_UUID);
    localBluetoothGattDescriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
    this.mBluetoothGatt.writeDescriptor(localBluetoothGattDescriptor);
    this.isNotificationEnable = true;
  }

  public BluetoothDevice getDevice()
  {
    return this.mDevice;
  }

  public long getFileSize()
  {
    return this.mFileSize;
  }

  public void resumeSendingPacket()
  {
    this.mStopSendingPacket = false;
    this.mPacketsSendSinceNotification = (1 + this.mPacketsSendSinceNotification);
    sendPacket();
  }

  public void setDeviceAddress(String paramString)
  {
    this.mDeviceAddress = paramString;
  }

  public void setFile(String paramString)
  {
    try
    {
      this.mPacketNumber = 0L;
      this.mFileStream = new HexInputStream(paramString);
      this.mFileSize = this.mFileStream.available();
      this.mTotalPackets = getNumberOfPackets();
      this.mFileCRC16 = crc16_compute(paramString);
      LogUtil.d("DFUManager", "File Size: " + this.mFileSize);
      if (this.mFileCRC16 < 0)
        this.mCallbacks.onError("Error on openning file", 0);
      return;
    }
    catch (IOException localIOException)
    {
      LogUtil.e("DFUManager", "Error on openning file " + localIOException);
      this.mCallbacks.onError("Error on openning file", 0);
    }
  }

  public void setGattCallbacks(DFUManagerCallbacks paramDFUManagerCallbacks)
  {
    this.mCallbacks = paramDFUManagerCallbacks;
  }

  public void startScan()
  {
    log("DFUManager", "startScan");
    if (mBluetoothAdapter.startLeScan(this.mLEScanCallback))
    {
      this.mIsScanning = true;
      this.mScanTimer = new Timer();
      this.mScanTimer.schedule(new ScanTimeoutTask(), 20000L);
      return;
    }
    this.mCallbacks.onError("Error on  scan for device", 0);
  }

  public void stopSendingPacket()
  {
    this.mStopSendingPacket = true;
  }

  public void systemReset()
  {
    byte[] arrayOfByte = { 6 };
    if ((this.mDFUControlPointCharacteristic != null) && (this.mBluetoothGatt != null))
    {
      this.mDFUControlPointCharacteristic.setValue(arrayOfByte);
      this.mBluetoothGatt.writeCharacteristic(this.mDFUControlPointCharacteristic);
    }
  }

  class ConnectTimeoutTask extends TimerTask
  {
    ConnectTimeoutTask()
    {
    }

    public void run()
    {
      LogUtil.v("DFUManager", "Inside ConnectTimeoutTask");
      if (DFUManager.this.mBluetoothGatt != null)
      {
        DFUManager.this.mBluetoothGatt.disconnect();
        DFUManager.this.mBluetoothGatt.close();
        DFUManager.this.mBluetoothGatt = null;
      }
      DFUManager.this.mCallbacks.onError("Error on  connect for device", 0);
    }
  }

  class ScanTimeoutTask extends TimerTask
  {
    ScanTimeoutTask()
    {
    }

    public void run()
    {
      LogUtil.v("DFUManager", "Inside ScanTimeoutTask");
      if (DFUManager.this.mIsScanning)
        DFUManager.this.stopScan();
      DFUManager.this.mCallbacks.onError("Error on  scan for device", 0);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ota.DFUManager
 * JD-Core Version:    0.6.2
 */