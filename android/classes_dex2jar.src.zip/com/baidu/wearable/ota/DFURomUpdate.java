package com.baidu.wearable.ota;

public class DFURomUpdate
{
  public String change_log;
  public int crc_16;
  public String hw_version;
  public String manufactory;
  public String model_name;
  public String rom_url;
  public String sw_version;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ota.DFURomUpdate
 * JD-Core Version:    0.6.2
 */