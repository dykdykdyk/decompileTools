package com.baidu.wearable;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

public class AppManager
{
  private static final String TAG = "AppManager";
  public static Stack<Activity> activityStack = new Stack();
  private static AppManager instance;

  public static AppManager getAppManager()
  {
    if (instance == null)
      instance = new AppManager();
    return instance;
  }

  public static String getTopActivityName(Context paramContext)
  {
    List localList = ((ActivityManager)paramContext.getSystemService("activity")).getRunningTasks(1);
    String str = null;
    if (localList != null)
      str = ((ActivityManager.RunningTaskInfo)localList.get(0)).topActivity.getClassName();
    return str;
  }

  public void AppExit(Context paramContext)
  {
    try
    {
      finishAllActivity();
      ((ActivityManager)paramContext.getSystemService("activity")).restartPackage(paramContext.getPackageName());
      System.exit(0);
      return;
    }
    catch (Exception localException)
    {
    }
  }

  public void addActivity(Activity paramActivity)
  {
    activityStack.add(paramActivity);
  }

  public Activity currentActivity()
  {
    return (Activity)activityStack.lastElement();
  }

  public void finishActivity()
  {
    finishActivity((Activity)activityStack.lastElement());
  }

  public void finishActivity(Activity paramActivity)
  {
    if (paramActivity != null)
    {
      activityStack.remove(paramActivity);
      paramActivity.finish();
    }
  }

  public void finishActivity(Class<?> paramClass)
  {
    Iterator localIterator = activityStack.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      Activity localActivity = (Activity)localIterator.next();
      if (localActivity.getClass().equals(paramClass))
        finishActivity(localActivity);
    }
  }

  public void finishAllActivity()
  {
    int i = 0;
    int j = activityStack.size();
    while (true)
    {
      if (i >= j)
      {
        activityStack.clear();
        return;
      }
      if (activityStack.get(i) != null)
        ((Activity)activityStack.get(i)).finish();
      i++;
    }
  }

  public String getPackageName(Context paramContext)
  {
    return paramContext.getPackageName();
  }

  public boolean isRunningForeground(Context paramContext)
  {
    String str1 = getPackageName(paramContext);
    String str2 = getTopActivityName(paramContext);
    LogUtil.d("AppManager", "packageName=" + str1 + ",topActivityClassName=" + str2);
    if ((str1 != null) && (str2 != null) && (str2.startsWith(str1)))
    {
      LogUtil.d("AppManager", "---> isRunningForeGround");
      return true;
    }
    LogUtil.d("AppManager", "---> isRunningBackGround");
    return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.AppManager
 * JD-Core Version:    0.6.2
 */