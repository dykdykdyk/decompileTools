package com.baidu.wearable;

import android.content.Context;
import com.baidu.wearable.agent.AgentManager;

public class Config
{
  public static final String APP_ID = "1325340";
  public static String BDUSS;
  public static String DEVICE_ID;
  public static String UID;

  public static void close()
  {
    BDUSS = null;
    UID = null;
    DEVICE_ID = null;
  }

  public static void init(Context paramContext, String paramString1, String paramString2)
  {
    BDUSS = paramString1;
    UID = paramString2;
    DEVICE_ID = AgentManager.getLocalId(paramContext);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.Config
 * JD-Core Version:    0.6.2
 */