package com.baidu.wearable.jni;

public class JniKey
{
  static
  {
    System.loadLibrary("key");
  }

  public native String getKey();
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.jni.JniKey
 * JD-Core Version:    0.6.2
 */