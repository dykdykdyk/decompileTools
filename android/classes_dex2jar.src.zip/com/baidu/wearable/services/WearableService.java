package com.baidu.wearable.services;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.support.v4.app.NotificationCompat.Builder;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Pair;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.AppManager;
import com.baidu.wearable.alarm.AlarmReceiver;
import com.baidu.wearable.alarm.clock.ClockManager;
import com.baidu.wearable.ble.connectmanager.BluetoothLeStateMachine;
import com.baidu.wearable.ble.connectmanager.BluetoothLeStateMachine.ReadBatteryLevelCallback;
import com.baidu.wearable.ble.connectmanager.BluetoothLeStateMachine.ReadDeviceInformationCallback;
import com.baidu.wearable.ble.connectmanager.BluetoothState;
import com.baidu.wearable.ble.model.SleepBlueTooth;
import com.baidu.wearable.ble.model.SportBlueTooth;
import com.baidu.wearable.ble.stack.BlueTooth;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothBondReceiverListener;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothCommonListener;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothConnectResetListener;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothLogReceiverListener;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothLoginReceiverListener;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SportDao;
import com.baidu.wearable.net.TrackerTransport;
import com.baidu.wearable.net.Transport.CommonListener;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.preference.ProfilePreference;
import com.baidu.wearable.profile.Gender;
import com.baidu.wearable.sleep.SleepController;
import com.baidu.wearable.sleep.SleepController.SleepDetailListener;
import com.baidu.wearable.sleep.SleepController.SleepSettingDetailListener;
import com.baidu.wearable.sleep.SleepDetail;
import com.baidu.wearable.sleep.SleepSettingDetail;
import com.baidu.wearable.sport.Sport;
import com.baidu.wearable.sport.SportController;
import com.baidu.wearable.sport.SportController.PhoneSportListener;
import com.baidu.wearable.sport.SportController.SportListener;
import com.baidu.wearable.sport.SportDetail;
import com.baidu.wearable.sport.SportPart;
import com.baidu.wearable.sport.SportSummary;
import com.baidu.wearable.sync.SettingsSyncManager;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.ui.activities.device.AddDeviceGuidActivity_bind;
import com.baidu.wearable.util.PhoneCheck;
import com.baidu.wearable.util.RomDebugManager;
import com.baidu.wearable.util.SilentSleepManager;
import com.baidu.wearable.util.TimeUtil;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class WearableService extends Service
  implements SensorEventListener
{
  public static final int BATTERY_PERCENT_FIRST_LEVEL = 10;
  public static final int BATTERY_PERCENT_SECOND_LEVEL = 20;
  private static int CONNECT_RETRY_COUNT = 0;
  public static final int NOTIFICATION_ID = 1004;
  private static final String PRE = "+86";
  private static int SCAN_RETRY_COUNT = 0;
  private static final long SYNC_DATA_INTERVAL = 5000L;
  private static final int SYNC_DATE_CODE = 10001;
  private static final String TAG = "WearableService";
  private final int REQUEST_DATA_INTERVAL = 3600000;
  private BlueTooth mBlueTooth;
  private BluetoothLeStateMachine mBluetoothStateMachine;
  private boolean mCanLowBatteryAlarmAtFirtstLevel = true;
  private boolean mCanLowBatteryAlarmAtSecondLevel = true;
  private Context mContext;
  private SQLiteDatabase mDb;
  private Timer mDeviceInformationTimer = null;
  private boolean mIsMainActivityInForground = false;
  private JniAlgorithm mJniAlgorithm;
  private LocalBroadcastManager mLocalBroadcastManager;
  private int mLoginRetryCounter = 0;
  private boolean mPhoneFlag = false;
  private PlanPreference mPlanMgr;
  private ProfilePreference mProfileMgr;
  private Timer mReadBatteryLevelTimer = null;
  private Receiver mReceiver;
  private Timer mRequestDataTimer = null;
  private SensorManager mSensorManager;
  private boolean mSetTimeOk = false;
  private SettingsSyncManager mSettingNetSyncManager;
  private SilentSleepManager mSilentSleepManager;
  private Timer mSyncDataTimer = null;
  private TelephonyManager mTelephonyManager;
  private PowerManager.WakeLock mWakeLock;
  private AlarmPreference mWarnMgr;
  private int sensorDataCount = 0;
  private List<SensorData> sensorDatas = new ArrayList();

  private void acquireWakeLock()
  {
    LogUtil.d("WearableService", "acquireWakeLock");
    this.mWakeLock = ((PowerManager)getSystemService("power")).newWakeLock(1, "WearableService");
    this.mWakeLock.acquire();
  }

  private void alarmLowBattery(int paramInt)
  {
    if (-1 != paramInt)
    {
      if (AppManager.getAppManager().isRunningForeground(this))
      {
        Intent localIntent = new Intent("action.wearable.ble.battery.lowbattery");
        localIntent.putExtra("extra.wearable.ble.battery.lowbattery_level", paramInt);
        this.mLocalBroadcastManager.sendBroadcast(localIntent);
      }
      NotificationCompat.Builder localBuilder = new NotificationCompat.Builder(this);
      localBuilder.setContentTitle(getString(2131296585));
      String str = getString(2131296588);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = (paramInt + "%");
      localBuilder.setContentText(String.format(str, arrayOfObject));
      localBuilder.setSmallIcon(2130837600);
      localBuilder.setAutoCancel(true);
      localBuilder.setContentIntent(PendingIntent.getActivity(getApplicationContext(), 0, new Intent(), 0));
      Notification localNotification = localBuilder.build();
      ((NotificationManager)this.mContext.getSystemService("notification")).notify(1004, localNotification);
    }
  }

  private void canLowBatteryAlarm()
  {
    ((NotificationManager)this.mContext.getSystemService("notification")).cancel(1004);
  }

  private void disableRomLog()
  {
    if (this.mBlueTooth != null)
      this.mBlueTooth.disableLog(new BlueTooth.BlueToothCommonListener()
      {
        public void onFailure()
        {
          LogUtil.d("WearableService", "disableLog rom debug log fail");
        }

        public void onSuccess()
        {
          LogUtil.d("WearableService", "disableLog rom debug log success");
        }
      });
  }

  private void doLogin()
  {
    String str = BDAccountManager.getInstance().getUserData("uid");
    LogUtil.d("WearableService", "userId:" + str);
    this.mBlueTooth.login(str, new BlueTooth.BlueToothCommonListener()
    {
      public void onFailure()
      {
        LogUtil.e("WearableService", "login send failure");
        Intent localIntent = new Intent("action.wearable.ble.statemachine.connect.command");
        localIntent.putExtra("extra.wearable.ble.statemachine.connect.command", 1);
        WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent);
        WearableService.this.handleNeedSendConnectCommandAgain();
      }

      public void onSuccess()
      {
        LogUtil.d("WearableService", "login send success");
      }
    }
    , this.mLoginRetryCounter);
  }

  private void enableRomLog()
  {
    if (this.mBlueTooth != null)
    {
      this.mBlueTooth.registerLogReceiverListener(new BlueTooth.BlueToothLogReceiverListener()
      {
        public void onLogReceived(byte[] paramAnonymousArrayOfByte)
        {
          String str = new String(paramAnonymousArrayOfByte).trim();
          LogUtil.d("WearableService", "rom debug log : " + str);
          LogUtil.romDebug(str);
        }
      });
      this.mBlueTooth.enableLog(new BlueTooth.BlueToothCommonListener()
      {
        public void onFailure()
        {
          LogUtil.d("WearableService", "enableLog rom debug log fail");
        }

        public void onSuccess()
        {
          LogUtil.d("WearableService", "enableLog rom debug log success");
        }
      });
    }
  }

  private Pair<String, String> getNamePhonePair(String paramString)
  {
    String str1 = paramString.substring("@name_".length(), paramString.indexOf("@number_"));
    String str2 = paramString.substring(paramString.indexOf("@number_") + "@number_".length(), paramString.length());
    return new Pair(str1.trim(), str2.trim());
  }

  private String getSelectionArgs()
  {
    HashSet localHashSet = (HashSet)AlarmPreference.getInstance(this.mContext).getContactIDs();
    if ((localHashSet != null) && (localHashSet.size() > 0))
    {
      StringBuilder localStringBuilder = new StringBuilder();
      Iterator localIterator = localHashSet.iterator();
      for (int i = 0; ; i++)
      {
        if (!localIterator.hasNext())
          return localStringBuilder.toString();
        if (i > 0)
          localStringBuilder.append(" or ");
        String str1 = (String)localIterator.next();
        String str2 = (String)getNamePhonePair(str1).first;
        String str3 = (String)getNamePhonePair(str1).second;
        localStringBuilder.append("( ");
        localStringBuilder.append("display_name");
        localStringBuilder.append(" = ");
        localStringBuilder.append("'").append(str2.replaceAll("'", "''")).append("'");
        localStringBuilder.append(" AND ");
        localStringBuilder.append("data1");
        localStringBuilder.append(" = ");
        localStringBuilder.append("'").append(str3.replaceAll("'", "''")).append("'");
        localStringBuilder.append(" ) ");
      }
    }
    return "_id IN ('-1')";
  }

  private void handleBindSuccess(String paramString1, String paramString2)
  {
    sendProfileAndPlanSync();
    this.mBluetoothStateMachine.setBindOk(-1, paramString1);
    BluetoothState.getInstance().setBleState(5);
    BluetoothState.getInstance().setDeviceAddress(paramString1);
    setTimeAndSyncMode(paramString1, paramString2);
    syncSportData();
    updatePhoneLoss();
    updateClock();
    startRequestDataTime();
    handleRomLog();
    startDeviceInformationTime();
    startBatteryLevelTime();
    registHandringInfo(this.mContext, paramString1, paramString2);
    Intent localIntent1 = new Intent("action.wearable.ble.bind.result");
    localIntent1.putExtra("extra.wearable.ble.bind.result", 0);
    this.mLocalBroadcastManager.sendBroadcast(new Intent("com.baidu.wearable.ACTION_CHANGE_TO_BRACELET"));
    this.mLocalBroadcastManager.sendBroadcast(localIntent1);
    Intent localIntent2 = new Intent("action.wearable.ble.connect.status");
    localIntent2.putExtra("extra.wearable.ble.connect.status", 5);
    localIntent2.putExtra("extra.wearable.ble.connect.status.device.address", paramString1);
    this.mLocalBroadcastManager.sendBroadcast(localIntent2);
  }

  private void handleConnectCommandIntent(Intent paramIntent)
  {
    LogUtil.d("WearableService", "handleConnectCommandIntent");
    switch (paramIntent.getIntExtra("extra.wearable.ble.connect.command", -1))
    {
    default:
      return;
    case 0:
      LogUtil.d("WearableService", "BLE_CONNECT_COMMAND_START_SCAN");
      LogUtil.d("WearableService", "retry:" + paramIntent.getIntExtra("extra.wearable.ble.connect.command.retry.count", -2));
      Intent localIntent3 = new Intent("action.wearable.ble.statemachine.connect.command");
      localIntent3.putExtra("extra.wearable.ble.statemachine.connect.command", 0);
      int j = paramIntent.getIntExtra("extra.wearable.ble.connect.command.retry.count", -2);
      if (-2 == j)
        localIntent3.putExtra("extra.wearable.ble.statemachine.connect.command.retry.count", SCAN_RETRY_COUNT);
      while (true)
      {
        this.mLocalBroadcastManager.sendBroadcast(localIntent3);
        return;
        localIntent3.putExtra("extra.wearable.ble.statemachine.connect.command.retry.count", j);
      }
    case 2:
      LogUtil.d("WearableService", "BLE_CONNECT_COMMAND_START_CONNECT");
      LogUtil.d("WearableService", "address:" + paramIntent.getStringExtra("extra.wearable.ble.connect.command.device.address"));
      LogUtil.d("WearableService", "retry:" + paramIntent.getIntExtra("extra.wearable.ble.connect.command.retry.count", -2));
      Intent localIntent2 = new Intent("action.wearable.ble.statemachine.connect.command");
      localIntent2.putExtra("extra.wearable.ble.statemachine.connect.command", 2);
      localIntent2.putExtra("extra.wearable.ble.statemachine.connect.command.device.address", paramIntent.getStringExtra("extra.wearable.ble.connect.command.device.address"));
      int i = paramIntent.getIntExtra("extra.wearable.ble.connect.command.retry.count", -2);
      if (-2 == i)
        localIntent2.putExtra("extra.wearable.ble.statemachine.connect.command.retry.count", CONNECT_RETRY_COUNT);
      while (true)
      {
        this.mLocalBroadcastManager.sendBroadcast(localIntent2);
        return;
        localIntent2.putExtra("extra.wearable.ble.statemachine.connect.command.retry.count", i);
      }
    case 1:
      LogUtil.d("WearableService", "BLE_CONNECT_COMMAND_FINALIZE");
      Intent localIntent1 = new Intent("action.wearable.ble.statemachine.connect.command");
      localIntent1.putExtra("extra.wearable.ble.statemachine.connect.command", 1);
      this.mLocalBroadcastManager.sendBroadcast(localIntent1);
      return;
    case 3:
    }
    String str1 = BDAccountManager.getInstance().getUserData("uid");
    LogUtil.d("WearableService", "userId:" + str1);
    String str2 = str1;
    if (TextUtils.isEmpty(str1))
      str2 = "123";
    this.mBlueTooth.bind(str2, new BlueTooth.BlueToothCommonListener()
    {
      public void onFailure()
      {
        LogUtil.e("WearableService", "bind send failure");
        Intent localIntent = new Intent("action.wearable.ble.statemachine.connect.command");
        localIntent.putExtra("extra.wearable.ble.statemachine.connect.command", 1);
        WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent);
      }

      public void onSuccess()
      {
        LogUtil.d("WearableService", "bind send success");
      }
    });
  }

  private void handleDeviceConnected(final String paramString1, final String paramString2)
  {
    LogUtil.d("WearableService", "handleDeviceConnected deviceAddress:" + paramString1 + " deviceName:" + paramString2);
    this.mLoginRetryCounter = 0;
    this.mBlueTooth.registerResetBleConnect(new BlueTooth.BlueToothConnectResetListener()
    {
      public void onReset()
      {
        LogUtil.d("WearableService", "BlueToothConnectResetListener onReset");
        Intent localIntent = new Intent("action.wearable.ble.statemachine.connect.command");
        localIntent.putExtra("extra.wearable.ble.statemachine.connect.command", 1);
        WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent);
        WearableService.this.handleNeedSendConnectCommandAgain();
      }
    });
    this.mBlueTooth.initBleStackNative();
    handleSleepSettingData();
    handleSleepData();
    handleSportData();
    this.mBlueTooth.registerBondReceiverListener(new BlueTooth.BlueToothBondReceiverListener()
    {
      public void onFailure()
      {
        LogUtil.d("WearableService", "registerBondReceiverListener  failure");
        Intent localIntent1 = new Intent("action.wearable.ble.bind.result");
        localIntent1.putExtra("extra.wearable.ble.bind.result", 1);
        WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent1);
        Intent localIntent2 = new Intent("action.wearable.ble.statemachine.connect.command");
        localIntent2.putExtra("extra.wearable.ble.statemachine.connect.command", 1);
        WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent2);
      }

      public void onSuccess()
      {
        LogUtil.d("WearableService", "registerBondReceiverListener onSuccess");
        WearableService.this.handleBindSuccess(paramString1, paramString2);
      }
    });
    this.mBlueTooth.registerLoginReceiverListener(new BlueTooth.BlueToothLoginReceiverListener()
    {
      public void onFailure()
      {
        if (WearableService.this.mLoginRetryCounter == 0)
        {
          WearableService.this.mLoginRetryCounter = 1;
          WearableService.this.doLogin();
        }
        while (WearableService.this.mLoginRetryCounter != 1)
          return;
        WearableService.this.mLoginRetryCounter = 0;
        LogUtil.d("WearableService", "registerLoginReceiverListener onFailure");
        Intent localIntent1 = new Intent("action.wearable.ble.login.result");
        localIntent1.putExtra("extra.wearable.ble.bind.result", 1);
        WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent1);
        Intent localIntent2 = new Intent("action.wearable.ble.connect.status");
        localIntent2.putExtra("extra.wearable.ble.connect.status", 4);
        localIntent2.putExtra("extra.wearable.ble.need.bind.device.address", paramString1);
        localIntent2.putExtra("extra.wearable.ble.need.bind.device.name", paramString2);
        WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent2);
        new Thread()
        {
          public void run()
          {
            try
            {
              Thread.sleep(2000L);
              Intent localIntent = new Intent(WearableService.this, AddDeviceGuidActivity_bind.class);
              localIntent.addFlags(268435456);
              localIntent.putExtra("extra.baidu.wearable.activity.device.add.device.guide.bind", AddDeviceGuidActivity_bind.START_FROM_CONNECT);
              WearableService.this.mContext.startActivity(localIntent);
              return;
            }
            catch (InterruptedException localInterruptedException)
            {
              while (true)
                localInterruptedException.printStackTrace();
            }
          }
        }
        .start();
      }

      public void onSuccess()
      {
        WearableService.this.mLoginRetryCounter = 0;
        LogUtil.d("WearableService", "registerLoginReceiverListener success");
        WearableService.this.handleLoginSuccess(paramString1, paramString2);
      }
    });
    doLogin();
  }

  private void handleDeviceDisconnected(int paramInt)
  {
    BluetoothState.getInstance().setDeviceAddress(null);
    BluetoothState.getInstance().setManufactureName(null);
    BluetoothState.getInstance().setModelNumber(null);
    BluetoothState.getInstance().setHardwareRevision(null);
    BluetoothState.getInstance().setSoftwareRevision(null);
    BluetoothState.getInstance().setBatteryLevel(-1);
    stopDeviceInformationTime();
    stopBatteryLevelTime();
    stopRequestDataTime();
    BluetoothState.getInstance().setBleState(paramInt);
    Intent localIntent = new Intent("action.wearable.ble.connect.status");
    localIntent.putExtra("extra.wearable.ble.connect.status", paramInt);
    this.mLocalBroadcastManager.sendBroadcast(localIntent);
  }

  private void handleLoginSuccess(String paramString1, String paramString2)
  {
    BluetoothState.getInstance().setBleState(5);
    BluetoothState.getInstance().setDeviceAddress(paramString1);
    this.mBluetoothStateMachine.setBindOk(-1, paramString1);
    setTimeAndSyncMode(paramString1, paramString2);
    updateClock();
    startRequestDataTime();
    registHandringInfo(this.mContext, paramString1, paramString2);
    handleRomLog();
    startDeviceInformationTime();
    startBatteryLevelTime();
    Intent localIntent1 = new Intent("action.wearable.ble.login.result");
    localIntent1.putExtra("extra.wearable.ble.bind.result", 0);
    this.mLocalBroadcastManager.sendBroadcast(localIntent1);
    this.mLocalBroadcastManager.sendBroadcast(new Intent("com.baidu.wearable.ACTION_CHANGE_TO_BRACELET"));
    Intent localIntent2 = new Intent("action.wearable.ble.connect.status");
    localIntent2.putExtra("extra.wearable.ble.connect.status", 5);
    localIntent2.putExtra("extra.wearable.ble.connect.status.device.address", paramString1);
    this.mLocalBroadcastManager.sendBroadcast(localIntent2);
  }

  private void handleNeedSendRequestData()
  {
    LogUtil.d("WearableService", "handleNeedSendRequestData");
    if ((!this.mIsMainActivityInForground) && (BluetoothState.getInstance().getBleState() == 5))
      this.mBlueTooth.requestData(new BlueTooth.BlueToothCommonListener()
      {
        public void onFailure()
        {
          LogUtil.e("WearableService", "send requestData onFailure");
        }

        public void onSuccess()
        {
          LogUtil.d("WearableService", "send requestData onSuccess");
        }
      });
  }

  private void handleNeedSportDataSync()
  {
    LogUtil.d("WearableService", "handleNeedSportDataSync");
    if ((this.mIsMainActivityInForground) && (BluetoothState.getInstance().getBleState() == 5))
    {
      LogUtil.d("WearableService", "need to set  setDataSync enable");
      this.mBlueTooth.setDataSync(new BlueTooth.BlueToothCommonListener()
      {
        public void onFailure()
        {
          LogUtil.e("WearableService", "mBlueTooth setDataSync onFailure");
          WearableService.this.mSyncDataTimer = new Timer();
          WearableService.this.mSyncDataTimer.schedule(new WearableService.SyncDataTimeTask(WearableService.this), 5000L);
        }

        public void onSuccess()
        {
          LogUtil.d("WearableService", "mBlueTooth setDataSync onSuccess");
        }
      }
      , 1);
    }
    while (BluetoothState.getInstance().getBleState() != 5)
      return;
    LogUtil.d("WearableService", "need to set  setDataSync disable");
    this.mBlueTooth.setDataSync(new BlueTooth.BlueToothCommonListener()
    {
      public void onFailure()
      {
        LogUtil.e("WearableService", "mBlueTooth setDataSync onFailure");
        WearableService.this.mSyncDataTimer = new Timer();
        WearableService.this.mSyncDataTimer.schedule(new WearableService.SyncDataTimeTask(WearableService.this), 5000L);
      }

      public void onSuccess()
      {
        LogUtil.d("WearableService", "mBlueTooth setDataSync onSuccess");
      }
    }
    , 0);
  }

  private void handlePhoneSportData(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong)
  {
    if (this.mJniAlgorithm != null)
    {
      final int i = this.mJniAlgorithm.newDataIn(paramFloat1, paramFloat2, paramFloat3, paramLong);
      if (i > 0)
      {
        double d1 = this.mJniAlgorithm.getStepLength();
        final double d2 = this.mJniAlgorithm.getCalory();
        LogUtil.d("WearableService", "step count:" + i + ", distance:" + d1 + ", calory:" + d2);
        SportController.saveSportPart(this, new SportPart(i, (float)d2, (float)d1), new SportController.PhoneSportListener()
        {
          public void onReceive(SportPart paramAnonymousSportPart)
          {
            Intent localIntent = new Intent();
            localIntent.setAction("com.baidu.wearable.STEP_COLLECT");
            localIntent.putExtra("steps", i);
            localIntent.putExtra("calories", (float)d2);
            localIntent.putExtra("distance_m", (float)this.val$distance);
            WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent);
          }
        });
      }
    }
  }

  private void handleRomLog()
  {
    if (RomDebugManager.getInstance(this).isRomDebug())
    {
      enableRomLog();
      return;
    }
    disableRomLog();
  }

  private void handleSleepData()
  {
    SleepBlueTooth.setOnSleepListener(new SleepController.SleepDetailListener()
    {
      public void onReceive(List<SleepDetail> paramAnonymousList)
      {
        LogUtil.d("WearableService", "receive sleep data");
        SleepController.saveSleepToDb(WearableService.this, paramAnonymousList, true);
      }
    });
  }

  private void handleSleepSettingData()
  {
    SleepBlueTooth.setOnSleepSettingListener(new SleepController.SleepSettingDetailListener()
    {
      public void onReceive(List<SleepSettingDetail> paramAnonymousList)
      {
        LogUtil.d("WearableService", "receive sleep setting data");
        WearableService.this.mSilentSleepManager.onSleepSettingsComing(paramAnonymousList);
        SleepController.addSleepSettingTask(WearableService.this, paramAnonymousList);
      }
    });
  }

  private void handleSportData()
  {
    SportBlueTooth.setOnSportListener(new SportController.SportListener()
    {
      public void onReceive(List<Sport> paramAnonymousList)
      {
        SportController.saveSportData(WearableService.this, paramAnonymousList);
      }
    });
  }

  private void handleStateMachineStateIntent(Intent paramIntent)
  {
    LogUtil.d("WearableService", "handleStateMachineStateIntent");
    switch (paramIntent.getIntExtra("extra.wearable.ble.statemachine.connect.state", -1))
    {
    default:
      return;
    case 2:
      handleDeviceDisconnected(2);
      return;
    case 3:
      handleDeviceDisconnected(3);
      return;
    case 0:
      handleDeviceDisconnected(0);
      this.mBlueTooth.finalizeBleStackNative();
      this.mCanLowBatteryAlarmAtFirtstLevel = true;
      this.mCanLowBatteryAlarmAtSecondLevel = true;
      return;
    case 1:
      handleDeviceDisconnected(1);
      this.mBlueTooth.finalizeBleStackNative();
      return;
    case 4:
    }
    BluetoothState.getInstance().setBleState(4);
    BluetoothState.getInstance().setDeviceAddress(null);
    handleDeviceConnected(paramIntent.getStringExtra("extra.wearable.ble.statemachine.connect.state.device.address"), paramIntent.getStringExtra("extra.wearable.ble.statemachine.connect.state.device.name"));
  }

  private void initAlgorithm(boolean paramBoolean, int paramInt1, float paramFloat, int paramInt2)
  {
    LogUtil.d("WearableService", "initAlgorithm isFemale:" + paramBoolean + ", height:" + paramInt1 + ", weight:" + paramFloat + ", age:" + paramInt2);
    if (paramBoolean)
    {
      if (paramInt1 <= 0)
        paramInt1 = 165;
      if (paramFloat <= 0.0F)
        paramFloat = 50.0F;
      if ((paramInt2 > 0) && (paramInt2 <= 200));
    }
    for (paramInt2 = 28; ; paramInt2 = 28)
      do
      {
        if (this.mJniAlgorithm != null)
        {
          this.mJniAlgorithm.algorithm_finalize();
          this.mJniAlgorithm = null;
        }
        this.mJniAlgorithm = new JniAlgorithm();
        LogUtil.d("WearableService", "algorithm init isFemale:" + paramBoolean + ", height:" + paramInt1 + ", (int)weight:" + (int)paramFloat + ", age:" + paramInt2);
        JniAlgorithm localJniAlgorithm = this.mJniAlgorithm;
        int i = (int)paramFloat;
        localJniAlgorithm.init(20, paramInt1, i, paramInt2, paramBoolean);
        return;
        if (paramInt1 <= 0)
          paramInt1 = 173;
        if (paramFloat <= 0.0F)
          paramFloat = 65.0F;
      }
      while ((paramInt2 > 0) && (paramInt2 <= 200));
  }

  private void initProfile()
  {
    ProfilePreference localProfilePreference = ProfilePreference.getInstance(this);
    int i = localProfilePreference.getHeight();
    float f = localProfilePreference.getWeight();
    int j = localProfilePreference.getAge(localProfilePreference.getYear());
    if (localProfilePreference.getGender() == Gender.female);
    for (boolean bool = true; ; bool = false)
    {
      initAlgorithm(bool, i, f, j);
      return;
    }
  }

  private void initReceiver()
  {
    LogUtil.d("WearableService", "initReceiver");
    this.mReceiver = new Receiver(this);
    this.mReceiver.addAction("com.baidu.wearable.BRACELET_REQUEST_DATA");
    this.mReceiver.addAction("com.baidu.wearable.BRACELET_SEND_TEST_DATA");
    this.mReceiver.addAction("com.baidu.wearable.ACTION_CHANGE_TO_PHONE");
    this.mReceiver.addAction("com.baidu.wearable.ACTION_CHANGE_TO_BRACELET");
    this.mReceiver.addAction("com.baidu.wearable.ACTION_GET_DATA_FOREGROUND");
    this.mReceiver.addAction("com.baidu.wearable.ACTION_GET_DATA_BACKGROUND");
    this.mReceiver.addAction("com.baidu.wearable.ACTION_PROFILE_CHANGE");
    this.mReceiver.addAction("action.wearable.ble.connect.command");
    this.mReceiver.addAction("action.wearable.ble.statemachine.connect.state");
    this.mReceiver.addAction("com.baidu.wearable.ACTION_SYNC_DATA");
    this.mReceiver.addAction("action.wearable.ble.battery.level");
    this.mReceiver.addAction("com.baidu.wearable.ACTION_SWITCH_ROM_DEBUG_LOG");
    this.mReceiver.registerAction();
  }

  private String phoneNumFormat(String paramString)
  {
    if (!TextUtils.isEmpty(paramString))
    {
      if (paramString.startsWith("+86"))
        paramString = paramString.replace("+86", "");
      return paramString.replace("-", "").replace(" ", "");
    }
    return null;
  }

  private void readHardwareRevision()
  {
    if (this.mBluetoothStateMachine == null)
      return;
    this.mBluetoothStateMachine.readHardwareRevision(new BluetoothLeStateMachine.ReadDeviceInformationCallback()
    {
      public void onFinish(int paramAnonymousInt, String paramAnonymousString)
      {
        LogUtil.d("WearableService", "readHardwareRevision onFinish statue:" + paramAnonymousInt + " value:" + paramAnonymousString);
        if (paramAnonymousInt == 0)
        {
          BluetoothState.getInstance().setHardwareRevision(paramAnonymousString);
          WearableService.this.readSoftwareRevision();
        }
      }
    });
  }

  private void readManufactureName()
  {
    if (this.mBluetoothStateMachine == null)
      return;
    this.mBluetoothStateMachine.readManufactureName(new BluetoothLeStateMachine.ReadDeviceInformationCallback()
    {
      public void onFinish(int paramAnonymousInt, String paramAnonymousString)
      {
        LogUtil.d("WearableService", "readManufactureName onFinish statue:" + paramAnonymousInt + " value:" + paramAnonymousString);
        if (paramAnonymousInt == 0)
          BluetoothState.getInstance().setManufactureName(paramAnonymousString);
        WearableService.this.readModelNumber();
      }
    });
  }

  private void readModelNumber()
  {
    if (this.mBluetoothStateMachine == null)
      return;
    this.mBluetoothStateMachine.readModelNumber(new BluetoothLeStateMachine.ReadDeviceInformationCallback()
    {
      public void onFinish(int paramAnonymousInt, String paramAnonymousString)
      {
        LogUtil.d("WearableService", "readModelNumber onFinish statue:" + paramAnonymousInt + " value:" + paramAnonymousString);
        if (paramAnonymousInt == 0)
        {
          BluetoothState.getInstance().setModelNumber(paramAnonymousString);
          WearableService.this.readHardwareRevision();
        }
      }
    });
  }

  private void readSoftwareRevision()
  {
    if (this.mBluetoothStateMachine == null)
      return;
    this.mBluetoothStateMachine.readSoftwareRevision(new BluetoothLeStateMachine.ReadDeviceInformationCallback()
    {
      public void onFinish(int paramAnonymousInt, String paramAnonymousString)
      {
        LogUtil.d("WearableService", "readSoftwareRevision onFinish statue:" + paramAnonymousInt + " value:" + paramAnonymousString);
        if (paramAnonymousInt == 0)
          BluetoothState.getInstance().setSoftwareRevision(paramAnonymousString);
      }
    });
  }

  private void registHandringInfo(Context paramContext, String paramString1, String paramString2)
  {
    final TrackerHelper localTrackerHelper = TrackerHelper.getInstance(paramContext);
    localTrackerHelper.saveHandringRegisterInfo(paramString1);
    LogUtil.d("WearableService", "registHandringInfo and model is " + localTrackerHelper.getTrackerModel());
    TrackerTransport.getInstance(paramContext).registerTracker(new Transport.CommonListener()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        localTrackerHelper.setRegisterState(false);
        LogUtil.e("WearableService", "registHandringInfo onFailure errCode is " + paramAnonymousInt + ",errMsg : " + paramAnonymousString);
      }

      public void onSuccess()
      {
        localTrackerHelper.setRegisterState(true);
        LogUtil.d("WearableService", "registerTracker onSuccess");
      }
    }
    , localTrackerHelper.getHandringTrackerList());
  }

  private void releaseWakeLock()
  {
    LogUtil.d("WearableService", "releaseWakeLock");
    if (this.mWakeLock != null)
    {
      this.mWakeLock.release();
      this.mWakeLock = null;
    }
  }

  private void sendProfileAndPlanSync()
  {
    this.mProfileMgr.sendProfileToBlueTooth();
    this.mPlanMgr.sendPlanToBlueTooth();
  }

  private void setTimeAndSyncMode(String paramString1, String paramString2)
  {
    LogUtil.d("WearableService", "registerLoginReceiverListener login  success");
    this.mBlueTooth.setTime(new BlueTooth.BlueToothCommonListener()
    {
      public void onFailure()
      {
        WearableService.this.mSetTimeOk = false;
        LogUtil.d("WearableService", "set time send failure");
      }

      public void onSuccess()
      {
        WearableService.this.mSetTimeOk = true;
        WearableService.this.handleNeedSportDataSync();
      }
    });
  }

  private void startBatteryLevelTime()
  {
    LogUtil.d("WearableService", "startBatteryLevelTime");
    this.mReadBatteryLevelTimer = new Timer();
    this.mReadBatteryLevelTimer.schedule(new BatteryLevelTimeTask(), 8000L);
  }

  private void startDeviceInformationTime()
  {
    LogUtil.d("WearableService", "startDeviceInformationTime");
    this.mDeviceInformationTimer = new Timer();
    this.mDeviceInformationTimer.schedule(new DeviceInfomationTimeTask(), 8000L);
  }

  private void startPhoneSensor()
  {
    LogUtil.d("WearableService", "startPhoneSensor");
    acquireWakeLock();
    this.mSensorManager = ((SensorManager)getSystemService("sensor"));
    Sensor localSensor = this.mSensorManager.getDefaultSensor(1);
    this.mSensorManager.registerListener(this, localSensor, 50000);
  }

  private void startRequestDataTime()
  {
    LogUtil.d("WearableService", "startRequestDataTime");
    this.mRequestDataTimer = new Timer();
    this.mRequestDataTimer.schedule(new RequestDataTimeTask(), 3600000L);
  }

  private void startUnuseAlarm()
  {
    Intent localIntent = new Intent(this.mContext, AlarmReceiver.class);
    localIntent.setAction("com.baidu.wearable.alarm_sync_date_action");
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(this.mContext, 10001, localIntent, 0);
    Date localDate = new Date(System.currentTimeMillis());
    localDate.setHours(24);
    localDate.setMinutes(0);
    localDate.setSeconds(0);
    AlarmManager localAlarmManager = (AlarmManager)this.mContext.getSystemService("alarm");
    localAlarmManager.cancel(localPendingIntent);
    localAlarmManager.setRepeating(1, localDate.getTime(), 86400000L, localPendingIntent);
  }

  private void stopBatteryLevelTime()
  {
    try
    {
      LogUtil.d("WearableService", "stopBatteryLevelTime");
      if (this.mReadBatteryLevelTimer != null)
      {
        this.mReadBatteryLevelTimer.cancel();
        this.mReadBatteryLevelTimer.purge();
        this.mReadBatteryLevelTimer = null;
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private void stopDeviceInformationTime()
  {
    try
    {
      LogUtil.d("WearableService", "stopDeviceInformationTime");
      if (this.mDeviceInformationTimer != null)
      {
        this.mDeviceInformationTimer.cancel();
        this.mDeviceInformationTimer.purge();
        this.mDeviceInformationTimer = null;
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private void stopPhoneSensor()
  {
    LogUtil.d("WearableService", "stopPhoneSensor");
    if (this.mSensorManager != null)
    {
      this.mSensorManager.unregisterListener(this);
      this.mSensorManager = null;
    }
    releaseWakeLock();
  }

  private void stopRequestDataTime()
  {
    try
    {
      LogUtil.d("WearableService", "stopRequestDataTime");
      if (this.mRequestDataTimer != null)
      {
        this.mRequestDataTimer.cancel();
        this.mRequestDataTimer.purge();
        this.mRequestDataTimer = null;
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  private void syncDailySportData()
  {
    List localList = SportDao.selectSportSummary(Database.getDb(this), TimeUtil.getDayStart() / 1000L);
    int i = 0;
    float f1 = 0.0F;
    float f2 = 0.0F;
    Iterator localIterator = localList.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        LogUtil.debug("sync sport data daily_step:" + i + " daily_distance:" + f1 + " daily_calory:" + f2);
        this.mBlueTooth.setDailySportData(new BlueTooth.BlueToothCommonListener()
        {
          public void onFailure()
          {
            LogUtil.debug("sync sport data daily failure");
          }

          public void onSuccess()
          {
            LogUtil.debug("sync sport data daily success");
          }
        }
        , i, (int)f1, (int)(1000.0F * f2));
        return;
      }
      SportSummary localSportSummary = (SportSummary)localIterator.next();
      LogUtil.d("WearableService", " steps: " + localSportSummary.getSteps());
      i += localSportSummary.getSteps();
      f1 += localSportSummary.getDistance();
      f2 += localSportSummary.getCalories();
    }
  }

  private void syncRecentSportData()
  {
    SQLiteDatabase localSQLiteDatabase = Database.getDb(getApplicationContext());
    long l1 = TimeUtil.getDurationStart() / 1000L;
    long l2 = l1 + 900L;
    LogUtil.debug("sync sport data recent start timestamp:" + l1 + ", start time:" + TimeUtil.getReadableTime(l1) + ", end timestamp:" + l2 + ", end time:" + TimeUtil.getReadableTime(l2));
    List localList = SportDao.selectSportDetail(localSQLiteDatabase, l1, l2);
    LogUtil.debug("sync sport data recent details count:" + localList.size());
    if (localList.size() < 0)
      return;
    int i = localList.size();
    int j = 0;
    int k = 0;
    int m = 0;
    if (i > 0)
    {
      j = ((SportDetail)localList.get(0)).getSteps();
      m = (int)(1000.0F * ((SportDetail)localList.get(0)).getCalories());
      k = (int)((SportDetail)localList.get(0)).getDistance();
    }
    LogUtil.debug("sync sport data recent step:" + j + ", calories:" + m + ", distance:" + k);
    this.mBlueTooth.syncRecentlySportData(new BlueTooth.BlueToothCommonListener()
    {
      public void onFailure()
      {
        LogUtil.debug("sync sport data recent failure");
      }

      public void onSuccess()
      {
        LogUtil.debug("sync sport data recent success");
      }
    }
    , 0, 0, j, k, m);
  }

  private void syncSportData()
  {
    syncDailySportData();
    syncRecentSportData();
  }

  private void updateClock()
  {
    if (ClockManager.isInit(this))
    {
      ClockManager.init(this);
      ClockManager.requestClockFromRing(this);
      return;
    }
    ClockManager.setClockToRing(this);
  }

  private void updatePhoneLoss()
  {
    boolean bool = AlarmPreference.getInstance(this.mContext).getMyphoneAntiLostState();
    this.mSettingNetSyncManager.updatePhoneLossSetting(bool);
  }

  public void handleNeedSendConnectCommandAgain()
  {
    TrackerHelper localTrackerHelper = TrackerHelper.getInstance(getApplicationContext());
    if (localTrackerHelper.isHandringMode())
    {
      LogUtil.d("WearableService", "is isHandringMode mode so we need to connect the device, address锛�" + localTrackerHelper.getTrackerID());
      Intent localIntent = new Intent("action.wearable.ble.statemachine.connect.command");
      localIntent.putExtra("extra.wearable.ble.statemachine.connect.command", 2);
      localIntent.putExtra("extra.wearable.ble.statemachine.connect.command.retry.count", CONNECT_RETRY_COUNT);
      localIntent.putExtra("extra.wearable.ble.statemachine.connect.command.device.address", localTrackerHelper.getTrackerID());
      this.mLocalBroadcastManager.sendBroadcast(localIntent);
    }
  }

  public void onAccuracyChanged(Sensor paramSensor, int paramInt)
  {
  }

  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }

  public void onCreate()
  {
    LogUtil.init();
    LogUtil.debug("onCreate");
    super.onCreate();
    this.mContext = this;
    initReceiver();
    if (PhoneCheck.isBleSupport(this))
    {
      BluetoothState.getInstance().setBleState(-1);
      BluetoothState.getInstance().setDeviceAddress(null);
      this.mBlueTooth = BlueTooth.getInstance();
    }
    this.mDb = Database.getDb(this);
    this.mPlanMgr = PlanPreference.getInstance(this);
    this.mProfileMgr = ProfilePreference.getInstance(this);
    this.mWarnMgr = AlarmPreference.getInstance(this);
    this.mTelephonyManager = ((TelephonyManager)getSystemService("phone"));
    this.mTelephonyManager.listen(new MyPhoneStateListener(), 32);
    this.mSettingNetSyncManager = SettingsSyncManager.getInstance(this);
    startUnuseAlarm();
    startBatteryLevelTime();
    this.mSilentSleepManager = SilentSleepManager.getInstance(this);
    for (int i = 0; ; i++)
    {
      if (i >= 20)
      {
        this.sensorDataCount = 0;
        return;
      }
      SensorData localSensorData = new SensorData(null);
      this.sensorDatas.add(localSensorData);
    }
  }

  public void onDestroy()
  {
    super.onDestroy();
    LogUtil.debug("onDestroy");
    if (PhoneCheck.isBleSupport(this))
    {
      BluetoothState.getInstance().setBleState(-1);
      BluetoothState.getInstance().setDeviceAddress(null);
    }
    if (this.mPhoneFlag)
      stopPhoneSensor();
    this.sensorDatas.clear();
    this.sensorDataCount = 0;
    Intent localIntent = new Intent("action.wearable.ble.statemachine.connect.command");
    localIntent.putExtra("extra.wearable.ble.statemachine.connect.command", 1);
    this.mLocalBroadcastManager.sendBroadcast(localIntent);
    if (this.mBluetoothStateMachine != null)
      this.mBluetoothStateMachine.finalize();
    if (this.mJniAlgorithm != null)
    {
      this.mJniAlgorithm.algorithm_finalize();
      this.mJniAlgorithm = null;
    }
    this.mLocalBroadcastManager.unregisterReceiver(this.mReceiver);
    stopBatteryLevelTime();
    stopDeviceInformationTime();
  }

  public void onSensorChanged(SensorEvent paramSensorEvent)
  {
    Sensor localSensor = paramSensorEvent.sensor;
    try
    {
      if ((localSensor.getType() == 1) && (this.mSensorManager != null))
      {
        ((SensorData)this.sensorDatas.get(this.sensorDataCount)).x = paramSensorEvent.values[0];
        ((SensorData)this.sensorDatas.get(this.sensorDataCount)).y = paramSensorEvent.values[1];
        ((SensorData)this.sensorDatas.get(this.sensorDataCount)).z = paramSensorEvent.values[2];
        ((SensorData)this.sensorDatas.get(this.sensorDataCount)).millis = System.currentTimeMillis();
        this.sensorDataCount = (1 + this.sensorDataCount);
        if (this.sensorDataCount != 20);
      }
      for (int i = 0; ; i++)
      {
        if (i >= this.sensorDataCount)
        {
          this.sensorDataCount = 0;
          return;
        }
        handlePhoneSportData(((SensorData)this.sensorDatas.get(i)).x, ((SensorData)this.sensorDatas.get(i)).y, ((SensorData)this.sensorDatas.get(i)).z, ((SensorData)this.sensorDatas.get(i)).millis);
      }
    }
    finally
    {
    }
  }

  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    LogUtil.d("WearableService", "onStartCommand, isLogin:" + BDAccountManager.getInstance().isLogin());
    return 1;
  }

  class BatteryLevelTimeTask extends TimerTask
  {
    BatteryLevelTimeTask()
    {
    }

    public void run()
    {
      LogUtil.d("WearableService", "BatteryLevelTimeTask");
      if (WearableService.this.mBluetoothStateMachine == null)
        return;
      WearableService.this.mBluetoothStateMachine.readBatterLevel(new BluetoothLeStateMachine.ReadBatteryLevelCallback()
      {
        public void onFinish(int paramAnonymousInt1, int paramAnonymousInt2)
        {
          LogUtil.d("WearableService", "readBatterLevel onFinish statue:" + paramAnonymousInt1 + " value:" + paramAnonymousInt2);
          BluetoothState.getInstance().setBatteryLevel(paramAnonymousInt2);
          if (paramAnonymousInt1 == -1)
          {
            if (WearableService.this.mReadBatteryLevelTimer != null)
            {
              WearableService.this.mReadBatteryLevelTimer.cancel();
              WearableService.this.mReadBatteryLevelTimer.purge();
              WearableService.this.mReadBatteryLevelTimer = null;
            }
            WearableService.this.mReadBatteryLevelTimer = new Timer();
            WearableService.this.mReadBatteryLevelTimer.schedule(new WearableService.BatteryLevelTimeTask(WearableService.this), 10000L);
            return;
          }
          Intent localIntent = new Intent("action.wearable.ble.battery.level");
          localIntent.putExtra("extra.wearable.ble.battery.level", paramAnonymousInt2);
          WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent);
        }
      });
      WearableService.this.mReadBatteryLevelTimer = new Timer();
      WearableService.this.mReadBatteryLevelTimer.schedule(new BatteryLevelTimeTask(WearableService.this), 300000L);
    }
  }

  class DeviceInfomationTimeTask extends TimerTask
  {
    DeviceInfomationTimeTask()
    {
    }

    public void run()
    {
      LogUtil.d("WearableService", "DeviceInfomationTimeTask");
      if ((BluetoothState.getInstance().getManufactureName() != null) && (BluetoothState.getInstance().getModelNumber() != null) && (BluetoothState.getInstance().getHardwareRevision() != null) && (BluetoothState.getInstance().getSoftwareRevision() != null))
      {
        WearableService.this.stopDeviceInformationTime();
        LogUtil.d("WearableService", "Device Infomation have been got");
        Intent localIntent = new Intent("action.wearable.ble.device.information");
        localIntent.putExtra("extra.wearable.ble.device.information.manufacture.name", BluetoothState.getInstance().getManufactureName());
        localIntent.putExtra("extra.wearable.ble.device.information.model.number", BluetoothState.getInstance().getModelNumber());
        localIntent.putExtra("extra.wearable.ble.device.information.hardware.revision", BluetoothState.getInstance().getHardwareRevision());
        localIntent.putExtra("extra.wearable.ble.device.information.software.revision", BluetoothState.getInstance().getSoftwareRevision());
        WearableService.this.mLocalBroadcastManager.sendBroadcast(localIntent);
        return;
      }
      WearableService.this.readManufactureName();
      WearableService.this.mDeviceInformationTimer = new Timer();
      WearableService.this.mDeviceInformationTimer.schedule(new DeviceInfomationTimeTask(WearableService.this), 5000L);
    }
  }

  class MyPhoneStateListener extends PhoneStateListener
  {
    private static final String TAG = "MyPhoneStateListener";
    final String[] PROJECTION = { "_id", "data1", "raw_contact_id" };
    private boolean mIsVipPhoneNum = false;

    MyPhoneStateListener()
    {
    }

    public void onCallStateChanged(int paramInt, String paramString)
    {
      if (!AlarmPreference.getInstance(WearableService.this.mContext).getCallingAlarmSwitcher())
      {
        LogUtil.d("MyPhoneStateListener", "鏉ョ數鎻愰啋鐨勫紑鍏虫病寮�");
        return;
      }
      switch (paramInt)
      {
      default:
      case 0:
      case 1:
      case 2:
      }
      while (true)
      {
        super.onCallStateChanged(paramInt, paramString);
        return;
        LogUtil.d("------------", "-----鐢佃瘽缁撴潫----" + paramString);
        if ((WearableService.this.mBluetoothStateMachine != null) && (WearableService.this.mBluetoothStateMachine.getStateMachineState() == 4) && (WearableService.this.mSetTimeOk) && (this.mIsVipPhoneNum))
          BlueTooth.getInstance().phoneDeny(new BlueTooth.BlueToothCommonListener()
          {
            public void onFailure()
            {
            }

            public void onSuccess()
            {
            }
          });
        this.mIsVipPhoneNum = false;
        continue;
        this.mIsVipPhoneNum = false;
        LogUtil.d("MyPhoneStateListener", "鏉ョ數鍙风爜 " + paramString);
        String str = WearableService.this.phoneNumFormat(paramString);
        if (!TextUtils.isEmpty(str))
        {
          new AsyncTask()
          {
            protected Boolean doInBackground(String[] paramAnonymousArrayOfString)
            {
              Uri localUri = Uri.parse("content://com.android.contacts/data");
              String str1 = WearableService.this.getSelectionArgs();
              Cursor localCursor = WearableService.this.mContext.getContentResolver().query(localUri, WearableService.MyPhoneStateListener.this.PROJECTION, str1, null, null);
              if (localCursor != null);
              try
              {
                String str2;
                do
                {
                  do
                  {
                    boolean bool = localCursor.moveToNext();
                    if (!bool)
                    {
                      if (localCursor != null)
                        localCursor.close();
                      localObject1 = Boolean.valueOf(false);
                      return localObject1;
                    }
                  }
                  while ((localCursor == null) || (localCursor.getCount() <= 0));
                  str2 = localCursor.getString(localCursor.getColumnIndexOrThrow("data1"));
                  LogUtil.d("MyPhoneStateListener", "DB phone is " + str2);
                }
                while (!paramAnonymousArrayOfString[0].equals(WearableService.this.phoneNumFormat(str2)));
                Boolean localBoolean = Boolean.valueOf(true);
                Object localObject1 = localBoolean;
                return localObject1;
              }
              finally
              {
                if (localCursor != null)
                  localCursor.close();
              }
            }

            protected void onPostExecute(Boolean paramAnonymousBoolean)
            {
              LogUtil.d("MyPhoneStateListener", " isVip " + paramAnonymousBoolean);
              if (paramAnonymousBoolean.booleanValue())
              {
                WearableService.MyPhoneStateListener.this.mIsVipPhoneNum = true;
                BlueTooth.getInstance().phoneComming(new BlueTooth.BlueToothCommonListener()
                {
                  public void onFailure()
                  {
                  }

                  public void onSuccess()
                  {
                  }
                });
              }
              while (true)
              {
                super.onPostExecute(paramAnonymousBoolean);
                return;
                WearableService.MyPhoneStateListener.this.mIsVipPhoneNum = false;
              }
            }
          }
          .execute(new String[] { str });
          continue;
          LogUtil.d("MyPhoneStateListener", " 鐢佃瘽琚帴閫� " + paramString);
          if ((this.mIsVipPhoneNum) && (WearableService.this.mBluetoothStateMachine.getStateMachineState() == 4) && (WearableService.this.mSetTimeOk))
            BlueTooth.getInstance().phoneAnswer(new BlueTooth.BlueToothCommonListener()
            {
              public void onFailure()
              {
              }

              public void onSuccess()
              {
              }
            });
        }
      }
    }
  }

  class Receiver extends BroadcastReceiver
  {
    Context mContext;
    private IntentFilter mIntentFilter;

    public Receiver(Context arg2)
    {
      Object localObject;
      this.mContext = localObject;
      WearableService.this.mLocalBroadcastManager = LocalBroadcastManager.getInstance(this.mContext);
      this.mIntentFilter = new IntentFilter();
    }

    public void addAction(String paramString)
    {
      this.mIntentFilter.addAction(paramString);
    }

    public void onReceive(Context paramContext, Intent paramIntent)
    {
      String str = paramIntent.getAction();
      LogUtil.d("WearableService", "onReceive action:" + str);
      if (str.equals("com.baidu.wearable.BRACELET_REQUEST_DATA"))
      {
        LogUtil.d("WearableService", Thread.currentThread().getName() + "-------BRACELET_REQUEST_DATA_INTENT-----");
        if (WearableService.this.mBluetoothStateMachine == null)
          WearableService.this.mBluetoothStateMachine = BluetoothLeStateMachine.getInstance(WearableService.this.getApplicationContext());
        if ((WearableService.this.mBluetoothStateMachine.getStateMachineState() == 4) && (WearableService.this.mSetTimeOk))
          WearableService.this.mBlueTooth.requestData(new BlueTooth.BlueToothCommonListener()
          {
            public void onFailure()
            {
              LogUtil.d("WearableService", "request data send failure");
            }

            public void onSuccess()
            {
              LogUtil.d("WearableService", "request data send success");
            }
          });
      }
      do
      {
        boolean bool;
        do
        {
          int i;
          do
          {
            do
            {
              BluetoothState localBluetoothState;
              do
              {
                do
                {
                  return;
                  if (str.equals("action.wearable.ble.connect.command"))
                  {
                    LogUtil.d("WearableService", "receive ACTION_BLE_CONNECT_COMMAND");
                    if (WearableService.this.mBluetoothStateMachine == null)
                      WearableService.this.mBluetoothStateMachine = BluetoothLeStateMachine.getInstance(WearableService.this.getApplicationContext());
                    WearableService.this.handleConnectCommandIntent(paramIntent);
                    return;
                  }
                  if (str.equals("action.wearable.ble.statemachine.connect.state"))
                  {
                    WearableService.this.handleStateMachineStateIntent(paramIntent);
                    return;
                  }
                  if (str.equals("com.baidu.wearable.BRACELET_SEND_TEST_DATA"))
                  {
                    LogUtil.d("WearableService", "BRACELET_SEND_TEST_DATA_INTENT");
                    return;
                  }
                  if (!str.equals("com.baidu.wearable.ACTION_CHANGE_TO_PHONE"))
                    break;
                  LogUtil.d("WearableService", "action change to phone and mPhoneFlag is " + WearableService.this.mPhoneFlag);
                }
                while (WearableService.this.mPhoneFlag);
                LogUtil.d("WearableService", "change to phone");
                WearableService.this.initProfile();
                WearableService.this.startPhoneSensor();
                WearableService.this.mPhoneFlag = true;
                return;
                if (str.equals("com.baidu.wearable.ACTION_CHANGE_TO_BRACELET"))
                {
                  LogUtil.d("WearableService", "change to bracelet");
                  if (WearableService.this.mPhoneFlag)
                    WearableService.this.stopPhoneSensor();
                  WearableService.this.mPhoneFlag = false;
                  return;
                }
                if (str.equals("com.baidu.wearable.ACTION_PROFILE_CHANGE"))
                {
                  WearableService.this.initProfile();
                  return;
                }
                if (str.equals("com.baidu.wearable.ACTION_GET_DATA_FOREGROUND"))
                {
                  LogUtil.d("WearableService", "receive ACTION_GET_DATA_FOREGROUND");
                  WearableService.this.mIsMainActivityInForground = true;
                  WearableService.this.handleNeedSportDataSync();
                  return;
                }
                if (str.equals("com.baidu.wearable.ACTION_GET_DATA_BACKGROUND"))
                {
                  LogUtil.d("WearableService", "receive ACTION_GET_DATA_BACKGROUND");
                  WearableService.this.mIsMainActivityInForground = false;
                  WearableService.this.handleNeedSportDataSync();
                  return;
                }
                if (!str.equals("action.wearable.ble.battery.level"))
                  break;
                localBluetoothState = BluetoothState.getInstance();
              }
              while (localBluetoothState == null);
              i = localBluetoothState.getBatteryLevel();
              LogUtil.d("WearableService", "the battery level is " + i);
            }
            while (-1 == i);
            if ((i > 10) && (!WearableService.this.mCanLowBatteryAlarmAtFirtstLevel))
              WearableService.this.mCanLowBatteryAlarmAtFirtstLevel = true;
            if ((i > 20) && (!WearableService.this.mCanLowBatteryAlarmAtSecondLevel))
            {
              WearableService.this.mCanLowBatteryAlarmAtSecondLevel = true;
              WearableService.this.canLowBatteryAlarm();
            }
            if ((i < 10) && (WearableService.this.mCanLowBatteryAlarmAtFirtstLevel))
            {
              WearableService.this.alarmLowBattery(10);
              WearableService.this.mCanLowBatteryAlarmAtFirtstLevel = false;
              return;
            }
          }
          while ((i >= 20) || (!WearableService.this.mCanLowBatteryAlarmAtSecondLevel));
          WearableService.this.alarmLowBattery(20);
          WearableService.this.mCanLowBatteryAlarmAtSecondLevel = false;
          return;
          if (!str.equals("com.baidu.wearable.ACTION_SWITCH_ROM_DEBUG_LOG"))
            break;
          bool = paramIntent.getBooleanExtra("com.baidu.wearable.ACTION_SWITCH_ROM_DEBUG_VALUE", false);
        }
        while (WearableService.this.mBluetoothStateMachine.getStateMachineState() != 4);
        if (bool)
        {
          WearableService.this.enableRomLog();
          return;
        }
        WearableService.this.disableRomLog();
        return;
      }
      while (!str.equals("com.baidu.wearable.ACTION_SYNC_DATA"));
      WearableService.this.syncSportData();
    }

    public void registerAction()
    {
      WearableService.this.mLocalBroadcastManager.registerReceiver(this, this.mIntentFilter);
    }
  }

  class RequestDataTimeTask extends TimerTask
  {
    RequestDataTimeTask()
    {
    }

    public void run()
    {
      LogUtil.d("WearableService", "RequestDataTimeTask");
      WearableService.this.handleNeedSendRequestData();
      WearableService.this.mRequestDataTimer = new Timer();
      WearableService.this.mRequestDataTimer.schedule(new RequestDataTimeTask(WearableService.this), 3600000L);
    }
  }

  private class SensorData
  {
    long millis;
    float x;
    float y;
    float z;

    private SensorData()
    {
    }
  }

  class SyncDataTimeTask extends TimerTask
  {
    SyncDataTimeTask()
    {
    }

    public void run()
    {
      WearableService.this.handleNeedSportDataSync();
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.services.WearableService
 * JD-Core Version:    0.6.2
 */