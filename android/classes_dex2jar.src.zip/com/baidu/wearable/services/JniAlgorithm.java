package com.baidu.wearable.services;

public class JniAlgorithm
{
  private final String TAG = "JniAlgorithm";

  static
  {
    System.loadLibrary("health-algorithm");
  }

  public native int DataIn(int paramInt1, int paramInt2, int paramInt3, int paramInt4, long paramLong);

  public native int algorithm_finalize();

  public native double getCalory();

  public native double getStepLength();

  public native int init(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);

  public int newDataIn(float paramFloat1, float paramFloat2, float paramFloat3, long paramLong)
  {
    int i = (int)(1000.0F * paramFloat1 / 9.800000000000001D);
    int j = (int)(1000.0F * paramFloat2 / 9.800000000000001D);
    int k = (int)(1000.0F * paramFloat3 / 9.800000000000001D);
    return DataIn(i, j, k, (int)Math.sqrt(Math.pow(i, 2.0D) + Math.pow(j, 2.0D) + Math.pow(k, 2.0D)), paramLong);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.services.JniAlgorithm
 * JD-Core Version:    0.6.2
 */