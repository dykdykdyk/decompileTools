package com.baidu.wearable;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.content.LocalBroadcastManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.alarm.AlarmManagerUtil;
import com.baidu.wearable.alarm.NotificationUtil;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.database.Database;
import com.baidu.wearable.database.SleepDao;
import com.baidu.wearable.database.SportDao;
import com.baidu.wearable.net.CompletionRateTransport;
import com.baidu.wearable.net.PlanTransport;
import com.baidu.wearable.net.ProfileTransport;
import com.baidu.wearable.net.RomUpdateTransport;
import com.baidu.wearable.net.SleepTransport;
import com.baidu.wearable.net.SportTransport;
import com.baidu.wearable.net.TrackerTransport;
import com.baidu.wearable.preference.AlarmPreference;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.preference.ProfilePreference;
import com.baidu.wearable.preference.SleepPreference;
import com.baidu.wearable.services.WearableService;
import com.baidu.wearable.sync.SettingsSyncManager;
import com.baidu.wearable.tracker.TrackerHelper;
import com.baidu.wearable.util.PhoneCheck;
import com.baidu.wearable.util.SilentSleepManager;

public class Destroy
{
  private static final String TAG = "Destroy";

  private static void closeAccount()
  {
    BDAccountManager.getInstance().logout();
  }

  private static void closeActivity()
  {
    AppManager.getAppManager().finishAllActivity();
  }

  private static void closeAlarmMgr(Context paramContext)
  {
    AlarmManagerUtil.stopAllAlarm(paramContext);
  }

  private static void closeBleConnect(Context paramContext)
  {
    Intent localIntent = new Intent("action.wearable.ble.connect.command");
    localIntent.putExtra("extra.wearable.ble.connect.command", 1);
    LocalBroadcastManager.getInstance(paramContext).sendBroadcast(localIntent);
  }

  private static void closeConfig()
  {
    Config.close();
  }

  private static void closeCookies(Context paramContext)
  {
    CookieSyncManager.createInstance(paramContext);
    CookieManager.getInstance().removeAllCookie();
    CookieSyncManager.getInstance().sync();
  }

  private static void closeDb(Context paramContext)
  {
    SQLiteDatabase localSQLiteDatabase = Database.getDb(paramContext);
    SportDao.clearSportDetail(localSQLiteDatabase);
    SportDao.clearSportSummary(localSQLiteDatabase);
    SleepDao.clearSleepDetail(localSQLiteDatabase);
    TrackerHelper.close();
  }

  private static void closeMgr()
  {
    PlanPreference.close();
    ProfilePreference.close();
    AlarmPreference.close();
    SleepPreference.close();
  }

  private static void closeNet()
  {
    CompletionRateTransport.close();
    PlanTransport.close();
    ProfileTransport.close();
    SleepTransport.close();
    SportTransport.close();
    TrackerTransport.close();
    RomUpdateTransport.close();
  }

  private static void closeNotification(Context paramContext)
  {
    NotificationUtil.cancelAllNotification(paramContext);
  }

  private static void closePreference(Context paramContext)
  {
    PlanPreference.getInstance(paramContext).clear();
    ProfilePreference.getInstance(paramContext).clear();
  }

  private static void closeService(Context paramContext)
  {
    paramContext.stopService(new Intent(paramContext, WearableService.class));
  }

  private static void closeSettingsSync(Context paramContext)
  {
    SettingsSyncManager.getInstance(paramContext).turnOffSync();
  }

  private static void closeSilentSleep(Context paramContext)
  {
    SilentSleepManager localSilentSleepManager = SilentSleepManager.getInstance(paramContext);
    if (localSilentSleepManager != null)
    {
      localSilentSleepManager.removeSharedPreference();
      localSilentSleepManager.setSilentMode(false);
    }
  }

  public static void executor(Context paramContext)
  {
    LogUtil.d("Destroy", "executor");
    if (PhoneCheck.isBleSupport(paramContext))
      closeBleConnect(paramContext);
    closeMgr();
    closeDb(paramContext);
    closePreference(paramContext);
    closeSettingsSync(paramContext);
    closeSilentSleep(paramContext);
    closeActivity();
    closeService(paramContext);
    closeAlarmMgr(paramContext);
    closeNotification(paramContext);
    closeNet();
    closeCookies(paramContext);
    closeAccount();
    closeConfig();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.Destroy
 * JD-Core Version:    0.6.2
 */