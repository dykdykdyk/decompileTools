package com.baidu.wearable.agent;

public class Agent
{
  public static final String CREATE_TIME = "_ctime";
  public static final String DISPLAY_NAME = "display_name";
  public static final String ID = "id";
  public static final String TYPE = "type";
  private String displayName;
  private String id;
  private String type;

  public Agent(String paramString1, String paramString2, String paramString3)
  {
    this.id = paramString1;
    this.displayName = paramString2;
    this.type = paramString3;
  }

  public String getDisplayName()
  {
    return this.displayName;
  }

  public String getId()
  {
    return this.id;
  }

  public String getType()
  {
    return this.type;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.agent.Agent
 * JD-Core Version:    0.6.2
 */