package com.baidu.wearable.agent;

import android.content.Context;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

public class AgentManager
{
  private static String mDeviceId;

  public static String getLocalDisplayName()
  {
    return Build.MODEL;
  }

  public static String getLocalId(Context paramContext)
  {
    String str = ((TelephonyManager)paramContext.getSystemService("phone")).getDeviceId();
    if (TextUtils.isEmpty(str))
      str = "123";
    return str;
  }

  public static String getLocalType()
  {
    return "Phone";
  }

  public static abstract interface LoginListener
  {
    public abstract void onFailure(int paramInt, String paramString);

    public abstract void onSuccess();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.agent.AgentManager
 * JD-Core Version:    0.6.2
 */