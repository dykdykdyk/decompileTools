package com.baidu.wearable;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.BuildConfig
 * JD-Core Version:    0.6.2
 */