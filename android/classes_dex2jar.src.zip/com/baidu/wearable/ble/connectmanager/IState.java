package com.baidu.wearable.ble.connectmanager;

import android.os.Message;

public abstract interface IState
{
  public static final boolean HANDLED = true;
  public static final boolean NOT_HANDLED;

  public abstract void enter();

  public abstract void exit();

  public abstract String getName();

  public abstract boolean processMessage(Message paramMessage);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.connectmanager.IState
 * JD-Core Version:    0.6.2
 */