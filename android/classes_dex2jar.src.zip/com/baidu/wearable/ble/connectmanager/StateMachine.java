package com.baidu.wearable.ble.connectmanager;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

public class StateMachine
{
  public static final boolean HANDLED = true;
  public static final boolean NOT_HANDLED = false;
  public static final int SM_INIT_CMD = -1;
  public static final int SM_QUIT_CMD = -1;
  private static final String TAG = "StateMachine";
  private String mName;
  private SmHandler mSmHandler;
  private HandlerThread mSmThread;

  protected StateMachine(String paramString)
  {
    this.mSmThread = new HandlerThread(paramString);
    this.mSmThread.start();
    initStateMachine(paramString, this.mSmThread.getLooper());
  }

  protected StateMachine(String paramString, Looper paramLooper)
  {
    initStateMachine(paramString, paramLooper);
  }

  private void initStateMachine(String paramString, Looper paramLooper)
  {
    this.mName = paramString;
    this.mSmHandler = new SmHandler(paramLooper, this, null);
  }

  protected final void addState(State paramState)
  {
    this.mSmHandler.addState(paramState, null);
  }

  protected final void addState(State paramState1, State paramState2)
  {
    this.mSmHandler.addState(paramState1, paramState2);
  }

  protected final void deferMessage(Message paramMessage)
  {
    this.mSmHandler.deferMessage(paramMessage);
  }

  protected final Message getCurrentMessage()
  {
    return this.mSmHandler.getCurrentMessage();
  }

  protected final IState getCurrentState()
  {
    return this.mSmHandler.getCurrentState();
  }

  public final Handler getHandler()
  {
    return this.mSmHandler;
  }

  public final String getName()
  {
    return this.mName;
  }

  public final ProcessedMessageInfo getProcessedMessageInfo(int paramInt)
  {
    return this.mSmHandler.getProcessedMessageInfo(paramInt);
  }

  public final int getProcessedMessagesCount()
  {
    return this.mSmHandler.getProcessedMessagesCount();
  }

  public final int getProcessedMessagesSize()
  {
    return this.mSmHandler.getProcessedMessagesSize();
  }

  protected void haltedProcessMessage(Message paramMessage)
  {
  }

  protected void halting()
  {
  }

  public boolean isDbg()
  {
    return this.mSmHandler.isDbg();
  }

  protected final boolean isQuit(Message paramMessage)
  {
    return this.mSmHandler.isQuit(paramMessage);
  }

  public final Message obtainMessage()
  {
    return Message.obtain(this.mSmHandler);
  }

  public final Message obtainMessage(int paramInt)
  {
    return Message.obtain(this.mSmHandler, paramInt);
  }

  public final Message obtainMessage(int paramInt1, int paramInt2, int paramInt3)
  {
    return Message.obtain(this.mSmHandler, paramInt1, paramInt2, paramInt3);
  }

  public final Message obtainMessage(int paramInt1, int paramInt2, int paramInt3, Object paramObject)
  {
    return Message.obtain(this.mSmHandler, paramInt1, paramInt2, paramInt3, paramObject);
  }

  public final Message obtainMessage(int paramInt, Object paramObject)
  {
    return Message.obtain(this.mSmHandler, paramInt, paramObject);
  }

  public final void quit()
  {
    this.mSmHandler.quit();
  }

  protected void quitting()
  {
  }

  protected final void removeMessages(int paramInt)
  {
    this.mSmHandler.removeMessages(paramInt);
  }

  public final void sendMessage(int paramInt)
  {
    this.mSmHandler.sendMessage(obtainMessage(paramInt));
  }

  public final void sendMessage(int paramInt, Object paramObject)
  {
    this.mSmHandler.sendMessage(obtainMessage(paramInt, paramObject));
  }

  public final void sendMessage(Message paramMessage)
  {
    this.mSmHandler.sendMessage(paramMessage);
  }

  protected final void sendMessageAtFrontOfQueue(int paramInt)
  {
    this.mSmHandler.sendMessageAtFrontOfQueue(obtainMessage(paramInt));
  }

  protected final void sendMessageAtFrontOfQueue(int paramInt, Object paramObject)
  {
    this.mSmHandler.sendMessageAtFrontOfQueue(obtainMessage(paramInt, paramObject));
  }

  protected final void sendMessageAtFrontOfQueue(Message paramMessage)
  {
    this.mSmHandler.sendMessageAtFrontOfQueue(paramMessage);
  }

  public final void sendMessageDelayed(int paramInt, long paramLong)
  {
    this.mSmHandler.sendMessageDelayed(obtainMessage(paramInt), paramLong);
  }

  public final void sendMessageDelayed(int paramInt, Object paramObject, long paramLong)
  {
    this.mSmHandler.sendMessageDelayed(obtainMessage(paramInt, paramObject), paramLong);
  }

  public final void sendMessageDelayed(Message paramMessage, long paramLong)
  {
    this.mSmHandler.sendMessageDelayed(paramMessage, paramLong);
  }

  public void setDbg(boolean paramBoolean)
  {
    this.mSmHandler.setDbg(paramBoolean);
  }

  protected final void setInitialState(State paramState)
  {
    this.mSmHandler.setInitialState(paramState);
  }

  public final void setProcessedMessagesSize(int paramInt)
  {
    this.mSmHandler.setProcessedMessagesSize(paramInt);
  }

  public void start()
  {
    this.mSmHandler.completeConstruction();
  }

  protected final void transitionTo(IState paramIState)
  {
    this.mSmHandler.transitionTo(paramIState);
  }

  protected final void transitionToHaltingState()
  {
    this.mSmHandler.transitionTo(this.mSmHandler.mHaltingState);
  }

  protected void unhandledMessage(Message paramMessage)
  {
    if (this.mSmHandler.mDbg)
      LogUtil.e("StateMachine", this.mName + " - unhandledMessage: msg.what=" + paramMessage.what);
  }

  public class ProcessedMessageInfo
  {
    private State orgState;
    private State state;
    private int what;

    ProcessedMessageInfo(Message paramState1, State paramState2, State arg4)
    {
      State localState;
      update(paramState1, paramState2, localState);
    }

    private String cn(Object paramObject)
    {
      if (paramObject == null)
        return "null";
      String str = paramObject.getClass().getName();
      return str.substring(1 + str.lastIndexOf('$'));
    }

    public State getOriginalState()
    {
      return this.orgState;
    }

    public State getState()
    {
      return this.state;
    }

    public int getWhat()
    {
      return this.what;
    }

    public String toString()
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append("what=");
      localStringBuilder.append(this.what);
      localStringBuilder.append(" state=");
      localStringBuilder.append(cn(this.state));
      localStringBuilder.append(" orgState=");
      localStringBuilder.append(cn(this.orgState));
      return localStringBuilder.toString();
    }

    public void update(Message paramMessage, State paramState1, State paramState2)
    {
      this.what = paramMessage.what;
      this.state = paramState1;
      this.orgState = paramState2;
    }
  }

  private class ProcessedMessages
  {
    private static final int DEFAULT_SIZE = 20;
    private int mCount = 0;
    private int mMaxSize = 20;
    private Vector<StateMachine.ProcessedMessageInfo> mMessages = new Vector();
    private int mOldestIndex = 0;

    ProcessedMessages()
    {
    }

    void add(Message paramMessage, State paramState1, State paramState2)
    {
      this.mCount = (1 + this.mCount);
      if (this.mMessages.size() < this.mMaxSize)
      {
        this.mMessages.add(new StateMachine.ProcessedMessageInfo(StateMachine.this, paramMessage, paramState1, paramState2));
        return;
      }
      StateMachine.ProcessedMessageInfo localProcessedMessageInfo = (StateMachine.ProcessedMessageInfo)this.mMessages.get(this.mOldestIndex);
      this.mOldestIndex = (1 + this.mOldestIndex);
      if (this.mOldestIndex >= this.mMaxSize)
        this.mOldestIndex = 0;
      localProcessedMessageInfo.update(paramMessage, paramState1, paramState2);
    }

    int count()
    {
      return this.mCount;
    }

    StateMachine.ProcessedMessageInfo get(int paramInt)
    {
      int i = paramInt + this.mOldestIndex;
      if (i >= this.mMaxSize)
        i -= this.mMaxSize;
      if (i >= size())
        return null;
      return (StateMachine.ProcessedMessageInfo)this.mMessages.get(i);
    }

    void setSize(int paramInt)
    {
      this.mMaxSize = paramInt;
      this.mCount = 0;
      this.mMessages.clear();
    }

    int size()
    {
      return this.mMessages.size();
    }
  }

  private class SmHandler extends Handler
  {
    private boolean mDbg = true;
    private ArrayList<Message> mDeferredMessages = new ArrayList();
    private State mDestState;
    private HaltingState mHaltingState = new HaltingState(null);
    private State mInitialState;
    private boolean mIsConstructionCompleted;
    private Message mMsg;
    private StateMachine.ProcessedMessages mProcessedMessages = new StateMachine.ProcessedMessages(StateMachine.this);
    private Object mQuitObj = new Object();
    private QuittingState mQuittingState = new QuittingState(null);
    private StateMachine mSm;
    private HashMap<State, StateInfo> mStateInfo = new HashMap();
    private StateInfo[] mStateStack;
    private int mStateStackTopIndex = -1;
    private StateInfo[] mTempStateStack;
    private int mTempStateStackCount;

    private SmHandler(Looper paramStateMachine, StateMachine arg3)
    {
      super();
      Object localObject;
      this.mSm = localObject;
      addState(this.mHaltingState, null);
      addState(this.mQuittingState, null);
    }

    private final StateInfo addState(State paramState1, State paramState2)
    {
      StringBuilder localStringBuilder;
      if (this.mDbg)
      {
        localStringBuilder = new StringBuilder("addStateInternal: E state=").append(paramState1.getName()).append(",parent=");
        if (paramState2 != null)
          break label149;
      }
      StateInfo localStateInfo1;
      StateInfo localStateInfo2;
      label149: for (String str = ""; ; str = paramState2.getName())
      {
        LogUtil.d("StateMachine", str);
        localStateInfo1 = null;
        if (paramState2 != null)
        {
          localStateInfo1 = (StateInfo)this.mStateInfo.get(paramState2);
          if (localStateInfo1 == null)
            localStateInfo1 = addState(paramState2, null);
        }
        localStateInfo2 = (StateInfo)this.mStateInfo.get(paramState1);
        if (localStateInfo2 == null)
        {
          localStateInfo2 = new StateInfo(null);
          this.mStateInfo.put(paramState1, localStateInfo2);
        }
        if ((localStateInfo2.parentStateInfo == null) || (localStateInfo2.parentStateInfo == localStateInfo1))
          break;
        throw new RuntimeException("state already added");
      }
      localStateInfo2.state = paramState1;
      localStateInfo2.parentStateInfo = localStateInfo1;
      localStateInfo2.active = false;
      if (this.mDbg)
        LogUtil.d("StateMachine", "addStateInternal: X stateInfo: " + localStateInfo2);
      return localStateInfo2;
    }

    private final void completeConstruction()
    {
      if (this.mDbg)
        LogUtil.d("StateMachine", "completeConstruction: E");
      int i = 0;
      Iterator localIterator = this.mStateInfo.values().iterator();
      if (!localIterator.hasNext())
      {
        if (this.mDbg)
          LogUtil.d("StateMachine", "completeConstruction: maxDepth=" + i);
        this.mStateStack = new StateInfo[i];
        this.mTempStateStack = new StateInfo[i];
        setupInitialStateStack();
        this.mIsConstructionCompleted = true;
        this.mMsg = obtainMessage(-1);
        invokeEnterMethods(0);
        performTransitions();
        if (this.mDbg)
          LogUtil.d("StateMachine", "completeConstruction: X");
        return;
      }
      StateInfo localStateInfo1 = (StateInfo)localIterator.next();
      int j = 0;
      StateInfo localStateInfo2 = localStateInfo1;
      while (true)
      {
        if (localStateInfo2 == null)
        {
          if (i >= j)
            break;
          i = j;
          break;
        }
        localStateInfo2 = localStateInfo2.parentStateInfo;
        j++;
      }
    }

    private final void deferMessage(Message paramMessage)
    {
      if (this.mDbg)
        LogUtil.d("StateMachine", "deferMessage: msg=" + paramMessage.what);
      Message localMessage = obtainMessage();
      localMessage.copyFrom(paramMessage);
      this.mDeferredMessages.add(localMessage);
    }

    private final Message getCurrentMessage()
    {
      return this.mMsg;
    }

    private final IState getCurrentState()
    {
      return this.mStateStack[this.mStateStackTopIndex].state;
    }

    private final StateMachine.ProcessedMessageInfo getProcessedMessageInfo(int paramInt)
    {
      return this.mProcessedMessages.get(paramInt);
    }

    private final int getProcessedMessagesCount()
    {
      return this.mProcessedMessages.count();
    }

    private final int getProcessedMessagesSize()
    {
      return this.mProcessedMessages.size();
    }

    private final void invokeEnterMethods(int paramInt)
    {
      for (int i = paramInt; ; i++)
      {
        if (i > this.mStateStackTopIndex)
          return;
        if (this.mDbg)
          LogUtil.d("StateMachine", "invokeEnterMethods: " + this.mStateStack[i].state.getName());
        this.mStateStack[i].state.enter();
        this.mStateStack[i].active = true;
      }
    }

    private final void invokeExitMethods(StateInfo paramStateInfo)
    {
      while (true)
      {
        if ((this.mStateStackTopIndex < 0) || (this.mStateStack[this.mStateStackTopIndex] == paramStateInfo))
          return;
        State localState = this.mStateStack[this.mStateStackTopIndex].state;
        if (this.mDbg)
          LogUtil.d("StateMachine", "invokeExitMethods: " + localState.getName());
        localState.exit();
        this.mStateStack[this.mStateStackTopIndex].active = false;
        this.mStateStackTopIndex = (-1 + this.mStateStackTopIndex);
      }
    }

    private final boolean isDbg()
    {
      return this.mDbg;
    }

    private final boolean isQuit(Message paramMessage)
    {
      return (paramMessage.what == -1) && (paramMessage.obj == this.mQuitObj);
    }

    private final void moveDeferredMessageAtFrontOfQueue()
    {
      for (int i = -1 + this.mDeferredMessages.size(); ; i--)
      {
        if (i < 0)
        {
          this.mDeferredMessages.clear();
          return;
        }
        Message localMessage = (Message)this.mDeferredMessages.get(i);
        if (this.mDbg)
          LogUtil.d("StateMachine", "moveDeferredMessageAtFrontOfQueue; what=" + localMessage.what);
        sendMessageAtFrontOfQueue(localMessage);
      }
    }

    private final int moveTempStateStackToStateStack()
    {
      int i = 1 + this.mStateStackTopIndex;
      int j = -1 + this.mTempStateStackCount;
      int k = i;
      while (true)
      {
        if (j < 0)
        {
          this.mStateStackTopIndex = (k - 1);
          if (this.mDbg)
            LogUtil.d("StateMachine", "moveTempStackToStateStack: X mStateStackTop=" + this.mStateStackTopIndex + ",startingIndex=" + i + ",Top=" + this.mStateStack[this.mStateStackTopIndex].state.getName());
          return i;
        }
        if (this.mDbg)
          LogUtil.d("StateMachine", "moveTempStackToStateStack: i=" + j + ",j=" + k);
        this.mStateStack[k] = this.mTempStateStack[j];
        k++;
        j--;
      }
    }

    private void performTransitions()
    {
      State localState = null;
      if (this.mDestState == null)
        if (localState != null)
        {
          if (localState != this.mQuittingState)
            break label118;
          this.mSm.quitting();
          if (this.mSm.mSmThread != null)
          {
            getLooper().quit();
            this.mSm.mSmThread = null;
            if (this.mDbg)
              LogUtil.d("StateMachine", "quit the looper");
          }
        }
      label118: 
      while (localState != this.mHaltingState)
      {
        return;
        if (this.mDbg)
          LogUtil.d("StateMachine", "handleMessage: new destination call exit");
        localState = this.mDestState;
        this.mDestState = null;
        invokeExitMethods(setupTempStateStackWithStatesToEnter(localState));
        invokeEnterMethods(moveTempStateStackToStateStack());
        moveDeferredMessageAtFrontOfQueue();
        break;
      }
      this.mSm.halting();
    }

    private final void processMsg(Message paramMessage)
    {
      StateInfo localStateInfo = this.mStateStack[this.mStateStackTopIndex];
      if (this.mDbg)
        LogUtil.d("StateMachine", "processMsg: " + localStateInfo.state.getName());
      while (true)
      {
        if (localStateInfo.state.processMessage(paramMessage));
        while (true)
        {
          if (localStateInfo == null)
            break label161;
          State localState = this.mStateStack[this.mStateStackTopIndex].state;
          this.mProcessedMessages.add(paramMessage, localStateInfo.state, localState);
          return;
          localStateInfo = localStateInfo.parentStateInfo;
          if (localStateInfo != null)
            break;
          this.mSm.unhandledMessage(paramMessage);
          if (isQuit(paramMessage))
            transitionTo(this.mQuittingState);
        }
        if (this.mDbg)
          LogUtil.d("StateMachine", "processMsg: " + localStateInfo.state.getName());
      }
      label161: this.mProcessedMessages.add(paramMessage, null, null);
    }

    private final void quit()
    {
      if (this.mDbg)
        LogUtil.d("StateMachine", "quit:");
      sendMessage(obtainMessage(-1, this.mQuitObj));
    }

    private final void setDbg(boolean paramBoolean)
    {
      this.mDbg = paramBoolean;
    }

    private final void setInitialState(State paramState)
    {
      if (this.mDbg)
        LogUtil.d("StateMachine", "setInitialState: initialState" + paramState.getName());
      this.mInitialState = paramState;
    }

    private final void setProcessedMessagesSize(int paramInt)
    {
      this.mProcessedMessages.setSize(paramInt);
    }

    private final void setupInitialStateStack()
    {
      if (this.mDbg)
        LogUtil.d("StateMachine", "setupInitialStateStack: E mInitialState=" + this.mInitialState.getName());
      StateInfo localStateInfo = (StateInfo)this.mStateInfo.get(this.mInitialState);
      for (this.mTempStateStackCount = 0; ; this.mTempStateStackCount = (1 + this.mTempStateStackCount))
      {
        if (localStateInfo == null)
        {
          this.mStateStackTopIndex = -1;
          moveTempStateStackToStateStack();
          return;
        }
        this.mTempStateStack[this.mTempStateStackCount] = localStateInfo;
        localStateInfo = localStateInfo.parentStateInfo;
      }
    }

    private final StateInfo setupTempStateStackWithStatesToEnter(State paramState)
    {
      this.mTempStateStackCount = 0;
      StateInfo localStateInfo = (StateInfo)this.mStateInfo.get(paramState);
      do
      {
        StateInfo[] arrayOfStateInfo = this.mTempStateStack;
        int i = this.mTempStateStackCount;
        this.mTempStateStackCount = (i + 1);
        arrayOfStateInfo[i] = localStateInfo;
        localStateInfo = localStateInfo.parentStateInfo;
      }
      while ((localStateInfo != null) && (!localStateInfo.active));
      if (this.mDbg)
        LogUtil.d("StateMachine", "setupTempStateStackWithStatesToEnter: X mTempStateStackCount=" + this.mTempStateStackCount + ",curStateInfo: " + localStateInfo);
      return localStateInfo;
    }

    private final void transitionTo(IState paramIState)
    {
      this.mDestState = ((State)paramIState);
      if (this.mDbg)
        LogUtil.d("StateMachine", "StateMachine.transitionTo EX destState" + this.mDestState.getName());
    }

    public final void handleMessage(Message paramMessage)
    {
      if (this.mDbg)
        LogUtil.d("StateMachine", "handleMessage: E msg.what=" + paramMessage.what);
      this.mMsg = paramMessage;
      if (!this.mIsConstructionCompleted)
        LogUtil.e("StateMachine", "The start method not called, ignore msg: " + paramMessage);
      do
      {
        return;
        processMsg(paramMessage);
        performTransitions();
      }
      while (!this.mDbg);
      LogUtil.d("StateMachine", "handleMessage: X");
    }

    private class HaltingState extends State
    {
      private HaltingState()
      {
      }

      public boolean processMessage(Message paramMessage)
      {
        StateMachine.this.haltedProcessMessage(paramMessage);
        return true;
      }
    }

    private class QuittingState extends State
    {
      private QuittingState()
      {
      }

      public boolean processMessage(Message paramMessage)
      {
        return false;
      }
    }

    private class StateInfo
    {
      boolean active;
      StateInfo parentStateInfo;
      State state;

      private StateInfo()
      {
      }

      public String toString()
      {
        StringBuilder localStringBuilder = new StringBuilder("state=").append(this.state.getName()).append(",active=").append(this.active).append(",parent=");
        if (this.parentStateInfo == null);
        for (String str = "null"; ; str = this.parentStateInfo.state.getName())
          return str;
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.connectmanager.StateMachine
 * JD-Core Version:    0.6.2
 */