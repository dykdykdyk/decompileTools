package com.baidu.wearable.ble.stack;

import android.os.Handler;
import com.baidu.wearable.ble.model.BlueToothSleepData;
import com.baidu.wearable.ble.model.BlueToothSleepDataSection;
import com.baidu.wearable.ble.model.BlueToothSportData;
import com.baidu.wearable.ble.model.BlueToothSportDataSection;
import com.baidu.wearable.ble.model.ClockList;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.ble.util.TimeUtil;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class BlueTooth
{
  public static final int SUCCESS = 0;
  private static final String TAG = "BlueTooth";
  private static BlueToothAlarmListReceiverListener mBlueToothAlarmListReceiverListener;
  private static BlueToothBondReceiverListener mBlueToothBondReceiverListener;
  private static BlueToothConnectResetListener mBlueToothConnectResetListener;
  private static BlueToothDataSyncProgressListener mBlueToothDataSyncProgressListener;
  private static BlueToothDataVerifyListener mBlueToothDataVerifyListener;
  private static BlueToothLogReceiverListener mBlueToothLogReceiverListener;
  private static BlueToothLoginReceiverListener mBlueToothLoginReceiverListener;
  private static BlueToothOTAEnterOtaModeReceiverListener mBlueToothOTAEnterOtaModeResponseReceiverListener;
  private static BlueToothRemoteControlReceiverListener mBlueToothRemoteControlReceiverListener;
  private static BlueToothSleepReceiverListener mBlueToothSleepReceiverListener;
  private static BlueToothSleepSettingReceiverListener mBlueToothSleepSettingReceiverListener;
  private static BlueToothSportReceiverListener mBlueToothSportReceiverListener;
  private static BlueToothSuperBondReceiverListener mBlueToothSuperBondReceiverListener;
  private static BlueToothTestModeReceiverListener mBlueToothTestModeResponseReceiverListener;
  private static BlueTooth mInstance;
  private final long TIMESTAMP_OF_2011 = 977616000L;
  Runnable mBleStackTimerRunnable = new Runnable()
  {
    public void run()
    {
      BlueTooth.this.bleStackTimeFire();
      BlueTooth.this.mHandler.postDelayed(BlueTooth.this.mBleStackTimerRunnable, 1000L);
    }
  };
  private Handler mHandler;
  private List<SendMeta> mSendMetas = new ArrayList();

  static
  {
    if (!BlueTooth.class.desiredAssertionStatus());
    for (boolean bool = true; ; bool = false)
    {
      $assertionsDisabled = bool;
      System.loadLibrary("jni-bluetooth");
      classInitNative();
      return;
    }
  }

  private native int bindNative(byte[] paramArrayOfByte);

  private native void bleStackTimeFireNative();

  private native int calibrateSportDataNative(int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public static native void classInitNative();

  private native int disableLogNative();

  private native int enableLogNative();

  private native int getAlarmListNative();

  private byte[] getByteArray(int paramInt, long paramLong)
  {
    byte[] arrayOfByte = new byte[paramInt];
    int i = paramInt;
    if (paramInt > 4)
      i = 4;
    for (int j = i; ; j--)
    {
      if (j <= 0)
        return arrayOfByte;
      paramInt--;
      arrayOfByte[paramInt] = ((byte)(int)(paramLong >> 8 * (i - j)));
    }
  }

  public static BlueTooth getInstance()
  {
    if (mInstance == null);
    try
    {
      if (mInstance == null)
      {
        mInstance = new BlueTooth();
        mInstance.init();
      }
      return mInstance;
    }
    finally
    {
    }
  }

  private native int loginNative(byte[] paramArrayOfByte);

  private native int otaEnterOTAModeNative();

  private native int phoneAnswerNative();

  private native int phoneCommingNative();

  private native int phoneDenyNative();

  private native int remoteControlCameraStateNative(int paramInt);

  private native int requestDataNative();

  private native int setAlarmListNative(ClockList paramClockList);

  private native int setDailySportDataNative(int paramInt1, int paramInt2, int paramInt3);

  private native int setDataSyncNative(int paramInt);

  private native int setLeftOrRightHandNative(boolean paramBoolean);

  private native int setLinklostNative(int paramInt);

  private native int setOperationSystemNative(int paramInt1, int paramInt2);

  private native int setSportTargetNative(int paramInt);

  private native int setStillAlarmNative(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7);

  private native int setTimeNative(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);

  private native int setUserProfileNative(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3);

  private native int superBindNative(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);

  private native int syncRecentlySportDataNative(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  private native int testChargeRequestNative();

  private native int testEchoRequestNative(byte[] paramArrayOfByte);

  private native int testEnterTestModeRequestNative();

  private native int testExitTestModeRequestNative();

  private native int testLedOnRequestNative(int paramInt1, int paramInt2);

  private native int testReadFlagRequestNative();

  private native int testReadSensorRequestNative();

  private native int testReadSnRequestNative();

  private native int testSetLedBurnInRequestNative(boolean paramBoolean);

  private native int testSetMotorBurnInRequestNative(boolean paramBoolean);

  private native int testVibrateRequestNative();

  private native int testWriteFlagRequestNative(byte paramByte);

  private native int testWriteSnRequestNative(byte[] paramArrayOfByte);

  public void bind(String paramString, BlueToothCommonListener paramBlueToothCommonListener)
  {
    try
    {
      byte[] arrayOfByte = paramString.getBytes("UTF-8");
      int i = bindNative(arrayOfByte);
      LogUtil.d("BlueTooth", "bind seqId:" + i);
      if (i >= 0)
      {
        SendMeta localSendMeta = new SendMeta();
        localSendMeta.seqId = i;
        localSendMeta.listener = paramBlueToothCommonListener;
        this.mSendMetas.add(localSendMeta);
        return;
      }
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      do
      {
        localUnsupportedEncodingException.printStackTrace();
        LogUtil.d("BlueTooth", "bind error");
      }
      while (paramBlueToothCommonListener == null);
      paramBlueToothCommonListener.onFailure();
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void bleStackTimeFire()
  {
    bleStackTimeFireNative();
  }

  public void calibrateSportData(BlueToothCommonListener paramBlueToothCommonListener, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int i = calibrateSportDataNative(paramInt1, paramInt2, paramInt3, paramInt4);
    LogUtil.d("BlueTooth", "calibrateSportData seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void disableLog(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = disableLogNative();
    LogUtil.d("BlueTooth", "disableLog seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void enableLog(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = enableLogNative();
    LogUtil.d("BlueTooth", "enableLog seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public native int finalizeBleStackNative();

  public void getAlarmList(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = getAlarmListNative();
    LogUtil.d("BlueTooth", "getAlarmList seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public List<BlueToothSleepData> hanleSleepDataDate(List<BlueToothSleepData> paramList)
  {
    assert (paramList.size() == 1);
    long l = ((BlueToothSleepData)paramList.get(0)).timestamp_second;
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    if (i >= paramList.size());
    BlueToothSleepData localBlueToothSleepData3;
    for (int j = 0; ; j++)
    {
      if (j >= paramList.size())
      {
        return localArrayList;
        BlueToothSleepData localBlueToothSleepData1 = (BlueToothSleepData)paramList.get(i);
        if (localBlueToothSleepData1.timestamp_second < 977616000L);
        while (true)
        {
          i++;
          break;
          BlueToothSleepData localBlueToothSleepData2 = new BlueToothSleepData();
          localBlueToothSleepData2.init();
          localBlueToothSleepData2.date = localBlueToothSleepData1.date;
          localBlueToothSleepData2.timestamp_second = localBlueToothSleepData1.timestamp_second;
          LogUtil.v("BlueTooth", " hanleSleepDataDate date:" + localBlueToothSleepData2.date + " timestamp:" + localBlueToothSleepData2.timestamp_second);
          localArrayList.add(localBlueToothSleepData2);
        }
      }
      localBlueToothSleepData3 = (BlueToothSleepData)paramList.get(j);
      if (localBlueToothSleepData3.timestamp_second >= 977616000L)
        break label227;
    }
    label227: int k = 0;
    label230: BlueToothSleepDataSection localBlueToothSleepDataSection;
    if (k < localBlueToothSleepData3.sleepDatas.size())
      localBlueToothSleepDataSection = (BlueToothSleepDataSection)localBlueToothSleepData3.sleepDatas.get(k);
    label525: for (int m = 0; ; m++)
    {
      int n = localArrayList.size();
      int i1 = 0;
      if (m >= n);
      while (true)
      {
        if (i1 == 0)
        {
          LogUtil.w("BlueTooth", "find SleepDataSection not belong to  any day timestamp:" + localBlueToothSleepDataSection.minute);
          BlueToothSleepData localBlueToothSleepData4 = new BlueToothSleepData();
          localBlueToothSleepData4.init();
          localBlueToothSleepData4.timestamp_second = (l + 60 * localBlueToothSleepDataSection.minute - 60 * localBlueToothSleepDataSection.minute % 86400);
          localBlueToothSleepData4.date = TimeUtil.getDate(1000L * localBlueToothSleepData4.timestamp_second);
          localArrayList.add(localBlueToothSleepData4);
          localBlueToothSleepDataSection.minute %= 1440;
          localBlueToothSleepData4.addSection(localBlueToothSleepDataSection);
        }
        k++;
        break label230;
        break;
        if ((l + 60 * localBlueToothSleepDataSection.minute < ((BlueToothSleepData)localArrayList.get(m)).timestamp_second) || (l + 60 * localBlueToothSleepDataSection.minute >= 86400L + ((BlueToothSleepData)localArrayList.get(m)).timestamp_second))
          break label525;
        i1 = 1;
        if (localBlueToothSleepDataSection.minute >= 1440)
          localBlueToothSleepDataSection.minute %= 1440;
        ((BlueToothSleepData)localArrayList.get(m)).addSection(localBlueToothSleepDataSection);
      }
    }
  }

  public List<BlueToothSportData> hanleSportDataDate(List<BlueToothSportData> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    int i = 0;
    if (i >= paramList.size());
    BlueToothSportData localBlueToothSportData3;
    for (int j = 0; ; j++)
    {
      if (j >= paramList.size())
      {
        return localArrayList;
        BlueToothSportData localBlueToothSportData1 = (BlueToothSportData)paramList.get(i);
        if (localBlueToothSportData1.timestamp_second < 977616000L);
        while (true)
        {
          i++;
          break;
          BlueToothSportData localBlueToothSportData2 = new BlueToothSportData();
          localBlueToothSportData2.init();
          localBlueToothSportData2.date = localBlueToothSportData1.date;
          localBlueToothSportData2.timestamp_second = localBlueToothSportData1.timestamp_second;
          LogUtil.v("BlueTooth", " hanleSportDataDate date:" + localBlueToothSportData2.date + " timestamp:" + localBlueToothSportData2.timestamp_second);
          localArrayList.add(localBlueToothSportData2);
        }
      }
      localBlueToothSportData3 = (BlueToothSportData)paramList.get(j);
      if (localBlueToothSportData3.timestamp_second >= 977616000L)
        break label183;
    }
    label183: int k = 0;
    label186: BlueToothSportDataSection localBlueToothSportDataSection;
    if (k < localBlueToothSportData3.sportDatas.size())
      localBlueToothSportDataSection = (BlueToothSportDataSection)localBlueToothSportData3.sportDatas.get(k);
    label411: for (int m = 0; ; m++)
    {
      int n = localArrayList.size();
      int i1 = 0;
      if (m >= n);
      while (true)
      {
        if (i1 == 0)
        {
          LogUtil.w("BlueTooth", "find SportDataSection not belong to  SportData,SportDataSection timestamp:" + localBlueToothSportDataSection.timestamp + ", SportData timestamp_second:" + localBlueToothSportData3.timestamp_second);
          BlueToothSportData localBlueToothSportData4 = new BlueToothSportData();
          localBlueToothSportData4.init();
          localBlueToothSportData4.timestamp_second = (localBlueToothSportDataSection.timestamp - localBlueToothSportDataSection.timestamp % 86400L);
          localBlueToothSportData4.date = TimeUtil.getDate(1000L * localBlueToothSportData4.timestamp_second);
          localArrayList.add(localBlueToothSportData4);
          localBlueToothSportDataSection.timestamp = localBlueToothSportDataSection.timestamp;
          localBlueToothSportData4.addSection(localBlueToothSportDataSection);
        }
        k++;
        break label186;
        break;
        if (!localBlueToothSportDataSection.belongToDay(((BlueToothSportData)localArrayList.get(m)).timestamp_second))
          break label411;
        i1 = 1;
        ((BlueToothSportData)localArrayList.get(m)).addSection(localBlueToothSportDataSection);
      }
    }
  }

  public int init()
  {
    this.mHandler = new Handler();
    initBleStackTimer();
    return initNative();
  }

  public native int initBleStackNative();

  public void initBleStackTimer()
  {
    this.mBleStackTimerRunnable.run();
  }

  public native int initNative();

  public void login(String paramString, BlueToothCommonListener paramBlueToothCommonListener, int paramInt)
  {
    if (paramInt == 0);
    try
    {
      byte[] arrayOfByte2 = paramString.getBytes("UTF-8");
      Object localObject = arrayOfByte2;
      while (true)
      {
        int i = loginNative((byte[])localObject);
        LogUtil.d("BlueTooth", "login seqId:" + i);
        if (i < 0)
          break;
        SendMeta localSendMeta = new SendMeta();
        localSendMeta.seqId = i;
        localSendMeta.listener = paramBlueToothCommonListener;
        this.mSendMetas.add(localSendMeta);
        return;
        localObject = null;
        if (paramInt == 1)
        {
          byte[] arrayOfByte1 = getByteArray(32, Long.valueOf(paramString).longValue());
          localObject = arrayOfByte1;
        }
      }
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      do
      {
        localUnsupportedEncodingException.printStackTrace();
        LogUtil.d("BlueTooth", "login error");
      }
      while (paramBlueToothCommonListener == null);
      paramBlueToothCommonListener.onFailure();
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void onReceiveAlarmList(ClockList paramClockList)
  {
    if (mBlueToothAlarmListReceiverListener != null)
      mBlueToothAlarmListReceiverListener.onSuccess(paramClockList);
  }

  public void onReceiveBindResponse(int paramInt)
  {
    if (mBlueToothBondReceiverListener != null)
    {
      if (paramInt == 0)
        mBlueToothBondReceiverListener.onSuccess();
    }
    else
      return;
    mBlueToothBondReceiverListener.onFailure();
  }

  public void onReceiveDailyDataVerify(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7)
  {
    if (mBlueToothDataVerifyListener != null)
      mBlueToothDataVerifyListener.onVerify(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
  }

  public void onReceiveLogLogs(byte[] paramArrayOfByte)
  {
    if (mBlueToothLogReceiverListener != null)
      mBlueToothLogReceiverListener.onLogReceived(paramArrayOfByte);
  }

  public void onReceiveLoginResponse(int paramInt)
  {
    if (mBlueToothLoginReceiverListener != null)
    {
      if (paramInt == 0)
        mBlueToothLoginReceiverListener.onSuccess();
    }
    else
      return;
    mBlueToothLoginReceiverListener.onFailure();
  }

  public void onReceiveMoreSportData()
  {
    requestData(new BlueToothCommonListener()
    {
      public void onFailure()
      {
        LogUtil.d("BlueTooth", "request data send failure");
      }

      public void onSuccess()
      {
        LogUtil.d("BlueTooth", "request data send success");
      }
    });
  }

  public void onReceiveOTAEnterOTAModeResponse(byte paramByte1, byte paramByte2)
  {
    if (mBlueToothOTAEnterOtaModeResponseReceiverListener != null)
      mBlueToothOTAEnterOtaModeResponseReceiverListener.onEnterOtaModeResponse(paramByte1, paramByte2);
  }

  public void onReceiveRemoteControlCameraTakePicture()
  {
    if (mBlueToothRemoteControlReceiverListener != null)
      mBlueToothRemoteControlReceiverListener.onCameraTakePicture();
  }

  public void onReceiveRemoteControlDoubleClick()
  {
    if (mBlueToothRemoteControlReceiverListener != null)
      mBlueToothRemoteControlReceiverListener.onDoubleClick();
  }

  public void onReceiveRemoteControlSingleClick()
  {
    if (mBlueToothRemoteControlReceiverListener != null)
      mBlueToothRemoteControlReceiverListener.onSingleClick();
  }

  public void onReceiveSleepData(BlueToothSleepData paramBlueToothSleepData)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramBlueToothSleepData);
    LogUtil.d("BlueTooth", "onReceiveSleepData");
    if (mBlueToothSleepReceiverListener != null)
      mBlueToothSleepReceiverListener.onSuccess(hanleSleepDataDate(localArrayList));
  }

  public void onReceiveSleepSettingData(BlueToothSleepData paramBlueToothSleepData)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramBlueToothSleepData);
    LogUtil.d("BlueTooth", "onReceiveSleepSettingData");
    if (mBlueToothSleepSettingReceiverListener != null)
      mBlueToothSleepSettingReceiverListener.onSuccess(hanleSleepDataDate(localArrayList));
  }

  public void onReceiveSportData(BlueToothSportData paramBlueToothSportData)
  {
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramBlueToothSportData);
    LogUtil.v("BlueTooth", "date:" + paramBlueToothSportData.date + " timestamp:" + paramBlueToothSportData.timestamp_second);
    if (mBlueToothSportReceiverListener != null)
      mBlueToothSportReceiverListener.onSuccess(hanleSportDataDate(localArrayList));
  }

  public void onReceiveSportDataSyncEnd()
  {
    if (mBlueToothDataSyncProgressListener != null)
      mBlueToothDataSyncProgressListener.onSyncEnd();
  }

  public void onReceiveSportDataSyncStart()
  {
    if (mBlueToothDataSyncProgressListener != null)
      mBlueToothDataSyncProgressListener.onSyncStart();
  }

  public void onReceiveSuperBindResponse(int paramInt)
  {
    if (mBlueToothSuperBondReceiverListener != null)
    {
      if (paramInt == 0)
        mBlueToothSuperBondReceiverListener.onSuccess();
    }
    else
      return;
    mBlueToothSuperBondReceiverListener.onFailure(paramInt);
  }

  public void onReceiveTestButton(int paramInt1, int paramInt2, long paramLong)
  {
    if (mBlueToothTestModeResponseReceiverListener != null)
      mBlueToothTestModeResponseReceiverListener.onTestButton(paramInt1, paramInt2, paramLong);
  }

  public void onReceiveTestModeChargeReadResponse(short paramShort)
  {
    if (mBlueToothTestModeResponseReceiverListener != null)
      mBlueToothTestModeResponseReceiverListener.onTestChargeReadResponse(paramShort);
  }

  public void onReceiveTestModeEchoResponse(byte[] paramArrayOfByte)
  {
    if (mBlueToothTestModeResponseReceiverListener != null)
      mBlueToothTestModeResponseReceiverListener.onTestEchoResponse(paramArrayOfByte);
  }

  public void onReceiveTestModeFlagReadResponse(byte paramByte)
  {
    if (mBlueToothTestModeResponseReceiverListener != null)
      mBlueToothTestModeResponseReceiverListener.onTestFlagReadResponse(paramByte);
  }

  public void onReceiveTestModeSensorReadResponse(short paramShort1, short paramShort2, short paramShort3)
  {
    if (mBlueToothTestModeResponseReceiverListener != null)
      mBlueToothTestModeResponseReceiverListener.onTestSensorReadResponse(paramShort1, paramShort2, paramShort3);
  }

  public void onReceiveTestModeSnReadResponse(byte[] paramArrayOfByte)
  {
    if (mBlueToothTestModeResponseReceiverListener != null)
      mBlueToothTestModeResponseReceiverListener.onTestSnReadResponse(paramArrayOfByte);
  }

  public void onSendCallback(int paramInt, long paramLong)
  {
    LogUtil.d("BlueTooth", "onSendCallback statusCode:" + paramInt + ", seqId:" + paramLong);
    LogUtil.d("BlueTooth", "mSendMetas count:" + this.mSendMetas.size());
    int i = -1;
    int j = 0;
    label82: SendMeta localSendMeta;
    if (j >= this.mSendMetas.size())
      if (i != -1)
      {
        localSendMeta = (SendMeta)this.mSendMetas.get(i);
        if (paramInt != 0)
          break label167;
        localSendMeta.listener.onSuccess();
      }
    while (true)
    {
      this.mSendMetas.remove(i);
      return;
      if (((SendMeta)this.mSendMetas.get(j)).seqId == paramLong)
      {
        i = j;
        break label82;
      }
      j++;
      break;
      label167: localSendMeta.listener.onFailure();
    }
  }

  public void otaEnterOTAMode(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = otaEnterOTAModeNative();
    LogUtil.d("BlueTooth", "otaEnterOTAMode seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void phoneAnswer(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = phoneAnswerNative();
    LogUtil.d("BlueTooth", "phoneAnswer seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void phoneComming(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = phoneCommingNative();
    LogUtil.d("BlueTooth", "phoneComming seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void phoneDeny(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = phoneDenyNative();
    LogUtil.d("BlueTooth", "phoneDeny seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void registerAlarmListReceiverListener(BlueToothAlarmListReceiverListener paramBlueToothAlarmListReceiverListener)
  {
    mBlueToothAlarmListReceiverListener = paramBlueToothAlarmListReceiverListener;
  }

  public void registerBondReceiverListener(BlueToothBondReceiverListener paramBlueToothBondReceiverListener)
  {
    mBlueToothBondReceiverListener = paramBlueToothBondReceiverListener;
  }

  public void registerDataSyncProgressListener(BlueToothDataSyncProgressListener paramBlueToothDataSyncProgressListener)
  {
    mBlueToothDataSyncProgressListener = paramBlueToothDataSyncProgressListener;
  }

  public void registerDataVerifyListener(BlueToothDataVerifyListener paramBlueToothDataVerifyListener)
  {
    mBlueToothDataVerifyListener = paramBlueToothDataVerifyListener;
  }

  public void registerLogReceiverListener(BlueToothLogReceiverListener paramBlueToothLogReceiverListener)
  {
    mBlueToothLogReceiverListener = paramBlueToothLogReceiverListener;
  }

  public void registerLoginReceiverListener(BlueToothLoginReceiverListener paramBlueToothLoginReceiverListener)
  {
    mBlueToothLoginReceiverListener = paramBlueToothLoginReceiverListener;
  }

  public void registerOTAEnterOtaModeResponseReceiverListener(BlueToothOTAEnterOtaModeReceiverListener paramBlueToothOTAEnterOtaModeReceiverListener)
  {
    mBlueToothOTAEnterOtaModeResponseReceiverListener = paramBlueToothOTAEnterOtaModeReceiverListener;
  }

  public void registerRemoteControlReceiverListener(BlueToothRemoteControlReceiverListener paramBlueToothRemoteControlReceiverListener)
  {
    mBlueToothRemoteControlReceiverListener = paramBlueToothRemoteControlReceiverListener;
  }

  public void registerResetBleConnect(BlueToothConnectResetListener paramBlueToothConnectResetListener)
  {
    mBlueToothConnectResetListener = paramBlueToothConnectResetListener;
  }

  public void registerSleepReceiverListener(BlueToothSleepReceiverListener paramBlueToothSleepReceiverListener)
  {
    mBlueToothSleepReceiverListener = paramBlueToothSleepReceiverListener;
  }

  public void registerSleepSettingReceiverListener(BlueToothSleepSettingReceiverListener paramBlueToothSleepSettingReceiverListener)
  {
    mBlueToothSleepSettingReceiverListener = paramBlueToothSleepSettingReceiverListener;
  }

  public void registerSportReceiverListener(BlueToothSportReceiverListener paramBlueToothSportReceiverListener)
  {
    mBlueToothSportReceiverListener = paramBlueToothSportReceiverListener;
  }

  public void registerSuperBondReceiverListener(BlueToothSuperBondReceiverListener paramBlueToothSuperBondReceiverListener)
  {
    mBlueToothSuperBondReceiverListener = paramBlueToothSuperBondReceiverListener;
  }

  public void registerTestModeResponseReceiverListener(BlueToothTestModeReceiverListener paramBlueToothTestModeReceiverListener)
  {
    mBlueToothTestModeResponseReceiverListener = paramBlueToothTestModeReceiverListener;
  }

  public void remoteControlCameraState(BlueToothCommonListener paramBlueToothCommonListener, int paramInt)
  {
    int i = remoteControlCameraStateNative(paramInt);
    LogUtil.d("BlueTooth", "remoteControlCameraState seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void requestData(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = requestDataNative();
    LogUtil.d("BlueTooth", "requestData seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void resetBleConnect()
  {
    if (mBlueToothConnectResetListener != null)
      mBlueToothConnectResetListener.onReset();
  }

  public void setAlarmList(ClockList paramClockList, BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = setAlarmListNative(paramClockList);
    LogUtil.d("BlueTooth", "setAlarmList seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setDailySportData(BlueToothCommonListener paramBlueToothCommonListener, int paramInt1, int paramInt2, int paramInt3)
  {
    int i = setDailySportDataNative(paramInt1, paramInt2, paramInt3);
    LogUtil.d("BlueTooth", "setDailySportData seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setDataSync(BlueToothCommonListener paramBlueToothCommonListener, int paramInt)
  {
    int i = setDataSyncNative(paramInt);
    LogUtil.d("BlueTooth", "setDataSync seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setLeftOrRightHand(BlueToothCommonListener paramBlueToothCommonListener, boolean paramBoolean)
  {
    int i = setLeftOrRightHandNative(paramBoolean);
    LogUtil.d("BlueTooth", "isLeft seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setLinklost(BlueToothCommonListener paramBlueToothCommonListener, int paramInt)
  {
    int i = setLinklostNative(paramInt);
    LogUtil.d("BlueTooth", "setLinklost seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setOperationSystem(BlueToothCommonListener paramBlueToothCommonListener, int paramInt1, int paramInt2)
  {
    int i = setOperationSystemNative(paramInt1, paramInt2);
    LogUtil.d("BlueTooth", "setOS seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setSportTarget(BlueToothCommonListener paramBlueToothCommonListener, int paramInt)
  {
    int i = setSportTargetNative(paramInt);
    LogUtil.d("BlueTooth", "setSportTarget seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setStillAlarm(BlueToothCommonListener paramBlueToothCommonListener, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7)
  {
    int i = setStillAlarmNative(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, paramBoolean6, paramBoolean7);
    LogUtil.d("BlueTooth", "setStillAlarm seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setTime(BlueToothCommonListener paramBlueToothCommonListener)
  {
    Calendar localCalendar = Calendar.getInstance();
    int i = localCalendar.get(1);
    int j = 1 + localCalendar.get(2);
    int k = localCalendar.get(5);
    int m = localCalendar.get(11);
    int n = localCalendar.get(12);
    int i1 = localCalendar.get(13);
    LogUtil.d("BlueTooth", "setTime year:" + i + " month:" + j + " day:" + k + " hour:" + m + " minute:" + n + " second:" + i1);
    int i2 = setTimeNative(i, j, k, m, n, i1);
    LogUtil.d("BlueTooth", "setTime seqId:" + i2);
    if (i2 >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i2;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void setUserProfile(BlueToothCommonListener paramBlueToothCommonListener, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3)
  {
    int i = setUserProfileNative(paramBoolean, paramInt1, paramInt2, paramInt3);
    LogUtil.d("BlueTooth", "setUserProfile seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void superBind(String paramString, byte[] paramArrayOfByte, BlueToothCommonListener paramBlueToothCommonListener)
  {
    try
    {
      byte[] arrayOfByte = paramString.getBytes("UTF-8");
      int i = superBindNative(arrayOfByte, paramArrayOfByte);
      LogUtil.d("BlueTooth", "super bind seqId:" + i);
      if (i >= 0)
      {
        SendMeta localSendMeta = new SendMeta();
        localSendMeta.seqId = i;
        localSendMeta.listener = paramBlueToothCommonListener;
        this.mSendMetas.add(localSendMeta);
        return;
      }
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      do
      {
        localUnsupportedEncodingException.printStackTrace();
        LogUtil.d("BlueTooth", "bind error");
      }
      while (paramBlueToothCommonListener == null);
      paramBlueToothCommonListener.onFailure();
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void syncRecentlySportData(BlueToothCommonListener paramBlueToothCommonListener, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5)
  {
    int i = syncRecentlySportDataNative(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
    LogUtil.d("BlueTooth", "syncRecentlySportData seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testChargeRequest(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testChargeRequestNative();
    LogUtil.d("BlueTooth", "testChargeRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testEchoRequest(byte[] paramArrayOfByte, BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testEchoRequestNative(paramArrayOfByte);
    LogUtil.d("BlueTooth", "testEchoRequestNative seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testEnterTestModeRequest(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testEnterTestModeRequestNative();
    LogUtil.d("BlueTooth", "testEnterTestModeRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testExitTestModeRequest(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testExitTestModeRequestNative();
    LogUtil.d("BlueTooth", "testExitTestModeRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testLedOnRequest(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testLedOnRequestNative(0, 0);
    LogUtil.d("BlueTooth", "testLedOnRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testLedOnRequest(BlueToothCommonListener paramBlueToothCommonListener, int paramInt)
  {
    int i = testLedOnRequestNative(1, paramInt);
    LogUtil.d("BlueTooth", "testLedOnRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testReadFlagRequest(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testReadFlagRequestNative();
    LogUtil.d("BlueTooth", "testReadFlagRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testReadSensorRequest(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testReadSensorRequestNative();
    LogUtil.d("BlueTooth", "testReadSensorRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testReadSnRequest(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testReadSnRequestNative();
    LogUtil.d("BlueTooth", "testVibrateRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testSetLedBurnInRequest(BlueToothCommonListener paramBlueToothCommonListener, boolean paramBoolean)
  {
    int i = testSetLedBurnInRequestNative(paramBoolean);
    LogUtil.d("BlueTooth", "testSetLedBurnInRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testSetMotorBurnInRequest(BlueToothCommonListener paramBlueToothCommonListener, boolean paramBoolean)
  {
    int i = testSetMotorBurnInRequestNative(paramBoolean);
    LogUtil.d("BlueTooth", "testSetMotorBurnInRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testVibrateRequest(BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testVibrateRequestNative();
    LogUtil.d("BlueTooth", "testVibrateRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testWriteFlagRequest(byte paramByte, BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testWriteFlagRequestNative(paramByte);
    LogUtil.d("BlueTooth", "testWriteFlagRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public void testWriteSnRequest(byte[] paramArrayOfByte, BlueToothCommonListener paramBlueToothCommonListener)
  {
    int i = testWriteSnRequestNative(paramArrayOfByte);
    LogUtil.d("BlueTooth", "testVibrateRequest seqId:" + i);
    if (i >= 0)
    {
      SendMeta localSendMeta = new SendMeta();
      localSendMeta.seqId = i;
      localSendMeta.listener = paramBlueToothCommonListener;
      this.mSendMetas.add(localSendMeta);
      return;
    }
    paramBlueToothCommonListener.onFailure();
  }

  public static abstract interface BlueToothAlarmListReceiverListener
  {
    public abstract void onSuccess(ClockList paramClockList);
  }

  public static abstract interface BlueToothBondReceiverListener
  {
    public abstract void onFailure();

    public abstract void onSuccess();
  }

  public static abstract interface BlueToothCommonListener
  {
    public abstract void onFailure();

    public abstract void onSuccess();
  }

  public static abstract interface BlueToothConnectResetListener
  {
    public abstract void onReset();
  }

  public static abstract interface BlueToothDataSyncProgressListener
  {
    public abstract void onSyncEnd();

    public abstract void onSyncStart();
  }

  public static abstract interface BlueToothDataVerifyListener
  {
    public abstract void onVerify(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  }

  public static abstract interface BlueToothLogReceiverListener
  {
    public abstract void onLogReceived(byte[] paramArrayOfByte);
  }

  public static abstract interface BlueToothLoginReceiverListener
  {
    public abstract void onFailure();

    public abstract void onSuccess();
  }

  public static abstract interface BlueToothOTAEnterOtaModeReceiverListener
  {
    public abstract void onEnterOtaModeResponse(byte paramByte1, byte paramByte2);
  }

  public static abstract interface BlueToothRemoteControlReceiverListener
  {
    public abstract void onCameraTakePicture();

    public abstract void onDoubleClick();

    public abstract void onSingleClick();
  }

  public static abstract interface BlueToothSleepReceiverListener
  {
    public abstract void onFailure();

    public abstract void onSuccess(List<BlueToothSleepData> paramList);
  }

  public static abstract interface BlueToothSleepSettingReceiverListener
  {
    public abstract void onFailure();

    public abstract void onSuccess(List<BlueToothSleepData> paramList);
  }

  public static abstract interface BlueToothSportReceiverListener
  {
    public abstract void onFailure();

    public abstract void onSuccess(List<BlueToothSportData> paramList);
  }

  public static abstract interface BlueToothSuperBondReceiverListener
  {
    public abstract void onFailure(int paramInt);

    public abstract void onSuccess();
  }

  public static abstract interface BlueToothTestModeReceiverListener
  {
    public abstract void onTestButton(int paramInt1, int paramInt2, long paramLong);

    public abstract void onTestChargeReadResponse(short paramShort);

    public abstract void onTestEchoResponse(byte[] paramArrayOfByte);

    public abstract void onTestFlagReadResponse(byte paramByte);

    public abstract void onTestSensorReadResponse(short paramShort1, short paramShort2, short paramShort3);

    public abstract void onTestSnReadResponse(byte[] paramArrayOfByte);
  }

  class SendMeta
  {
    BlueTooth.BlueToothCommonListener listener;
    int seqId;

    SendMeta()
    {
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.stack.BlueTooth
 * JD-Core Version:    0.6.2
 */