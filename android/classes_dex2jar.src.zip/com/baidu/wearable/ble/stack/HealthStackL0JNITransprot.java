package com.baidu.wearable.ble.stack;

import android.content.Context;
import com.baidu.wearable.ble.util.LogUtil;

public class HealthStackL0JNITransprot
{
  private static HealthStackL0JNITransprot instance;
  private final String TAG = "HealthStackL0JNITransprot";
  private Context mContext;
  private IBlueToothSend mSender;

  static
  {
    classInitNative();
  }

  private HealthStackL0JNITransprot(Context paramContext, IBlueToothSend paramIBlueToothSend)
  {
    this.mContext = paramContext.getApplicationContext();
    this.mSender = paramIBlueToothSend;
  }

  public static native void classInitNative();

  public static HealthStackL0JNITransprot getInstance(Context paramContext, IBlueToothSend paramIBlueToothSend)
  {
    if (instance == null);
    try
    {
      if (instance == null)
      {
        instance = new HealthStackL0JNITransprot(paramContext, paramIBlueToothSend);
        instance.init();
      }
      return instance;
    }
    finally
    {
    }
  }

  public void finalize()
  {
    instance = null;
  }

  public native int init();

  public int sendData(long paramLong, byte[] paramArrayOfByte)
  {
    LogUtil.v("HealthStackL0JNITransprot", "sendData");
    return this.mSender.sendData(paramArrayOfByte);
  }

  public native int sendReadResult(byte[] paramArrayOfByte, char paramChar);

  public native int sendWriteResult(int paramInt);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.stack.HealthStackL0JNITransprot
 * JD-Core Version:    0.6.2
 */