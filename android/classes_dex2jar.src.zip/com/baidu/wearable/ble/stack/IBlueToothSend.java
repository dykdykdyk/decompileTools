package com.baidu.wearable.ble.stack;

public abstract interface IBlueToothSend
{
  public abstract int sendData(byte[] paramArrayOfByte);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.stack.IBlueToothSend
 * JD-Core Version:    0.6.2
 */