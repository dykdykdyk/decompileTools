package com.baidu.wearable.ble.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeUtil
{
  private static final String TAG = "TimeUtil";

  public static long dateToTimestamp(String paramString)
  {
    int i = Integer.valueOf(paramString.substring(0, 3)).intValue();
    int j = Integer.valueOf(paramString.substring(4, 5)).intValue();
    int k = Integer.valueOf(paramString.substring(6, 7)).intValue();
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(i, j, k);
    return localCalendar.getTimeInMillis() / 1000L;
  }

  public static int daysBetween(Calendar paramCalendar1, Calendar paramCalendar2)
  {
    Calendar localCalendar = (Calendar)paramCalendar1.clone();
    for (int i = 0; ; i++)
    {
      if (!localCalendar.before(paramCalendar2))
        return i;
      localCalendar.add(5, 1);
    }
  }

  public static int getCurrentYear()
  {
    return Calendar.getInstance().get(1);
  }

  public static String getDate(long paramLong)
  {
    Date localDate = new Date(paramLong);
    return new SimpleDateFormat("yyyy-MM-dd").format(localDate);
  }

  public static String getDateBeforeDays(int paramInt)
  {
    Calendar.getInstance();
    long l = 86400000L * paramInt;
    return getDate(System.currentTimeMillis() - l);
  }

  public static int getDayCountForCurrentMonth()
  {
    return Calendar.getInstance().getActualMaximum(5);
  }

  public static long getDayStart()
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
    return localCalendar.getTimeInMillis();
  }

  public static long getDayStartTimestamp()
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
    return localCalendar.getTimeInMillis();
  }

  public static long getDayStartTimestamp(int paramInt)
  {
    return getDayStartTimestamp() - 86400000L * paramInt;
  }

  public static long getDayStartTimestamp(long paramLong)
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTimeInMillis(paramLong);
    localCalendar.set(localCalendar.get(1), localCalendar.get(2), localCalendar.get(5), 0, 0, 0);
    return localCalendar.getTimeInMillis();
  }

  public static long getDurationStart()
  {
    Calendar localCalendar = Calendar.getInstance();
    int i = localCalendar.get(1);
    int j = localCalendar.get(2);
    int k = localCalendar.get(5);
    int m = localCalendar.get(11);
    int n = localCalendar.get(12);
    localCalendar.set(i, j, k, m, n - n % 15, 0);
    return localCalendar.getTimeInMillis();
  }

  public static long getDurationStart(long paramLong)
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTimeInMillis(paramLong);
    int i = localCalendar.get(1);
    int j = localCalendar.get(2);
    int k = localCalendar.get(5);
    int m = localCalendar.get(11);
    int n = localCalendar.get(12);
    localCalendar.set(i, j, k, m, n - n % 15, 0);
    return localCalendar.getTimeInMillis();
  }

  public static String getLastYear()
  {
    Calendar localCalendar = Calendar.getInstance();
    int i = -1 + localCalendar.get(1);
    int j = localCalendar.get(2);
    int k = localCalendar.get(5);
    String str1 = String.valueOf(i);
    if ((j < 10) && (j > 0));
    for (String str2 = "0" + String.valueOf(j); ; str2 = String.valueOf(j))
    {
      String str3 = String.valueOf(k);
      return str1 + str2 + str3;
    }
  }

  public static long getMonthStartTimestamp()
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(localCalendar.get(1), localCalendar.get(2), 1);
    return localCalendar.getTimeInMillis() / 1000L;
  }

  public static long getNextDurationStart()
  {
    Calendar localCalendar = Calendar.getInstance();
    int i = localCalendar.get(1);
    int j = localCalendar.get(2);
    int k = localCalendar.get(5);
    int m = localCalendar.get(11);
    int n = localCalendar.get(12);
    localCalendar.set(i, j, k, m, n + (15 - n % 15), 0);
    return localCalendar.getTimeInMillis();
  }

  public static long getTimestamp(String paramString)
  {
    SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    try
    {
      Date localDate = localSimpleDateFormat.parse(paramString);
      return localDate.getTime();
    }
    catch (ParseException localParseException)
    {
      localParseException.printStackTrace();
    }
    return -1L;
  }

  public static boolean isDurationStart()
  {
    return Calendar.getInstance().get(12) % 15 == 0;
  }

  public static int monthBetween(Calendar paramCalendar1, Calendar paramCalendar2)
  {
    int i = paramCalendar1.get(1);
    return 12 * (paramCalendar2.get(1) - i) + paramCalendar2.get(2) - paramCalendar1.get(2);
  }

  public static String timestampToDate(long paramLong)
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTimeInMillis(paramLong);
    int i = localCalendar.get(1);
    int j = 1 + localCalendar.get(2);
    int k = localCalendar.get(5);
    LogUtil.d("TimeUtil", "year:" + i);
    LogUtil.d("TimeUtil", "month:" + j);
    LogUtil.d("TimeUtil", "day:" + k);
    String str1 = String.valueOf(i);
    String str2 = String.valueOf(j);
    if ((j < 10) && (j > 0))
      str2 = "0" + str2;
    String str3 = String.valueOf(k);
    if ((k > 0) && (k < 10))
      str3 = "0" + str3;
    return str1 + "-" + str2 + "-" + str3;
  }

  public static String timestampToDateByMonth(long paramLong)
  {
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.setTimeInMillis(paramLong);
    int i = 1 + localCalendar.get(2);
    int j = localCalendar.get(5);
    String str1 = String.valueOf(i);
    if ((i < 10) && (i > 0))
      str1 = "0" + str1;
    String str2 = String.valueOf(j);
    if ((j > 0) && (j < 10))
      str2 = "0" + str2;
    return str1 + "月" + str2;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.util.TimeUtil
 * JD-Core Version:    0.6.2
 */