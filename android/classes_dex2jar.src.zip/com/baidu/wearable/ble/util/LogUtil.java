package com.baidu.wearable.ble.util;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import de.mindpipe.android.logging.log4j.LogConfigurator;
import java.io.File;
import java.io.PrintStream;
import java.util.Calendar;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class LogUtil
{
  private static final String APK_LOG_TAG = "Wearable";
  private static boolean DEBUG = false;
  private static boolean ERROR = false;
  private static int FILE_LOG_LEVEL = 0;
  private static boolean INFO = false;
  private static final boolean IS_DEBUGING = true;
  private static int LOGCAT_LEVEL = 0;
  private static final String LOG_ENTRY_FORMAT = "[%tF %tT][%s][%s]%s";
  private static final String LOG_FILE_NAME = ".Wearable.log";
  static final int LOG_LEVEL_DEBUG = 2;
  static final int LOG_LEVEL_ERROR = 16;
  static final int LOG_LEVEL_INFO = 4;
  static final int LOG_LEVEL_VERBOSE = 0;
  static final int LOG_LEVEL_WARN = 8;
  private static final long LOG_SIZE = 5242880L;
  private static final String LOG_TAG_STRING = "WearableLog";
  private static final String ROM_LOG_TAG = "Rom_Log";
  static final String TAG;
  private static boolean VERBOSE;
  private static boolean WARN;
  static boolean initialized;
  static PrintStream logStream;
  public static File mFile;
  public static Logger mInstance;
  public static Intent mIntent;

  static
  {
    boolean bool1 = true;
    TAG = LogUtil.class.getSimpleName();
    LOGCAT_LEVEL = 2;
    FILE_LOG_LEVEL = 2;
    boolean bool2;
    boolean bool3;
    label39: boolean bool4;
    label52: boolean bool5;
    if (LOGCAT_LEVEL <= 0)
    {
      bool2 = bool1;
      VERBOSE = bool2;
      if (LOGCAT_LEVEL > 2)
        break label94;
      bool3 = bool1;
      DEBUG = bool3;
      if (LOGCAT_LEVEL > 4)
        break label99;
      bool4 = bool1;
      INFO = bool4;
      if (LOGCAT_LEVEL > 8)
        break label104;
      bool5 = bool1;
      label67: WARN = bool5;
      if (LOGCAT_LEVEL > 16)
        break label110;
    }
    while (true)
    {
      ERROR = bool1;
      initialized = false;
      return;
      bool2 = false;
      break;
      label94: bool3 = false;
      break label39;
      label99: bool4 = false;
      break label52;
      label104: bool5 = false;
      break label67;
      label110: bool1 = false;
    }
  }

  private static void d(File paramFile)
  {
    if (DEBUG)
      Log.d("WearableLog", TAG + " : Log to file : " + paramFile);
  }

  public static void d(String paramString1, String paramString2)
  {
    if (DEBUG)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.d("WearableLog", str + " : " + paramString2);
      if (FILE_LOG_LEVEL <= 2)
        write("D", str, paramString2, null);
    }
  }

  public static void d(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (DEBUG)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.d("WearableLog", str + " : " + paramString2, paramThrowable);
      if (FILE_LOG_LEVEL <= 2)
        write("D", str, paramString2, paramThrowable);
    }
  }

  public static void debug(String paramString)
  {
    if (DEBUG)
      Logger.getLogger("Wearable").debug(paramString);
  }

  private static void e(String paramString, Exception paramException)
  {
    if (ERROR)
      Log.e("WearableLog", paramString, paramException);
  }

  public static void e(String paramString1, String paramString2)
  {
    if (ERROR)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.e("WearableLog", str + " : " + paramString2);
      if (FILE_LOG_LEVEL <= 16)
        write("E", str, paramString2, null);
    }
  }

  public static void e(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (ERROR)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.e("WearableLog", str + " : " + paramString2, paramThrowable);
      if (FILE_LOG_LEVEL <= 16)
        write("E", str, paramString2, paramThrowable);
    }
  }

  private static Intent getSendToBaiduYunIntent(String paramString)
  {
    Intent localIntent = new Intent("android.intent.action.SEND");
    localIntent.setType("text/plain");
    mFile = new File(Environment.getExternalStorageDirectory() + File.separator + "Dulife" + File.separator + "logs" + File.separator + paramString);
    localIntent.putExtra("android.intent.extra.STREAM", Uri.fromFile(mFile));
    localIntent.setPackage("com.baidu.netdisk");
    localIntent.setFlags(268435456);
    return localIntent;
  }

  public static void i(String paramString1, String paramString2)
  {
    if (INFO)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.i("WearableLog", str + " : " + paramString2);
      if (FILE_LOG_LEVEL <= 4)
        write("I", str, paramString2, null);
    }
  }

  public static void i(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (INFO)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.i("WearableLog", str + " : " + paramString2, paramThrowable);
      if (FILE_LOG_LEVEL <= 4)
        write("I", str, paramString2, paramThrowable);
    }
  }

  public static void init()
  {
    if (DEBUG)
    {
      Calendar localCalendar = Calendar.getInstance();
      int i = localCalendar.get(1);
      int j = 1 + localCalendar.get(2);
      int k = localCalendar.get(5);
      int m = localCalendar.get(11);
      int n = localCalendar.get(12);
      int i1 = localCalendar.get(13);
      String str1 = i + "-" + j + "-" + k + "-" + m + "-" + n + "-" + i1;
      String str2 = Environment.getExternalStorageDirectory() + File.separator + "Dulife" + File.separator + "logs" + File.separator + str1;
      LogConfigurator localLogConfigurator = new LogConfigurator();
      localLogConfigurator.setFileName(str2);
      localLogConfigurator.setRootLevel(Level.DEBUG);
      localLogConfigurator.setLevel("org.apache", Level.ERROR);
      localLogConfigurator.setFilePattern("%d %-5p [%c{2}]-[%L] %m%n");
      localLogConfigurator.setMaxFileSize(20971520L);
      localLogConfigurator.setImmediateFlush(true);
      localLogConfigurator.configure();
    }
  }

  public static boolean isDebug()
  {
    return true;
  }

  public static void romDebug(String paramString)
  {
    if (DEBUG)
      Logger.getLogger("Rom_Log").debug(paramString);
  }

  public static void sendBaiduYun(Context paramContext)
  {
    if ((DEBUG) && (mIntent != null) && (mFile != null) && (mFile.length() > 10L))
      paramContext.startActivity(mIntent);
  }

  private static void v(File paramFile)
  {
    if (VERBOSE)
      Log.v("WearableLog", TAG + " : Create back log file : " + paramFile.getName());
  }

  public static void v(String paramString1, String paramString2)
  {
    if (DEBUG)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.v("WearableLog", str + " : " + paramString2);
      if (FILE_LOG_LEVEL <= 2)
        write("V", str, paramString2, null);
    }
  }

  public static void v(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (DEBUG)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.v("WearableLog", str + " : " + paramString2, paramThrowable);
      if (FILE_LOG_LEVEL <= 2)
        write("V", str, paramString2, paramThrowable);
    }
  }

  private static void w()
  {
    if (WARN)
      Log.w("WearableLog", "Unable to create external cache directory");
  }

  public static void w(String paramString1, String paramString2)
  {
    if (WARN)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.w("WearableLog", str + " : " + paramString2);
      if (FILE_LOG_LEVEL <= 8)
        write("W", str, paramString2, null);
    }
  }

  public static void w(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (WARN)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.w("WearableLog", str + " : " + paramString2, paramThrowable);
      if (FILE_LOG_LEVEL <= 8)
        write("W", str, paramString2, paramThrowable);
    }
  }

  private static void write(String paramString1, String paramString2, String paramString3, Throwable paramThrowable)
  {
  }

  public static void wtf(String paramString1, String paramString2)
  {
    if (ERROR)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.wtf("WearableLog", str + " : " + paramString2);
      if (FILE_LOG_LEVEL <= 16)
        write("E", str, paramString2, null);
    }
  }

  public static void wtf(String paramString1, String paramString2, Throwable paramThrowable)
  {
    if (ERROR)
    {
      String str = Thread.currentThread().getName() + ":" + paramString1;
      Log.wtf("WearableLog", str + " : " + paramString2, paramThrowable);
      if (FILE_LOG_LEVEL <= 16)
        write("E", str, paramString2, paramThrowable);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.util.LogUtil
 * JD-Core Version:    0.6.2
 */