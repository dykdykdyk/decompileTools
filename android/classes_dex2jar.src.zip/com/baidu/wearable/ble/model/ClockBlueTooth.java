package com.baidu.wearable.ble.model;

import android.os.Handler;
import android.os.Message;
import com.baidu.wearable.ble.stack.BlueTooth;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothAlarmListReceiverListener;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothCommonListener;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.Timer;
import java.util.TimerTask;

public class ClockBlueTooth
{
  private static final int BLUETOOTH_TIMEOUT = 30000;
  private static final int KEY_FAILURE = 2;
  private static final int KEY_SUCCESS = 1;
  private static final String TAG = "ClockBlueTooth";
  private static BlueTooth mBlueTooth;
  private static ClockBlueTooth mInstance;
  private boolean mGetClockListFlag = false;
  private GetClockListListener mGetClockListListener;
  private Handler mHandler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      switch (paramAnonymousMessage.what)
      {
      default:
      case 2:
      case 1:
      }
      ClockList localClockList;
      do
      {
        do
          return;
        while (ClockBlueTooth.this.mGetClockListListener == null);
        ClockBlueTooth.this.mGetClockListListener.onFailure();
        return;
        localClockList = (ClockList)paramAnonymousMessage.obj;
      }
      while (ClockBlueTooth.this.mGetClockListListener == null);
      ClockBlueTooth.this.mGetClockListListener.onSuccess(localClockList);
    }
  };

  public static ClockBlueTooth getInstance()
  {
    if (mInstance == null);
    try
    {
      if (mInstance == null)
      {
        mInstance = new ClockBlueTooth();
        mBlueTooth = BlueTooth.getInstance();
      }
      return mInstance;
    }
    finally
    {
    }
  }

  public void getClockList(GetClockListListener paramGetClockListListener)
  {
    this.mGetClockListListener = paramGetClockListListener;
    this.mGetClockListFlag = false;
    new Timer().schedule(new TimerTask()
    {
      public void run()
      {
        LogUtil.d("ClockBlueTooth", "mGetClockListFlag:" + ClockBlueTooth.this.mGetClockListFlag);
        if (!ClockBlueTooth.this.mGetClockListFlag)
        {
          ClockBlueTooth.this.mHandler.sendEmptyMessage(2);
          ClockBlueTooth.this.mGetClockListFlag = true;
        }
      }
    }
    , 30000L);
    mBlueTooth.registerAlarmListReceiverListener(new BlueTooth.BlueToothAlarmListReceiverListener()
    {
      public void onSuccess(ClockList paramAnonymousClockList)
      {
        LogUtil.d("ClockBlueTooth", "receive alarmList cmd success, mGetClockListFlag:" + ClockBlueTooth.this.mGetClockListFlag);
        for (int i = 0; ; i++)
        {
          if (i >= paramAnonymousClockList.getListSize())
          {
            if (!ClockBlueTooth.this.mGetClockListFlag)
            {
              Message localMessage = new Message();
              localMessage.what = 1;
              localMessage.obj = paramAnonymousClockList;
              ClockBlueTooth.this.mHandler.sendMessage(localMessage);
              ClockBlueTooth.this.mGetClockListFlag = true;
            }
            return;
          }
          LogUtil.d("ClockBlueTooth", "alarm:" + paramAnonymousClockList.getClock(i));
        }
      }
    });
    mBlueTooth.getAlarmList(new BlueTooth.BlueToothCommonListener()
    {
      public void onFailure()
      {
        LogUtil.d("ClockBlueTooth", "send getAlarmList cmd failure");
        if (!ClockBlueTooth.this.mGetClockListFlag)
        {
          ClockBlueTooth.this.mHandler.sendEmptyMessage(2);
          ClockBlueTooth.this.mGetClockListFlag = true;
        }
      }

      public void onSuccess()
      {
        LogUtil.d("ClockBlueTooth", "send getAlarmList cmd success, mGetClockListFlag:" + ClockBlueTooth.this.mGetClockListFlag);
      }
    });
  }

  public static abstract interface GetClockListListener
  {
    public abstract void onFailure();

    public abstract void onSuccess(ClockList paramClockList);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.ClockBlueTooth
 * JD-Core Version:    0.6.2
 */