package com.baidu.wearable.ble.model;

public class BlueToothSleepDataSection
{
  public int minute;
  public int type;

  public void setMinute(int paramInt)
  {
    this.minute = paramInt;
  }

  public void setType(int paramInt)
  {
    this.type = paramInt;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.BlueToothSleepDataSection
 * JD-Core Version:    0.6.2
 */