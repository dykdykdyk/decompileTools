package com.baidu.wearable.ble.model;

import com.baidu.wearable.ble.stack.BlueTooth;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothSleepReceiverListener;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothSleepSettingReceiverListener;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.sleep.SleepController.SleepDetailListener;
import com.baidu.wearable.sleep.SleepController.SleepSettingDetailListener;
import com.baidu.wearable.sleep.SleepDetail;
import com.baidu.wearable.sleep.SleepSettingDetail;
import com.baidu.wearable.sleep.SleepSettingState;
import com.baidu.wearable.sleep.SleepState;
import com.baidu.wearable.util.TimeUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SleepBlueTooth
{
  private static final String TAG = "SleepBlueTooth";

  private static List<SleepDetail> constructSleepDetails(List<BlueToothSleepData> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator1 = paramList.iterator();
    while (true)
    {
      if (!localIterator1.hasNext())
        return localArrayList;
      BlueToothSleepData localBlueToothSleepData = (BlueToothSleepData)localIterator1.next();
      String str = localBlueToothSleepData.date;
      long l = localBlueToothSleepData.getSecond();
      if ((l > 0L) && (str != null))
      {
        Iterator localIterator2 = localBlueToothSleepData.sleepDatas.iterator();
        while (localIterator2.hasNext())
        {
          BlueToothSleepDataSection localBlueToothSleepDataSection = (BlueToothSleepDataSection)localIterator2.next();
          int i = localBlueToothSleepDataSection.minute;
          int j = localBlueToothSleepDataSection.type;
          if ((i >= 0) && (i <= 1440) && (j > 0) && (j <= 3))
            localArrayList.add(new SleepDetail(l + i * 60, str, SleepState.valueOf(j)));
        }
      }
    }
  }

  private static List<SleepSettingDetail> constructSleepSettingDetails(List<BlueToothSleepData> paramList)
  {
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator1 = paramList.iterator();
    while (true)
    {
      if (!localIterator1.hasNext())
        return localArrayList;
      BlueToothSleepData localBlueToothSleepData = (BlueToothSleepData)localIterator1.next();
      long l = localBlueToothSleepData.getSecond();
      String str = localBlueToothSleepData.date;
      if ((l > 0L) && (str != null))
      {
        Iterator localIterator2 = localBlueToothSleepData.sleepDatas.iterator();
        while (localIterator2.hasNext())
        {
          BlueToothSleepDataSection localBlueToothSleepDataSection = (BlueToothSleepDataSection)localIterator2.next();
          int i = localBlueToothSleepDataSection.minute;
          int j = localBlueToothSleepDataSection.type;
          if ((i >= 0) && (i <= 1440) && (j >= 0) && (j <= 1))
          {
            LogUtil.d("SleepBlueTooth", "minute:" + i + ", state:" + j);
            localArrayList.add(new SleepSettingDetail(l + i * 60, str, SleepSettingState.valueOf(j)));
          }
        }
      }
    }
  }

  public static void setOnSleepListener(SleepController.SleepDetailListener paramSleepDetailListener)
  {
    BlueTooth.getInstance().registerSleepReceiverListener(new BlueTooth.BlueToothSleepReceiverListener()
    {
      public void onFailure()
      {
        LogUtil.d("SleepBlueTooth", "receive sleep data failure");
      }

      public void onSuccess(List<BlueToothSleepData> paramAnonymousList)
      {
        LogUtil.d("SleepBlueTooth", "receive sleep data success, count:" + paramAnonymousList.size());
        Iterator localIterator1 = paramAnonymousList.iterator();
        while (true)
        {
          if (!localIterator1.hasNext())
          {
            List localList = SleepBlueTooth.constructSleepDetails(paramAnonymousList);
            if (SleepBlueTooth.this != null)
              SleepBlueTooth.this.onReceive(localList);
            return;
          }
          BlueToothSleepData localBlueToothSleepData = (BlueToothSleepData)localIterator1.next();
          LogUtil.d("SleepBlueTooth", "sleep data timestamp:" + localBlueToothSleepData.timestamp_second + ", date:" + localBlueToothSleepData.date);
          LogUtil.debug("sleep data timestamp:" + localBlueToothSleepData.timestamp_second + ", date:" + localBlueToothSleepData.date);
          Iterator localIterator2 = localBlueToothSleepData.sleepDatas.iterator();
          while (localIterator2.hasNext())
          {
            BlueToothSleepDataSection localBlueToothSleepDataSection = (BlueToothSleepDataSection)localIterator2.next();
            LogUtil.d("SleepBlueTooth", "sleep minute:" + localBlueToothSleepDataSection.minute + ", " + TimeUtil.getReadableTime(localBlueToothSleepData.timestamp_second, localBlueToothSleepDataSection.minute) + ", state:" + localBlueToothSleepDataSection.type);
            LogUtil.debug("sleep minute:" + localBlueToothSleepDataSection.minute + ", " + TimeUtil.getReadableTime(localBlueToothSleepData.timestamp_second, localBlueToothSleepDataSection.minute) + ", state:" + localBlueToothSleepDataSection.type);
          }
        }
      }
    });
  }

  public static void setOnSleepSettingListener(SleepController.SleepSettingDetailListener paramSleepSettingDetailListener)
  {
    BlueTooth.getInstance().registerSleepSettingReceiverListener(new BlueTooth.BlueToothSleepSettingReceiverListener()
    {
      public void onFailure()
      {
        LogUtil.d("SleepBlueTooth", "receive sleep setting data failure");
      }

      public void onSuccess(List<BlueToothSleepData> paramAnonymousList)
      {
        LogUtil.d("SleepBlueTooth", "receive setting sleep data success, count:" + paramAnonymousList.size());
        Iterator localIterator1 = paramAnonymousList.iterator();
        while (true)
        {
          if (!localIterator1.hasNext())
          {
            List localList = SleepBlueTooth.constructSleepSettingDetails(paramAnonymousList);
            if (SleepBlueTooth.this != null)
              SleepBlueTooth.this.onReceive(localList);
            return;
          }
          BlueToothSleepData localBlueToothSleepData = (BlueToothSleepData)localIterator1.next();
          LogUtil.d("SleepBlueTooth", "sleep setting data timestamp:" + localBlueToothSleepData.timestamp_second + ", date:" + localBlueToothSleepData.date);
          LogUtil.debug("sleep setting data timestamp:" + localBlueToothSleepData.timestamp_second + ", date:" + localBlueToothSleepData.date);
          Iterator localIterator2 = localBlueToothSleepData.sleepDatas.iterator();
          while (localIterator2.hasNext())
          {
            BlueToothSleepDataSection localBlueToothSleepDataSection = (BlueToothSleepDataSection)localIterator2.next();
            LogUtil.d("SleepBlueTooth", "sleep setting minute:" + localBlueToothSleepDataSection.minute + ", " + TimeUtil.getReadableTime(localBlueToothSleepData.timestamp_second, localBlueToothSleepDataSection.minute) + ", state:" + localBlueToothSleepDataSection.type);
            LogUtil.debug("sleep setting minute:" + localBlueToothSleepDataSection.minute + ", " + TimeUtil.getReadableTime(localBlueToothSleepData.timestamp_second, localBlueToothSleepDataSection.minute) + ", state:" + localBlueToothSleepDataSection.type);
          }
        }
      }
    });
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.SleepBlueTooth
 * JD-Core Version:    0.6.2
 */