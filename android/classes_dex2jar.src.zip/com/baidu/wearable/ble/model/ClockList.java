package com.baidu.wearable.ble.model;

import com.baidu.wearable.ble.util.LogUtil;
import java.util.ArrayList;
import java.util.List;

public class ClockList
{
  private static final String TAG = "ClockList";
  public List<Clock> clocks = new ArrayList();

  public void addClock(Clock paramClock)
  {
    this.clocks.add(paramClock);
  }

  public Clock getClock(int paramInt)
  {
    return (Clock)this.clocks.get(paramInt);
  }

  public List<Clock> getClocks()
  {
    return this.clocks;
  }

  public int getListSize()
  {
    return this.clocks.size();
  }

  public void init()
  {
    LogUtil.v("ClockList", "init");
    if (this.clocks == null)
      this.clocks = new ArrayList();
  }

  public void setClocks(List<Clock> paramList)
  {
    this.clocks = paramList;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.ClockList
 * JD-Core Version:    0.6.2
 */