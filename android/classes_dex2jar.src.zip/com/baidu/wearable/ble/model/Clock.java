package com.baidu.wearable.ble.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.baidu.wearable.ble.util.LogUtil;
import java.util.Calendar;

public class Clock
  implements Parcelable
{
  public static final String CLOCK_KEY_ALARM_ID = "alarm_id";
  public static final String CLOCK_KEY_HOUR = "hour";
  public static final String CLOCK_KEY_MINUTE = "minute";
  public static final Parcelable.Creator<Clock> CREATOR = new Parcelable.Creator()
  {
    public Clock createFromParcel(Parcel paramAnonymousParcel)
    {
      Clock localClock = new Clock();
      localClock.id = paramAnonymousParcel.readLong();
      localClock.year = paramAnonymousParcel.readInt();
      localClock.month = paramAnonymousParcel.readInt();
      localClock.day = paramAnonymousParcel.readInt();
      localClock.hour = paramAnonymousParcel.readInt();
      localClock.minute = paramAnonymousParcel.readInt();
      localClock.alarm_id = paramAnonymousParcel.readInt();
      boolean[] arrayOfBoolean = new boolean[8];
      paramAnonymousParcel.readBooleanArray(arrayOfBoolean);
      localClock.Sun = arrayOfBoolean[0];
      localClock.Mon = arrayOfBoolean[1];
      localClock.Tue = arrayOfBoolean[2];
      localClock.Wed = arrayOfBoolean[3];
      localClock.Thu = arrayOfBoolean[4];
      localClock.Fri = arrayOfBoolean[5];
      localClock.Sat = arrayOfBoolean[6];
      localClock.on = arrayOfBoolean[7];
      return localClock;
    }

    public Clock[] newArray(int paramAnonymousInt)
    {
      return new Clock[paramAnonymousInt];
    }
  };
  private static final String TAG = "Clock";
  private boolean Fri;
  private boolean Mon;
  private boolean Sat;
  private boolean Sun;
  private boolean Thu;
  private boolean Tue;
  private boolean Wed;
  private int alarm_id = -1;
  private boolean bracelet;
  private int day;
  private boolean dirty;
  private int hour;
  private long id;
  private int minute;
  private int month;
  private boolean on;
  private int year;

  public int describeContents()
  {
    return 0;
  }

  public int getAlarmId()
  {
    return this.alarm_id;
  }

  public int getDay()
  {
    return this.day;
  }

  public int getHour()
  {
    return this.hour;
  }

  public long getId()
  {
    return this.id;
  }

  public int getMinute()
  {
    return this.minute;
  }

  public int getMonth()
  {
    return this.month;
  }

  public int getYear()
  {
    return this.year;
  }

  public boolean isBraceletDirty()
  {
    return this.bracelet;
  }

  public boolean isEveryDay()
  {
    return (this.Sun) && (this.Mon) && (this.Tue) && (this.Wed) && (this.Thu) && (this.Fri) && (this.Sat);
  }

  public boolean isExpire()
  {
    if (!isRepeat())
    {
      Calendar localCalendar = Calendar.getInstance();
      long l = localCalendar.getTimeInMillis();
      localCalendar.set(this.year, -1 + this.month, this.day, this.hour, this.minute, 0);
      if (l >= localCalendar.getTimeInMillis())
      {
        LogUtil.d("Clock", "clock is expired.");
        return true;
      }
      LogUtil.d("Clock", "clock is not expired.");
      return false;
    }
    LogUtil.d("Clock", "clock is not expired.");
    return false;
  }

  public boolean isFri()
  {
    return this.Fri;
  }

  public boolean isMon()
  {
    return this.Mon;
  }

  public boolean isNetDirty()
  {
    return this.dirty;
  }

  public boolean isOn()
  {
    return this.on;
  }

  public boolean isRepeat()
  {
    return (this.Sun) || (this.Mon) || (this.Tue) || (this.Wed) || (this.Thu) || (this.Fri) || (this.Sat);
  }

  public boolean isSat()
  {
    return this.Sat;
  }

  public boolean isSun()
  {
    return this.Sun;
  }

  public boolean isThu()
  {
    return this.Thu;
  }

  public boolean isTue()
  {
    return this.Tue;
  }

  public boolean isWed()
  {
    return this.Wed;
  }

  public void setAlarmId(int paramInt)
  {
    this.alarm_id = paramInt;
  }

  public void setBraceletDirty(boolean paramBoolean)
  {
    this.bracelet = paramBoolean;
  }

  public void setDay(int paramInt)
  {
    this.day = paramInt;
  }

  public void setFri(boolean paramBoolean)
  {
    this.Fri = paramBoolean;
  }

  public void setHour(int paramInt)
  {
    this.hour = paramInt;
  }

  public void setId(long paramLong)
  {
    this.id = paramLong;
  }

  public void setMinute(int paramInt)
  {
    this.minute = paramInt;
  }

  public void setMon(boolean paramBoolean)
  {
    this.Mon = paramBoolean;
  }

  public void setMonth(int paramInt)
  {
    this.month = paramInt;
  }

  public void setNetDirty(boolean paramBoolean)
  {
    this.dirty = paramBoolean;
  }

  public void setOn(boolean paramBoolean)
  {
    this.on = paramBoolean;
  }

  public void setSat(boolean paramBoolean)
  {
    this.Sat = paramBoolean;
  }

  public void setSun(boolean paramBoolean)
  {
    this.Sun = paramBoolean;
  }

  public void setThu(boolean paramBoolean)
  {
    this.Thu = paramBoolean;
  }

  public void setTue(boolean paramBoolean)
  {
    this.Tue = paramBoolean;
  }

  public void setWed(boolean paramBoolean)
  {
    this.Wed = paramBoolean;
  }

  public void setYear(int paramInt)
  {
    this.year = paramInt;
  }

  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeLong(this.id);
    paramParcel.writeInt(this.year);
    paramParcel.writeInt(this.month);
    paramParcel.writeInt(this.day);
    paramParcel.writeInt(this.hour);
    paramParcel.writeInt(this.minute);
    paramParcel.writeInt(this.alarm_id);
    boolean[] arrayOfBoolean = new boolean[8];
    arrayOfBoolean[0] = this.Sun;
    arrayOfBoolean[1] = this.Mon;
    arrayOfBoolean[2] = this.Tue;
    arrayOfBoolean[3] = this.Wed;
    arrayOfBoolean[4] = this.Thu;
    arrayOfBoolean[5] = this.Fri;
    arrayOfBoolean[6] = this.Sat;
    arrayOfBoolean[7] = this.on;
    paramParcel.writeBooleanArray(arrayOfBoolean);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.Clock
 * JD-Core Version:    0.6.2
 */