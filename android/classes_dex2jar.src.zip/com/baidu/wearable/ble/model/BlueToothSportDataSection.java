package com.baidu.wearable.ble.model;

public class BlueToothSportDataSection
{
  public float calorie;
  public float distance;
  public int step;
  public long timestamp;

  public boolean belongToDay(long paramLong)
  {
    return (this.timestamp >= paramLong) && (this.timestamp - paramLong < 86400L);
  }

  public void setCalory(float paramFloat)
  {
    this.calorie = paramFloat;
  }

  public void setDistance(float paramFloat)
  {
    this.distance = paramFloat;
  }

  public void setStep(int paramInt)
  {
    this.step = paramInt;
  }

  public void setTimestamp(long paramLong, int paramInt)
  {
    this.timestamp = (paramLong + 60 * (paramInt * 15));
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.BlueToothSportDataSection
 * JD-Core Version:    0.6.2
 */