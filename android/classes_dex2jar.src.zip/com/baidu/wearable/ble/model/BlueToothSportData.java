package com.baidu.wearable.ble.model;

import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.ble.util.TimeUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class BlueToothSportData
{
  private static final String TAG = "BlueToothSportData";
  public String date;
  public List<BlueToothSportDataSection> sportDatas = null;
  public long timestamp_second;

  public void addSection(BlueToothSportDataSection paramBlueToothSportDataSection)
  {
    if (this.sportDatas == null)
      this.sportDatas = new ArrayList();
    this.sportDatas.add(paramBlueToothSportDataSection);
  }

  public long getSecond()
  {
    return this.timestamp_second;
  }

  public void init()
  {
    LogUtil.v("BlueToothSportData", "init");
    if (this.sportDatas == null)
    {
      LogUtil.v("BlueToothSportData", "sportDatas is null");
      this.sportDatas = new ArrayList();
    }
  }

  public void setDate(int paramInt1, int paramInt2, int paramInt3)
  {
    LogUtil.v("BlueToothSportData", "setDate year:" + paramInt1 + " month:" + paramInt2 + " day:" + paramInt3);
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(paramInt1, paramInt2 - 1, paramInt3, 0, 0, 0);
    long l = localCalendar.getTimeInMillis();
    this.date = TimeUtil.getDate(l);
    this.timestamp_second = (l / 1000L);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.BlueToothSportData
 * JD-Core Version:    0.6.2
 */