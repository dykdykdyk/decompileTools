package com.baidu.wearable.ble.model;

import com.baidu.wearable.ble.stack.BlueTooth;
import com.baidu.wearable.ble.stack.BlueTooth.BlueToothSportReceiverListener;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.sport.Sport;
import com.baidu.wearable.sport.SportController.SportListener;
import com.baidu.wearable.sport.SportDetail;
import com.baidu.wearable.util.TimeUtil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SportBlueTooth
{
  private static final String TAG = "SportBlueTooth";

  private static List<Sport> constructBlueToothSportDataToSportDetailList(List<BlueToothSportData> paramList)
  {
    if (paramList == null)
    {
      localObject = null;
      return localObject;
    }
    Object localObject = new ArrayList();
    Iterator localIterator1 = paramList.iterator();
    label23: label40: String str3;
    Iterator localIterator4;
    if (!localIterator1.hasNext())
    {
      Iterator localIterator3 = ((List)localObject).iterator();
      if (localIterator3.hasNext())
      {
        Sport localSport = (Sport)localIterator3.next();
        str3 = localSport.getDate();
        localIterator4 = localSport.getSportDetails().iterator();
      }
    }
    while (true)
    {
      if (!localIterator4.hasNext())
      {
        LogUtil.d("SportBlueTooth", "constructBlueToothSportDataToSportDetailList:" + str3);
        break label40;
        break;
        BlueToothSportData localBlueToothSportData = (BlueToothSportData)localIterator1.next();
        String str1 = localBlueToothSportData.date;
        List localList = localBlueToothSportData.sportDatas;
        if ((str1 == null) || (localList == null))
          break label23;
        String str2 = str1;
        ArrayList localArrayList = new ArrayList();
        Iterator localIterator2 = localList.iterator();
        while (true)
        {
          if (!localIterator2.hasNext())
          {
            LogUtil.debug(str2);
            if (localArrayList.size() <= 0)
              break;
            ((List)localObject).add(new Sport(str1, localArrayList));
            break;
          }
          BlueToothSportDataSection localBlueToothSportDataSection = (BlueToothSportDataSection)localIterator2.next();
          str2 = str2 + "sport data timestamp:" + localBlueToothSportDataSection.timestamp + ", " + TimeUtil.getReadableTime(localBlueToothSportDataSection.timestamp) + ", steps:" + localBlueToothSportDataSection.step + ", calories:" + localBlueToothSportDataSection.calorie + ", distance:" + localBlueToothSportDataSection.distance;
          if ((localBlueToothSportDataSection.timestamp > 0L) && (localBlueToothSportDataSection.step >= 0) && (localBlueToothSportDataSection.calorie >= 0.0F) && (localBlueToothSportDataSection.distance >= 0.0F))
            localArrayList.add(new SportDetail(localBlueToothSportDataSection.timestamp, localBlueToothSportDataSection.step, localBlueToothSportDataSection.calorie, 1000.0F * localBlueToothSportDataSection.distance));
        }
      }
      SportDetail localSportDetail = (SportDetail)localIterator4.next();
      str3 = str3 + "time:" + localSportDetail.getTimestampS() + ", steps:" + localSportDetail.getSteps() + ", calories:" + localSportDetail.getCalories() + ", distance:" + localSportDetail.getDistance();
    }
  }

  public static void setOnSportListener(SportController.SportListener paramSportListener)
  {
    BlueTooth.getInstance().registerSportReceiverListener(new BlueTooth.BlueToothSportReceiverListener()
    {
      public void onFailure()
      {
        LogUtil.d("SportBlueTooth", "receive sport data failure");
      }

      public void onSuccess(List<BlueToothSportData> paramAnonymousList)
      {
        LogUtil.d("SportBlueTooth", "receive sport data success, count:" + paramAnonymousList.size());
        if (SportBlueTooth.this != null)
          SportBlueTooth.this.onReceive(SportBlueTooth.constructBlueToothSportDataToSportDetailList(paramAnonymousList));
      }
    });
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.SportBlueTooth
 * JD-Core Version:    0.6.2
 */