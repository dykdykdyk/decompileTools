package com.baidu.wearable.ble.model;

import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.ble.util.TimeUtil;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class BlueToothSleepData
{
  private static final String TAG = "BlueToothSleepData";
  public String date;
  public List<BlueToothSleepDataSection> sleepDatas = null;
  public long timestamp_second;

  public void addSection(BlueToothSleepDataSection paramBlueToothSleepDataSection)
  {
    this.sleepDatas.add(paramBlueToothSleepDataSection);
  }

  public long getSecond()
  {
    return this.timestamp_second;
  }

  public void init()
  {
    LogUtil.v("BlueToothSleepData", "init");
    if (this.sleepDatas == null)
    {
      LogUtil.v("BlueToothSleepData", "sleepDatas is null");
      this.sleepDatas = new ArrayList();
    }
  }

  public void setDate(int paramInt1, int paramInt2, int paramInt3)
  {
    LogUtil.v("BlueToothSleepData", "setDate year:" + paramInt1 + " month:" + paramInt2 + " day:" + paramInt3);
    Calendar localCalendar = Calendar.getInstance();
    localCalendar.set(paramInt1, paramInt2 - 1, paramInt3, 0, 0, 0);
    long l = localCalendar.getTimeInMillis();
    this.date = TimeUtil.getDate(l);
    this.timestamp_second = (l / 1000L);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.ble.model.BlueToothSleepData
 * JD-Core Version:    0.6.2
 */