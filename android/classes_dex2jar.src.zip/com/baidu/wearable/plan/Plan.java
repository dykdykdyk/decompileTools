package com.baidu.wearable.plan;

public class Plan
{
  public static final String CALORIES = "daily_calories";
  public static final String DISTANCE = "daily_distance_m";
  public static final String MTIME = "_mtime";
  public static final String STEPS = "daily_steps";
  public long _mtime;
  public float calories;
  public float distance;
  public boolean lastest;
  public long steps;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.plan.Plan
 * JD-Core Version:    0.6.2
 */