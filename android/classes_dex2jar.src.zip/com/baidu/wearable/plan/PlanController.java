package com.baidu.wearable.plan;

import android.content.Context;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.net.PlanTransport;
import com.baidu.wearable.net.PlanTransport.PlanResult;
import com.baidu.wearable.net.Transport.CommonResult;
import com.baidu.wearable.preference.PlanPreference;
import com.baidu.wearable.util.SportsIndexCalcUtil;

public class PlanController
{
  private static final String TAG = "PlanController";

  public static boolean sendPlanToNetAndUpdateDbSync(Context paramContext)
  {
    PlanTransport localPlanTransport = PlanTransport.getInstance(paramContext);
    Plan localPlan = new Plan();
    localPlan.steps = PlanPreference.getInstance(paramContext).getTargetStep();
    localPlan._mtime = PlanPreference.getInstance(paramContext).getMTime();
    int i;
    if (paramContext != null)
    {
      i = SportsIndexCalcUtil.getCaloriesFromSteps(paramContext, (int)localPlan.steps);
      localPlan.calories = i;
      if (paramContext == null)
        break label144;
    }
    label144: for (float f = 1000.0F * SportsIndexCalcUtil.getDistanceFromSteps(paramContext, (int)localPlan.steps); ; f = 6000.0F)
    {
      localPlan.distance = f;
      PlanTransport.PlanResult localPlanResult = localPlanTransport.updatePlanXSync(localPlan);
      if (localPlanResult.commonResult.errCode != 0)
        break label151;
      LogUtil.v("PlanController", "update plan to net success.");
      PlanPreference.getInstance(paramContext).setDirty(false);
      if (!localPlanResult.plan.lastest)
        PlanPreference.getInstance(paramContext).saveAllTargetPlan(localPlanResult.plan);
      return true;
      i = 100;
      break;
    }
    label151: return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.plan.PlanController
 * JD-Core Version:    0.6.2
 */