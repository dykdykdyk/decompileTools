package com.baidu.wearable;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import android.view.Window;
import com.baidu.sapi2.BDAccountManager;
import com.baidu.wearable.ble.util.LogUtil;
import com.baidu.wearable.preference.AgentPreference;
import com.baidu.wearable.sync.NetDataSyncManager;
import com.baidu.wearable.sync.NetDataSyncManager.ForceLoginCallback;
import com.baidu.wearable.sync.NetDataSyncManager.LoginCallback;

public class LoginManager
{
  private static final String TAG = "LoginManager";
  private static AlertDialog mAgentExpireDialog;
  private Activity mActivity;
  private NetDataSyncManager mNetManager;

  public LoginManager(Activity paramActivity)
  {
    this.mActivity = paramActivity;
    this.mNetManager = NetDataSyncManager.getInstance(paramActivity.getApplicationContext());
  }

  private void showAgentDialog(final LoginListener paramLoginListener)
  {
    mAgentExpireDialog = new AlertDialog.Builder(this.mActivity).setMessage(this.mActivity.getString(2131296582)).setPositiveButton(this.mActivity.getString(2131296454), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        LogUtil.d("LoginManager", "login cancel");
        if (paramLoginListener != null)
          paramLoginListener.onCancel();
      }
    }).setNegativeButton(this.mActivity.getString(2131296455), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        LoginManager.this.mNetManager.forceLogin(new NetDataSyncManager.ForceLoginCallback()
        {
          public void onFailure(int paramAnonymous2Int, String paramAnonymous2String)
          {
            LogUtil.d("LoginManager", "force login failure, errCode:" + paramAnonymous2Int + ", errMsg:" + paramAnonymous2String);
            if (this.val$listener != null)
              this.val$listener.onFailure();
          }

          public void onSuccess()
          {
            LogUtil.d("LoginManager", "force login success");
            AgentPreference.setAgentId(LoginManager.this.mActivity);
            if (this.val$listener != null)
              this.val$listener.onSuccess();
          }
        });
      }
    }).create();
    mAgentExpireDialog.getWindow().setType(2003);
    mAgentExpireDialog.setCancelable(false);
    mAgentExpireDialog.show();
  }

  public void login(final LoginListener paramLoginListener)
  {
    this.mNetManager.login(new NetDataSyncManager.LoginCallback()
    {
      public void onFailure(int paramAnonymousInt, String paramAnonymousString)
      {
        LogUtil.d("LoginManager", "login failure, errCode:" + paramAnonymousInt + ", errMsg:" + paramAnonymousString);
        if (paramAnonymousInt == 9)
          LoginManager.this.mActivity.runOnUiThread(new Runnable()
          {
            public void run()
            {
              LoginManager.this.showAgentDialog(this.val$listener);
            }
          });
        while (paramLoginListener == null)
          return;
        paramLoginListener.onFailure();
      }

      public void onSuccess()
      {
        LogUtil.d("LoginManager", "login success");
        AgentPreference.setAgentId(LoginManager.this.mActivity);
        if (paramLoginListener != null)
          paramLoginListener.onSuccess();
      }
    });
  }

  public boolean needUpgrade()
  {
    return AgentPreference.getAgentId(this.mActivity).equals("-1");
  }

  public void onStop()
  {
    LogUtil.d("LoginManager", "LoginViewManager onStop");
    if (mAgentExpireDialog != null)
    {
      LogUtil.d("LoginManager", "LoginViewManager onStop mAgentExpireDialog cancel");
      mAgentExpireDialog.cancel();
    }
  }

  public void saveBduss(String paramString)
  {
    if (TextUtils.isEmpty(paramString))
      LogUtil.e("LoginManager", "鐧诲綍鍚嶣DUSS IS NULL!!!!!!");
    while (true)
    {
      SharedPreferences.Editor localEditor = this.mActivity.getSharedPreferences("usercount", 0).edit();
      localEditor.putString("usercount_bduss", paramString);
      boolean bool = localEditor.commit();
      LogUtil.d("LoginManager", "saveBduss result " + bool);
      String str = BDAccountManager.getInstance().getUserData("uid");
      Config.init(this.mActivity, paramString, str);
      return;
      LogUtil.d("LoginManager", "鐧诲綍鍚嶣DUSS IS " + paramString);
    }
  }

  public void upgrade(final UpgradeListener paramUpgradeListener)
  {
    if (AgentPreference.getAgentId(this.mActivity).equals("-1"))
      this.mNetManager.login(new NetDataSyncManager.LoginCallback()
      {
        public void onFailure(int paramAnonymousInt, String paramAnonymousString)
        {
          LogUtil.d("LoginManager", "login failure, errCode:" + paramAnonymousInt + ", errMsg:" + paramAnonymousString);
          if (paramUpgradeListener != null)
            paramUpgradeListener.onFailure();
        }

        public void onSuccess()
        {
          LogUtil.d("LoginManager", "login success");
          AgentPreference.setAgentId(LoginManager.this.mActivity);
          if (paramUpgradeListener != null)
            paramUpgradeListener.onSuccess();
        }
      });
    while (paramUpgradeListener == null)
      return;
    paramUpgradeListener.onSuccess();
  }

  public static abstract interface LoginListener
  {
    public abstract void onCancel();

    public abstract void onFailure();

    public abstract void onSuccess();
  }

  public static enum TYPE
  {
    static
    {
      TYPE[] arrayOfTYPE = new TYPE[2];
      arrayOfTYPE[0] = LOGIN;
      arrayOfTYPE[1] = UPGRADE;
    }
  }

  public static abstract interface UpgradeListener
  {
    public abstract void onFailure();

    public abstract void onSuccess();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.wearable.LoginManager
 * JD-Core Version:    0.6.2
 */