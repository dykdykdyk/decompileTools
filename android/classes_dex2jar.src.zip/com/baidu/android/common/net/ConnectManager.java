package com.baidu.android.common.net;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;

public class ConnectManager
{
  private static final boolean DEBUG;
  private static final String TAG = ConnectManager.class.getSimpleName();
  private String mApn;
  private String mNetType;
  private String mPort;
  private String mProxy;
  private boolean mUseWap;

  public ConnectManager(Context paramContext)
  {
    checkNetworkType(paramContext);
  }

  private void checkApn(Context paramContext, NetworkInfo paramNetworkInfo)
  {
    if (paramNetworkInfo.getExtraInfo() != null)
    {
      String str2 = paramNetworkInfo.getExtraInfo().toLowerCase();
      if (str2 != null)
      {
        if ((str2.startsWith("cmwap")) || (str2.startsWith("uniwap")) || (str2.startsWith("3gwap")))
        {
          this.mUseWap = true;
          this.mApn = str2;
          this.mProxy = "10.0.0.172";
          this.mPort = "80";
          return;
        }
        if (str2.startsWith("ctwap"))
        {
          this.mUseWap = true;
          this.mApn = str2;
          this.mProxy = "10.0.0.200";
          this.mPort = "80";
          return;
        }
        if ((str2.startsWith("cmnet")) || (str2.startsWith("uninet")) || (str2.startsWith("ctnet")) || (str2.startsWith("3gnet")))
        {
          this.mUseWap = false;
          this.mApn = str2;
          return;
        }
      }
    }
    String str1 = Proxy.getDefaultHost();
    int i = Proxy.getDefaultPort();
    if ((str1 != null) && (str1.length() > 0))
    {
      this.mProxy = str1;
      if ("10.0.0.172".equals(this.mProxy.trim()))
      {
        this.mUseWap = true;
        this.mPort = "80";
        return;
      }
      if ("10.0.0.200".equals(this.mProxy.trim()))
      {
        this.mUseWap = true;
        this.mPort = "80";
        return;
      }
      this.mUseWap = false;
      this.mPort = Integer.toString(i);
      return;
    }
    this.mUseWap = false;
  }

  private void checkNetworkType(Context paramContext)
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getApplicationContext().getSystemService("connectivity")).getActiveNetworkInfo();
    if (localNetworkInfo != null)
    {
      if ("wifi".equals(localNetworkInfo.getTypeName().toLowerCase()))
      {
        this.mNetType = "wifi";
        this.mUseWap = false;
      }
    }
    else
      return;
    checkApn(paramContext, localNetworkInfo);
    this.mNetType = this.mApn;
  }

  public static boolean isNetworkConnected(Context paramContext)
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getApplicationContext().getSystemService("connectivity")).getActiveNetworkInfo();
    if (localNetworkInfo != null)
      return localNetworkInfo.isConnectedOrConnecting();
    return false;
  }

  public String getApn()
  {
    return this.mApn;
  }

  public String getNetType()
  {
    return this.mNetType;
  }

  public String getProxy()
  {
    return this.mProxy;
  }

  public String getProxyPort()
  {
    return this.mPort;
  }

  public boolean isWapNetwork()
  {
    return this.mUseWap;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.android.common.net.ConnectManager
 * JD-Core Version:    0.6.2
 */