package com.baidu.android.common.security;

import java.io.UnsupportedEncodingException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;

public final class RSAUtil
{
  public static final String ALGORITHM_RSA = "RSA";
  public static final int BYTE_IN_BITS = 8;
  public static final String PRIVATE_KEY = "PrivateKey";
  public static final int PT_MAXLEN_OFFSET = 11;
  public static final String PUBLIC_KEY = "PublicKey";

  public static byte[] decryptByPrivateKey(byte[] paramArrayOfByte, String paramString)
    throws Exception
  {
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(Base64.decode(paramString.getBytes()));
    PrivateKey localPrivateKey = KeyFactory.getInstance("RSA").generatePrivate(localPKCS8EncodedKeySpec);
    Cipher localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    localCipher.init(2, localPrivateKey);
    return localCipher.doFinal(paramArrayOfByte);
  }

  public static byte[] decryptByPublicKey(byte[] paramArrayOfByte, String paramString)
    throws Exception
  {
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(Base64.decode(paramString.getBytes()));
    PublicKey localPublicKey = KeyFactory.getInstance("RSA").generatePublic(localX509EncodedKeySpec);
    Cipher localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    localCipher.init(2, localPublicKey);
    return localCipher.doFinal(paramArrayOfByte);
  }

  public static byte[] decryptLongByPrivateKey(byte[] paramArrayOfByte, String paramString, int paramInt)
    throws Exception
  {
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(Base64.decode(paramString.getBytes()));
    PrivateKey localPrivateKey = KeyFactory.getInstance("RSA").generatePrivate(localPKCS8EncodedKeySpec);
    Cipher localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    localCipher.init(2, localPrivateKey);
    int i = paramInt / 8;
    StringBuilder localStringBuilder = new StringBuilder();
    int j = paramArrayOfByte.length;
    int n;
    for (int k = 0; k < j; k = n)
    {
      int m = j - k;
      if (i < m)
        m = i;
      byte[] arrayOfByte = new byte[m];
      System.arraycopy(paramArrayOfByte, k, arrayOfByte, 0, m);
      n = m + k;
      localStringBuilder.append(new String(localCipher.doFinal(arrayOfByte)));
    }
    return localStringBuilder.toString().getBytes();
  }

  public static byte[] encryptByPrivateKey(byte[] paramArrayOfByte, String paramString)
    throws Exception
  {
    PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(Base64.decode(paramString.getBytes()));
    PrivateKey localPrivateKey = KeyFactory.getInstance("RSA").generatePrivate(localPKCS8EncodedKeySpec);
    Cipher localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    localCipher.init(1, localPrivateKey);
    return localCipher.doFinal(paramArrayOfByte);
  }

  public static byte[] encryptByPublicKey(byte[] paramArrayOfByte, String paramString)
    throws Exception
  {
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(Base64.decode(paramString.getBytes()));
    PublicKey localPublicKey = KeyFactory.getInstance("RSA").generatePublic(localX509EncodedKeySpec);
    Cipher localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    localCipher.init(1, localPublicKey);
    return localCipher.doFinal(paramArrayOfByte);
  }

  public static byte[] encryptLongByPublicKey(byte[] paramArrayOfByte, String paramString, int paramInt)
    throws Exception
  {
    X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(Base64.decode(paramString.getBytes()));
    PublicKey localPublicKey = KeyFactory.getInstance("RSA").generatePublic(localX509EncodedKeySpec);
    Cipher localCipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
    localCipher.init(1, localPublicKey);
    int i = paramInt / 8;
    int j = i - 11;
    int k = paramArrayOfByte.length;
    byte[] arrayOfByte1 = new byte[i * ((-1 + (k + j)) / j)];
    int m = 0;
    int n = 0;
    while (n < k)
    {
      int i1 = k - n;
      if (j < i1)
        i1 = j;
      byte[] arrayOfByte2 = new byte[i1];
      System.arraycopy(paramArrayOfByte, n, arrayOfByte2, 0, i1);
      n += i1;
      System.arraycopy(localCipher.doFinal(arrayOfByte2), 0, arrayOfByte1, m, i);
      m += i;
    }
    return arrayOfByte1;
  }

  public static Map<String, Object> generateKey(int paramInt)
    throws NoSuchAlgorithmException
  {
    KeyPairGenerator localKeyPairGenerator = KeyPairGenerator.getInstance("RSA");
    localKeyPairGenerator.initialize(paramInt);
    KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
    RSAPublicKey localRSAPublicKey = (RSAPublicKey)localKeyPair.getPublic();
    RSAPrivateKey localRSAPrivateKey = (RSAPrivateKey)localKeyPair.getPrivate();
    HashMap localHashMap = new HashMap(2);
    localHashMap.put("PublicKey", localRSAPublicKey);
    localHashMap.put("PrivateKey", localRSAPrivateKey);
    return localHashMap;
  }

  // ERROR //
  public static RSAPrivateKey generateRSAPrivateKey(java.math.BigInteger paramBigInteger1, java.math.BigInteger paramBigInteger2)
    throws Exception
  {
    // Byte code:
    //   0: ldc 8
    //   2: invokestatic 50	java/security/KeyFactory:getInstance	(Ljava/lang/String;)Ljava/security/KeyFactory;
    //   5: astore_3
    //   6: new 146	java/security/spec/RSAPrivateKeySpec
    //   9: dup
    //   10: aload_0
    //   11: aload_1
    //   12: invokespecial 149	java/security/spec/RSAPrivateKeySpec:<init>	(Ljava/math/BigInteger;Ljava/math/BigInteger;)V
    //   15: astore 4
    //   17: aload_3
    //   18: aload 4
    //   20: invokevirtual 54	java/security/KeyFactory:generatePrivate	(Ljava/security/spec/KeySpec;)Ljava/security/PrivateKey;
    //   23: checkcast 130	java/security/interfaces/RSAPrivateKey
    //   26: astore 6
    //   28: aload 6
    //   30: areturn
    //   31: astore_2
    //   32: new 27	java/lang/Exception
    //   35: dup
    //   36: aload_2
    //   37: invokevirtual 152	java/security/NoSuchAlgorithmException:getMessage	()Ljava/lang/String;
    //   40: invokespecial 155	java/lang/Exception:<init>	(Ljava/lang/String;)V
    //   43: athrow
    //   44: astore 5
    //   46: new 27	java/lang/Exception
    //   49: dup
    //   50: aload 5
    //   52: invokevirtual 156	java/security/spec/InvalidKeySpecException:getMessage	()Ljava/lang/String;
    //   55: invokespecial 155	java/lang/Exception:<init>	(Ljava/lang/String;)V
    //   58: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	6	31	java/security/NoSuchAlgorithmException
    //   17	28	44	java/security/spec/InvalidKeySpecException
  }

  // ERROR //
  public static RSAPublicKey generateRSAPublicKey(java.math.BigInteger paramBigInteger1, java.math.BigInteger paramBigInteger2)
    throws Exception
  {
    // Byte code:
    //   0: ldc 8
    //   2: invokestatic 50	java/security/KeyFactory:getInstance	(Ljava/lang/String;)Ljava/security/KeyFactory;
    //   5: astore_3
    //   6: new 160	java/security/spec/RSAPublicKeySpec
    //   9: dup
    //   10: aload_0
    //   11: aload_1
    //   12: invokespecial 161	java/security/spec/RSAPublicKeySpec:<init>	(Ljava/math/BigInteger;Ljava/math/BigInteger;)V
    //   15: astore 4
    //   17: aload_3
    //   18: aload 4
    //   20: invokevirtual 76	java/security/KeyFactory:generatePublic	(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;
    //   23: checkcast 124	java/security/interfaces/RSAPublicKey
    //   26: astore 6
    //   28: aload 6
    //   30: areturn
    //   31: astore_2
    //   32: new 27	java/lang/Exception
    //   35: dup
    //   36: aload_2
    //   37: invokevirtual 152	java/security/NoSuchAlgorithmException:getMessage	()Ljava/lang/String;
    //   40: invokespecial 155	java/lang/Exception:<init>	(Ljava/lang/String;)V
    //   43: athrow
    //   44: astore 5
    //   46: new 27	java/lang/Exception
    //   49: dup
    //   50: aload 5
    //   52: invokevirtual 156	java/security/spec/InvalidKeySpecException:getMessage	()Ljava/lang/String;
    //   55: invokespecial 155	java/lang/Exception:<init>	(Ljava/lang/String;)V
    //   58: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   0	6	31	java/security/NoSuchAlgorithmException
    //   17	28	44	java/security/spec/InvalidKeySpecException
  }

  public static String getPrivateKey(Map<String, Object> paramMap)
    throws Exception
  {
    return Base64.encode(((Key)paramMap.get("PrivateKey")).getEncoded(), "utf-8");
  }

  public static String getPublicKey(Map<String, Object> paramMap)
    throws UnsupportedEncodingException
  {
    return Base64.encode(((Key)paramMap.get("PublicKey")).getEncoded(), "utf-8");
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.android.common.security.RSAUtil
 * JD-Core Version:    0.6.2
 */