package com.baidu.android.common.security;

public class RC4
{
  private static final int STATE_LENGTH = 256;
  private byte[] engineState = null;
  private byte[] workingKey = null;
  private int x = 0;
  private int y = 0;

  public RC4(String paramString)
  {
    this.workingKey = paramString.getBytes();
  }

  private void processBytes(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2, int paramInt3)
  {
    if (paramInt1 + paramInt2 > paramArrayOfByte1.length)
      throw new RuntimeException("input buffer too short");
    if (paramInt3 + paramInt2 > paramArrayOfByte2.length)
      throw new RuntimeException("output buffer too short");
    for (int i = 0; i < paramInt2; i++)
    {
      this.x = (0xFF & 1 + this.x);
      this.y = (0xFF & this.engineState[this.x] + this.y);
      int j = this.engineState[this.x];
      this.engineState[this.x] = this.engineState[this.y];
      this.engineState[this.y] = j;
      paramArrayOfByte2[(i + paramInt3)] = ((byte)(paramArrayOfByte1[(i + paramInt1)] ^ this.engineState[(0xFF & this.engineState[this.x] + this.engineState[this.y])]));
    }
  }

  private void reset()
  {
    setKey(this.workingKey);
  }

  private void setKey(byte[] paramArrayOfByte)
  {
    int i = 0;
    this.x = 0;
    this.y = 0;
    if (this.engineState == null)
      this.engineState = new byte[256];
    for (int j = 0; j < 256; j++)
      this.engineState[j] = ((byte)j);
    int k = 0;
    int m = 0;
    while (i < 256)
    {
      k = 0xFF & k + ((0xFF & paramArrayOfByte[m]) + this.engineState[i]);
      int n = this.engineState[i];
      this.engineState[i] = this.engineState[k];
      this.engineState[k] = n;
      m = (m + 1) % paramArrayOfByte.length;
      i++;
    }
  }

  public byte[] decrypt(byte[] paramArrayOfByte)
  {
    reset();
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    processBytes(paramArrayOfByte, 0, paramArrayOfByte.length, arrayOfByte, 0);
    return arrayOfByte;
  }

  public byte[] encrypt(byte[] paramArrayOfByte)
  {
    reset();
    byte[] arrayOfByte = new byte[paramArrayOfByte.length];
    processBytes(paramArrayOfByte, 0, paramArrayOfByte.length, arrayOfByte, 0);
    return arrayOfByte;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.android.common.security.RC4
 * JD-Core Version:    0.6.2
 */