package com.baidu.android.common.logging;

import android.os.Environment;
import android.os.Process;
import android.text.TextUtils;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public final class Log
{
  public static final int FILE_LIMETE = 10485760;
  public static final int FILE_NUMBER = 2;
  private static Logger sFilelogger;
  private static boolean sLog2File = false;
  private static boolean sLogEnabled = true;

  public static void d(String paramString1, String paramString2)
  {
    if (sLogEnabled)
    {
      if ((sLog2File) && (sFilelogger != null))
        sFilelogger.log(Level.INFO, paramString1 + ": " + paramString2);
    }
    else
      return;
    android.util.Log.d(paramString1, paramString2);
  }

  public static void d(String paramString1, String paramString2, Throwable paramThrowable)
  {
    d(paramString1, paramString2 + '\n' + getStackTraceString(paramThrowable));
  }

  public static void e(String paramString1, String paramString2)
  {
    if (sLogEnabled)
    {
      if ((sLog2File) && (sFilelogger != null))
        sFilelogger.log(Level.SEVERE, paramString1 + ": " + paramString2);
    }
    else
      return;
    android.util.Log.e(paramString1, paramString2);
  }

  public static void e(String paramString1, String paramString2, Throwable paramThrowable)
  {
    e(paramString1, paramString2 + '\n' + getStackTraceString(paramThrowable));
  }

  public static void e(String paramString, Throwable paramThrowable)
  {
    e(paramString, getStackTraceString(paramThrowable));
  }

  private static String getLogFileName()
  {
    String str = getProcessNameForPid(Process.myPid());
    if (TextUtils.isEmpty(str))
      str = "BaiduFileLog";
    return str.replace(':', '_');
  }

  // ERROR //
  private static String getProcessNameForPid(int paramInt)
  {
    // Byte code:
    //   0: new 35	java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial 36	java/lang/StringBuilder:<init>	()V
    //   7: ldc 105
    //   9: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   12: iload_0
    //   13: invokevirtual 108	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   16: ldc 110
    //   18: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   24: astore_1
    //   25: new 35	java/lang/StringBuilder
    //   28: dup
    //   29: invokespecial 36	java/lang/StringBuilder:<init>	()V
    //   32: ldc 105
    //   34: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: iload_0
    //   38: invokevirtual 108	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   41: ldc 112
    //   43: invokevirtual 40	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: invokevirtual 46	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   49: astore_2
    //   50: new 114	java/io/BufferedReader
    //   53: dup
    //   54: new 116	java/io/FileReader
    //   57: dup
    //   58: new 118	java/io/File
    //   61: dup
    //   62: aload_1
    //   63: invokespecial 121	java/io/File:<init>	(Ljava/lang/String;)V
    //   66: invokespecial 124	java/io/FileReader:<init>	(Ljava/io/File;)V
    //   69: invokespecial 127	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   72: astore_3
    //   73: aload_3
    //   74: invokevirtual 130	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   77: astore 7
    //   79: aload 7
    //   81: invokestatic 93	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   84: ifne +32 -> 116
    //   87: aload 7
    //   89: iconst_0
    //   90: aload 7
    //   92: iconst_0
    //   93: invokevirtual 134	java/lang/String:indexOf	(I)I
    //   96: invokevirtual 138	java/lang/String:substring	(II)Ljava/lang/String;
    //   99: astore 13
    //   101: aload 13
    //   103: astore 5
    //   105: aload_3
    //   106: astore 12
    //   108: aload 12
    //   110: invokevirtual 141	java/io/BufferedReader:close	()V
    //   113: aload 5
    //   115: areturn
    //   116: new 114	java/io/BufferedReader
    //   119: dup
    //   120: new 116	java/io/FileReader
    //   123: dup
    //   124: new 118	java/io/File
    //   127: dup
    //   128: aload_2
    //   129: invokespecial 121	java/io/File:<init>	(Ljava/lang/String;)V
    //   132: invokespecial 124	java/io/FileReader:<init>	(Ljava/io/File;)V
    //   135: invokespecial 127	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   138: astore 8
    //   140: aload 8
    //   142: invokevirtual 130	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   145: astore 9
    //   147: aload 9
    //   149: ifnull +82 -> 231
    //   152: aload 9
    //   154: ldc 143
    //   156: invokevirtual 147	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   159: ifeq +35 -> 194
    //   162: aload 9
    //   164: ldc 149
    //   166: invokevirtual 152	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   169: istore 11
    //   171: iload 11
    //   173: iflt +58 -> 231
    //   176: aload 9
    //   178: iload 11
    //   180: iconst_1
    //   181: iadd
    //   182: invokevirtual 154	java/lang/String:substring	(I)Ljava/lang/String;
    //   185: astore 5
    //   187: aload 8
    //   189: astore 12
    //   191: goto -83 -> 108
    //   194: aload 8
    //   196: invokevirtual 130	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   199: astore 10
    //   201: aload 10
    //   203: astore 9
    //   205: goto -58 -> 147
    //   208: astore 4
    //   210: ldc 156
    //   212: astore 5
    //   214: aload 4
    //   216: astore 6
    //   218: aload 6
    //   220: invokevirtual 159	java/lang/Exception:printStackTrace	()V
    //   223: aload 5
    //   225: areturn
    //   226: astore 6
    //   228: goto -10 -> 218
    //   231: ldc 156
    //   233: astore 5
    //   235: aload 8
    //   237: astore 12
    //   239: goto -131 -> 108
    //
    // Exception table:
    //   from	to	target	type
    //   50	101	208	java/lang/Exception
    //   116	147	208	java/lang/Exception
    //   152	171	208	java/lang/Exception
    //   176	187	208	java/lang/Exception
    //   194	201	208	java/lang/Exception
    //   108	113	226	java/lang/Exception
  }

  public static String getStackTraceString(Throwable paramThrowable)
  {
    if (paramThrowable == null)
      return "";
    StringWriter localStringWriter = new StringWriter();
    paramThrowable.printStackTrace(new PrintWriter(localStringWriter));
    return localStringWriter.toString();
  }

  public static void i(String paramString1, String paramString2)
  {
    if (sLogEnabled)
    {
      if ((sLog2File) && (sFilelogger != null))
        sFilelogger.log(Level.INFO, paramString1 + ": " + paramString2);
    }
    else
      return;
    android.util.Log.i(paramString1, paramString2);
  }

  public static void i(String paramString1, String paramString2, Throwable paramThrowable)
  {
    i(paramString1, paramString2 + '\n' + getStackTraceString(paramThrowable));
  }

  public static void setLog2File(boolean paramBoolean)
  {
    sLog2File = paramBoolean;
    String str1;
    String str2;
    if ((sLog2File) && (sFilelogger == null))
    {
      str1 = getLogFileName();
      str2 = new File(Environment.getExternalStorageDirectory(), str1).getAbsolutePath();
    }
    try
    {
      FileHandler localFileHandler = new FileHandler(str2 + "_%g.log", 10485760, 2, true);
      localFileHandler.setFormatter(new SimpleFormatter());
      sFilelogger = Logger.getLogger(str1);
      sFilelogger.setLevel(Level.ALL);
      sFilelogger.addHandler(localFileHandler);
      return;
    }
    catch (SecurityException localSecurityException)
    {
      localSecurityException.printStackTrace();
      return;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  public static void setLogEnabled(boolean paramBoolean)
  {
    sLogEnabled = paramBoolean;
  }

  public static void v(String paramString1, String paramString2)
  {
    if (sLogEnabled)
    {
      if ((sLog2File) && (sFilelogger != null))
        sFilelogger.log(Level.INFO, paramString1 + ": " + paramString2);
    }
    else
      return;
    android.util.Log.v(paramString1, paramString2);
  }

  public static void v(String paramString1, String paramString2, Throwable paramThrowable)
  {
    v(paramString1, paramString2 + '\n' + getStackTraceString(paramThrowable));
  }

  public static void w(String paramString1, String paramString2)
  {
    if (sLogEnabled)
    {
      if ((sLog2File) && (sFilelogger != null))
        sFilelogger.log(Level.WARNING, paramString1 + ": " + paramString2);
    }
    else
      return;
    android.util.Log.w(paramString1, paramString2);
  }

  public static void w(String paramString1, String paramString2, Throwable paramThrowable)
  {
    w(paramString1, paramString2 + '\n' + getStackTraceString(paramThrowable));
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.android.common.logging.Log
 * JD-Core Version:    0.6.2
 */