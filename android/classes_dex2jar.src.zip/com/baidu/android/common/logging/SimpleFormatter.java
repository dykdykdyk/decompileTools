package com.baidu.android.common.logging;

import java.text.MessageFormat;
import java.util.Date;
import java.util.logging.Formatter;

class SimpleFormatter extends Formatter
{
  private static String format = "{0,date} {0,time}";
  private Object[] args = new Object[1];
  Date dat = new Date();
  private MessageFormat formatter;

  // ERROR //
  public String format(java.util.logging.LogRecord paramLogRecord)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 35	java/lang/Throwable
    //   5: dup
    //   6: invokespecial 36	java/lang/Throwable:<init>	()V
    //   9: invokevirtual 40	java/lang/Throwable:getStackTrace	()[Ljava/lang/StackTraceElement;
    //   12: astore_3
    //   13: aload_3
    //   14: arraylength
    //   15: istore 4
    //   17: iconst_0
    //   18: istore 5
    //   20: iconst_0
    //   21: istore 6
    //   23: iload 5
    //   25: iload 4
    //   27: if_icmpge +398 -> 425
    //   30: aload_3
    //   31: iload 5
    //   33: aaload
    //   34: astore 7
    //   36: aload 7
    //   38: invokevirtual 46	java/lang/StackTraceElement:getClassName	()Ljava/lang/String;
    //   41: ldc 48
    //   43: invokevirtual 53	java/lang/Class:getName	()Ljava/lang/String;
    //   46: invokevirtual 59	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   49: ifeq +9 -> 58
    //   52: iconst_1
    //   53: istore 6
    //   55: goto +382 -> 437
    //   58: iload 6
    //   60: ifeq +377 -> 437
    //   63: aload 7
    //   65: invokevirtual 46	java/lang/StackTraceElement:getClassName	()Ljava/lang/String;
    //   68: astore 8
    //   70: aload 7
    //   72: invokevirtual 62	java/lang/StackTraceElement:getMethodName	()Ljava/lang/String;
    //   75: astore 9
    //   77: aload 7
    //   79: invokevirtual 66	java/lang/StackTraceElement:getLineNumber	()I
    //   82: istore 10
    //   84: aload_1
    //   85: aload 8
    //   87: invokevirtual 72	java/util/logging/LogRecord:setSourceClassName	(Ljava/lang/String;)V
    //   90: aload_1
    //   91: aload 9
    //   93: invokevirtual 75	java/util/logging/LogRecord:setSourceMethodName	(Ljava/lang/String;)V
    //   96: new 77	java/lang/StringBuffer
    //   99: dup
    //   100: invokespecial 78	java/lang/StringBuffer:<init>	()V
    //   103: astore 11
    //   105: aload_0
    //   106: getfield 26	com/baidu/android/common/logging/SimpleFormatter:dat	Ljava/util/Date;
    //   109: aload_1
    //   110: invokevirtual 82	java/util/logging/LogRecord:getMillis	()J
    //   113: invokevirtual 86	java/util/Date:setTime	(J)V
    //   116: aload_0
    //   117: getfield 30	com/baidu/android/common/logging/SimpleFormatter:args	[Ljava/lang/Object;
    //   120: iconst_0
    //   121: aload_0
    //   122: getfield 26	com/baidu/android/common/logging/SimpleFormatter:dat	Ljava/util/Date;
    //   125: aastore
    //   126: new 77	java/lang/StringBuffer
    //   129: dup
    //   130: invokespecial 78	java/lang/StringBuffer:<init>	()V
    //   133: astore 12
    //   135: aload_0
    //   136: getfield 88	com/baidu/android/common/logging/SimpleFormatter:formatter	Ljava/text/MessageFormat;
    //   139: ifnonnull +17 -> 156
    //   142: aload_0
    //   143: new 90	java/text/MessageFormat
    //   146: dup
    //   147: getstatic 18	com/baidu/android/common/logging/SimpleFormatter:format	Ljava/lang/String;
    //   150: invokespecial 92	java/text/MessageFormat:<init>	(Ljava/lang/String;)V
    //   153: putfield 88	com/baidu/android/common/logging/SimpleFormatter:formatter	Ljava/text/MessageFormat;
    //   156: aload_0
    //   157: getfield 88	com/baidu/android/common/logging/SimpleFormatter:formatter	Ljava/text/MessageFormat;
    //   160: aload_0
    //   161: getfield 30	com/baidu/android/common/logging/SimpleFormatter:args	[Ljava/lang/Object;
    //   164: aload 12
    //   166: aconst_null
    //   167: invokevirtual 95	java/text/MessageFormat:format	([Ljava/lang/Object;Ljava/lang/StringBuffer;Ljava/text/FieldPosition;)Ljava/lang/StringBuffer;
    //   170: pop
    //   171: aload 11
    //   173: aload 12
    //   175: invokevirtual 99	java/lang/StringBuffer:append	(Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;
    //   178: pop
    //   179: aload 11
    //   181: new 101	java/lang/StringBuilder
    //   184: dup
    //   185: invokespecial 102	java/lang/StringBuilder:<init>	()V
    //   188: ldc 104
    //   190: invokevirtual 107	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: aload_1
    //   194: invokevirtual 82	java/util/logging/LogRecord:getMillis	()J
    //   197: ldc2_w 108
    //   200: lrem
    //   201: invokevirtual 112	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   204: invokevirtual 115	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   207: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   210: pop
    //   211: aload 11
    //   213: ldc 120
    //   215: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   218: pop
    //   219: aload_1
    //   220: invokevirtual 123	java/util/logging/LogRecord:getSourceClassName	()Ljava/lang/String;
    //   223: ifnull +174 -> 397
    //   226: aload 11
    //   228: aload_1
    //   229: invokevirtual 123	java/util/logging/LogRecord:getSourceClassName	()Ljava/lang/String;
    //   232: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   235: pop
    //   236: aload_1
    //   237: invokevirtual 126	java/util/logging/LogRecord:getSourceMethodName	()Ljava/lang/String;
    //   240: ifnull +21 -> 261
    //   243: aload 11
    //   245: ldc 120
    //   247: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   250: pop
    //   251: aload 11
    //   253: aload_1
    //   254: invokevirtual 126	java/util/logging/LogRecord:getSourceMethodName	()Ljava/lang/String;
    //   257: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   260: pop
    //   261: aload 11
    //   263: ldc 120
    //   265: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   268: pop
    //   269: aload 11
    //   271: iload 10
    //   273: invokevirtual 129	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
    //   276: pop
    //   277: aload 11
    //   279: ldc 120
    //   281: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   284: pop
    //   285: aload_0
    //   286: aload_1
    //   287: invokevirtual 132	com/baidu/android/common/logging/SimpleFormatter:formatMessage	(Ljava/util/logging/LogRecord;)Ljava/lang/String;
    //   290: astore 21
    //   292: aload 11
    //   294: aload_1
    //   295: invokevirtual 136	java/util/logging/LogRecord:getLevel	()Ljava/util/logging/Level;
    //   298: invokevirtual 141	java/util/logging/Level:getLocalizedName	()Ljava/lang/String;
    //   301: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   304: pop
    //   305: aload 11
    //   307: ldc 143
    //   309: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   312: pop
    //   313: aload 11
    //   315: aload 21
    //   317: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   320: pop
    //   321: aload 11
    //   323: ldc 145
    //   325: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   328: pop
    //   329: aload_1
    //   330: invokevirtual 149	java/util/logging/LogRecord:getThrown	()Ljava/lang/Throwable;
    //   333: astore 26
    //   335: aload 26
    //   337: ifnull +48 -> 385
    //   340: new 151	java/io/StringWriter
    //   343: dup
    //   344: invokespecial 152	java/io/StringWriter:<init>	()V
    //   347: astore 28
    //   349: new 154	java/io/PrintWriter
    //   352: dup
    //   353: aload 28
    //   355: invokespecial 157	java/io/PrintWriter:<init>	(Ljava/io/Writer;)V
    //   358: astore 29
    //   360: aload_1
    //   361: invokevirtual 149	java/util/logging/LogRecord:getThrown	()Ljava/lang/Throwable;
    //   364: aload 29
    //   366: invokevirtual 161	java/lang/Throwable:printStackTrace	(Ljava/io/PrintWriter;)V
    //   369: aload 29
    //   371: invokevirtual 164	java/io/PrintWriter:close	()V
    //   374: aload 11
    //   376: aload 28
    //   378: invokevirtual 165	java/io/StringWriter:toString	()Ljava/lang/String;
    //   381: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   384: pop
    //   385: aload 11
    //   387: invokevirtual 166	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   390: astore 27
    //   392: aload_0
    //   393: monitorexit
    //   394: aload 27
    //   396: areturn
    //   397: aload 11
    //   399: aload_1
    //   400: invokevirtual 169	java/util/logging/LogRecord:getLoggerName	()Ljava/lang/String;
    //   403: invokevirtual 118	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   406: pop
    //   407: goto -171 -> 236
    //   410: astore_2
    //   411: aload_0
    //   412: monitorexit
    //   413: aload_2
    //   414: athrow
    //   415: astore 30
    //   417: aload 30
    //   419: invokevirtual 171	java/lang/Exception:printStackTrace	()V
    //   422: goto -37 -> 385
    //   425: iconst_0
    //   426: istore 10
    //   428: aconst_null
    //   429: astore 9
    //   431: aconst_null
    //   432: astore 8
    //   434: goto -350 -> 84
    //   437: iinc 5 1
    //   440: goto -417 -> 23
    //
    // Exception table:
    //   from	to	target	type
    //   2	17	410	finally
    //   30	52	410	finally
    //   63	84	410	finally
    //   84	156	410	finally
    //   156	236	410	finally
    //   236	261	410	finally
    //   261	335	410	finally
    //   340	385	410	finally
    //   385	392	410	finally
    //   397	407	410	finally
    //   417	422	410	finally
    //   340	385	415	java/lang/Exception
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.android.common.logging.SimpleFormatter
 * JD-Core Version:    0.6.2
 */