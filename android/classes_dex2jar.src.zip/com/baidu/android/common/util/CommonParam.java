package com.baidu.android.common.util;

import android.content.Context;
import android.text.TextUtils;

public class CommonParam
{
  private static final boolean DEBUG;
  private static final String TAG = CommonParam.class.getSimpleName();

  public static String getCUID(Context paramContext)
  {
    String str1 = getDeviceId(paramContext);
    String str2 = DeviceId.getIMEI(paramContext);
    if (TextUtils.isEmpty(str2))
      str2 = "0";
    String str3 = new StringBuffer(str2).reverse().toString();
    return str1 + "|" + str3;
  }

  private static String getDeviceId(Context paramContext)
  {
    return DeviceId.getDeviceID(paramContext);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.android.common.util.CommonParam
 * JD-Core Version:    0.6.2
 */