package com.baidu.location;

public abstract interface BDLocationListener
{
  public abstract void onReceiveLocation(BDLocation paramBDLocation);

  public abstract void onReceivePoi(BDLocation paramBDLocation);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.location.BDLocationListener
 * JD-Core Version:    0.6.2
 */