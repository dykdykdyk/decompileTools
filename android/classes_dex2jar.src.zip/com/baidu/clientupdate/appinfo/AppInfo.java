package com.baidu.clientupdate.appinfo;

import java.io.Serializable;

public class AppInfo
  implements Serializable
{
  private static final long serialVersionUID = -7278336877072691905L;
  public String mApkMd5;
  public String mChangelog;
  public String mDownurl;
  public String mIconUrl;
  public String mPackageName;
  public String mPatchDownUrl;
  public String mPatchSize;
  public String mSignMd5;
  public String mSize;
  public String mSname;
  public String mUpdateTime;
  public String mVercode;
  public String mVername;

  public String toString()
  {
    return "sname: " + this.mSname + " vcode: " + this.mVercode + " vname: " + this.mVername + " downurl: " + this.mDownurl + " changelog: " + this.mChangelog + " size: " + this.mSize + " packageName: " + this.mPackageName + " signmd5: " + this.mSignMd5 + " apkmd5: " + this.mApkMd5 + " patch_downUrl: " + this.mPatchDownUrl + " patch_size: " + this.mPatchSize + " iconurl: " + this.mIconUrl;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.appinfo.AppInfo
 * JD-Core Version:    0.6.2
 */