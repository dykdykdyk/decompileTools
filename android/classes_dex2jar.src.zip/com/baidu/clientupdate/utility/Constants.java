package com.baidu.clientupdate.utility;

public final class Constants
{
  public static final String APPSEARCH_NAME = "百度手机助手";
  public static final String APPSEARCH_PACKAGENAME = "com.baidu.appsearch";
  public static final int APPSEARCH_VERSIONCODE = 16782394;
  public static final String APP_UPDATER_ALARM_ACTION = "com.baidu.sdk.APP_UPDATER_ALARM_ACTION";
  public static final String CLIENT_UPDATE_AUTO_URL_PARAM = "client_update_auto_url_param";
  public static final String CLIENT_UPDATE_IGNORE_TIME = "client_update_ignore_time";
  public static boolean DEBUG = false;
  public static final String LOG_INTERFACE = "/appsrv?native_api=1&action=showlog";
  public static final String SDK_THREAD_PRENAME = "SDK_ClientUpdater_thread";
  public static final String URL_INTERFACE = "/lcmanage/index.php?r=InterfaceAction&method=upgrade&contype=client&clientv=2.0";
  public static final long VALID_INTERVAL = 120000L;

  public static enum StatisticType
  {
    static
    {
      FREQ_STATISTIC = new StatisticType("FREQ_STATISTIC", 1);
      StatisticType[] arrayOfStatisticType = new StatisticType[2];
      arrayOfStatisticType[0] = UE_STATISTIC;
      arrayOfStatisticType[1] = FREQ_STATISTIC;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.utility.Constants
 * JD-Core Version:    0.6.2
 */