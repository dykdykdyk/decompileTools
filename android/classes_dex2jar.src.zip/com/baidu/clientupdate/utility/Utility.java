package com.baidu.clientupdate.utility;

import android.app.ActivityManager;
import android.app.ActivityManager.RecentTaskInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.Signature;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.util.Log;
import com.baidu.appsearch.security.md5.MD5;
import com.baidu.util.Base64Encoder;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.List;
import java.util.zip.GZIPOutputStream;
import org.json.JSONException;
import org.json.JSONObject;

public final class Utility
{
  private static final Boolean DEBUG = Boolean.valueOf(Constants.DEBUG);
  public static final String EXTRA_INSTALLER_PACKAGE_NAME = "android.intent.extra.INSTALLER_PACKAGE_NAME";
  static final char[] HEXCHAR = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
  private static final String TAG = "Utility";

  public static boolean checkCallingPermission(Context paramContext)
  {
    return (paramContext.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == 0) && (paramContext.checkCallingOrSelfPermission("android.permission.INTERNET") == 0) && (paramContext.checkCallingOrSelfPermission("android.permission.GET_TASKS") == 0);
  }

  public static String convertURL(String paramString)
  {
    try
    {
      String str = new String(paramString.trim().replace(" ", "%20").replace("&", "%26").replace(",", "%2c").replace("(", "%28").replace(")", "%29").replace("!", "%21").replace("=", "%3D").replace("<", "%3C").replace(">", "%3E").replace("#", "%23").replace("$", "%24").replace("'", "%27").replace("*", "%2A").replace("-", "%2D").replace(".", "%2E").replace("/", "%2F").replace(":", "%3A").replace(";", "%3B").replace("?", "%3F").replace("@", "%40").replace("[", "%5B").replace("\\", "%5C").replace("]", "%5D").replace("_", "%5F").replace("`", "%60").replace("{", "%7B").replace("|", "%7C").replace("}", "%7D"));
      return str;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return null;
  }

  public static String creatSignInt(String paramString)
  {
    if ((paramString == null) || (paramString.length() < 32))
      return "-1";
    String str = paramString.substring(8, 24);
    long l1 = 0L;
    long l2 = 0L;
    int i = 0;
    if (i >= 8);
    for (int j = 8; ; j++)
    {
      if (j >= str.length())
      {
        return String.valueOf(0xFFFFFFFF & l1 + l2);
        l2 = l2 * 16L + Integer.parseInt(str.substring(i, i + 1), 16);
        i++;
        break;
      }
      l1 = l1 * 16L + Integer.parseInt(str.substring(j, j + 1), 16);
    }
  }

  public static Bitmap drawableToBitmap(Drawable paramDrawable)
  {
    if (paramDrawable == null)
      return null;
    if (paramDrawable.getOpacity() != -1);
    for (Bitmap.Config localConfig = Bitmap.Config.ARGB_8888; ; localConfig = Bitmap.Config.RGB_565)
    {
      Bitmap localBitmap = Bitmap.createBitmap(paramDrawable.getIntrinsicWidth(), paramDrawable.getIntrinsicHeight(), localConfig);
      Canvas localCanvas = new Canvas(localBitmap);
      paramDrawable.setBounds(0, 0, paramDrawable.getIntrinsicWidth(), paramDrawable.getIntrinsicHeight());
      paramDrawable.draw(localCanvas);
      return localBitmap;
    }
  }

  public static Bitmap findBitmapFromPackageManager(String paramString, Context paramContext)
  {
    if (DEBUG.booleanValue())
      Log.d("Utility", "findBitmapFromPackageManager pname = " + paramString);
    try
    {
      Bitmap localBitmap = drawableToBitmap(paramContext.getPackageManager().getPackageInfo(paramString, 0).applicationInfo.loadIcon(paramContext.getPackageManager()));
      return localBitmap;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      if (DEBUG.booleanValue())
        Log.e("Utility", "error1 in findBitmapFromPackageManager -:" + localNameNotFoundException);
    }
    return null;
  }

  public static byte[] gZip(byte[] paramArrayOfByte)
  {
    byte[] arrayOfByte = null;
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(localByteArrayOutputStream);
      localGZIPOutputStream.write(paramArrayOfByte);
      localGZIPOutputStream.finish();
      localGZIPOutputStream.close();
      arrayOfByte = localByteArrayOutputStream.toByteArray();
      localByteArrayOutputStream.close();
      return arrayOfByte;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return arrayOfByte;
  }

  public static String getApkmd5(Context paramContext, String paramString)
  {
    try
    {
      String str = MD5.asHex(MD5.getHash(new File(getPacakgeInfo(paramContext, paramString).applicationInfo.publicSourceDir)));
      return str;
    }
    catch (Exception localException)
    {
      Log.e("", "error" + localException.getMessage());
    }
    return "";
  }

  public static String getAutoClientUpdateUrlParam(Context paramContext)
  {
    return PreferenceManager.getDefaultSharedPreferences(paramContext).getString("client_update_auto_url_param", null);
  }

  public static byte[] getByteFromInputStream(InputStream paramInputStream)
  {
    if (paramInputStream == null)
      return null;
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    byte[] arrayOfByte1 = new byte[1024];
    try
    {
      while (true)
      {
        int j = paramInputStream.read(arrayOfByte1, 0, arrayOfByte1.length);
        i = j;
        if (i == -1)
          break;
        localByteArrayOutputStream.write(arrayOfByte1, 0, i);
      }
    }
    catch (IOException localIOException1)
    {
      while (true)
      {
        localIOException1.printStackTrace();
        int i = 0;
      }
      byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
      try
      {
        localByteArrayOutputStream.close();
        return arrayOfByte2;
      }
      catch (IOException localIOException2)
      {
        localIOException2.printStackTrace();
      }
      return arrayOfByte2;
    }
  }

  public static long getClientUpdateTimeLast(Context paramContext)
  {
    return PreferenceManager.getDefaultSharedPreferences(paramContext).getLong("client_update_ignore_time", 0L);
  }

  public static ActivityManager.RunningTaskInfo getCurrentTask(Context paramContext)
  {
    ActivityManager localActivityManager = (ActivityManager)paramContext.getSystemService("activity");
    List localList1 = localActivityManager.getRecentTasks(1, 1);
    List localList2 = localActivityManager.getRunningTasks(3);
    Iterator localIterator1 = localList1.iterator();
    Iterator localIterator2 = localList2.iterator();
    boolean bool1 = localIterator1.hasNext();
    ActivityManager.RecentTaskInfo localRecentTaskInfo = null;
    if (bool1)
    {
      localRecentTaskInfo = (ActivityManager.RecentTaskInfo)localIterator1.next();
      if (DEBUG.booleanValue())
      {
        Log.d("Utility", "getCurrentTask---------当前任务----localRecentTaskInfo.id = " + localRecentTaskInfo.id);
        Log.d("Utility", "getCurrentTask---------当前任务----localRecentTaskInfo.PackageName = " + localRecentTaskInfo.baseIntent.getComponent().getPackageName());
      }
    }
    if (localRecentTaskInfo == null)
      return null;
    boolean bool2 = localIterator2.hasNext();
    ActivityManager.RunningTaskInfo localRunningTaskInfo1 = null;
    if (bool2)
      localRunningTaskInfo1 = (ActivityManager.RunningTaskInfo)localIterator2.next();
    if (localRunningTaskInfo1 == null)
      return null;
    Object localObject;
    if ((localRecentTaskInfo.id != -1) && (localRunningTaskInfo1.id == localRecentTaskInfo.id))
    {
      localObject = localRunningTaskInfo1;
      if (DEBUG.booleanValue())
        Log.d("Utility", "getCurrentTask---------new task");
    }
    while (true)
    {
      return localObject;
      String str = localRecentTaskInfo.baseIntent.getComponent().getPackageName();
      if (!localRunningTaskInfo1.baseActivity.getPackageName().equals(str))
      {
        localObject = localRunningTaskInfo1;
      }
      else
      {
        while (localIterator2.hasNext())
        {
          ActivityManager.RunningTaskInfo localRunningTaskInfo2 = (ActivityManager.RunningTaskInfo)localIterator2.next();
          if (!localRunningTaskInfo2.baseActivity.getPackageName().equals(str))
          {
            localObject = localRunningTaskInfo2;
            break;
          }
        }
        localObject = null;
      }
    }
  }

  public static String getMD5(byte[] paramArrayOfByte)
  {
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
      localMessageDigest.update(paramArrayOfByte);
      String str = toHexString(localMessageDigest.digest());
      return str;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      localNoSuchAlgorithmException.printStackTrace();
    }
    return null;
  }

  public static PackageInfo getPacakgeInfo(Context paramContext, String paramString)
  {
    try
    {
      PackageInfo localPackageInfo = paramContext.getPackageManager().getPackageInfo(paramString, 64);
      return localPackageInfo;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
    }
    return null;
  }

  public static String getSignMd5(String paramString, Context paramContext)
  {
    PackageInfo localPackageInfo = getPacakgeInfo(paramContext, paramString);
    if (localPackageInfo != null)
      return creatSignInt(getMD5(localPackageInfo.signatures[0].toCharsString().getBytes()));
    return "";
  }

  public static String getStringFromInput(InputStream paramInputStream)
  {
    byte[] arrayOfByte = getByteFromInputStream(paramInputStream);
    if (arrayOfByte != null)
      return new String(arrayOfByte);
    return null;
  }

  public static boolean isAppForground(Context paramContext)
  {
    Context localContext = paramContext.getApplicationContext();
    ActivityManager.RunningTaskInfo localRunningTaskInfo = getCurrentTask(localContext);
    if (localRunningTaskInfo == null)
      return false;
    return TextUtils.equals(localContext.getPackageName(), localRunningTaskInfo.baseActivity.getPackageName());
  }

  public static boolean isExternalMediaMounted()
  {
    if (!Environment.getExternalStorageState().equals("mounted"))
    {
      Log.d("Utility", "no external storage");
      return false;
    }
    return true;
  }

  public static boolean isNetWorkEnabled(Context paramContext)
  {
    ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getApplicationContext().getSystemService("connectivity");
    if (localConnectivityManager == null);
    while (true)
    {
      return false;
      for (NetworkInfo localNetworkInfo : localConnectivityManager.getAllNetworkInfo())
        if ((localNetworkInfo != null) && (localNetworkInfo.isConnected()))
          return true;
    }
  }

  public static String parseJSONObjectToBase64String(JSONObject paramJSONObject)
  {
    if (paramJSONObject == null)
      return null;
    Iterator localIterator = paramJSONObject.keys();
    StringBuilder localStringBuilder = new StringBuilder();
    if (!localIterator.hasNext())
      return localStringBuilder.toString();
    String str1 = localIterator.next().toString();
    while (true)
    {
      try
      {
        String str2 = paramJSONObject.getString(str1);
        if ((str2 == null) || (str2.length() == 0))
          break;
        if (!"cuid".equals(str1))
          break label146;
        localObject = URLEncoder.encode(paramJSONObject.getString(str1));
        byte[] arrayOfByte = Base64Encoder.B64Encode(((String)localObject).getBytes());
        localStringBuilder.append("&" + str1 + "=");
        localStringBuilder.append(new String(arrayOfByte));
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
      break;
      label146: String str3 = paramJSONObject.getString(str1);
      Object localObject = str3;
    }
  }

  public static String parseJSONObjectToString(JSONObject paramJSONObject)
  {
    if (paramJSONObject == null)
      return null;
    Iterator localIterator = paramJSONObject.keys();
    StringBuilder localStringBuilder = new StringBuilder();
    if (!localIterator.hasNext())
      return localStringBuilder.toString();
    String str1 = localIterator.next().toString();
    localStringBuilder.append("&" + str1 + "=");
    while (true)
    {
      try
      {
        if (!"cuid".equals(str1))
          break label109;
        localObject = URLEncoder.encode(paramJSONObject.getString(str1));
        localStringBuilder.append((String)localObject);
      }
      catch (JSONException localJSONException)
      {
        localJSONException.printStackTrace();
      }
      break;
      label109: String str2 = paramJSONObject.getString(str1);
      Object localObject = str2;
    }
  }

  public static JSONObject parsePuString(String paramString)
  {
    int i = 0;
    if (paramString == null)
    {
      if (DEBUG.booleanValue())
        Log.d("Utility", "puString == null");
      localJSONObject = null;
      return localJSONObject;
    }
    JSONObject localJSONObject = new JSONObject();
    String[] arrayOfString1 = paramString.replace("%2C", " ").split(" ");
    int j = arrayOfString1.length;
    while (i < j)
    {
      String[] arrayOfString2 = arrayOfString1[i].replace("%40", " ").split(" ");
      try
      {
        localJSONObject.put(arrayOfString2[0], arrayOfString2[1]);
        i++;
      }
      catch (JSONException localJSONException)
      {
        while (true)
          localJSONException.printStackTrace();
      }
    }
  }

  public static void setAutoClientUpdateUrlParam(Context paramContext, String paramString)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(paramContext).edit();
    localEditor.putString("client_update_auto_url_param", paramString);
    localEditor.commit();
  }

  public static void setClientUpdateTime(Context paramContext, long paramLong)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(paramContext).edit();
    localEditor.putLong("client_update_ignore_time", paramLong);
    localEditor.commit();
  }

  public static void startSystemInstallUI(Context paramContext, File paramFile)
  {
    if (DEBUG.booleanValue())
      Log.d("Utility", "startSystemInstallUI安装文件存在:" + paramFile.exists() + ":" + paramFile.getPath());
    Intent localIntent = new Intent("android.intent.action.VIEW");
    try
    {
      localIntent.setDataAndType(Uri.fromFile(paramFile), "application/vnd.android.package-archive");
      localIntent.setFlags(1342177280);
      localIntent.putExtra("android.intent.extra.INSTALLER_PACKAGE_NAME", paramContext.getPackageName());
      localIntent.setComponent(new ComponentName("com.android.packageinstaller", "com.android.packageinstaller.PackageInstallerActivity"));
      paramContext.startActivity(localIntent);
      if (DEBUG.booleanValue())
        Log.d("Utility", "启动系统安装界面");
      return;
    }
    catch (Exception localException1)
    {
      do
      {
        if (DEBUG.booleanValue())
          Log.e("Utility", "启动系统安装界面失败");
        localIntent.setComponent(null);
        try
        {
          paramContext.startActivity(localIntent);
          return;
        }
        catch (Exception localException2)
        {
        }
      }
      while (!DEBUG.booleanValue());
      Log.e("Utility", "再次启动系统安装界面失败");
    }
  }

  public static String toHexString(byte[] paramArrayOfByte)
  {
    StringBuilder localStringBuilder = new StringBuilder(2 * paramArrayOfByte.length);
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfByte.length)
        return localStringBuilder.toString();
      localStringBuilder.append(HEXCHAR[((0xF0 & paramArrayOfByte[i]) >>> 4)]);
      localStringBuilder.append(HEXCHAR[(0xF & paramArrayOfByte[i])]);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.utility.Utility
 * JD-Core Version:    0.6.2
 */