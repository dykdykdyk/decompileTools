package com.baidu.clientupdate.utility;

import com.baidu.clientupdate.appinfo.AppInfo;
import com.baidu.clientupdate.appinfo.AppSearchInfo;
import com.baidu.clientupdate.appinfo.ClientUpdateInfo;
import com.baidu.clientupdate.appinfo.RecommandAppInfo;
import org.json.JSONObject;

public final class MsgFactory
{
  private static final boolean DEBUG = false;
  public static final int MSG_APPSEARCH = 1;
  public static final int MSG_CLIENTUPDATE = 0;
  public static final int MSG_RECOMMANDAPP = 2;
  private static final String TAG = "MsgFactory";

  public static AppInfo parseJsonResult(JSONObject paramJSONObject, int paramInt)
  {
    if (paramJSONObject == null)
      return null;
    Object localObject;
    if (paramInt == 0)
    {
      ClientUpdateInfo localClientUpdateInfo = new ClientUpdateInfo();
      localClientUpdateInfo.mIsForceUpdate = paramJSONObject.optString("isforce");
      localObject = localClientUpdateInfo;
    }
    while (true)
    {
      ((AppInfo)localObject).mSname = paramJSONObject.optString("label");
      ((AppInfo)localObject).mChangelog = paramJSONObject.optString("changelog");
      ((AppInfo)localObject).mDownurl = paramJSONObject.optString("downurl");
      ((AppInfo)localObject).mVername = paramJSONObject.optString("vname");
      ((AppInfo)localObject).mVercode = paramJSONObject.optString("vcode");
      ((AppInfo)localObject).mSignMd5 = paramJSONObject.optString("signmd5");
      ((AppInfo)localObject).mApkMd5 = paramJSONObject.optString("apkmd5");
      ((AppInfo)localObject).mSize = paramJSONObject.optString("size");
      ((AppInfo)localObject).mPatchDownUrl = paramJSONObject.optString("patch_downurl");
      ((AppInfo)localObject).mPatchSize = paramJSONObject.optString("patch_size");
      ((AppInfo)localObject).mIconUrl = paramJSONObject.optString("iconurl");
      ((AppInfo)localObject).mPackageName = paramJSONObject.optString("packagename");
      ((AppInfo)localObject).mUpdateTime = paramJSONObject.optString("update_time");
      return localObject;
      if (1 == paramInt)
      {
        localObject = new AppSearchInfo();
      }
      else
      {
        localObject = null;
        if (2 == paramInt)
          localObject = new RecommandAppInfo();
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.utility.MsgFactory
 * JD-Core Version:    0.6.2
 */