package com.baidu.clientupdate.utility;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import com.baidu.clientupdate.IClientUpdaterCallback;
import com.baidu.clientupdate.appinfo.AppInfo;
import com.baidu.clientupdate.appinfo.AppSearchInfo;
import com.baidu.clientupdate.appinfo.ClientUpdateInfo;
import com.baidu.clientupdate.appinfo.RecommandAppInfo;
import com.baidu.clientupdate.download.Download;
import com.baidu.clientupdate.download.DownloadManager;
import com.baidu.clientupdate.statistic.StatisticProcessor;
import java.util.ArrayList;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;

public final class ClientUpdateUtility
{
  private static final boolean DEBUG = false;
  private static final String INVOKE_APPSEARCH_ACTION = "com.baidu.appsearch.extinvoker.LAUNCH";
  private static final String TAG = "ClientUpdateUtility";
  private static ClientUpdateUtility mClientUpdateUtility = null;
  private long endTime;
  private AppSearchInfo mAppSearchInfo = null;
  private ClientUpdateInfo mClientUpdateInfo = null;
  private Context mContext;
  private ClientUpdateInfo mDownloadClient;
  private RecommandAppInfo mDownloadRecommand;
  private Handler mHandler;
  private IntentFilter mIntentFilter;
  private boolean mIsPatchDownload = false;
  private BroadcastReceiver mPackageReceiver;
  private ArrayList<RecommandAppInfo> mRecommandAppInfo = new ArrayList();
  private String mSavedPath = null;
  private long startTime;

  private ClientUpdateUtility(Context paramContext)
  {
    this.mContext = paramContext;
    this.mHandler = new Handler(Looper.getMainLooper());
    this.mIntentFilter = new IntentFilter();
    this.mIntentFilter.addAction("android.intent.action.PACKAGE_ADDED");
    this.mIntentFilter.addDataScheme("package");
    this.mPackageReceiver = new BroadcastReceiver()
    {
      public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
      {
        if (ClientUpdateUtility.DEBUG)
          Log.d("ClientUpdateUtility", "receive: " + paramAnonymousIntent.getAction());
        ClientUpdateUtility.this.handleIntent(paramAnonymousIntent);
      }
    };
    this.mContext.registerReceiver(this.mPackageReceiver, this.mIntentFilter);
  }

  private boolean checkAppSearchVersion()
  {
    PackageInfo localPackageInfo = Utility.getPacakgeInfo(this.mContext, "com.baidu.appsearch");
    if (localPackageInfo == null);
    while ((this.mAppSearchInfo == null) || (localPackageInfo.versionCode <= 16782394))
      return false;
    return true;
  }

  private void createDownload(AppInfo paramAppInfo, String paramString)
  {
    Download localDownload = new Download();
    localDownload.mFileName = paramAppInfo.mSname;
    localDownload.mSavedPath = paramString;
    localDownload.mUrl = paramAppInfo.mDownurl;
    localDownload.mMimeType = "application/vnd.android.package-archive";
    localDownload.mSourceKey = (paramAppInfo.mPackageName + "@" + paramAppInfo.mVercode);
    DownloadManager.getInstance(this.mContext).startDownload(localDownload);
  }

  public static ClientUpdateUtility getInstance(Context paramContext)
  {
    try
    {
      if (mClientUpdateUtility == null)
        mClientUpdateUtility = new ClientUpdateUtility(paramContext);
      ClientUpdateUtility localClientUpdateUtility = mClientUpdateUtility;
      return localClientUpdateUtility;
    }
    finally
    {
    }
  }

  private RecommandAppInfo getRecommandAppInfo()
  {
    RecommandAppInfo localRecommandAppInfo;
    if (this.mRecommandAppInfo == null)
    {
      localRecommandAppInfo = null;
      return localRecommandAppInfo;
    }
    Iterator localIterator = this.mRecommandAppInfo.iterator();
    PackageInfo localPackageInfo;
    do
    {
      if (!localIterator.hasNext())
        return null;
      localRecommandAppInfo = (RecommandAppInfo)localIterator.next();
      localPackageInfo = Utility.getPacakgeInfo(this.mContext, localRecommandAppInfo.mPackageName);
      if (localPackageInfo == null)
        break;
    }
    while (localPackageInfo.versionCode >= Integer.valueOf(localRecommandAppInfo.mVercode).intValue());
    return localRecommandAppInfo;
  }

  private void handleIntent(Intent paramIntent)
  {
    if (paramIntent != null)
      try
      {
        String str = paramIntent.getData().getSchemeSpecificPart();
        if (DEBUG)
        {
          Log.d("ClientUpdateUtility", "Install packagename: " + str);
          if (TextUtils.equals(str, "com.baidu.appsearch"))
          {
            if (this.mIsPatchDownload)
            {
              if (DEBUG)
                Log.d("ClientUpdateUtility", "来自增量下载请求，通过手助下载客户端.");
              StatisticProcessor.addOnlyValueUEStatisticWithoutCache(this.mContext, "920001", this.mContext.getPackageName());
              this.endTime = System.currentTimeMillis();
              if (this.endTime - this.startTime < 120000L)
                startDownloadIntent(this.mDownloadClient, this.mDownloadRecommand);
            }
          }
          else if ((TextUtils.equals(str, this.mDownloadRecommand.mPackageName)) && (DEBUG))
          {
            Log.d("ClientUpdateUtility", "推荐应用已安装");
            return;
          }
        }
      }
      catch (Exception localException)
      {
        if (DEBUG)
          localException.printStackTrace();
      }
  }

  private void parseRecommandAppInfo(JSONArray paramJSONArray)
  {
    if (paramJSONArray == null)
    {
      this.mRecommandAppInfo.clear();
      return;
    }
    for (int i = 0; ; i++)
    {
      if (i >= paramJSONArray.length())
      {
        if (!DEBUG)
          break;
        Iterator localIterator = this.mRecommandAppInfo.iterator();
        while (localIterator.hasNext())
        {
          AppInfo localAppInfo = (AppInfo)localIterator.next();
          Log.d("ClientUpdateUtility", "mRecommandAppInfo: " + localAppInfo.toString());
        }
        break;
      }
      JSONObject localJSONObject = paramJSONArray.optJSONObject(i);
      this.mRecommandAppInfo.add((RecommandAppInfo)MsgFactory.parseJsonResult(localJSONObject, 2));
    }
  }

  private void startDownloadIntent(ClientUpdateInfo paramClientUpdateInfo, RecommandAppInfo paramRecommandAppInfo)
  {
    if (paramClientUpdateInfo == null)
      return;
    Intent localIntent = new Intent("com.baidu.appsearch.extinvoker.LAUNCH");
    localIntent.putExtra("id", this.mContext.getPackageName());
    localIntent.putExtra("backop", "0");
    localIntent.putExtra("func", "11");
    Bundle localBundle1 = new Bundle();
    localBundle1.putString("sname", paramClientUpdateInfo.mSname);
    localBundle1.putString("packagename", paramClientUpdateInfo.mPackageName);
    localBundle1.putInt("versioncode", Integer.valueOf(paramClientUpdateInfo.mVercode).intValue());
    localBundle1.putString("downurl", paramClientUpdateInfo.mDownurl);
    localBundle1.putString("signmd5", paramClientUpdateInfo.mSignMd5);
    localBundle1.putString("tj", paramClientUpdateInfo.mSignMd5 + paramClientUpdateInfo.mSname);
    localBundle1.putString("versionname", paramClientUpdateInfo.mVername);
    localBundle1.putString("fparam", "lc");
    localBundle1.putString("iconurl", paramClientUpdateInfo.mIconUrl);
    localBundle1.putString("updatetime", paramClientUpdateInfo.mUpdateTime);
    localBundle1.putString("size", paramClientUpdateInfo.mSize);
    localBundle1.putString("changelog", paramClientUpdateInfo.mChangelog);
    if ((!TextUtils.isEmpty(paramClientUpdateInfo.mPatchDownUrl)) && (!TextUtils.isEmpty(paramClientUpdateInfo.mPatchSize)))
    {
      localBundle1.putString("patch_url", paramClientUpdateInfo.mPatchDownUrl);
      localBundle1.putLong("patch_size", Long.valueOf(paramClientUpdateInfo.mPatchSize).longValue());
    }
    localIntent.putExtra("extra_client_downloadinfo", localBundle1);
    if (DEBUG)
      Log.d("ClientUpdateUtility", "手机助手下载客户端");
    if (paramRecommandAppInfo != null)
    {
      Bundle localBundle2 = new Bundle();
      localBundle2.putString("sname", paramRecommandAppInfo.mSname);
      localBundle2.putString("packagename", paramRecommandAppInfo.mPackageName);
      localBundle2.putInt("versioncode", Integer.valueOf(paramRecommandAppInfo.mVercode).intValue());
      localBundle2.putString("downurl", paramRecommandAppInfo.mDownurl);
      localBundle2.putString("signmd5", paramRecommandAppInfo.mSignMd5);
      localBundle2.putString("tj", paramRecommandAppInfo.mSignMd5 + paramRecommandAppInfo.mSname);
      localBundle2.putString("versionname", paramRecommandAppInfo.mVername);
      localBundle2.putString("iconurl", paramRecommandAppInfo.mIconUrl);
      localBundle2.putString("fparam", "lc");
      localBundle2.putString("updatetime", paramRecommandAppInfo.mUpdateTime);
      localBundle2.putString("size", paramRecommandAppInfo.mSize);
      if ((!TextUtils.isEmpty(paramRecommandAppInfo.mPatchDownUrl)) && (!TextUtils.isEmpty(paramRecommandAppInfo.mPatchSize)))
      {
        localBundle2.putString("patch_url", paramRecommandAppInfo.mPatchDownUrl);
        localBundle2.putLong("patch_size", Long.valueOf(paramRecommandAppInfo.mPatchSize).longValue());
      }
      localBundle2.putString("changelog", paramRecommandAppInfo.mChangelog);
      localIntent.putExtra("extra_recommand_downloadinfo", localBundle2);
      if (DEBUG)
        Log.d("ClientUpdateUtility", "手机助手下载推荐应用");
      StatisticProcessor.addOnlyValueUEStatisticWithoutCache(this.mContext, "920002", this.mContext.getPackageName());
    }
    while (true)
    {
      localIntent.addFlags(32);
      localIntent.setPackage("com.baidu.appsearch");
      this.mContext.sendBroadcast(localIntent);
      return;
      StatisticProcessor.addOnlyValueUEStatisticWithoutCache(this.mContext, "920005", this.mContext.getPackageName());
    }
  }

  public void clearLastResult()
  {
    try
    {
      if (this.mAppSearchInfo != null)
        this.mAppSearchInfo = null;
      this.mRecommandAppInfo.clear();
      if (this.mClientUpdateInfo != null)
        this.mClientUpdateInfo = null;
      if (this.mDownloadRecommand != null)
        this.mDownloadRecommand = null;
      if (this.mSavedPath != null)
        this.mSavedPath = null;
      this.mIsPatchDownload = false;
      return;
    }
    finally
    {
    }
  }

  public void parseResult(JSONObject paramJSONObject, IClientUpdaterCallback paramIClientUpdaterCallback)
  {
    while (true)
    {
      String str;
      try
      {
        this.mIsPatchDownload = false;
        if (paramJSONObject == null)
        {
          paramIClientUpdaterCallback.onCompleted(null, null, null);
          return;
        }
        if (DEBUG)
          Log.d("ClientUpdateUtility", "parse result: " + paramJSONObject.toString());
        str = paramJSONObject.optString("status");
        if (TextUtils.isEmpty(str))
        {
          paramIClientUpdaterCallback.onCompleted(null, null, null);
          continue;
        }
      }
      finally
      {
      }
      if (Integer.valueOf(str).intValue() == 1)
      {
        this.mClientUpdateInfo = ((ClientUpdateInfo)MsgFactory.parseJsonResult(paramJSONObject.optJSONObject("clientupdate"), 0));
        if (this.mClientUpdateInfo != null)
        {
          this.mClientUpdateInfo.mStatus = paramJSONObject.optString("status");
          this.mClientUpdateInfo.mReverson = paramJSONObject.optString("re_version");
        }
        this.mAppSearchInfo = ((AppSearchInfo)MsgFactory.parseJsonResult(paramJSONObject.optJSONObject("appsearch"), 1));
        parseRecommandAppInfo(paramJSONObject.optJSONArray("recommandapp"));
        RecommandAppInfo localRecommandAppInfo = getRecommandAppInfo();
        if (DEBUG)
        {
          if (localRecommandAppInfo == null)
            break label327;
          Log.d("ClientUpdateUtility", "select app: " + localRecommandAppInfo);
        }
        while (true)
        {
          if ((DEBUG) && (this.mClientUpdateInfo != null))
            Log.d("ClientUpdateUtility", "mClientUpdateInfo: " + this.mClientUpdateInfo.toString());
          if ((DEBUG) && (this.mAppSearchInfo != null))
            Log.d("ClientUpdateUtility", "mAppSearchInfo: " + this.mAppSearchInfo.toString());
          paramIClientUpdaterCallback.onCompleted(this.mClientUpdateInfo, localRecommandAppInfo, this.mAppSearchInfo);
          break;
          label327: Log.d("ClientUpdateUtility", "select app: " + localRecommandAppInfo);
        }
      }
      if (Integer.valueOf(str).intValue() == 0)
      {
        this.mClientUpdateInfo = new ClientUpdateInfo();
        this.mClientUpdateInfo.mStatus = str;
        paramIClientUpdaterCallback.onCompleted(this.mClientUpdateInfo, null, null);
      }
    }
  }

  public void startDownload(ClientUpdateInfo paramClientUpdateInfo, RecommandAppInfo paramRecommandAppInfo, String paramString)
  {
    if (paramClientUpdateInfo == null)
      return;
    while (true)
    {
      try
      {
        this.mDownloadRecommand = paramRecommandAppInfo;
        this.mDownloadClient = paramClientUpdateInfo;
        this.mSavedPath = paramString;
        if ((TextUtils.isEmpty(paramClientUpdateInfo.mStatus)) || (Integer.valueOf(paramClientUpdateInfo.mStatus).intValue() != 1) || (TextUtils.isEmpty(paramClientUpdateInfo.mDownurl)) || (TextUtils.isEmpty(paramClientUpdateInfo.mSize)) || (Integer.valueOf(paramClientUpdateInfo.mSize).intValue() <= 0))
          break;
        if (paramRecommandAppInfo != null)
        {
          createDownload(paramClientUpdateInfo, paramString);
          createDownload(paramRecommandAppInfo, paramString);
          StatisticProcessor.addOnlyValueUEStatisticWithoutCache(this.mContext, "920004", this.mContext.getPackageName());
          this.mIsPatchDownload = false;
          break;
        }
      }
      finally
      {
      }
      createDownload(paramClientUpdateInfo, paramString);
      StatisticProcessor.addOnlyValueUEStatisticWithoutCache(this.mContext, "920003", this.mContext.getPackageName());
    }
  }

  public void startPatchDownload(ClientUpdateInfo paramClientUpdateInfo, RecommandAppInfo paramRecommandAppInfo, String paramString)
  {
    if (paramClientUpdateInfo == null)
      return;
    while (true)
    {
      try
      {
        this.mDownloadRecommand = paramRecommandAppInfo;
        this.mDownloadClient = paramClientUpdateInfo;
        this.mSavedPath = paramString;
        if ((TextUtils.isEmpty(paramClientUpdateInfo.mStatus)) || (Integer.valueOf(paramClientUpdateInfo.mStatus).intValue() != 1))
          break;
        boolean bool = checkAppSearchVersion();
        if (DEBUG)
          Log.d("ClientUpdateUtility", "isNewVersion: " + bool);
        if (bool)
          break label137;
        if (this.mAppSearchInfo != null)
        {
          this.startTime = System.currentTimeMillis();
          createDownload(this.mAppSearchInfo, paramString);
          this.mIsPatchDownload = true;
          break;
        }
      }
      finally
      {
      }
      startDownload(paramClientUpdateInfo, paramRecommandAppInfo, paramString);
      continue;
      label137: startDownloadIntent(paramClientUpdateInfo, paramRecommandAppInfo);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.utility.ClientUpdateUtility
 * JD-Core Version:    0.6.2
 */