package com.baidu.clientupdate.statistic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import com.baidu.clientupdate.utility.Constants;

public class UEStatisticReceiver extends BroadcastReceiver
{
  private static final boolean DEBUG = false;
  private static final String TAG = "UEStatisticReceiver";

  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str = paramIntent.getAction();
    if (DEBUG)
      Log.d("UEStatisticReceiver", "UEStatisticReceiver----------action = " + str);
    if ((TextUtils.equals(str, "com.baidu.appsearch.action.CHECKSENDSTATISTICDATA")) || (TextUtils.equals(str, "android.intent.action.TIME_SET")))
      StatisticPoster.getInstance(paramContext).checkSendStatisticData("UEStatisticReceiver");
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.statistic.UEStatisticReceiver
 * JD-Core Version:    0.6.2
 */