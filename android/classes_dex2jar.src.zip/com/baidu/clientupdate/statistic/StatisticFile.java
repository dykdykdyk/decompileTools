package com.baidu.clientupdate.statistic;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.TextUtils;
import android.util.Log;
import com.baidu.android.common.util.Util;
import com.baidu.clientupdate.utility.Constants;
import com.baidu.clientupdate.utility.Constants.StatisticType;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class StatisticFile
{
  private static final boolean DEBUG = false;
  public static final String LAST_SENDSTATISTIC_TIME = "updateinfo";
  public static final String LAST_SEND_DOWNLOAD_TIME = "download_time";
  public static final int NUM_1024 = 1024;
  public static final long ONEDAY = 86400000L;
  public static final String SETTINGS_PREFERENCE = "statistic_settings_preference";
  public static final double STATISTIC_DEFAULT_THRESHOLD = 10.0D;
  public static final double STATISTIC_DEFAULT_TIMEOUT = 7.0D;
  public static final double STATISTIC_DEFAULT_TIMEUP = 2.0D;
  public static final String STATISTIC_DOWNLOAD_INFO = "05";
  public static final String STATISTIC_MASTER_SWITCH = "master";
  public static final double STATISTIC_MAX_THRESHOLD = 300.0D;
  public static final double STATISTIC_MAX_TIMEOUT = 30.0D;
  public static final double STATISTIC_MAX_TIMEUP = 4.0D;
  public static final double STATISTIC_MIN_THRESHOLD = 1.0D;
  public static final double STATISTIC_MIN_TIMEOUT = 4.0D;
  public static final double STATISTIC_MIN_TIMEUP = 1.0D;
  public static final String STATISTIC_PROTOCOL_VERSION = "01";
  public static final String STATISTIC_PUBLIC_INFO = "02";
  public static final String STATISTIC_SUB_PREFF = "ue_sub_";
  public static final String STATISTIC_SUB_SWITCH = "sub";
  public static final String STATISTIC_THRESHOLD = "threshold";
  public static final String STATISTIC_TIMEOUT = "timeout";
  public static final String STATISTIC_TIMEUP = "timeup";
  public static final String STATISTIC_USER_BEHAVIOUR = "03";
  public static final String STATISTIC_USER_STATIC_INFO = "04";
  public static final List<String> SUB_SWITCHS = Collections.unmodifiableList(Arrays.asList(new String[] { "01", "02", "03", "04", "05" }));
  private static final String TAG = "StatisticFile";
  public static final String UE_FILE = Util.toMd5("clientupdate_1".getBytes(), false);
  public static final String UE_FILE_BAK = Util.toMd5("clientupdate_2".getBytes(), false);
  private static final String UE_FILE_NAME = "clientupdate_1";
  private static final String UE_FILE_NAME_BAK = "clientupdate_2";
  private static volatile StatisticFile instance = null;
  private boolean isFileFull = false;
  private Context mContext = null;

  private StatisticFile(Context paramContext)
  {
    this.mContext = paramContext.getApplicationContext();
    File localFile1 = paramContext.getFilesDir();
    File localFile2 = new File(localFile1 + "/" + UE_FILE);
    try
    {
      if ((!localFile2.exists()) && (!localFile2.createNewFile()))
        Log.e("StatisticFile", "error:createNewFile" + localFile2.toString());
      return;
    }
    catch (IOException localIOException)
    {
      while (!DEBUG);
      Log.e("StatisticFile", "error:" + localIOException.getMessage());
    }
  }

  private void appendUEdatatoFile(OutputStream paramOutputStream, String paramString, List<JSONObject> paramList)
  {
    if ((paramOutputStream == null) || (paramList == null) || (paramList.size() == 0))
      if (DEBUG)
        Log.d("StatisticFile", "appendUBData, null");
    do
      while (true)
      {
        return;
        try
        {
          localJSONArray = new JSONArray(paramString);
          localIterator = paramList.iterator();
          if (!localIterator.hasNext())
          {
            paramOutputStream.write(localJSONArray.toString().getBytes());
            paramOutputStream.flush();
            return;
          }
        }
        catch (JSONException localJSONException)
        {
          JSONArray localJSONArray;
          Iterator localIterator;
          while (DEBUG)
          {
            Log.d("StatisticFile", "append save failed.");
            return;
            localJSONArray.put(localIterator.next());
          }
        }
        catch (IOException localIOException)
        {
        }
      }
    while (!DEBUG);
    Log.d("StatisticFile", "append save failed.");
  }

  private void ensureFileExist(String paramString)
  {
    File localFile = new File(this.mContext.getFilesDir(), paramString);
    try
    {
      if ((!localFile.exists()) && (!localFile.createNewFile()) && (DEBUG))
        Log.e("StatisticFile", "error:createNewFile" + localFile.toString());
      return;
    }
    catch (IOException localIOException)
    {
      while (!DEBUG);
      Log.e("StatisticFile", "error:" + localIOException.getMessage());
    }
  }

  public static StatisticFile getInstance(Context paramContext)
  {
    if (instance == null)
      instance = new StatisticFile(paramContext);
    return instance;
  }

  private void saveUEDatafirstly(OutputStream paramOutputStream, List<JSONObject> paramList)
  {
    if ((paramOutputStream == null) || (paramList == null) || (paramList.size() == 0))
    {
      if (DEBUG)
        Log.d("StatisticFile", "saveUBDatafirstly, null");
      return;
    }
    JSONArray localJSONArray = new JSONArray();
    Iterator localIterator = paramList.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        try
        {
          paramOutputStream.write(localJSONArray.toString().getBytes());
          paramOutputStream.flush();
          return;
        }
        catch (IOException localIOException)
        {
        }
        if (!DEBUG)
          break;
        Log.d("StatisticFile", "first save failed.");
        return;
      }
      localJSONArray.put((JSONObject)localIterator.next());
    }
  }

  // ERROR //
  private void writeDataToStatisticFile(String paramString, List<JSONObject> paramList)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial 272	com/baidu/clientupdate/statistic/StatisticFile:ensureFileExist	(Ljava/lang/String;)V
    //   5: aconst_null
    //   6: astore_3
    //   7: aconst_null
    //   8: astore 4
    //   10: aload_0
    //   11: getfield 147	com/baidu/clientupdate/statistic/StatisticFile:mContext	Landroid/content/Context;
    //   14: aload_1
    //   15: invokevirtual 276	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   18: astore_3
    //   19: aconst_null
    //   20: astore 22
    //   22: aconst_null
    //   23: astore 4
    //   25: aload_3
    //   26: ifnull +45 -> 71
    //   29: aload_3
    //   30: invokevirtual 281	java/io/InputStream:available	()I
    //   33: istore 23
    //   35: aconst_null
    //   36: astore 22
    //   38: aconst_null
    //   39: astore 4
    //   41: iload 23
    //   43: ifle +28 -> 71
    //   46: new 283	com/baidu/util/Base64InputStream
    //   49: dup
    //   50: aload_3
    //   51: iconst_0
    //   52: invokespecial 286	com/baidu/util/Base64InputStream:<init>	(Ljava/io/InputStream;I)V
    //   55: astore 24
    //   57: aload 24
    //   59: invokestatic 292	com/baidu/clientupdate/utility/Utility:getStringFromInput	(Ljava/io/InputStream;)Ljava/lang/String;
    //   62: astore 25
    //   64: aload 25
    //   66: astore 22
    //   68: aload 24
    //   70: astore_3
    //   71: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   74: ifeq +27 -> 101
    //   77: ldc 87
    //   79: new 163	java/lang/StringBuilder
    //   82: dup
    //   83: ldc_w 294
    //   86: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   89: aload 22
    //   91: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   97: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   100: pop
    //   101: aload_0
    //   102: getfield 147	com/baidu/clientupdate/statistic/StatisticFile:mContext	Landroid/content/Context;
    //   105: aload_1
    //   106: iconst_0
    //   107: invokevirtual 298	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   110: astore 4
    //   112: new 300	com/baidu/util/Base64OutputStream
    //   115: dup
    //   116: aload 4
    //   118: iconst_0
    //   119: invokespecial 303	com/baidu/util/Base64OutputStream:<init>	(Ljava/io/OutputStream;I)V
    //   122: astore 26
    //   124: aload 22
    //   126: invokestatic 309	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   129: ifeq +29 -> 158
    //   132: aload_0
    //   133: aload 26
    //   135: aload_2
    //   136: invokespecial 311	com/baidu/clientupdate/statistic/StatisticFile:saveUEDatafirstly	(Ljava/io/OutputStream;Ljava/util/List;)V
    //   139: aload_3
    //   140: ifnull +7 -> 147
    //   143: aload_3
    //   144: invokevirtual 314	java/io/InputStream:close	()V
    //   147: aload 26
    //   149: ifnull +443 -> 592
    //   152: aload 26
    //   154: invokevirtual 315	java/io/OutputStream:close	()V
    //   157: return
    //   158: aload_0
    //   159: aload 26
    //   161: aload 22
    //   163: aload_2
    //   164: invokespecial 317	com/baidu/clientupdate/statistic/StatisticFile:appendUEdatatoFile	(Ljava/io/OutputStream;Ljava/lang/String;Ljava/util/List;)V
    //   167: goto -28 -> 139
    //   170: astore 5
    //   172: aload 26
    //   174: astore 4
    //   176: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   179: ifeq +29 -> 208
    //   182: ldc 87
    //   184: new 163	java/lang/StringBuilder
    //   187: dup
    //   188: ldc 199
    //   190: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   193: aload 5
    //   195: invokevirtual 318	java/io/FileNotFoundException:getMessage	()Ljava/lang/String;
    //   198: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   201: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   204: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   207: pop
    //   208: aload_3
    //   209: ifnull +7 -> 216
    //   212: aload_3
    //   213: invokevirtual 314	java/io/InputStream:close	()V
    //   216: aload 4
    //   218: ifnull -61 -> 157
    //   221: aload 4
    //   223: invokevirtual 315	java/io/OutputStream:close	()V
    //   226: return
    //   227: astore 11
    //   229: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   232: ifeq -75 -> 157
    //   235: ldc 87
    //   237: new 163	java/lang/StringBuilder
    //   240: dup
    //   241: ldc 199
    //   243: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   246: aload 11
    //   248: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   251: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   254: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   257: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   260: pop
    //   261: return
    //   262: astore 13
    //   264: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   267: ifeq -51 -> 216
    //   270: ldc 87
    //   272: new 163	java/lang/StringBuilder
    //   275: dup
    //   276: ldc 199
    //   278: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   281: aload 13
    //   283: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   286: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   289: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   292: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   295: pop
    //   296: goto -80 -> 216
    //   299: astore 16
    //   301: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   304: ifeq +29 -> 333
    //   307: ldc 87
    //   309: new 163	java/lang/StringBuilder
    //   312: dup
    //   313: ldc 199
    //   315: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   318: aload 16
    //   320: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   323: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   326: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   329: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   332: pop
    //   333: aload_3
    //   334: ifnull +7 -> 341
    //   337: aload_3
    //   338: invokevirtual 314	java/io/InputStream:close	()V
    //   341: aload 4
    //   343: ifnull -186 -> 157
    //   346: aload 4
    //   348: invokevirtual 315	java/io/OutputStream:close	()V
    //   351: return
    //   352: astore 17
    //   354: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   357: ifeq -200 -> 157
    //   360: ldc 87
    //   362: new 163	java/lang/StringBuilder
    //   365: dup
    //   366: ldc 199
    //   368: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   371: aload 17
    //   373: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   376: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   379: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   382: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   385: pop
    //   386: return
    //   387: astore 19
    //   389: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   392: ifeq -51 -> 341
    //   395: ldc 87
    //   397: new 163	java/lang/StringBuilder
    //   400: dup
    //   401: ldc 199
    //   403: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   406: aload 19
    //   408: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   411: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   414: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   417: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   420: pop
    //   421: goto -80 -> 341
    //   424: astore 6
    //   426: aload_3
    //   427: ifnull +7 -> 434
    //   430: aload_3
    //   431: invokevirtual 314	java/io/InputStream:close	()V
    //   434: aload 4
    //   436: ifnull +8 -> 444
    //   439: aload 4
    //   441: invokevirtual 315	java/io/OutputStream:close	()V
    //   444: aload 6
    //   446: athrow
    //   447: astore 9
    //   449: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   452: ifeq -18 -> 434
    //   455: ldc 87
    //   457: new 163	java/lang/StringBuilder
    //   460: dup
    //   461: ldc 199
    //   463: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   466: aload 9
    //   468: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   471: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   474: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   477: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   480: pop
    //   481: goto -47 -> 434
    //   484: astore 7
    //   486: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   489: ifeq -45 -> 444
    //   492: ldc 87
    //   494: new 163	java/lang/StringBuilder
    //   497: dup
    //   498: ldc 199
    //   500: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   503: aload 7
    //   505: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   508: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   511: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   514: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   517: pop
    //   518: goto -74 -> 444
    //   521: astore 29
    //   523: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   526: ifeq -379 -> 147
    //   529: ldc 87
    //   531: new 163	java/lang/StringBuilder
    //   534: dup
    //   535: ldc 199
    //   537: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   540: aload 29
    //   542: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   545: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   548: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   551: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   554: pop
    //   555: goto -408 -> 147
    //   558: astore 27
    //   560: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   563: ifeq +29 -> 592
    //   566: ldc 87
    //   568: new 163	java/lang/StringBuilder
    //   571: dup
    //   572: ldc 199
    //   574: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   577: aload 27
    //   579: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   582: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   585: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   588: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   591: pop
    //   592: return
    //   593: astore 6
    //   595: aload 24
    //   597: astore_3
    //   598: aconst_null
    //   599: astore 4
    //   601: goto -175 -> 426
    //   604: astore 6
    //   606: aload 26
    //   608: astore 4
    //   610: goto -184 -> 426
    //   613: astore 16
    //   615: aload 24
    //   617: astore_3
    //   618: aconst_null
    //   619: astore 4
    //   621: goto -320 -> 301
    //   624: astore 16
    //   626: aload 26
    //   628: astore 4
    //   630: goto -329 -> 301
    //   633: astore 5
    //   635: goto -459 -> 176
    //   638: astore 5
    //   640: aload 24
    //   642: astore_3
    //   643: aconst_null
    //   644: astore 4
    //   646: goto -470 -> 176
    //
    // Exception table:
    //   from	to	target	type
    //   124	139	170	java/io/FileNotFoundException
    //   158	167	170	java/io/FileNotFoundException
    //   221	226	227	java/io/IOException
    //   212	216	262	java/io/IOException
    //   10	19	299	java/io/IOException
    //   29	35	299	java/io/IOException
    //   46	57	299	java/io/IOException
    //   71	101	299	java/io/IOException
    //   101	124	299	java/io/IOException
    //   346	351	352	java/io/IOException
    //   337	341	387	java/io/IOException
    //   10	19	424	finally
    //   29	35	424	finally
    //   46	57	424	finally
    //   71	101	424	finally
    //   101	124	424	finally
    //   176	208	424	finally
    //   301	333	424	finally
    //   430	434	447	java/io/IOException
    //   439	444	484	java/io/IOException
    //   143	147	521	java/io/IOException
    //   152	157	558	java/io/IOException
    //   57	64	593	finally
    //   124	139	604	finally
    //   158	167	604	finally
    //   57	64	613	java/io/IOException
    //   124	139	624	java/io/IOException
    //   158	167	624	java/io/IOException
    //   10	19	633	java/io/FileNotFoundException
    //   29	35	633	java/io/FileNotFoundException
    //   46	57	633	java/io/FileNotFoundException
    //   71	101	633	java/io/FileNotFoundException
    //   101	124	633	java/io/FileNotFoundException
    //   57	64	638	java/io/FileNotFoundException
  }

  public void checkSendBakFileToServer()
  {
    File localFile = new File(this.mContext.getFilesDir(), UE_FILE_BAK);
    if ((localFile.exists()) && (localFile.length() > 0L))
    {
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(Constants.StatisticType.UE_STATISTIC);
      StatisticPoster.getInstance(this.mContext).sendStatisticData(localArrayList);
      if (DEBUG)
        Log.d("StatisticFile", "发送备份统计文件");
      StatisticPoster.getInstance(this.mContext).setAlarmForStatisticData(getStatisticTimeup());
    }
  }

  public void checkStatisticFilesSize()
  {
    File localFile1 = this.mContext.getFilesDir();
    File localFile2 = new File(localFile1 + "/" + UE_FILE);
    int i = (int)(1024.0F * getStatisticFileMaxSize());
    if (localFile2.length() > i)
      if (!this.isFileFull);
    label167: 
    while (!DEBUG)
    {
      do
      {
        do
          while (true)
          {
            return;
            File localFile3 = new File(localFile1, UE_FILE_BAK);
            if (localFile3.exists())
              this.mContext.deleteFile(UE_FILE_BAK);
            if (!localFile2.renameTo(localFile3))
              break label167;
            try
            {
              if ((!localFile2.createNewFile()) && (DEBUG))
              {
                Log.e("StatisticFile", "error:createNewFile" + localFile2.toString());
                return;
              }
            }
            catch (IOException localIOException)
            {
            }
          }
        while (!DEBUG);
        Log.d("StatisticFile", "创建文件ue统计文件失败");
        return;
      }
      while (!DEBUG);
      Log.e("StatisticFile", "rename statistic file failed");
      return;
    }
    Log.d("StatisticFile", "Files is not full.");
  }

  public boolean containLastSendDownloadTime()
  {
    boolean bool1 = this.mContext.getSharedPreferences("statistic_settings_preference", 0).contains("download_time");
    boolean bool2 = false;
    if (bool1)
      bool2 = true;
    return bool2;
  }

  public boolean containLastSendStatisticTime()
  {
    boolean bool1 = this.mContext.getSharedPreferences("statistic_settings_preference", 0).contains("updateinfo");
    boolean bool2 = false;
    if (bool1)
      bool2 = true;
    return bool2;
  }

  // ERROR //
  public void copyFile(String paramString1, String paramString2)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore 4
    //   5: aload_0
    //   6: getfield 147	com/baidu/clientupdate/statistic/StatisticFile:mContext	Landroid/content/Context;
    //   9: aload_2
    //   10: ldc_w 390
    //   13: invokevirtual 298	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   16: astore_3
    //   17: aload_0
    //   18: getfield 147	com/baidu/clientupdate/statistic/StatisticFile:mContext	Landroid/content/Context;
    //   21: aload_1
    //   22: invokevirtual 276	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   25: astore 4
    //   27: sipush 1024
    //   30: newarray byte
    //   32: astore 16
    //   34: aload 4
    //   36: aload 16
    //   38: invokevirtual 396	java/io/FileInputStream:read	([B)I
    //   41: istore 17
    //   43: iload 17
    //   45: iconst_m1
    //   46: if_icmpne +35 -> 81
    //   49: aload_3
    //   50: invokevirtual 399	java/io/FileOutputStream:flush	()V
    //   53: aload 4
    //   55: invokevirtual 400	java/io/FileInputStream:close	()V
    //   58: aload_3
    //   59: invokevirtual 401	java/io/FileOutputStream:close	()V
    //   62: aload_3
    //   63: ifnull +7 -> 70
    //   66: aload_3
    //   67: invokevirtual 401	java/io/FileOutputStream:close	()V
    //   70: aload 4
    //   72: ifnull +8 -> 80
    //   75: aload 4
    //   77: invokevirtual 400	java/io/FileInputStream:close	()V
    //   80: return
    //   81: aload_3
    //   82: aload 16
    //   84: iconst_0
    //   85: iload 17
    //   87: invokevirtual 404	java/io/FileOutputStream:write	([BII)V
    //   90: goto -56 -> 34
    //   93: astore 10
    //   95: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   98: ifeq +29 -> 127
    //   101: ldc 87
    //   103: new 163	java/lang/StringBuilder
    //   106: dup
    //   107: ldc 199
    //   109: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   112: aload 10
    //   114: invokevirtual 405	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   117: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   123: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   126: pop
    //   127: aload_3
    //   128: ifnull +7 -> 135
    //   131: aload_3
    //   132: invokevirtual 401	java/io/FileOutputStream:close	()V
    //   135: aload 4
    //   137: ifnull -57 -> 80
    //   140: aload 4
    //   142: invokevirtual 400	java/io/FileInputStream:close	()V
    //   145: return
    //   146: astore 11
    //   148: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   151: ifeq -71 -> 80
    //   154: ldc 87
    //   156: new 163	java/lang/StringBuilder
    //   159: dup
    //   160: ldc 199
    //   162: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   165: aload 11
    //   167: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   170: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   176: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   179: pop
    //   180: return
    //   181: astore 13
    //   183: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   186: ifeq -51 -> 135
    //   189: ldc 87
    //   191: new 163	java/lang/StringBuilder
    //   194: dup
    //   195: ldc 199
    //   197: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   200: aload 13
    //   202: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   205: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   211: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   214: pop
    //   215: goto -80 -> 135
    //   218: astore 5
    //   220: aload_3
    //   221: ifnull +7 -> 228
    //   224: aload_3
    //   225: invokevirtual 401	java/io/FileOutputStream:close	()V
    //   228: aload 4
    //   230: ifnull +8 -> 238
    //   233: aload 4
    //   235: invokevirtual 400	java/io/FileInputStream:close	()V
    //   238: aload 5
    //   240: athrow
    //   241: astore 8
    //   243: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   246: ifeq -18 -> 228
    //   249: ldc 87
    //   251: new 163	java/lang/StringBuilder
    //   254: dup
    //   255: ldc 199
    //   257: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   260: aload 8
    //   262: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   265: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   268: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   271: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   274: pop
    //   275: goto -47 -> 228
    //   278: astore 6
    //   280: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   283: ifeq -45 -> 238
    //   286: ldc 87
    //   288: new 163	java/lang/StringBuilder
    //   291: dup
    //   292: ldc 199
    //   294: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   297: aload 6
    //   299: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   302: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   305: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   308: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   311: pop
    //   312: goto -74 -> 238
    //   315: astore 20
    //   317: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   320: ifeq -250 -> 70
    //   323: ldc 87
    //   325: new 163	java/lang/StringBuilder
    //   328: dup
    //   329: ldc 199
    //   331: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   334: aload 20
    //   336: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   339: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   342: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   345: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   348: pop
    //   349: goto -279 -> 70
    //   352: astore 18
    //   354: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   357: ifeq -277 -> 80
    //   360: ldc 87
    //   362: new 163	java/lang/StringBuilder
    //   365: dup
    //   366: ldc 199
    //   368: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   371: aload 18
    //   373: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   376: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   379: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   382: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   385: pop
    //   386: return
    //
    // Exception table:
    //   from	to	target	type
    //   5	34	93	java/lang/Exception
    //   34	43	93	java/lang/Exception
    //   49	62	93	java/lang/Exception
    //   81	90	93	java/lang/Exception
    //   140	145	146	java/io/IOException
    //   131	135	181	java/io/IOException
    //   5	34	218	finally
    //   34	43	218	finally
    //   49	62	218	finally
    //   81	90	218	finally
    //   95	127	218	finally
    //   224	228	241	java/io/IOException
    //   233	238	278	java/io/IOException
    //   66	70	315	java/io/IOException
    //   75	80	352	java/io/IOException
  }

  public void deleteUserBehaivorStatisticFiles()
  {
    File localFile = this.mContext.getFilesDir();
    if (new File(localFile + "/" + UE_FILE).exists())
      this.mContext.deleteFile(UE_FILE);
    if (new File(localFile, UE_FILE_BAK).exists())
      this.mContext.deleteFile(UE_FILE_BAK);
  }

  public void disableAllSubSwitch()
  {
    Iterator localIterator = SUB_SWITCHS.iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      String str = (String)localIterator.next();
      setSubStatisticEnabled("ue_sub_" + str, false);
    }
  }

  public void forceMoveToUpFile()
  {
    File localFile1 = this.mContext.getFilesDir();
    File localFile2 = new File(localFile1 + "/" + UE_FILE);
    if (localFile2.length() > 0L)
    {
      File localFile3 = new File(localFile1, UE_FILE_BAK);
      if (localFile3.exists())
        this.mContext.deleteFile(UE_FILE_BAK);
      if (!localFile2.renameTo(localFile3))
        break label145;
    }
    label145: 
    while (!DEBUG)
      try
      {
        if ((!localFile2.createNewFile()) && (DEBUG))
          Log.e("StatisticFile", "error:createNewFile" + localFile2.toString());
        return;
      }
      catch (IOException localIOException)
      {
        while (!DEBUG);
        Log.d("StatisticFile", "创建文件ue统计文件失败");
        return;
      }
    Log.e("StatisticFile", "rename statistic file failed");
  }

  public long getLastSendDownloadTime(Context paramContext)
  {
    return paramContext.getSharedPreferences("statistic_settings_preference", 0).getLong("download_time", 0L);
  }

  public long getLastSendStatisticTime(Context paramContext)
  {
    return paramContext.getSharedPreferences("statistic_settings_preference", 0).getLong("updateinfo", 0L);
  }

  public float getStatisticFileMaxSize()
  {
    return this.mContext.getSharedPreferences("statistic_settings_preference", 0).getFloat("threshold", 10.0F);
  }

  public long getStatisticTimeout()
  {
    return this.mContext.getSharedPreferences("statistic_settings_preference", 0).getLong("timeout", 7L);
  }

  public long getStatisticTimeup()
  {
    return this.mContext.getSharedPreferences("statistic_settings_preference", 0).getLong("timeup", 172800000L);
  }

  public boolean isDownloadStatisticInfoEnabled(Context paramContext)
  {
    return paramContext.getSharedPreferences("statistic_settings_preference", 0).getBoolean("ue_sub_05", true);
  }

  public boolean isFileFull()
  {
    return this.isFileFull;
  }

  public boolean isPubStatisticEnabled(Context paramContext)
  {
    return paramContext.getSharedPreferences("statistic_settings_preference", 0).getBoolean("ue_sub_02", false);
  }

  public boolean isUEStatisticEnabled(Context paramContext)
  {
    return paramContext.getSharedPreferences("statistic_settings_preference", 0).getBoolean("ue_sub_03", true);
  }

  public boolean isUSStatisticInfoEnabled(Context paramContext)
  {
    return paramContext.getSharedPreferences("statistic_settings_preference", 0).getBoolean("ue_sub_04", false);
  }

  public boolean isVersionInfoStatisticEnabled(Context paramContext)
  {
    return paramContext.getSharedPreferences("statistic_settings_preference", 0).getBoolean("ue_sub_01", false);
  }

  // ERROR //
  public String readBase64File(String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 147	com/baidu/clientupdate/statistic/StatisticFile:mContext	Landroid/content/Context;
    //   4: invokevirtual 159	android/content/Context:getFilesDir	()Ljava/io/File;
    //   7: astore_2
    //   8: new 161	java/io/File
    //   11: dup
    //   12: new 163	java/lang/StringBuilder
    //   15: dup
    //   16: invokespecial 164	java/lang/StringBuilder:<init>	()V
    //   19: aload_2
    //   20: invokevirtual 168	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   23: ldc 170
    //   25: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   28: aload_1
    //   29: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   32: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   35: invokespecial 180	java/io/File:<init>	(Ljava/lang/String;)V
    //   38: invokevirtual 184	java/io/File:exists	()Z
    //   41: ifne +9 -> 50
    //   44: aconst_null
    //   45: astore 7
    //   47: aload 7
    //   49: areturn
    //   50: aconst_null
    //   51: astore_3
    //   52: aload_0
    //   53: getfield 147	com/baidu/clientupdate/statistic/StatisticFile:mContext	Landroid/content/Context;
    //   56: aload_1
    //   57: invokevirtual 276	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   60: astore_3
    //   61: aconst_null
    //   62: astore 7
    //   64: aload_3
    //   65: ifnull +42 -> 107
    //   68: aload_3
    //   69: invokevirtual 281	java/io/InputStream:available	()I
    //   72: istore 14
    //   74: aconst_null
    //   75: astore 7
    //   77: iload 14
    //   79: ifle +28 -> 107
    //   82: new 283	com/baidu/util/Base64InputStream
    //   85: dup
    //   86: aload_3
    //   87: iconst_0
    //   88: invokespecial 286	com/baidu/util/Base64InputStream:<init>	(Ljava/io/InputStream;I)V
    //   91: astore 15
    //   93: aload 15
    //   95: invokestatic 292	com/baidu/clientupdate/utility/Utility:getStringFromInput	(Ljava/io/InputStream;)Ljava/lang/String;
    //   98: astore 16
    //   100: aload 16
    //   102: astore 7
    //   104: aload 15
    //   106: astore_3
    //   107: aload_3
    //   108: ifnull +7 -> 115
    //   111: aload_3
    //   112: invokevirtual 314	java/io/InputStream:close	()V
    //   115: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   118: ifeq -71 -> 47
    //   121: ldc 87
    //   123: new 163	java/lang/StringBuilder
    //   126: dup
    //   127: ldc_w 453
    //   130: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   133: aload 7
    //   135: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   138: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   141: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   144: pop
    //   145: aload 7
    //   147: areturn
    //   148: astore 11
    //   150: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   153: ifeq +29 -> 182
    //   156: ldc 87
    //   158: new 163	java/lang/StringBuilder
    //   161: dup
    //   162: ldc 199
    //   164: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   167: aload 11
    //   169: invokevirtual 318	java/io/FileNotFoundException:getMessage	()Ljava/lang/String;
    //   172: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   178: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   181: pop
    //   182: aconst_null
    //   183: astore 7
    //   185: aload_3
    //   186: ifnull -71 -> 115
    //   189: aload_3
    //   190: invokevirtual 314	java/io/InputStream:close	()V
    //   193: aconst_null
    //   194: astore 7
    //   196: goto -81 -> 115
    //   199: astore 12
    //   201: aload 12
    //   203: invokevirtual 456	java/io/IOException:printStackTrace	()V
    //   206: aconst_null
    //   207: astore 7
    //   209: goto -94 -> 115
    //   212: astore 6
    //   214: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   217: ifeq +29 -> 246
    //   220: ldc 87
    //   222: new 163	java/lang/StringBuilder
    //   225: dup
    //   226: ldc 199
    //   228: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   231: aload 6
    //   233: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   236: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   239: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   242: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   245: pop
    //   246: aconst_null
    //   247: astore 7
    //   249: aload_3
    //   250: ifnull -135 -> 115
    //   253: aload_3
    //   254: invokevirtual 314	java/io/InputStream:close	()V
    //   257: aconst_null
    //   258: astore 7
    //   260: goto -145 -> 115
    //   263: astore 8
    //   265: aload 8
    //   267: invokevirtual 456	java/io/IOException:printStackTrace	()V
    //   270: aconst_null
    //   271: astore 7
    //   273: goto -158 -> 115
    //   276: astore 4
    //   278: aload_3
    //   279: ifnull +7 -> 286
    //   282: aload_3
    //   283: invokevirtual 314	java/io/InputStream:close	()V
    //   286: aload 4
    //   288: athrow
    //   289: astore 5
    //   291: aload 5
    //   293: invokevirtual 456	java/io/IOException:printStackTrace	()V
    //   296: goto -10 -> 286
    //   299: astore 17
    //   301: aload 17
    //   303: invokevirtual 456	java/io/IOException:printStackTrace	()V
    //   306: goto -191 -> 115
    //   309: astore 4
    //   311: aload 15
    //   313: astore_3
    //   314: goto -36 -> 278
    //   317: astore 6
    //   319: aload 15
    //   321: astore_3
    //   322: goto -108 -> 214
    //   325: astore 11
    //   327: aload 15
    //   329: astore_3
    //   330: goto -180 -> 150
    //
    // Exception table:
    //   from	to	target	type
    //   52	61	148	java/io/FileNotFoundException
    //   68	74	148	java/io/FileNotFoundException
    //   82	93	148	java/io/FileNotFoundException
    //   189	193	199	java/io/IOException
    //   52	61	212	java/io/IOException
    //   68	74	212	java/io/IOException
    //   82	93	212	java/io/IOException
    //   253	257	263	java/io/IOException
    //   52	61	276	finally
    //   68	74	276	finally
    //   82	93	276	finally
    //   150	182	276	finally
    //   214	246	276	finally
    //   282	286	289	java/io/IOException
    //   111	115	299	java/io/IOException
    //   93	100	309	finally
    //   93	100	317	java/io/IOException
    //   93	100	325	java/io/FileNotFoundException
  }

  public String readFromFile(String paramString)
  {
    File localFile = this.mContext.getFilesDir();
    String str;
    if (!new File(localFile + "/" + paramString).exists())
    {
      str = null;
      return str;
    }
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    while (true)
    {
      byte[] arrayOfByte;
      int i;
      try
      {
        FileInputStream localFileInputStream = this.mContext.openFileInput(paramString);
        arrayOfByte = new byte[1024];
        i = localFileInputStream.read(arrayOfByte);
        if (i == -1)
        {
          localFileInputStream.close();
          str = new String(localByteArrayOutputStream.toByteArray());
          if (!DEBUG)
            break;
          Log.d("StatisticFile", "文件中读取的内容：" + str);
          return str;
        }
      }
      catch (Exception localException)
      {
        if (DEBUG)
          Log.e("StatisticFile", "error:" + localException.getMessage());
        return null;
      }
      localByteArrayOutputStream.write(arrayOfByte, 0, i);
    }
  }

  public void removeStatisticFile()
  {
    this.mContext.deleteFile(UE_FILE_BAK);
  }

  public void setFileFull(boolean paramBoolean)
  {
    this.isFileFull = paramBoolean;
  }

  public void setLastSendDownloadTime(Context paramContext, long paramLong)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("statistic_settings_preference", 0).edit();
    localEditor.putLong("download_time", paramLong);
    localEditor.commit();
  }

  public void setLastSendStatisticTime(Context paramContext, long paramLong)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("statistic_settings_preference", 0).edit();
    localEditor.putLong("updateinfo", paramLong);
    localEditor.commit();
  }

  public void setStatisticThreshold(double paramDouble)
  {
    SharedPreferences.Editor localEditor = this.mContext.getSharedPreferences("statistic_settings_preference", 0).edit();
    localEditor.putFloat("threshold", (float)paramDouble);
    localEditor.commit();
  }

  public void setStatisticTimeout(long paramLong)
  {
    SharedPreferences.Editor localEditor = this.mContext.getSharedPreferences("statistic_settings_preference", 0).edit();
    localEditor.putLong("timeout", paramLong);
    localEditor.commit();
  }

  public void setStatisticTimeup(long paramLong)
  {
    SharedPreferences.Editor localEditor = this.mContext.getSharedPreferences("statistic_settings_preference", 0).edit();
    localEditor.putLong("timeup", paramLong);
    localEditor.commit();
  }

  public void setSubStatisticEnabled(String paramString, boolean paramBoolean)
  {
    SharedPreferences.Editor localEditor = this.mContext.getSharedPreferences("statistic_settings_preference", 0).edit();
    localEditor.putBoolean(paramString, paramBoolean);
    localEditor.commit();
  }

  public void writeDataToFile(String paramString, List<JSONObject> paramList)
  {
    try
    {
      if ((!TextUtils.isEmpty(paramString)) && (paramList != null))
      {
        int i = paramList.size();
        if (i != 0)
          break label29;
      }
      while (true)
      {
        return;
        label29: writeDataToStatisticFile(paramString, paramList);
        checkStatisticFilesSize();
      }
    }
    finally
    {
    }
  }

  // ERROR //
  public void writeDataToFile(String paramString, byte[] paramArrayOfByte)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_0
    //   3: getfield 147	com/baidu/clientupdate/statistic/StatisticFile:mContext	Landroid/content/Context;
    //   6: aload_1
    //   7: ldc_w 390
    //   10: invokevirtual 298	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   13: astore_3
    //   14: aload_3
    //   15: aload_2
    //   16: invokevirtual 506	java/io/FileOutputStream:write	([B)V
    //   19: aload_3
    //   20: invokevirtual 399	java/io/FileOutputStream:flush	()V
    //   23: aload_3
    //   24: invokevirtual 401	java/io/FileOutputStream:close	()V
    //   27: aload_3
    //   28: ifnull +7 -> 35
    //   31: aload_3
    //   32: invokevirtual 401	java/io/FileOutputStream:close	()V
    //   35: return
    //   36: astore 7
    //   38: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   41: ifeq +29 -> 70
    //   44: ldc 87
    //   46: new 163	java/lang/StringBuilder
    //   49: dup
    //   50: ldc 199
    //   52: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   55: aload 7
    //   57: invokevirtual 405	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   60: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   63: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   66: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   69: pop
    //   70: aload_3
    //   71: ifnull -36 -> 35
    //   74: aload_3
    //   75: invokevirtual 401	java/io/FileOutputStream:close	()V
    //   78: return
    //   79: astore 8
    //   81: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   84: ifeq -49 -> 35
    //   87: ldc 87
    //   89: new 163	java/lang/StringBuilder
    //   92: dup
    //   93: ldc 199
    //   95: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   98: aload 8
    //   100: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   103: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   109: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   112: pop
    //   113: return
    //   114: astore 4
    //   116: aload_3
    //   117: ifnull +7 -> 124
    //   120: aload_3
    //   121: invokevirtual 401	java/io/FileOutputStream:close	()V
    //   124: aload 4
    //   126: athrow
    //   127: astore 5
    //   129: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   132: ifeq -8 -> 124
    //   135: ldc 87
    //   137: new 163	java/lang/StringBuilder
    //   140: dup
    //   141: ldc 199
    //   143: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   146: aload 5
    //   148: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   151: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   157: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   160: pop
    //   161: goto -37 -> 124
    //   164: astore 11
    //   166: getstatic 107	com/baidu/clientupdate/statistic/StatisticFile:DEBUG	Z
    //   169: ifeq -134 -> 35
    //   172: ldc 87
    //   174: new 163	java/lang/StringBuilder
    //   177: dup
    //   178: ldc 199
    //   180: invokespecial 190	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   183: aload 11
    //   185: invokevirtual 202	java/io/IOException:getMessage	()Ljava/lang/String;
    //   188: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: invokevirtual 177	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   194: invokestatic 197	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   197: pop
    //   198: return
    //
    // Exception table:
    //   from	to	target	type
    //   2	27	36	java/lang/Exception
    //   74	78	79	java/io/IOException
    //   2	27	114	finally
    //   38	70	114	finally
    //   120	124	127	java/io/IOException
    //   31	35	164	java/io/IOException
  }

  public void writeDataToFileInBackground(String paramString, List<JSONObject> paramList)
  {
    if ((TextUtils.isEmpty(paramString)) || (paramList == null) || (paramList.size() == 0))
      return;
    new Thread(new Runnable()
    {
      List<JSONObject> mData;
      String mFileName;

      public void run()
      {
        StatisticFile.this.writeDataToFile(this.mFileName, this.mData);
        StatisticFile.this.checkSendBakFileToServer();
      }

      Runnable setData(String paramAnonymousString, List<JSONObject> paramAnonymousList)
      {
        this.mFileName = paramAnonymousString;
        this.mData = paramAnonymousList;
        return this;
      }
    }
    .setData(paramString, paramList)).start();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.statistic.StatisticFile
 * JD-Core Version:    0.6.2
 */