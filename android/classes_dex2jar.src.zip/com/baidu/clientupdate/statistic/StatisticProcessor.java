package com.baidu.clientupdate.statistic;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import com.baidu.clientupdate.utility.Constants;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class StatisticProcessor
{
  private static final boolean DEBUG = false;
  private static final String TAG = "StatisticProcessor";
  private static final int UE_STATISTIC_DATA_SIZE = 20;
  private static StatisticProcessor instance = null;
  private String mAppVersionName;
  private Context mContext = null;
  private StatisticFile mStatisticFile = null;
  private ExecutorService mUEStatisticExecutorService = Executors.newSingleThreadExecutor();
  private List<JSONObject> mdatas = new ArrayList();

  private StatisticProcessor(Context paramContext)
  {
    this.mContext = paramContext.getApplicationContext();
    this.mStatisticFile = StatisticFile.getInstance(paramContext);
  }

  public static void addOnlyKeyUEStatisticCache(Context paramContext, String paramString)
  {
    if (!TextUtils.isEmpty(paramString))
    {
      if (DEBUG)
        Log.d("StatisticProcessor", "statistic key: " + paramString);
      StatisticProcessor localStatisticProcessor = getInstance(paramContext);
      JSONObject localJSONObject = localStatisticProcessor.buildJsonStrOnlyKey(paramString);
      if (DEBUG)
        Log.e("StatisticProcessor", "写入行为统计:" + localJSONObject);
      localStatisticProcessor.addUEStatisticData(localJSONObject);
    }
  }

  public static void addOnlyKeyUEStatisticWithoutCache(Context paramContext, String paramString)
  {
    if (!TextUtils.isEmpty(paramString))
    {
      if (DEBUG)
        Log.d("StatisticProcessor", "statistic key: " + paramString);
      StatisticProcessor localStatisticProcessor = getInstance(paramContext);
      JSONObject localJSONObject = localStatisticProcessor.buildJsonStrOnlyKey(paramString);
      if (DEBUG)
        Log.e("StatisticProcessor", "写入行为统计:" + localJSONObject);
      localStatisticProcessor.addUEStatisticDataWithoutCache(localJSONObject);
    }
  }

  public static void addOnlyValueUEStatisticCache(Context paramContext, String paramString1, String paramString2)
  {
    if (!TextUtils.isEmpty(paramString1))
    {
      if (DEBUG)
        Log.d("StatisticProcessor", "statistic key: " + paramString1 + "value: " + paramString2);
      StatisticProcessor localStatisticProcessor = getInstance(paramContext);
      JSONObject localJSONObject = localStatisticProcessor.buildJsonStrWithStr(paramString1, paramString2);
      if (DEBUG)
        Log.e("StatisticProcessor", "写入行为统计:" + localJSONObject);
      localStatisticProcessor.addUEStatisticData(localJSONObject);
    }
  }

  public static void addOnlyValueUEStatisticWithoutCache(Context paramContext, String paramString1, String paramString2)
  {
    if (!TextUtils.isEmpty(paramString1))
    {
      if (DEBUG)
        Log.d("StatisticProcessor", "statistic key: " + paramString1 + "value: " + paramString2);
      StatisticProcessor localStatisticProcessor = getInstance(paramContext);
      JSONObject localJSONObject = localStatisticProcessor.buildJsonStrWithStr(paramString1, paramString2);
      if (DEBUG)
        Log.e("StatisticProcessor", "写入行为统计:" + localJSONObject);
      localStatisticProcessor.addUEStatisticDataWithoutCache(localJSONObject);
    }
  }

  public static void addValueListUEStatisticCache(Context paramContext, String paramString, String[] paramArrayOfString)
  {
    if (!TextUtils.isEmpty(paramString))
    {
      StatisticProcessor localStatisticProcessor = getInstance(paramContext);
      JSONObject localJSONObject = localStatisticProcessor.buildJsonStrWithList(paramString, Arrays.asList(paramArrayOfString));
      if (DEBUG)
        Log.e("StatisticProcessor", "写入行为统计:" + localJSONObject);
      localStatisticProcessor.addUEStatisticData(localJSONObject);
    }
  }

  public static void addValueListUEStatisticWithoutCache(Context paramContext, String paramString, String[] paramArrayOfString)
  {
    if (!TextUtils.isEmpty(paramString))
    {
      StatisticProcessor localStatisticProcessor = getInstance(paramContext);
      JSONObject localJSONObject = localStatisticProcessor.buildJsonStrWithList(paramString, Arrays.asList(paramArrayOfString));
      if (DEBUG)
        Log.e("StatisticProcessor", "写入行为统计:" + localJSONObject);
      localStatisticProcessor.addUEStatisticDataWithoutCache(localJSONObject);
    }
  }

  public static StatisticProcessor getInstance(Context paramContext)
  {
    try
    {
      if (instance == null)
        instance = new StatisticProcessor(paramContext);
      StatisticProcessor localStatisticProcessor = instance;
      return localStatisticProcessor;
    }
    finally
    {
    }
  }

  public void addUEStatisticData(String paramString)
  {
    addOnlyKeyUEStatisticCache(this.mContext, paramString);
  }

  public void addUEStatisticData(final JSONObject paramJSONObject)
  {
    if (!this.mStatisticFile.isUEStatisticEnabled(this.mContext));
    while (paramJSONObject == null)
      return;
    Runnable local1 = new Runnable()
    {
      public void run()
      {
        try
        {
          if (StatisticProcessor.DEBUG)
            Log.e("StatisticProcessor", "写入主程序用户行为统计：" + paramJSONObject);
          StatisticProcessor.this.mdatas.add(paramJSONObject);
          if (StatisticProcessor.this.mdatas.size() > 20)
          {
            ArrayList localArrayList = new ArrayList(StatisticProcessor.this.mdatas);
            StatisticProcessor.this.mStatisticFile.writeDataToFileInBackground(StatisticFile.UE_FILE, localArrayList);
            StatisticProcessor.this.mdatas.clear();
          }
          return;
        }
        finally
        {
        }
      }
    };
    this.mUEStatisticExecutorService.execute(local1);
  }

  public void addUEStatisticDataWithoutCache(JSONObject paramJSONObject)
  {
    if (paramJSONObject == null);
    while (!this.mStatisticFile.isUEStatisticEnabled(this.mContext))
      return;
    if (DEBUG)
      Log.e("StatisticProcessor", "写入widget用户行为统计：" + paramJSONObject);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(paramJSONObject);
    this.mStatisticFile.writeDataToFileInBackground(StatisticFile.UE_FILE, localArrayList);
  }

  public JSONObject buildJsonStrOnlyKey(String paramString)
  {
    JSONObject localJSONObject = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    try
    {
      localJSONArray.put(String.valueOf(System.currentTimeMillis()));
      localJSONObject.put(paramString, localJSONArray);
      return localJSONObject;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
    return null;
  }

  public JSONObject buildJsonStrWithList(String paramString, Collection<String> paramCollection)
  {
    JSONObject localJSONObject = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    try
    {
      localJSONArray.put(0, String.valueOf(System.currentTimeMillis()));
      Iterator localIterator = paramCollection.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
        {
          localJSONObject.put(paramString, localJSONArray);
          return localJSONObject;
        }
        localJSONArray.put((String)localIterator.next());
      }
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
    return null;
  }

  public JSONObject buildJsonStrWithStr(String paramString1, String paramString2)
  {
    JSONObject localJSONObject = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    try
    {
      localJSONArray.put(String.valueOf(System.currentTimeMillis()));
      localJSONArray.put(paramString2);
      localJSONObject.put(paramString1, localJSONArray);
      return localJSONObject;
    }
    catch (JSONException localJSONException)
    {
      localJSONException.printStackTrace();
    }
    return null;
  }

  public void clearBuffer()
  {
    try
    {
      this.mdatas.clear();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public String generateUEStatistics()
  {
    String str = this.mStatisticFile.readBase64File(StatisticFile.UE_FILE_BAK);
    if (DEBUG)
      Log.d("StatisticProcessor", "用户行为统计信息:" + str);
    return str;
  }

  public void writeBufferToFile()
  {
    try
    {
      this.mStatisticFile.writeDataToFile(StatisticFile.UE_FILE, this.mdatas);
      this.mdatas.clear();
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void writeStatisticDataBeforeAppInBackground()
  {
    if (!this.mStatisticFile.isUEStatisticEnabled(this.mContext));
    while ((this.mdatas == null) || (this.mdatas.size() <= 0))
      return;
    new Thread(new Runnable()
    {
      public void run()
      {
        StatisticProcessor.this.writeBufferToFile();
      }
    }
    , "addUC").start();
  }

  public void writeStatisticDataBeforeQuit(String paramString)
  {
    if (!this.mStatisticFile.isUEStatisticEnabled(this.mContext))
      return;
    JSONObject localJSONObject = buildJsonStrOnlyKey(paramString);
    if (DEBUG)
      Log.e("StatisticProcessor", "写入主程序用户行为统计:" + localJSONObject);
    this.mdatas.add(localJSONObject);
    writeBufferToFile();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.statistic.StatisticProcessor
 * JD-Core Version:    0.6.2
 */