package com.baidu.clientupdate.statistic;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import com.baidu.android.common.net.ProxyHttpClient;
import com.baidu.clientupdate.url.BaiduParamManager;
import com.baidu.clientupdate.utility.Constants;
import com.baidu.clientupdate.utility.Constants.StatisticType;
import com.baidu.clientupdate.utility.Utility;
import com.baidu.util.Base64;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.HttpPost;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class StatisticPoster
{
  public static final String BROADCAST_CHECK_SEND_STATISTIC_DATA = "com.baidu.appsearch.action.CHECKSENDSTATISTICDATA";
  private static final boolean DEBUG = false;
  private static final boolean DEBUG_POSTER = false;
  public static final byte GZIP_HEAD_1 = 117;
  public static final byte GZIP_HEAD_2 = 123;
  private static final long MIN_15 = 900000L;
  private static final String STATISTIC_PROTOCL_VERSION = "1.1";
  private static final String TAG = "StatisticPoster";
  private static StatisticPoster instance = null;
  private Context mContext = null;
  private StatisticProcessor mStatisticProcessor = null;
  private ArrayList<Constants.StatisticType> mStatisticTypes = new ArrayList();

  private StatisticPoster(Context paramContext)
  {
    this.mContext = paramContext.getApplicationContext();
    this.mStatisticProcessor = StatisticProcessor.getInstance(paramContext);
  }

  private String buildPostContent(ArrayList<Constants.StatisticType> paramArrayList)
  {
    JSONObject localJSONObject = new JSONObject();
    StatisticFile localStatisticFile = StatisticFile.getInstance(this.mContext);
    while (true)
      try
      {
        Iterator localIterator = paramArrayList.iterator();
        boolean bool = localIterator.hasNext();
        if (!bool)
        {
          if (DEBUG)
            Log.d("StatisticPoster", "所有统计信息:" + localJSONObject.toString());
          arrayOfByte1 = localJSONObject.toString().getBytes();
          arrayOfByte2 = Utility.gZip(arrayOfByte1);
          if (arrayOfByte2 == null)
            return null;
        }
        else
        {
          Constants.StatisticType localStatisticType = (Constants.StatisticType)localIterator.next();
          switch ($SWITCH_TABLE$com$baidu$clientupdate$utility$Constants$StatisticType()[localStatisticType.ordinal()])
          {
          case 1:
            if (localStatisticFile.isVersionInfoStatisticEnabled(this.mContext))
              localJSONObject.put("01", "1.1");
            if (localStatisticFile.isUEStatisticEnabled(this.mContext))
            {
              String str = this.mStatisticProcessor.generateUEStatistics();
              if (!TextUtils.isEmpty(str))
                localJSONObject.put("03", new JSONArray(str));
            }
            break;
          }
        }
      }
      catch (JSONException localJSONException)
      {
        byte[] arrayOfByte1;
        byte[] arrayOfByte2;
        if (DEBUG)
        {
          Log.e("StatisticPoster", "error:" + localJSONException.getMessage());
          continue;
          arrayOfByte2[0] = 117;
          arrayOfByte2[1] = 123;
          if (DEBUG)
          {
            Log.d("StatisticPoster", "用户行为统计数据size:(byte)" + arrayOfByte1.length);
            Log.d("StatisticPoster", "用户行为统计数据,压缩后size:(byte)" + arrayOfByte2.length);
          }
          return Base64.encodeToString(arrayOfByte2, 0);
        }
      }
  }

  public static StatisticPoster getInstance(Context paramContext)
  {
    if (instance == null)
      instance = new StatisticPoster(paramContext);
    return instance;
  }

  private boolean needSendStatisticData()
  {
    StatisticFile localStatisticFile = StatisticFile.getInstance(this.mContext);
    long l1 = localStatisticFile.getLastSendStatisticTime(this.mContext);
    if (l1 == 0L)
      return false;
    File localFile = new File(this.mContext.getFilesDir(), StatisticFile.UE_FILE_BAK);
    long l2 = localStatisticFile.getStatisticTimeout();
    long l3 = System.currentTimeMillis();
    long l4 = localStatisticFile.getStatisticTimeup();
    long l5 = l1 + 86400000L * l2;
    if ((l3 - l1 >= l4) && (l3 <= l5))
    {
      if (localFile.length() > 0L)
        return true;
      StatisticProcessor.getInstance(this.mContext).writeBufferToFile();
      localStatisticFile.forceMoveToUpFile();
      return localFile.length() > 0L;
    }
    if ((localFile.length() > 0L) && (l3 <= l5))
      return true;
    if ((l3 > l5) && (localStatisticFile.isUEStatisticEnabled(this.mContext)))
    {
      if (DEBUG)
        Log.d("StatisticPoster", "超时，删除用户行为统计文件");
      localStatisticFile.deleteUserBehaivorStatisticFiles();
      localStatisticFile.setLastSendStatisticTime(this.mContext, l3);
    }
    return false;
  }

  public void checkSendStatisticData(String paramString)
  {
    if (DEBUG)
      Log.d("StatisticPoster", "checkSendStatisticData -- " + paramString);
    new Thread(new Runnable()
    {
      public void run()
      {
        if (StatisticPoster.this.needSendStatisticData())
        {
          ArrayList localArrayList = new ArrayList();
          localArrayList.add(Constants.StatisticType.UE_STATISTIC);
          StatisticPoster.getInstance(StatisticPoster.this.mContext).sendStatisticData(localArrayList);
          return;
        }
        StatisticFile localStatisticFile = StatisticFile.getInstance(StatisticPoster.this.mContext);
        long l1 = localStatisticFile.getStatisticTimeup();
        long l2 = System.currentTimeMillis();
        long l3 = l1 + localStatisticFile.getLastSendStatisticTime(StatisticPoster.this.mContext);
        if (l3 > l2);
        for (long l4 = (l3 - l2) % l1; ; l4 = l1)
        {
          StatisticPoster.this.setAlarmForStatisticData(l4);
          return;
        }
      }
    }
    , "checkSendS").start();
  }

  public void sendStatisticData(ArrayList<Constants.StatisticType> paramArrayList)
  {
    StatisticFile localStatisticFile = StatisticFile.getInstance(this.mContext);
    if (localStatisticFile.isFileFull());
    String str;
    do
    {
      return;
      localStatisticFile.setFileFull(true);
      this.mStatisticTypes = paramArrayList;
      str = buildPostContent(this.mStatisticTypes);
      if (!TextUtils.isEmpty(str))
        break;
    }
    while (!DEBUG);
    Log.i("StatisticPoster", "buildPostContent return null!");
    return;
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append(BaiduParamManager.getInstance(this.mContext).getLogServerAddress() + "/appsrv?native_api=1&action=showlog");
    if (DEBUG)
      Log.d("StatisticPoster", "send statistic data url:" + localStringBuilder.toString());
    new SendStaticDataWorker(localStringBuilder.toString(), str).start();
  }

  void setAlarmForStatisticData(long paramLong)
  {
    if (!StatisticFile.getInstance(this.mContext).isUEStatisticEnabled(this.mContext))
      return;
    if (DEBUG)
      Log.d("StatisticPoster", "setAlarmForStatisticData: " + paramLong);
    Intent localIntent = new Intent("com.baidu.appsearch.action.CHECKSENDSTATISTICDATA");
    localIntent.setPackage(this.mContext.getPackageName());
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(this.mContext, 1, localIntent, 268435456);
    long l = paramLong + SystemClock.elapsedRealtime();
    AlarmManager localAlarmManager = (AlarmManager)this.mContext.getSystemService("alarm");
    localAlarmManager.cancel(localPendingIntent);
    localAlarmManager.set(3, l, localPendingIntent);
  }

  private class SendStaticDataWorker extends Thread
  {
    private String mPostContent = null;
    private final CharSequence mUrl;

    public SendStaticDataWorker(CharSequence paramString, String arg3)
    {
      this.mUrl = paramString;
      Object localObject;
      this.mPostContent = localObject;
    }

    // ERROR //
    private org.apache.http.client.entity.UrlEncodedFormEntity getPostData()
    {
      // Byte code:
      //   0: new 51	java/util/ArrayList
      //   3: dup
      //   4: invokespecial 52	java/util/ArrayList:<init>	()V
      //   7: astore_1
      //   8: aload_1
      //   9: new 54	org/apache/http/message/BasicNameValuePair
      //   12: dup
      //   13: ldc 56
      //   15: aload_0
      //   16: getfield 43	com/baidu/clientupdate/statistic/StatisticPoster$SendStaticDataWorker:mPostContent	Ljava/lang/String;
      //   19: invokespecial 59	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
      //   22: invokeinterface 65 2 0
      //   27: pop
      //   28: aconst_null
      //   29: astore_3
      //   30: new 67	org/apache/http/client/entity/UrlEncodedFormEntity
      //   33: dup
      //   34: aload_1
      //   35: ldc 69
      //   37: invokespecial 72	org/apache/http/client/entity/UrlEncodedFormEntity:<init>	(Ljava/util/List;Ljava/lang/String;)V
      //   40: astore 4
      //   42: aload 4
      //   44: ldc 74
      //   46: invokevirtual 78	org/apache/http/client/entity/UrlEncodedFormEntity:setContentType	(Ljava/lang/String;)V
      //   49: aload 4
      //   51: areturn
      //   52: astore 5
      //   54: aload 5
      //   56: invokevirtual 81	java/io/UnsupportedEncodingException:printStackTrace	()V
      //   59: aload_3
      //   60: areturn
      //   61: astore 5
      //   63: aload 4
      //   65: astore_3
      //   66: goto -12 -> 54
      //
      // Exception table:
      //   from	to	target	type
      //   30	42	52	java/io/UnsupportedEncodingException
      //   42	49	61	java/io/UnsupportedEncodingException
    }

    public void run()
    {
      ProxyHttpClient localProxyHttpClient = new ProxyHttpClient(StatisticPoster.this.mContext);
      HttpPost localHttpPost = new HttpPost(this.mUrl.toString());
      while (true)
      {
        Iterator localIterator1;
        Iterator localIterator2;
        try
        {
          localHttpPost.addHeader("Content-Type", "application/x-www-form-urlencoded");
          localHttpPost.addHeader("Accept-Encoding", "gzip");
          localHttpPost.setEntity(getPostData());
          localHttpResponse = localProxyHttpClient.execute(localHttpPost);
          if (localHttpResponse.getStatusLine().getStatusCode() == 200)
          {
            Iterator localIterator3 = StatisticPoster.this.mStatisticTypes.iterator();
            boolean bool = localIterator3.hasNext();
            if (!bool)
              return;
            Constants.StatisticType localStatisticType3 = (Constants.StatisticType)localIterator3.next();
            switch ($SWITCH_TABLE$com$baidu$clientupdate$utility$Constants$StatisticType()[localStatisticType3.ordinal()])
            {
            case 1:
              StatisticFile localStatisticFile = StatisticFile.getInstance(StatisticPoster.this.mContext);
              localStatisticFile.removeStatisticFile();
              if (localStatisticFile.isUEStatisticEnabled(StatisticPoster.this.mContext))
                localStatisticFile.setLastSendStatisticTime(StatisticPoster.this.mContext, System.currentTimeMillis());
              long l3 = localStatisticFile.getStatisticTimeup();
              StatisticPoster.this.setAlarmForStatisticData(l3);
              continue;
            }
          }
        }
        catch (Exception localException)
        {
          HttpResponse localHttpResponse;
          localIterator1 = StatisticPoster.this.mStatisticTypes.iterator();
          if (localIterator1.hasNext())
            break label453;
          if (StatisticPoster.DEBUG)
            Log.w("StatisticPoster", "error:" + localException);
          return;
          localIterator2 = StatisticPoster.this.mStatisticTypes.iterator();
          if (!localIterator2.hasNext())
          {
            if (!StatisticPoster.DEBUG)
              continue;
            Log.d("StatisticPoster", "request failed  " + localHttpResponse.getStatusLine());
            continue;
          }
        }
        finally
        {
          StatisticFile.getInstance(StatisticPoster.this.mContext).setFileFull(false);
          localProxyHttpClient.close();
        }
        Constants.StatisticType localStatisticType2 = (Constants.StatisticType)localIterator2.next();
        switch ($SWITCH_TABLE$com$baidu$clientupdate$utility$Constants$StatisticType()[localStatisticType2.ordinal()])
        {
        case 1:
          long l2 = Math.min(StatisticFile.getInstance(StatisticPoster.this.mContext).getStatisticTimeup(), 900000L);
          StatisticPoster.this.setAlarmForStatisticData(l2);
          continue;
          label453: Constants.StatisticType localStatisticType1 = (Constants.StatisticType)localIterator1.next();
          switch ($SWITCH_TABLE$com$baidu$clientupdate$utility$Constants$StatisticType()[localStatisticType1.ordinal()])
          {
          case 1:
            long l1 = Math.min(StatisticFile.getInstance(StatisticPoster.this.mContext).getStatisticTimeup(), 1800000L);
            StatisticPoster.this.setAlarmForStatisticData(l1);
          }
          break;
        }
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.statistic.StatisticPoster
 * JD-Core Version:    0.6.2
 */