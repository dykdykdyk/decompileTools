package com.baidu.clientupdate.statistic;

public final class StatisticConstants
{
  public static final String UEID_920001 = "920001";
  public static final String UEID_920002 = "920002";
  public static final String UEID_920003 = "920003";
  public static final String UEID_920004 = "920004";
  public static final String UEID_920005 = "920005";
  public static final String UEID_920006 = "920006";
  public static final String UE_00 = "00";
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.statistic.StatisticConstants
 * JD-Core Version:    0.6.2
 */