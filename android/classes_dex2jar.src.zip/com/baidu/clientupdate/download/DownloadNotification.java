package com.baidu.clientupdate.download;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import com.baidu.clientupdate.utility.Constants;
import java.util.Collection;
import java.util.Iterator;

public class DownloadNotification
{
  private static final boolean DEBUG = false;
  private static final int NOTIFICATION_ID_ONGOING = 0;
  static final String TAG = "DownloadNotification";
  public static final int mAppSearchNotificationId = 24467;
  public static final int mClientNotificationId = 24467;
  public static int mCompleteNotificationId = 0;
  public static final int mRecommandNotificationId = 24466;
  private static int mRunningNotificationId = 24452;
  Context mContext;
  private NotificationManager mNotificationManager;

  static
  {
    mCompleteNotificationId = 24453;
  }

  DownloadNotification(Context paramContext)
  {
    this.mContext = paramContext;
    this.mNotificationManager = ((NotificationManager)this.mContext.getSystemService("notification"));
  }

  private void updateCompletedNotification(Collection<Download> paramCollection)
  {
    Iterator localIterator = paramCollection.iterator();
    Notification localNotification;
    if (!localIterator.hasNext())
    {
      Intent localIntent = new Intent();
      localNotification = new Notification();
      localNotification.deleteIntent = PendingIntent.getBroadcast(this.mContext, 0, localIntent, 0);
      localNotification.flags = (0x10 | localNotification.flags);
      if (0 != 0)
        break label87;
      cancelNotification(mCompleteNotificationId);
    }
    label87: 
    while (0 <= 0)
    {
      return;
      ((Download)localIterator.next());
      break;
    }
    postNotification(mCompleteNotificationId, localNotification);
  }

  public void cancelAllNotifications()
  {
    this.mNotificationManager.cancelAll();
  }

  public void cancelNotification(long paramLong)
  {
    this.mNotificationManager.cancel((int)paramLong);
  }

  public void postNotification(long paramLong, Notification paramNotification)
  {
    try
    {
      this.mNotificationManager.notify((int)paramLong, paramNotification);
      return;
    }
    catch (Exception localException)
    {
      while (!DEBUG);
      Log.e("DownloadNotification", "postNotification:" + localException.getMessage());
    }
  }

  public void showAppSearchNotification(String paramString)
  {
    Intent localIntent = new Intent();
    localIntent.setPackage(this.mContext.getPackageName());
    Notification localNotification = new Notification();
    localNotification.icon = 17301543;
    localNotification.when = System.currentTimeMillis();
    localNotification.setLatestEventInfo(this.mContext, "应用下载中", "正在下载" + paramString, PendingIntent.getActivity(this.mContext, 0, localIntent, 0));
    localNotification.flags = (0x10 | localNotification.flags);
    postNotification(24467L, localNotification);
  }

  public void showClientNotification(String paramString)
  {
    Intent localIntent = new Intent();
    localIntent.setPackage(this.mContext.getPackageName());
    Notification localNotification = new Notification();
    localNotification.icon = 17301543;
    localNotification.when = System.currentTimeMillis();
    localNotification.setLatestEventInfo(this.mContext, "应用下载中", "正在下载" + paramString, PendingIntent.getActivity(this.mContext, 0, localIntent, 0));
    localNotification.flags = (0x10 | localNotification.flags);
    postNotification(24467L, localNotification);
  }

  public void showRecommandNotification(String paramString)
  {
    Intent localIntent = new Intent();
    localIntent.setPackage(this.mContext.getPackageName());
    Notification localNotification = new Notification();
    localNotification.icon = 17301543;
    localNotification.when = System.currentTimeMillis();
    localNotification.setLatestEventInfo(this.mContext, "应用下载中", "正在下载" + paramString + "的更新", PendingIntent.getActivity(this.mContext, 0, localIntent, 0));
    localNotification.flags = (0x10 | localNotification.flags);
    postNotification(24466L, localNotification);
  }

  public void updateActiveNotification(Collection<Download> paramCollection)
  {
    int i = 0;
    int j = 0;
    int k = 0;
    Iterator localIterator = paramCollection.iterator();
    Notification localNotification;
    while (true)
    {
      if (!localIterator.hasNext())
      {
        if (DEBUG)
          Log.i("DownloadNotification", "downloads.size(): " + paramCollection.size() + " running: " + i + " waitting: " + j + " paused: " + k);
        int m = k + (i + j);
        if (DEBUG)
          Log.d("DownloadNotification", "download name: " + "");
        Intent localIntent = new Intent();
        localIntent.setPackage(this.mContext.getPackageName());
        localNotification = new Notification();
        localNotification.icon = 17301543;
        localNotification.when = System.currentTimeMillis();
        localNotification.setLatestEventInfo(this.mContext, m + "个下载任务", "任务下载中", PendingIntent.getActivity(this.mContext, 0, localIntent, 0));
        localNotification.flags = (0x10 | localNotification.flags);
        if (i + j > 0)
          break;
        cancelNotification(mRunningNotificationId);
        return;
      }
      Download localDownload = (Download)localIterator.next();
      if (localDownload.getState() == Download.DownloadState.PAUSE)
        k++;
      else if (localDownload.getState() == Download.DownloadState.DOWNLOADING)
        i++;
      else if (localDownload.getState() == Download.DownloadState.WAITING)
        j++;
    }
    postNotification(mRunningNotificationId, localNotification);
  }

  public void updateNotification(Collection<Download> paramCollection)
  {
    updateActiveNotification(paramCollection);
  }

  static class NotificationItem
  {
    int mDownloadingCount;
    int mPausedCount;
    int mTitleCount = 0;
    String[] mTitles = new String[2];
    long mTotalCurrent = 0L;
    long mTotalTotal = 0L;
    int mWaitingCount;

    void addItem(String paramString, long paramLong1, long paramLong2, boolean paramBoolean, Download.DownloadState paramDownloadState)
    {
      this.mTotalCurrent = (paramLong1 + this.mTotalCurrent);
      if ((paramLong2 <= 0L) || (this.mTotalTotal == -1L));
      for (this.mTotalTotal = -1L; ; this.mTotalTotal = (paramLong2 + this.mTotalTotal))
      {
        if (this.mTitleCount < 2)
          this.mTitles[this.mTitleCount] = paramString;
        this.mTitleCount = (1 + this.mTitleCount);
        if (!paramBoolean)
          break;
        this.mPausedCount = (1 + this.mPausedCount);
        return;
      }
      if (paramDownloadState == Download.DownloadState.DOWNLOADING)
      {
        this.mDownloadingCount = (1 + this.mDownloadingCount);
        return;
      }
      this.mWaitingCount = (1 + this.mWaitingCount);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.download.DownloadNotification
 * JD-Core Version:    0.6.2
 */