package com.baidu.clientupdate.download;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import com.baidu.clientupdate.statistic.StatisticProcessor;
import com.baidu.clientupdate.utility.Constants;
import com.baidu.clientupdate.utility.Utility;
import com.request.taskmanager.BinaryTaskMng;
import com.request.taskmanager.FileMsg;
import com.request.taskmanager.TaskFacade;
import com.request.taskmanager.TaskObserver;
import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

public final class DownloadManager
{
  public static final String ACTION_DOWNLOAD_PROGRESS_CHANGE = "com.baidu.clientupdate.download.PROGRESS_CHANGE";
  public static final String ACTION_DOWNLOAD_STATUS_CHANGE = "com.baidu.clientupdate.download.STATUS_CHANGE";
  private static final boolean DEBUG = false;
  private static final long MIN_LEFT_SIZE = 20971520L;
  private static final long MIN_PROGRESS_INTERVAL = 200L;
  private static final long MIN_PROGRESS_SAVE_INTERVAL = 2000L;
  private static final String TAG = "DownloadManager";
  private static DownloadManager sInstance;
  private String mClientFileName = null;
  private String mClientSourceKey = null;
  private Context mContext;
  private DownloadDBHelper mDbHelper;
  private Hashtable<Long, Download> mDownloadMap = new Hashtable();
  private Handler mHandler = new Handler(Looper.getMainLooper());
  private HashMap<String, String> mHeaders;
  private String mRecommandFileName = null;
  private String mRecommandSourceKey = null;
  private BinaryTaskMng mTaskManager;
  private TaskObserver mtaskObserver = new TaskObserver()
  {
    protected void onDownloadCancel(String paramAnonymousString1, long paramAnonymousLong1, long paramAnonymousLong2, long paramAnonymousLong3, String paramAnonymousString2)
    {
      if (DownloadManager.DEBUG)
        Log.d("DownloadManager", "--- onDownloadCancel : " + paramAnonymousLong1);
      DownloadManager.this.changeState(Download.DownloadState.CANCEL, paramAnonymousLong1);
    }

    protected void onDownloadFail(String paramAnonymousString1, long paramAnonymousLong1, long paramAnonymousLong2, String paramAnonymousString2, String paramAnonymousString3)
    {
      Download localDownload = (Download)DownloadManager.this.mDownloadMap.get(Long.valueOf(paramAnonymousLong1));
      if (localDownload != null)
      {
        if (paramAnonymousLong2 <= localDownload.mFileLength)
          localDownload.mCurrentLength = paramAnonymousLong2;
        localDownload.mFailReason = paramAnonymousString3;
        StatisticProcessor.addOnlyValueUEStatisticWithoutCache(DownloadManager.this.mContext, "920006", localDownload.mFileName);
      }
      DownloadManager.this.changeState(Download.DownloadState.FAILED, paramAnonymousLong1);
    }

    protected void onDownloadPause(String paramAnonymousString1, long paramAnonymousLong1, long paramAnonymousLong2, long paramAnonymousLong3, String paramAnonymousString2)
    {
      Download localDownload = (Download)DownloadManager.this.mDownloadMap.get(Long.valueOf(paramAnonymousLong1));
      if (localDownload != null)
        localDownload.mCurrentLength = paramAnonymousLong2;
      DownloadManager.this.changeState(Download.DownloadState.PAUSE, paramAnonymousLong1);
    }

    protected void onDownloadStart(String paramAnonymousString1, long paramAnonymousLong1, long paramAnonymousLong2, String paramAnonymousString2, String paramAnonymousString3, String paramAnonymousString4)
    {
      Download localDownload = (Download)DownloadManager.this.mDownloadMap.get(Long.valueOf(paramAnonymousLong1));
      if (localDownload != null)
      {
        File localFile = new File(paramAnonymousString3);
        String str = localFile.getParent();
        if (!TextUtils.equals(str, localDownload.mSavedPath))
        {
          new File(localDownload.mSavedPath, localDownload.mFileName).delete();
          localDownload.mSavedPath = str;
          localDownload.mCurrentLength = 0L;
        }
        localDownload.mFileLength = paramAnonymousLong2;
        localDownload.mFileName = localFile.getName();
      }
      DownloadManager.this.changeState(Download.DownloadState.DOWNLOADING, paramAnonymousLong1);
    }

    protected void onDownloadSuccess(String paramAnonymousString1, long paramAnonymousLong1, long paramAnonymousLong2, long paramAnonymousLong3, String paramAnonymousString2, long paramAnonymousLong4)
    {
      if (DownloadManager.DEBUG)
        Log.d("DownloadManager", "--- onDownloadSuccess : " + paramAnonymousLong1);
    }

    protected void onDownloading(String paramAnonymousString, long paramAnonymousLong1, long paramAnonymousLong2, long paramAnonymousLong3, long paramAnonymousLong4)
    {
      if ((paramAnonymousLong3 == 0L) || (paramAnonymousLong2 == 0L) || (paramAnonymousLong2 > paramAnonymousLong3));
      Download localDownload;
      long l;
      do
      {
        do
        {
          do
          {
            return;
            localDownload = (Download)DownloadManager.this.mDownloadMap.get(Long.valueOf(paramAnonymousLong1));
            if (localDownload != null)
              break;
          }
          while (!DownloadManager.DEBUG);
          Log.e("DownloadManager", "*** onDownloading, found download is null!");
          return;
          localDownload.mCurrentLength = paramAnonymousLong2;
          localDownload.mFileLength = paramAnonymousLong3;
          l = System.currentTimeMillis();
        }
        while (l - localDownload.mLastProgressNotiStamp < 200L);
        localDownload.mLastProgressNotiStamp = l;
        int i = localDownload.getProgress();
        if (i != localDownload.mLastProgressNoti)
        {
          DownloadManager.this.notifyProgressChange(paramAnonymousLong1, i);
          localDownload.mLastProgressNoti = i;
        }
      }
      while (l - localDownload.mLastProgressSaveStamp <= 2000L);
      DownloadManager.this.mDbHelper.update(localDownload);
      localDownload.mLastProgressSaveStamp = l;
    }

    protected void onWriteFinish(String paramAnonymousString, long paramAnonymousLong)
    {
      if (DownloadManager.DEBUG)
        Log.d("DownloadManager", "--- onWriteFinish : " + paramAnonymousLong);
      Download localDownload = (Download)DownloadManager.this.mDownloadMap.get(Long.valueOf(paramAnonymousLong));
      if (localDownload != null)
      {
        localDownload.mCurrentLength = localDownload.mFileLength;
        final String str = localDownload.mSavedPath + "/" + localDownload.mFileName;
        if (DownloadManager.DEBUG)
          Log.d("DownloadManager", "Download path:" + str);
        DownloadManager.this.mHandler.post(new Runnable()
        {
          public void run()
          {
            DownloadManager.this.launchSystemInstalller(str);
          }
        });
      }
      DownloadManager.this.changeState(Download.DownloadState.FINISH, paramAnonymousLong);
    }
  };

  private DownloadManager(Context paramContext)
  {
    this.mContext = paramContext;
    this.mDbHelper = new DownloadDBHelper(paramContext);
    this.mTaskManager = TaskFacade.getInstance(this.mContext).getBinaryTaskMng();
    this.mTaskManager.addObserver(this.mtaskObserver);
    this.mHeaders = new HashMap();
    this.mHeaders.put("referer", "m.baidu.com");
    queryAll();
  }

  private void changeState(Download.DownloadState paramDownloadState, long paramLong)
  {
    Download localDownload = (Download)this.mDownloadMap.get(Long.valueOf(paramLong));
    if (localDownload != null)
    {
      if (paramDownloadState != Download.DownloadState.CANCEL)
        break label159;
      if (!localDownload.mNeedDeleteFile);
    }
    while (true)
    {
      try
      {
        new File(localDownload.mSavedPath, localDownload.mFileName).delete();
        this.mDownloadMap.remove(Long.valueOf(paramLong));
        if (DEBUG)
          Log.i("DownloadManager", "mDownloadMap remove downloadId: " + paramLong + "  mDownloadMap size: " + this.mDownloadMap.size());
        this.mDbHelper.delete(new long[] { paramLong });
        notifyStateChange(paramLong, localDownload);
        return;
      }
      catch (Exception localException)
      {
        if (!DEBUG)
          continue;
        Log.e("DownloadManager", "delete download file error!!");
        localException.printStackTrace();
        continue;
      }
      label159: localDownload.mState = paramDownloadState;
      this.mDbHelper.update(localDownload);
      if (DEBUG)
        Log.d("DownloadManager", "downloadmanger notification :" + localDownload);
    }
  }

  private Download getDownload(String paramString)
  {
    Iterator localIterator = this.mDownloadMap.values().iterator();
    Download localDownload;
    do
    {
      if (!localIterator.hasNext())
        return null;
      localDownload = (Download)localIterator.next();
    }
    while (!TextUtils.equals(localDownload.mSourceKey, paramString));
    return localDownload;
  }

  public static DownloadManager getInstance(Context paramContext)
  {
    if (sInstance == null);
    try
    {
      if (sInstance == null)
        sInstance = new DownloadManager(paramContext);
      return sInstance;
    }
    finally
    {
    }
  }

  private void launchSystemInstalller(String paramString)
  {
    File localFile = new File(paramString);
    Utility.startSystemInstallUI(this.mContext, localFile);
  }

  private void notifyProgressChange(final long paramLong, int paramInt)
  {
    if (DEBUG)
      Log.d("DownloadManager", "notifyStateChange downloadId " + paramLong + " progress " + paramInt);
    this.mHandler.post(new Runnable()
    {
      public void run()
      {
        Download localDownload = (Download)DownloadManager.this.mDownloadMap.get(Long.valueOf(paramLong));
        if (localDownload != null)
        {
          Intent localIntent = new Intent("com.baidu.clientupdate.download.PROGRESS_CHANGE");
          localIntent.putExtra("downloadid", paramLong);
          localIntent.putExtra("download", localDownload);
          localIntent.putExtra("progress", this.val$progress);
          localIntent.setPackage(DownloadManager.this.mContext.getPackageName());
          DownloadManager.this.mContext.sendBroadcast(localIntent);
        }
      }
    });
  }

  private void notifyStateChange(final long paramLong, Download paramDownload)
  {
    if (DEBUG)
      Log.d("DownloadManager", "notifyStateChange downloadId " + paramLong + " state " + paramDownload.getState());
    this.mHandler.post(new Runnable()
    {
      public void run()
      {
        Intent localIntent = new Intent("com.baidu.clientupdate.download.STATUS_CHANGE");
        localIntent.putExtra("downloadid", paramLong);
        localIntent.putExtra("state", this.val$download.getState());
        localIntent.putExtra("download", this.val$download);
        localIntent.setPackage(DownloadManager.this.mContext.getPackageName());
        DownloadManager.this.mContext.sendBroadcast(localIntent);
      }
    });
  }

  private void queryAll()
  {
    Cursor localCursor;
    if ((this.mDownloadMap == null) || (this.mDownloadMap.size() == 0))
    {
      localCursor = this.mDbHelper.queryAll();
      if (localCursor != null)
        localCursor.moveToFirst();
    }
    while (true)
    {
      if (localCursor.isAfterLast())
      {
        localCursor.close();
        return;
      }
      Download localDownload = readDownload(localCursor);
      this.mDownloadMap.put(Long.valueOf(localDownload.mId), localDownload);
      localCursor.moveToNext();
    }
  }

  private Download readDownload(Cursor paramCursor)
  {
    Download localDownload = new Download();
    localDownload.mId = paramCursor.getLong(paramCursor.getColumnIndex("_id"));
    localDownload.mUrl = paramCursor.getString(paramCursor.getColumnIndex("downloadurl"));
    localDownload.mFileName = paramCursor.getString(paramCursor.getColumnIndex("filename"));
    localDownload.mSavedPath = paramCursor.getString(paramCursor.getColumnIndex("savedpath"));
    localDownload.mFileLength = paramCursor.getLong(paramCursor.getColumnIndex("totalsize"));
    localDownload.mCurrentLength = paramCursor.getLong(paramCursor.getColumnIndex("downloadedsize"));
    File localFile = new File(localDownload.mSavedPath + File.separator + localDownload.mFileName);
    if (localFile.exists());
    for (localDownload.mCurrentLength = localFile.length(); ; localDownload.mCurrentLength = 0L)
    {
      localDownload.mState = Download.DownloadState.getState(paramCursor.getInt(paramCursor.getColumnIndex("status")));
      localDownload.mFailReason = paramCursor.getString(paramCursor.getColumnIndex("failreason"));
      localDownload.mMimeType = paramCursor.getString(paramCursor.getColumnIndex("mimetype"));
      localDownload.mSourceKey = paramCursor.getString(paramCursor.getColumnIndex("sourcekey"));
      return localDownload;
    }
  }

  public void setFileNameInfo(String paramString1, String paramString2)
  {
    this.mClientFileName = paramString1;
    this.mRecommandFileName = paramString2;
    if (DEBUG)
      Log.d("DownloadManager", "mClientFileName: " + this.mClientFileName + " ,mRecommandFileName: " + this.mRecommandFileName);
  }

  public void setInstallInfo(String paramString1, String paramString2)
  {
    this.mClientSourceKey = paramString1;
    this.mRecommandSourceKey = paramString2;
    if (DEBUG)
      Log.d("DownloadManager", "mClientSourceKey: " + this.mClientSourceKey + " ,mRecommandSourceKey: " + this.mRecommandSourceKey);
  }

  public long startDownload(Download paramDownload)
  {
    long l1 = -1L;
    try
    {
      Download localDownload1 = getDownload(paramDownload.mSourceKey);
      Download localDownload2 = null;
      if (localDownload1 != null)
        localDownload2 = getDownload(paramDownload.mSourceKey);
      if (localDownload2 != null)
      {
        File localFile = new File(localDownload2.mSavedPath, localDownload2.mFileName);
        if (localFile.exists())
        {
          if (DEBUG)
            Log.d("DownloadManager", "Exist file: " + localFile.getAbsolutePath());
          localFile.delete();
        }
        this.mDownloadMap.remove(Long.valueOf(localDownload2.mId));
        if (DEBUG)
          Log.i("DownloadManager", "mDownloadMap remove downloadId: " + localDownload2.mId + "  mDownloadMap size: " + this.mDownloadMap.size());
        DownloadDBHelper localDownloadDBHelper = this.mDbHelper;
        long[] arrayOfLong = new long[1];
        arrayOfLong[0] = localDownload2.mId;
        localDownloadDBHelper.delete(arrayOfLong);
      }
      paramDownload.mFailReason = "";
      String str = paramDownload.mSavedPath;
      if (TextUtils.isEmpty(str))
        str = Environment.getExternalStorageDirectory().getPath();
      long l2 = paramDownload.mFileLength;
      long l3 = paramDownload.mCurrentLength;
      l1 = this.mDbHelper.insert(paramDownload);
      paramDownload.mId = l1;
      this.mDownloadMap.put(Long.valueOf(l1), paramDownload);
      FileMsg localFileMsg = new FileMsg(paramDownload.mUrl, l1, str, paramDownload.mFileName, paramDownload.mMimeType, Boolean.valueOf(false), this.mHeaders, l3, l2, "");
      this.mTaskManager.startDownload(localFileMsg);
      return l1;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return l1;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.download.DownloadManager
 * JD-Core Version:    0.6.2
 */