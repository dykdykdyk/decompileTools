package com.baidu.clientupdate.download;

import android.util.Pair;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Download
  implements Serializable
{
  private static final long serialVersionUID = 4323766085367277105L;
  public long mCurrentLength = 0L;
  public String mFailReason = "";
  public long mFileLength = 0L;
  public String mFileName = "";
  public long mId;
  public int mLastProgressNoti = 0;
  public long mLastProgressNotiStamp = 0L;
  public long mLastProgressSaveStamp = 0L;
  public String mMimeType = "";
  public boolean mNeedDeleteFile = true;
  public List<Pair<String, String>> mRequestHeaders = new ArrayList();
  public String mSavedPath = "";
  public String mSourceKey = "";
  public DownloadState mState = DownloadState.WAITING;
  public String mUrl = "";

  public long getCurrentLength()
  {
    return this.mCurrentLength;
  }

  public String getDownloadUri()
  {
    return this.mUrl;
  }

  public String getFailReason()
  {
    return this.mFailReason;
  }

  public long getFileLength()
  {
    return this.mFileLength;
  }

  public String getFileType()
  {
    return this.mMimeType;
  }

  public int getProgress()
  {
    if ((this.mCurrentLength == 0L) || (this.mFileLength == 0L))
      return 0;
    int i = (int)(100L * this.mCurrentLength / this.mFileLength);
    if (i >= 100)
      i = 99;
    return i;
  }

  public DownloadState getState()
  {
    return this.mState;
  }

  public Download parseToObject(String paramString)
  {
    return new Download();
  }

  public String toString()
  {
    return "mUrl=" + this.mUrl + ", mFileName=" + this.mFileName + ", mSavedPath=" + this.mSavedPath + ", mFileLength=" + this.mFileLength + ", mCurrentLength=" + this.mCurrentLength + ", mState=" + this.mState + ", mFailReason=" + this.mFailReason + ", mMimeType=" + this.mMimeType + ", mSourceKey=" + this.mSourceKey + ", mLastProgressNotiStamp=" + this.mLastProgressNotiStamp + ", mLastProgressSaveStamp=" + this.mLastProgressSaveStamp + ", mLastProgressNoti=" + this.mLastProgressNoti + ", mNeedDeleteFile=" + this.mNeedDeleteFile;
  }

  public static enum DownloadState
  {
    static
    {
      DOWNLOADING = new DownloadState("DOWNLOADING", 1);
      PAUSE = new DownloadState("PAUSE", 2);
      FAILED = new DownloadState("FAILED", 3);
      CANCEL = new DownloadState("CANCEL", 4);
      FINISH = new DownloadState("FINISH", 5);
      UNKNOWN = new DownloadState("UNKNOWN", 6);
      DownloadState[] arrayOfDownloadState = new DownloadState[7];
      arrayOfDownloadState[0] = WAITING;
      arrayOfDownloadState[1] = DOWNLOADING;
      arrayOfDownloadState[2] = PAUSE;
      arrayOfDownloadState[3] = FAILED;
      arrayOfDownloadState[4] = CANCEL;
      arrayOfDownloadState[5] = FINISH;
      arrayOfDownloadState[6] = UNKNOWN;
    }

    public static DownloadState getState(int paramInt)
    {
      switch (paramInt)
      {
      default:
        return UNKNOWN;
      case 0:
        return WAITING;
      case 1:
        return DOWNLOADING;
      case 2:
        return PAUSE;
      case 3:
        return FAILED;
      case 4:
        return CANCEL;
      case 5:
      }
      return FINISH;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.download.Download
 * JD-Core Version:    0.6.2
 */