package com.baidu.clientupdate.download;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DownloadDBHelper extends SQLiteOpenHelper
{
  public static final String COLUMN_CURRENT_BYTES = "downloadedsize";
  public static final String COLUMN_FAILED_REASON = "failreason";
  public static final String COLUMN_FILE_NAME = "filename";
  public static final String COLUMN_MIME_TYPE = "mimetype";
  public static final String COLUMN_SAVED_PATH = "savedpath";
  public static final String COLUMN_SOURCE_KEY = "sourcekey";
  public static final String COLUMN_STATUS = "status";
  public static final String COLUMN_TOTAL_BYTES = "totalsize";
  public static final String COLUMN_URI = "downloadurl";
  private static final String DB_NAME = "lcupdatedown.db";
  private static final String DB_TABLE = "downloads";
  private static final int DB_VERSION = 1;
  private static final boolean DEBUG = true;
  private static final String TAG = "lcdownloadsdk";
  private Context mContext;

  public DownloadDBHelper(Context paramContext)
  {
    super(paramContext, "lcupdatedown.db", null, 1);
    this.mContext = paramContext;
  }

  private void createDownloadTable(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      paramSQLiteDatabase.execSQL("DROP TABLE IF EXISTS downloads");
      paramSQLiteDatabase.execSQL("CREATE TABLE downloads(_id INTEGER PRIMARY KEY AUTOINCREMENT,downloadurl TEXT, filename TEXT, savedpath TEXT, mimetype TEXT, status INTEGER, totalsize INTEGER, downloadedsize INTEGER, sourcekey TEXT, failreason TEXT);");
      return;
    }
    catch (SQLException localSQLException)
    {
      Log.e("lcdownloadsdk", "couldn't create table in downloads database");
      throw localSQLException;
    }
  }

  private ContentValues generateContentValues(Download paramDownload)
  {
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("filename", paramDownload.mFileName);
    localContentValues.put("savedpath", paramDownload.mSavedPath);
    localContentValues.put("downloadurl", paramDownload.mUrl);
    localContentValues.put("mimetype", paramDownload.mMimeType);
    localContentValues.put("status", Integer.valueOf(paramDownload.mState.ordinal()));
    localContentValues.put("totalsize", Long.valueOf(paramDownload.mFileLength));
    localContentValues.put("downloadedsize", Long.valueOf(paramDownload.mCurrentLength));
    localContentValues.put("sourcekey", paramDownload.mSourceKey);
    localContentValues.put("failreason", paramDownload.mFailReason);
    return localContentValues;
  }

  static String[] getWhereArgsForIds(long[] paramArrayOfLong)
  {
    String[] arrayOfString = new String[paramArrayOfLong.length];
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfLong.length)
        return arrayOfString;
      arrayOfString[i] = Long.toString(paramArrayOfLong[i]);
    }
  }

  static String getWhereClauseForIds(long[] paramArrayOfLong)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("(");
    for (int i = 0; ; i++)
    {
      if (i >= paramArrayOfLong.length)
      {
        localStringBuilder.append(")");
        return localStringBuilder.toString();
      }
      if (i > 0)
        localStringBuilder.append("OR ");
      localStringBuilder.append("_id");
      localStringBuilder.append(" = ? ");
    }
  }

  public int delete(long[] paramArrayOfLong)
  {
    if ((paramArrayOfLong == null) || (paramArrayOfLong.length == 0))
      throw new IllegalArgumentException("input param 'ids' can't be null");
    return getWritableDatabase().delete("downloads", getWhereClauseForIds(paramArrayOfLong), getWhereArgsForIds(paramArrayOfLong));
  }

  public long insert(Download paramDownload)
  {
    long l = getWritableDatabase().insert("downloads", null, generateContentValues(paramDownload));
    paramDownload.mId = l;
    return l;
  }

  public void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    Log.v("lcdownloadsdk", "populating new database");
    createDownloadTable(paramSQLiteDatabase);
  }

  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
  {
  }

  public Cursor queryAll()
  {
    return getReadableDatabase().query("downloads", null, null, null, null, null, null);
  }

  public int update(Download paramDownload)
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase();
    ContentValues localContentValues = generateContentValues(paramDownload);
    String[] arrayOfString = new String[1];
    arrayOfString[0] = Long.toString(paramDownload.mId);
    return localSQLiteDatabase.update("downloads", localContentValues, "_id = ?", arrayOfString);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.download.DownloadDBHelper
 * JD-Core Version:    0.6.2
 */