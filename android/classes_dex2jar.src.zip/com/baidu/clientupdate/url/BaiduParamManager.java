package com.baidu.clientupdate.url;

import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.content.Context;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Build.VERSION;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import com.baidu.android.common.util.CommonParam;
import com.baidu.clientupdate.statistic.UEStatisticReceiver;
import com.baidu.clientupdate.utility.Constants;
import com.baidu.clientupdate.utility.Utility;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public final class BaiduParamManager
{
  private static final boolean DEBUG = false;
  private static final String TAG = "BaiduParamManager";
  private static BaiduParamManager mInstance;
  private ActivityManager mActivityManager;
  private String mAppsearchMd5;
  private boolean mAuto = false;
  private String mCfrom;
  private Context mContext;
  private String mCuid;
  private String mFrom;
  private String mIgnore;
  private String mLogServer;
  private String mNetwork;
  private String mOsBranch;
  private String mOsName;
  private String mPkgname;
  private String mServerUrl;
  private IntentFilter mStatisticFileter;
  private UEStatisticReceiver mStatisticReceiver;
  private String mTime;
  private String mTypeId;
  private String mUa;
  private String mUrl;
  private String mUserMd5;
  private String mUt;
  private String mUtm;
  private String mVersionCode;
  private String mVersionName;

  private BaiduParamManager(Context paramContext)
  {
    this.mContext = paramContext.getApplicationContext();
    init();
  }

  private String getAvaialbeMemorySize()
  {
    ActivityManager.MemoryInfo localMemoryInfo = new ActivityManager.MemoryInfo();
    this.mActivityManager.getMemoryInfo(localMemoryInfo);
    if (DEBUG)
      Log.d("BaiduParamManager", "Avaialbe memory: " + localMemoryInfo.availMem);
    return Long.toHexString(localMemoryInfo.availMem);
  }

  public static BaiduParamManager getInstance(Context paramContext)
  {
    try
    {
      if (mInstance == null)
        mInstance = new BaiduParamManager(paramContext);
      BaiduParamManager localBaiduParamManager = mInstance;
      return localBaiduParamManager;
    }
    finally
    {
    }
  }

  private String getServerAddress()
  {
    String str = "http://lc.ops.baidu.com";
    loadServerProperty();
    if (this.mServerUrl != null)
      str = this.mServerUrl;
    return str;
  }

  private String getTotalMemory()
  {
    while (true)
    {
      int i;
      int j;
      try
      {
        BufferedReader localBufferedReader = new BufferedReader(new FileReader("/proc/meminfo"), 8192);
        String str = localBufferedReader.readLine();
        localBufferedReader.close();
        if (str == null)
          break;
        String[] arrayOfString = str.split("\\s+");
        if (DEBUG)
        {
          i = arrayOfString.length;
          j = 0;
        }
        else
        {
          if (DEBUG)
            Log.d("BaiduParamManager", "Total memory: " + 1024 * Integer.valueOf(arrayOfString[1]).intValue());
          return Long.toHexString(1024 * Integer.valueOf(arrayOfString[1]).intValue());
          Log.i(str, arrayOfString[j] + "\t");
          j++;
        }
      }
      catch (IOException localIOException)
      {
        localIOException.printStackTrace();
        return null;
      }
      if (j < i);
    }
    return null;
  }

  private String getUa(Context paramContext)
  {
    String str;
    if (!TextUtils.isEmpty(this.mUa))
      str = this.mUa;
    do
    {
      return str;
      DisplayMetrics localDisplayMetrics = paramContext.getResources().getDisplayMetrics();
      int i = localDisplayMetrics.widthPixels;
      int j = localDisplayMetrics.heightPixels;
      int k = localDisplayMetrics.densityDpi;
      StringBuffer localStringBuffer = new StringBuffer();
      localStringBuffer.append(i);
      localStringBuffer.append("_");
      localStringBuffer.append(j);
      localStringBuffer.append("_");
      localStringBuffer.append("android");
      localStringBuffer.append("_");
      localStringBuffer.append(this.mVersionName);
      localStringBuffer.append("_");
      localStringBuffer.append(k);
      str = localStringBuffer.toString();
    }
    while (!DEBUG);
    Log.d("BaiduParamManager", "ua = " + str);
    return str;
  }

  private String getUid()
  {
    String str;
    if (!TextUtils.isEmpty(this.mCuid))
      str = this.mCuid;
    do
    {
      return str;
      str = CommonParam.getCUID(this.mContext);
    }
    while (!DEBUG);
    Log.d("BaiduParamManager", "new generated uid " + str);
    return str;
  }

  private String getUt()
  {
    String str1 = Build.MODEL;
    String str2 = Build.VERSION.RELEASE;
    int i = Build.VERSION.SDK_INT;
    String str3 = Build.MANUFACTURER;
    String str4 = str1.replace("_", "-") + "_" + str2.replace("_", "-") + "_" + i + "_" + str3.replace("_", "-");
    if (DEBUG)
      Log.d("BaiduParamManager", "get ut : " + str4);
    return str4;
  }

  private String getUtmParam()
  {
    String str = getTotalMemory();
    if (str == null)
      return null;
    StringBuilder localStringBuilder = new StringBuilder(str);
    localStringBuilder.append("_");
    localStringBuilder.append(getAvaialbeMemorySize());
    return localStringBuilder.reverse().toString();
  }

  private String getWifiOr2gOr3G(Context paramContext)
  {
    String str = "";
    NetworkInfo localNetworkInfo;
    if (paramContext != null)
    {
      localNetworkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
      if ((localNetworkInfo != null) && (localNetworkInfo.isConnectedOrConnecting()))
      {
        if (!localNetworkInfo.getTypeName().toLowerCase().equals("wifi"))
          break label55;
        str = "WF";
      }
    }
    return str;
    label55: str = "2G";
    switch (localNetworkInfo.getSubtype())
    {
    case 1:
    case 2:
    case 4:
    case 11:
    default:
      return str;
    case 3:
      return "3G";
    case 7:
      return "3G";
    case 5:
      return "3G";
    case 6:
      return "3G";
    case 8:
      return "3G";
    case 10:
      return "3G";
    case 9:
      return "3G";
    case 14:
      return "3G";
    case 12:
      return "3G";
    case 15:
      return "3G";
    case 13:
    }
    return "4G";
  }

  private void init()
  {
    this.mPkgname = this.mContext.getPackageName();
    this.mActivityManager = ((ActivityManager)this.mContext.getSystemService("activity"));
    try
    {
      PackageInfo localPackageInfo = this.mContext.getPackageManager().getPackageInfo(this.mPkgname, 64);
      this.mVersionName = localPackageInfo.versionName;
      this.mVersionCode = String.valueOf(localPackageInfo.versionCode);
      this.mCuid = getUid();
      this.mUt = getUt();
      this.mUa = getUa(this.mContext);
      this.mUrl = (getServerAddress() + "/lcmanage/index.php?r=InterfaceAction&method=upgrade&contype=client&clientv=2.0");
      this.mStatisticReceiver = new UEStatisticReceiver();
      this.mStatisticFileter = new IntentFilter();
      this.mStatisticFileter.addAction("android.intent.action.TIME_SET");
      this.mStatisticFileter.addAction("com.baidu.appsearch.action.CHECKSENDSTATISTICDATA");
      this.mContext.registerReceiver(this.mStatisticReceiver, this.mStatisticFileter);
      return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      while (true)
        localNameNotFoundException.printStackTrace();
    }
  }

  // ERROR //
  private void loadServerProperty()
  {
    // Byte code:
    //   0: new 389	java/io/File
    //   3: dup
    //   4: invokestatic 395	android/os/Environment:getExternalStorageDirectory	()Ljava/io/File;
    //   7: ldc_w 397
    //   10: invokespecial 400	java/io/File:<init>	(Ljava/io/File;Ljava/lang/String;)V
    //   13: astore_1
    //   14: aload_1
    //   15: invokevirtual 403	java/io/File:exists	()Z
    //   18: ifeq +279 -> 297
    //   21: new 405	java/util/Properties
    //   24: dup
    //   25: invokespecial 406	java/util/Properties:<init>	()V
    //   28: astore_2
    //   29: aconst_null
    //   30: astore_3
    //   31: new 408	java/io/FileInputStream
    //   34: dup
    //   35: aload_1
    //   36: invokespecial 411	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   39: astore 4
    //   41: aload_2
    //   42: aload 4
    //   44: invokevirtual 415	java/util/Properties:load	(Ljava/io/InputStream;)V
    //   47: aload_2
    //   48: ldc_w 417
    //   51: invokevirtual 421	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   54: ifnull +17 -> 71
    //   57: aload_0
    //   58: aload_2
    //   59: ldc_w 417
    //   62: invokevirtual 421	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   65: invokestatic 168	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   68: putfield 123	com/baidu/clientupdate/url/BaiduParamManager:mServerUrl	Ljava/lang/String;
    //   71: aload_2
    //   72: ldc_w 423
    //   75: invokevirtual 421	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   78: ifnull +17 -> 95
    //   81: aload_0
    //   82: aload_2
    //   83: ldc_w 423
    //   86: invokevirtual 421	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   89: invokestatic 168	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   92: putfield 425	com/baidu/clientupdate/url/BaiduParamManager:mLogServer	Ljava/lang/String;
    //   95: aload_2
    //   96: ldc_w 427
    //   99: invokevirtual 421	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   102: ifnull +37 -> 139
    //   105: ldc2_w 428
    //   108: aload_2
    //   109: ldc_w 427
    //   112: invokevirtual 421	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   115: invokestatic 168	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   118: invokestatic 432	java/lang/Long:valueOf	(Ljava/lang/String;)Ljava/lang/Long;
    //   121: invokevirtual 436	java/lang/Long:longValue	()J
    //   124: lmul
    //   125: lstore 13
    //   127: aload_0
    //   128: getfield 63	com/baidu/clientupdate/url/BaiduParamManager:mContext	Landroid/content/Context;
    //   131: invokestatic 441	com/baidu/clientupdate/statistic/StatisticFile:getInstance	(Landroid/content/Context;)Lcom/baidu/clientupdate/statistic/StatisticFile;
    //   134: lload 13
    //   136: invokevirtual 445	com/baidu/clientupdate/statistic/StatisticFile:setStatisticTimeup	(J)V
    //   139: getstatic 49	com/baidu/clientupdate/url/BaiduParamManager:DEBUG	Z
    //   142: ifeq +29 -> 171
    //   145: ldc 11
    //   147: new 81	java/lang/StringBuilder
    //   150: dup
    //   151: ldc_w 447
    //   154: invokespecial 86	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   157: aload_0
    //   158: getfield 123	com/baidu/clientupdate/url/BaiduParamManager:mServerUrl	Ljava/lang/String;
    //   161: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: invokevirtual 97	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   167: invokestatic 103	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   170: pop
    //   171: getstatic 49	com/baidu/clientupdate/url/BaiduParamManager:DEBUG	Z
    //   174: ifeq +29 -> 203
    //   177: ldc 11
    //   179: new 81	java/lang/StringBuilder
    //   182: dup
    //   183: ldc_w 449
    //   186: invokespecial 86	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   189: aload_0
    //   190: getfield 425	com/baidu/clientupdate/url/BaiduParamManager:mLogServer	Ljava/lang/String;
    //   193: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   196: invokevirtual 97	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   199: invokestatic 103	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   202: pop
    //   203: aload 4
    //   205: ifnull +124 -> 329
    //   208: aload 4
    //   210: invokevirtual 450	java/io/FileInputStream:close	()V
    //   213: return
    //   214: astore 5
    //   216: getstatic 49	com/baidu/clientupdate/url/BaiduParamManager:DEBUG	Z
    //   219: ifeq +30 -> 249
    //   222: ldc 11
    //   224: new 81	java/lang/StringBuilder
    //   227: dup
    //   228: ldc_w 452
    //   231: invokespecial 86	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   234: aload 5
    //   236: invokevirtual 455	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   239: invokevirtual 173	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: invokevirtual 97	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   245: invokestatic 458	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   248: pop
    //   249: aload_3
    //   250: ifnull -37 -> 213
    //   253: aload_3
    //   254: invokevirtual 450	java/io/FileInputStream:close	()V
    //   257: return
    //   258: astore 8
    //   260: aload 8
    //   262: invokevirtual 179	java/io/IOException:printStackTrace	()V
    //   265: return
    //   266: astore 6
    //   268: aload_3
    //   269: ifnull +7 -> 276
    //   272: aload_3
    //   273: invokevirtual 450	java/io/FileInputStream:close	()V
    //   276: aload 6
    //   278: athrow
    //   279: astore 7
    //   281: aload 7
    //   283: invokevirtual 179	java/io/IOException:printStackTrace	()V
    //   286: goto -10 -> 276
    //   289: astore 10
    //   291: aload 10
    //   293: invokevirtual 179	java/io/IOException:printStackTrace	()V
    //   296: return
    //   297: getstatic 49	com/baidu/clientupdate/url/BaiduParamManager:DEBUG	Z
    //   300: ifeq -87 -> 213
    //   303: ldc 11
    //   305: ldc_w 460
    //   308: invokestatic 103	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
    //   311: pop
    //   312: return
    //   313: astore 6
    //   315: aload 4
    //   317: astore_3
    //   318: goto -50 -> 268
    //   321: astore 5
    //   323: aload 4
    //   325: astore_3
    //   326: goto -110 -> 216
    //   329: return
    //
    // Exception table:
    //   from	to	target	type
    //   31	41	214	java/lang/Exception
    //   253	257	258	java/io/IOException
    //   31	41	266	finally
    //   216	249	266	finally
    //   272	276	279	java/io/IOException
    //   208	213	289	java/io/IOException
    //   41	71	313	finally
    //   71	95	313	finally
    //   95	139	313	finally
    //   139	171	313	finally
    //   171	203	313	finally
    //   41	71	321	java/lang/Exception
    //   71	95	321	java/lang/Exception
    //   95	139	321	java/lang/Exception
    //   139	171	321	java/lang/Exception
    //   171	203	321	java/lang/Exception
  }

  public String getLogServerAddress()
  {
    String str = "http://m.baidu.com";
    if (this.mLogServer != null)
      str = this.mLogServer;
    return str;
  }

  public String processUrl()
  {
    ClientUpdateUriHelper localClientUpdateUriHelper = new ClientUpdateUriHelper(this.mUrl);
    localClientUpdateUriHelper.addParamToUrl("versioncode", this.mVersionCode);
    localClientUpdateUriHelper.addParamToUrl("versionname", this.mVersionName);
    localClientUpdateUriHelper.addParamToUrl("pkgname", this.mPkgname);
    localClientUpdateUriHelper.addParamToUrl("cuid", this.mCuid);
    localClientUpdateUriHelper.addParamToUrl("ua", this.mUa);
    localClientUpdateUriHelper.addParamToUrl("ut", this.mUt);
    localClientUpdateUriHelper.addParamToUrl("auto", String.valueOf(this.mAuto));
    this.mNetwork = getWifiOr2gOr3G(this.mContext);
    localClientUpdateUriHelper.addParamToUrl("network", this.mNetwork);
    this.mUtm = getUtmParam();
    if (this.mUtm != null)
      localClientUpdateUriHelper.addParamToUrl("utm", this.mUtm);
    localClientUpdateUriHelper.addParamToUrl("osname", this.mOsName);
    localClientUpdateUriHelper.addParamToUrl("typeid", this.mTypeId);
    localClientUpdateUriHelper.addParamToUrl("from", this.mFrom);
    localClientUpdateUriHelper.addParamToUrl("osbranch", this.mOsBranch);
    localClientUpdateUriHelper.addParamToUrl("cfrom", this.mCfrom);
    localClientUpdateUriHelper.addParamToUrl("ignore", this.mIgnore);
    localClientUpdateUriHelper.addParamToUrl("time", this.mTime);
    if (this.mAuto)
      localClientUpdateUriHelper.addParamToUrl("auto", "true");
    while (true)
    {
      this.mUserMd5 = Utility.getApkmd5(this.mContext, this.mPkgname);
      if (!TextUtils.isEmpty(this.mUserMd5))
        localClientUpdateUriHelper.addParamToUrl("usermd5", this.mUserMd5);
      this.mAppsearchMd5 = Utility.getApkmd5(this.mContext, "com.baidu.appsearch");
      if (!TextUtils.isEmpty(this.mAppsearchMd5))
        localClientUpdateUriHelper.addParamToUrl("appsearchmd5", this.mAppsearchMd5);
      return localClientUpdateUriHelper.toString();
      localClientUpdateUriHelper.addParamToUrl("auto", "false");
    }
  }

  public void setAuto(boolean paramBoolean)
  {
    this.mAuto = paramBoolean;
  }

  public void setCfrom(String paramString)
  {
    this.mCfrom = paramString;
  }

  public void setFrom(String paramString)
  {
    this.mFrom = paramString;
  }

  public void setIgnore(String paramString)
  {
    this.mIgnore = paramString;
  }

  public void setOsBranch(String paramString)
  {
    this.mOsBranch = paramString;
  }

  public void setOsName(String paramString)
  {
    this.mOsName = paramString;
  }

  public void setTime(String paramString)
  {
    this.mTime = paramString;
  }

  public void setTypeId(String paramString)
  {
    this.mTypeId = paramString;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.url.BaiduParamManager
 * JD-Core Version:    0.6.2
 */