package com.baidu.clientupdate.url;

import android.text.TextUtils;
import android.util.Log;
import com.baidu.clientupdate.utility.Constants;
import com.baidu.util.Base64Encoder;
import java.net.URLEncoder;

class ClientUpdateUriHelper
{
  private static final boolean DEBUG = false;
  private static final String TAG = "ClientUpdateUriHelper";
  private StringBuilder mStringBuilder;

  public ClientUpdateUriHelper(String paramString)
  {
    this.mStringBuilder = new StringBuilder(paramString);
  }

  protected void addParamToUrl(String paramString1, String paramString2)
  {
    if (!TextUtils.isEmpty(paramString2))
    {
      if (DEBUG)
        Log.d("ClientUpdateUriHelper", "key: " + paramString1 + ", value: " + paramString2);
      this.mStringBuilder.append("&" + paramString1 + "=");
      byte[] arrayOfByte = Base64Encoder.B64Encode(URLEncoder.encode(paramString2).getBytes());
      this.mStringBuilder.append(new String(arrayOfByte));
      if (DEBUG)
        Log.d("ClientUpdateUriHelper", "b64encode key: " + paramString1 + ", value: " + new String(arrayOfByte));
    }
  }

  public String toString()
  {
    if (DEBUG)
      Log.d("ClientUpdateUriHelper", "url: " + this.mStringBuilder.toString());
    return this.mStringBuilder.toString();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.url.ClientUpdateUriHelper
 * JD-Core Version:    0.6.2
 */