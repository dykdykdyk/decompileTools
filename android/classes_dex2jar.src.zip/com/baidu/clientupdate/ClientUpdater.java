package com.baidu.clientupdate;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.util.Log;
import com.baidu.clientupdate.appinfo.ClientUpdateInfo;
import com.baidu.clientupdate.appinfo.RecommandAppInfo;
import com.baidu.clientupdate.url.BaiduParamManager;
import com.baidu.clientupdate.utility.ClientUpdateUtility;
import com.baidu.clientupdate.utility.Constants;
import com.baidu.clientupdate.utility.Utility;
import org.json.JSONException;
import org.json.JSONObject;

public final class ClientUpdater
{
  private static final boolean DEBUG = false;
  private static final long DELAYTIME = 20000L;
  private static final String TAG = "ClientUpdater";
  private static Runnable mClientUpdateRunnable = null;
  private static ClientUpdater mClientUpdater = null;
  private Boolean isRegisterReceiver = Boolean.valueOf(false);
  private boolean mAppLaunched = false;
  private BaiduParamManager mBaiduParamManager;
  private Context mContext;
  private IClientUpdaterCallback mForceIClientUpdaterCallback;
  private Handler mHandler;
  private IClientUpdaterCallback mIClientUpdaterCallback;
  private IntentFilter mIntentFilter;
  private double mIntervalHour;
  private boolean mIsAutoUpdate = false;
  private BroadcastReceiver mUpdateReceiver;
  private String mUrl;

  private ClientUpdater(Context paramContext)
  {
    this.mContext = paramContext;
    if (this.mHandler == null)
      this.mHandler = new Handler(this.mContext.getMainLooper());
    if (mClientUpdateRunnable == null)
      mClientUpdateRunnable = new Runnable()
      {
        public void run()
        {
          if (ClientUpdater.DEBUG)
            Log.d("ClientUpdater", "background Check ClientUpdate!");
          ClientUpdater.this.doAutoUpdate();
        }
      };
    this.mUpdateReceiver = new BroadcastReceiver()
    {
      public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
      {
        if (ClientUpdater.DEBUG)
          Log.e("ClientUpdater", "receive:android.net.conn.CONNECTIVITY_CHANGE");
        ClientUpdater.this.scheduleClientUpdate();
      }
    };
    this.mIntentFilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
    this.mBaiduParamManager = BaiduParamManager.getInstance(paramContext);
  }

  private void doAutoUpdate()
  {
    this.mIsAutoUpdate = true;
    long l = System.currentTimeMillis();
    if (DEBUG)
    {
      Log.d("ClientUpdater", "接收到网络状态的变化，检测上次更新时间");
      Log.d("ClientUpdater", "设置的检查更新的间隔时间： " + ()(3600000.0D * this.mIntervalHour) + "ms");
    }
    if (DEBUG)
    {
      Log.d("ClientUpdater", "当前时间：" + l);
      Log.d("ClientUpdater", "上次检查更新时间： " + Utility.getClientUpdateTimeLast(this.mContext));
    }
    if (l - Utility.getClientUpdateTimeLast(this.mContext) > ()(3600000.0D * this.mIntervalHour))
    {
      if (DEBUG)
        Log.d("ClientUpdater", "大于设置的时间间隔，当前存在网络连接时进行更新检查 ");
      if (!Utility.isNetWorkEnabled(this.mContext))
      {
        localStringBuilder = new StringBuilder("当前网络不可用!");
        localJSONObject = new JSONObject();
      }
    }
    while (!DEBUG)
    {
      try
      {
        StringBuilder localStringBuilder;
        JSONObject localJSONObject;
        localJSONObject.put("msgId", "2");
        localJSONObject.put("messageDetail", localStringBuilder.toString());
        this.mIClientUpdaterCallback.onError(localJSONObject);
        if (DEBUG)
          Log.d("ClientUpdater", "当前网络不可用! ");
        return;
      }
      catch (JSONException localJSONException)
      {
        while (true)
          localJSONException.printStackTrace();
      }
      new ClientUpdaterWorker().start();
      return;
    }
    Log.d("ClientUpdater", "离上一次更新检查的时间小于设置的时间间隔，不检查更新 ");
  }

  public static ClientUpdater getInstance(Context paramContext)
  {
    try
    {
      if (mClientUpdater == null)
        mClientUpdater = new ClientUpdater(paramContext);
      ClientUpdater localClientUpdater = mClientUpdater;
      return localClientUpdater;
    }
    finally
    {
    }
  }

  private void scheduleClientUpdate()
  {
    if (this.mHandler == null);
    do
    {
      do
      {
        return;
        if (!Utility.isAppForground(this.mContext))
          break;
      }
      while (!DEBUG);
      Log.d("ClientUpdater", "应用位于前台，不发起自动检查更新请求;");
      return;
    }
    while (!Utility.isNetWorkEnabled(this.mContext));
    this.mHandler.removeCallbacks(mClientUpdateRunnable);
    if (DEBUG)
      Log.d("ClientUpdater", "延迟20秒，因为有时CONNECTIVITY_CHANGE Action会很频繁");
    this.mHandler.postDelayed(mClientUpdateRunnable, 20000L);
  }

  public void appLaunchedCheckUpdate(IClientUpdaterCallback paramIClientUpdaterCallback)
  {
    this.mAppLaunched = true;
    checkUpdate(paramIClientUpdaterCallback);
  }

  public void cancelAutoCheckUpdate()
  {
    this.mIsAutoUpdate = false;
    if (this.isRegisterReceiver.booleanValue())
      this.mContext.unregisterReceiver(this.mUpdateReceiver);
    this.isRegisterReceiver = Boolean.valueOf(false);
  }

  public void checkUpdate(double paramDouble, IClientUpdaterCallback paramIClientUpdaterCallback)
  {
    if ((paramDouble > 0.0D) && (paramIClientUpdaterCallback != null))
    {
      this.mIClientUpdaterCallback = paramIClientUpdaterCallback;
      this.mIntervalHour = paramDouble;
      if (!Utility.checkCallingPermission(this.mContext))
      {
        localStringBuilder = new StringBuilder("请加入权限：ACCESS_NETWORK_STATE、INTERNET、GET_TASKS");
        localJSONObject = new JSONObject();
      }
    }
    while (!DEBUG)
    {
      try
      {
        StringBuilder localStringBuilder;
        JSONObject localJSONObject;
        localJSONObject.put("msgId", "1");
        localJSONObject.put("messageDetail", localStringBuilder.toString());
        this.mIClientUpdaterCallback.onError(localJSONObject);
        return;
      }
      catch (JSONException localJSONException)
      {
        while (true)
          localJSONException.printStackTrace();
      }
      this.mContext.registerReceiver(this.mUpdateReceiver, this.mIntentFilter);
      this.isRegisterReceiver = Boolean.valueOf(true);
      return;
    }
    Log.e("ClientUpdater", "intervalHour < 0 或者 clientUpdaterCallback为null或者JSONObject为null");
  }

  public void checkUpdate(IClientUpdaterCallback paramIClientUpdaterCallback)
  {
    if (paramIClientUpdaterCallback != null)
    {
      this.mForceIClientUpdaterCallback = paramIClientUpdaterCallback;
      if (!Utility.checkCallingPermission(this.mContext))
      {
        localStringBuilder1 = new StringBuilder("请加入权限：ACCESS_NETWORK_STATE、INTERNET、GET_TASKS");
        localJSONObject1 = new JSONObject();
      }
    }
    while (!DEBUG)
    {
      while (true)
      {
        try
        {
          StringBuilder localStringBuilder1;
          JSONObject localJSONObject1;
          localJSONObject1.put("msgId", "1");
          localJSONObject1.put("messageDetail", localStringBuilder1.toString());
          if (this.mForceIClientUpdaterCallback != null)
            this.mForceIClientUpdaterCallback.onError(localJSONObject1);
          return;
        }
        catch (JSONException localJSONException1)
        {
          localJSONException1.printStackTrace();
          continue;
        }
        if (!Utility.isNetWorkEnabled(this.mContext))
        {
          StringBuilder localStringBuilder2 = new StringBuilder("当前网络不可用!");
          JSONObject localJSONObject2 = new JSONObject();
          try
          {
            localJSONObject2.put("msgId", "2");
            localJSONObject2.put("messageDetail", localStringBuilder2.toString());
            if (this.mForceIClientUpdaterCallback != null)
            {
              this.mForceIClientUpdaterCallback.onError(localJSONObject2);
              return;
            }
          }
          catch (JSONException localJSONException2)
          {
            while (true)
              localJSONException2.printStackTrace();
          }
        }
      }
      this.mIsAutoUpdate = false;
      new ClientUpdaterWorker().start();
      return;
    }
    Log.e("ClientUpdater", " clientUpdaterCallback为null或者JSONObject为null");
  }

  public void setCfrom(String paramString)
  {
    this.mBaiduParamManager.setCfrom(paramString);
  }

  public void setContext(Context paramContext)
  {
    this.mContext = paramContext;
  }

  public void setFrom(String paramString)
  {
    this.mBaiduParamManager.setFrom(paramString);
  }

  public void setIgnore(String paramString)
  {
    this.mBaiduParamManager.setIgnore(paramString);
  }

  public void setOsBranch(String paramString)
  {
    this.mBaiduParamManager.setOsBranch(paramString);
  }

  public void setOsName(String paramString)
  {
    this.mBaiduParamManager.setOsName(paramString);
  }

  public void setTime(String paramString)
  {
    this.mBaiduParamManager.setTime(paramString);
  }

  public void setTypeId(String paramString)
  {
    this.mBaiduParamManager.setTypeId(paramString);
  }

  public void startDownload(ClientUpdateInfo paramClientUpdateInfo, RecommandAppInfo paramRecommandAppInfo, String paramString)
  {
    ClientUpdateUtility.getInstance(this.mContext).startDownload(paramClientUpdateInfo, paramRecommandAppInfo, paramString);
  }

  public void startPatchDownload(ClientUpdateInfo paramClientUpdateInfo, RecommandAppInfo paramRecommandAppInfo, String paramString)
  {
    ClientUpdateUtility.getInstance(this.mContext).startPatchDownload(paramClientUpdateInfo, paramRecommandAppInfo, paramString);
  }

  private class ClientUpdaterWorker extends Thread
  {
    public ClientUpdaterWorker()
    {
      setName("SDK_ClientUpdater_thread");
    }

    // ERROR //
    public void run()
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   4: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   7: invokestatic 36	com/baidu/clientupdate/statistic/StatisticFile:getInstance	(Landroid/content/Context;)Lcom/baidu/clientupdate/statistic/StatisticFile;
      //   10: astore_1
      //   11: aload_1
      //   12: invokevirtual 40	com/baidu/clientupdate/statistic/StatisticFile:containLastSendStatisticTime	()Z
      //   15: ifne +32 -> 47
      //   18: aload_1
      //   19: aload_0
      //   20: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   23: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   26: invokestatic 46	java/lang/System:currentTimeMillis	()J
      //   29: invokevirtual 50	com/baidu/clientupdate/statistic/StatisticFile:setLastSendStatisticTime	(Landroid/content/Context;J)V
      //   32: aload_0
      //   33: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   36: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   39: invokestatic 55	com/baidu/clientupdate/statistic/StatisticPoster:getInstance	(Landroid/content/Context;)Lcom/baidu/clientupdate/statistic/StatisticPoster;
      //   42: ldc 57
      //   44: invokevirtual 60	com/baidu/clientupdate/statistic/StatisticPoster:checkSendStatisticData	(Ljava/lang/String;)V
      //   47: new 62	com/baidu/android/common/net/ProxyHttpClient
      //   50: dup
      //   51: aload_0
      //   52: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   55: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   58: invokespecial 65	com/baidu/android/common/net/ProxyHttpClient:<init>	(Landroid/content/Context;)V
      //   61: astore_2
      //   62: aload_0
      //   63: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   66: invokestatic 69	com/baidu/clientupdate/ClientUpdater:access$1	(Lcom/baidu/clientupdate/ClientUpdater;)Z
      //   69: ifne +13 -> 82
      //   72: aload_0
      //   73: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   76: invokestatic 72	com/baidu/clientupdate/ClientUpdater:access$2	(Lcom/baidu/clientupdate/ClientUpdater;)Z
      //   79: ifeq +299 -> 378
      //   82: aload_0
      //   83: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   86: invokestatic 76	com/baidu/clientupdate/ClientUpdater:access$3	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/url/BaiduParamManager;
      //   89: iconst_1
      //   90: invokevirtual 82	com/baidu/clientupdate/url/BaiduParamManager:setAuto	(Z)V
      //   93: aload_0
      //   94: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   97: iconst_0
      //   98: invokestatic 86	com/baidu/clientupdate/ClientUpdater:access$4	(Lcom/baidu/clientupdate/ClientUpdater;Z)V
      //   101: aload_0
      //   102: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   105: aload_0
      //   106: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   109: invokestatic 76	com/baidu/clientupdate/ClientUpdater:access$3	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/url/BaiduParamManager;
      //   112: invokevirtual 90	com/baidu/clientupdate/url/BaiduParamManager:processUrl	()Ljava/lang/String;
      //   115: invokestatic 94	com/baidu/clientupdate/ClientUpdater:access$5	(Lcom/baidu/clientupdate/ClientUpdater;Ljava/lang/String;)V
      //   118: invokestatic 97	com/baidu/clientupdate/ClientUpdater:access$6	()Z
      //   121: ifeq +31 -> 152
      //   124: ldc 57
      //   126: new 99	java/lang/StringBuilder
      //   129: dup
      //   130: ldc 101
      //   132: invokespecial 103	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   135: aload_0
      //   136: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   139: invokestatic 107	com/baidu/clientupdate/ClientUpdater:access$7	(Lcom/baidu/clientupdate/ClientUpdater;)Ljava/lang/String;
      //   142: invokevirtual 111	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   145: invokevirtual 114	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   148: invokestatic 120	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   151: pop
      //   152: new 122	org/apache/http/client/methods/HttpGet
      //   155: dup
      //   156: aload_0
      //   157: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   160: invokestatic 107	com/baidu/clientupdate/ClientUpdater:access$7	(Lcom/baidu/clientupdate/ClientUpdater;)Ljava/lang/String;
      //   163: invokespecial 123	org/apache/http/client/methods/HttpGet:<init>	(Ljava/lang/String;)V
      //   166: astore_3
      //   167: aload_2
      //   168: aload_3
      //   169: invokevirtual 127	com/baidu/android/common/net/ProxyHttpClient:execute	(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
      //   172: astore 13
      //   174: aload 13
      //   176: invokeinterface 133 1 0
      //   181: invokeinterface 139 1 0
      //   186: sipush 200
      //   189: if_icmpne +364 -> 553
      //   192: aload_0
      //   193: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   196: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   199: invokestatic 46	java/lang/System:currentTimeMillis	()J
      //   202: invokestatic 144	com/baidu/clientupdate/utility/Utility:setClientUpdateTime	(Landroid/content/Context;J)V
      //   205: invokestatic 97	com/baidu/clientupdate/ClientUpdater:access$6	()Z
      //   208: ifeq +38 -> 246
      //   211: aload_0
      //   212: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   215: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   218: invokestatic 148	com/baidu/clientupdate/utility/Utility:getClientUpdateTimeLast	(Landroid/content/Context;)J
      //   221: lstore 24
      //   223: ldc 57
      //   225: new 99	java/lang/StringBuilder
      //   228: dup
      //   229: ldc 150
      //   231: invokespecial 103	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   234: lload 24
      //   236: invokevirtual 153	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
      //   239: invokevirtual 114	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   242: invokestatic 120	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   245: pop
      //   246: aload_0
      //   247: invokevirtual 156	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:isInterrupted	()Z
      //   250: ifne +101 -> 351
      //   253: aload 13
      //   255: invokeinterface 160 1 0
      //   260: invokestatic 165	org/apache/http/util/EntityUtils:toString	(Lorg/apache/http/HttpEntity;)Ljava/lang/String;
      //   263: astore 21
      //   265: invokestatic 97	com/baidu/clientupdate/ClientUpdater:access$6	()Z
      //   268: ifeq +26 -> 294
      //   271: ldc 57
      //   273: new 99	java/lang/StringBuilder
      //   276: dup
      //   277: ldc 167
      //   279: invokespecial 103	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   282: aload 21
      //   284: invokevirtual 111	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   287: invokevirtual 114	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   290: invokestatic 120	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   293: pop
      //   294: new 169	org/json/JSONObject
      //   297: dup
      //   298: aload 21
      //   300: invokespecial 170	org/json/JSONObject:<init>	(Ljava/lang/String;)V
      //   303: astore 22
      //   305: aload_0
      //   306: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   309: invokestatic 69	com/baidu/clientupdate/ClientUpdater:access$1	(Lcom/baidu/clientupdate/ClientUpdater;)Z
      //   312: ifeq +80 -> 392
      //   315: aload_0
      //   316: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   319: invokestatic 174	com/baidu/clientupdate/ClientUpdater:access$9	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   322: aload 22
      //   324: invokeinterface 180 2 0
      //   329: aload_0
      //   330: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   333: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   336: invokestatic 185	com/baidu/clientupdate/utility/ClientUpdateUtility:getInstance	(Landroid/content/Context;)Lcom/baidu/clientupdate/utility/ClientUpdateUtility;
      //   339: aload 22
      //   341: aload_0
      //   342: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   345: invokestatic 174	com/baidu/clientupdate/ClientUpdater:access$9	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   348: invokevirtual 189	com/baidu/clientupdate/utility/ClientUpdateUtility:parseResult	(Lorg/json/JSONObject;Lcom/baidu/clientupdate/IClientUpdaterCallback;)V
      //   351: invokestatic 97	com/baidu/clientupdate/ClientUpdater:access$6	()Z
      //   354: ifeq +11 -> 365
      //   357: ldc 57
      //   359: ldc 191
      //   361: invokestatic 120	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   364: pop
      //   365: aload_2
      //   366: invokevirtual 194	com/baidu/android/common/net/ProxyHttpClient:close	()V
      //   369: aload_0
      //   370: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   373: aconst_null
      //   374: invokestatic 198	com/baidu/clientupdate/ClientUpdater:access$8	(Lcom/baidu/clientupdate/ClientUpdater;Lcom/baidu/clientupdate/IClientUpdaterCallback;)V
      //   377: return
      //   378: aload_0
      //   379: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   382: invokestatic 76	com/baidu/clientupdate/ClientUpdater:access$3	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/url/BaiduParamManager;
      //   385: iconst_0
      //   386: invokevirtual 82	com/baidu/clientupdate/url/BaiduParamManager:setAuto	(Z)V
      //   389: goto -296 -> 93
      //   392: aload_0
      //   393: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   396: invokestatic 201	com/baidu/clientupdate/ClientUpdater:access$10	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   399: ifnull -48 -> 351
      //   402: aload_0
      //   403: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   406: invokestatic 201	com/baidu/clientupdate/ClientUpdater:access$10	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   409: aload 22
      //   411: invokeinterface 180 2 0
      //   416: aload_0
      //   417: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   420: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   423: invokestatic 185	com/baidu/clientupdate/utility/ClientUpdateUtility:getInstance	(Landroid/content/Context;)Lcom/baidu/clientupdate/utility/ClientUpdateUtility;
      //   426: aload 22
      //   428: aload_0
      //   429: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   432: invokestatic 201	com/baidu/clientupdate/ClientUpdater:access$10	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   435: invokevirtual 189	com/baidu/clientupdate/utility/ClientUpdateUtility:parseResult	(Lorg/json/JSONObject;Lcom/baidu/clientupdate/IClientUpdaterCallback;)V
      //   438: goto -87 -> 351
      //   441: astore 6
      //   443: invokestatic 97	com/baidu/clientupdate/ClientUpdater:access$6	()Z
      //   446: ifeq +11 -> 457
      //   449: ldc 57
      //   451: aload 6
      //   453: invokestatic 205	android/util/Log:w	(Ljava/lang/String;Ljava/lang/Throwable;)I
      //   456: pop
      //   457: new 169	org/json/JSONObject
      //   460: dup
      //   461: invokespecial 206	org/json/JSONObject:<init>	()V
      //   464: astore 7
      //   466: aload 7
      //   468: ldc 208
      //   470: ldc 210
      //   472: invokevirtual 214	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   475: pop
      //   476: aload 7
      //   478: ldc 216
      //   480: aload 6
      //   482: invokevirtual 217	java/lang/Exception:toString	()Ljava/lang/String;
      //   485: invokevirtual 214	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   488: pop
      //   489: aload_0
      //   490: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   493: invokestatic 69	com/baidu/clientupdate/ClientUpdater:access$1	(Lcom/baidu/clientupdate/ClientUpdater;)Z
      //   496: ifeq +245 -> 741
      //   499: aload_0
      //   500: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   503: invokestatic 174	com/baidu/clientupdate/ClientUpdater:access$9	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   506: aload 7
      //   508: invokeinterface 220 2 0
      //   513: aload_0
      //   514: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   517: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   520: invokestatic 185	com/baidu/clientupdate/utility/ClientUpdateUtility:getInstance	(Landroid/content/Context;)Lcom/baidu/clientupdate/utility/ClientUpdateUtility;
      //   523: invokevirtual 223	com/baidu/clientupdate/utility/ClientUpdateUtility:clearLastResult	()V
      //   526: invokestatic 97	com/baidu/clientupdate/ClientUpdater:access$6	()Z
      //   529: ifeq +11 -> 540
      //   532: ldc 57
      //   534: ldc 191
      //   536: invokestatic 120	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   539: pop
      //   540: aload_2
      //   541: invokevirtual 194	com/baidu/android/common/net/ProxyHttpClient:close	()V
      //   544: aload_0
      //   545: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   548: aconst_null
      //   549: invokestatic 198	com/baidu/clientupdate/ClientUpdater:access$8	(Lcom/baidu/clientupdate/ClientUpdater;Lcom/baidu/clientupdate/IClientUpdaterCallback;)V
      //   552: return
      //   553: aload 13
      //   555: invokeinterface 133 1 0
      //   560: invokevirtual 226	java/lang/Object:toString	()Ljava/lang/String;
      //   563: astore 14
      //   565: invokestatic 97	com/baidu/clientupdate/ClientUpdater:access$6	()Z
      //   568: ifeq +26 -> 594
      //   571: ldc 57
      //   573: new 99	java/lang/StringBuilder
      //   576: dup
      //   577: ldc 228
      //   579: invokespecial 103	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
      //   582: aload 14
      //   584: invokevirtual 111	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   587: invokevirtual 114	java/lang/StringBuilder:toString	()Ljava/lang/String;
      //   590: invokestatic 120	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   593: pop
      //   594: new 169	org/json/JSONObject
      //   597: dup
      //   598: invokespecial 206	org/json/JSONObject:<init>	()V
      //   601: astore 15
      //   603: aload 15
      //   605: ldc 208
      //   607: ldc 230
      //   609: invokevirtual 214	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   612: pop
      //   613: aload 15
      //   615: ldc 216
      //   617: aload 14
      //   619: invokevirtual 214	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
      //   622: pop
      //   623: aload_0
      //   624: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   627: invokestatic 69	com/baidu/clientupdate/ClientUpdater:access$1	(Lcom/baidu/clientupdate/ClientUpdater;)Z
      //   630: ifeq +74 -> 704
      //   633: aload_0
      //   634: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   637: invokestatic 174	com/baidu/clientupdate/ClientUpdater:access$9	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   640: aload 15
      //   642: invokeinterface 233 2 0
      //   647: aload_0
      //   648: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   651: invokestatic 30	com/baidu/clientupdate/ClientUpdater:access$0	(Lcom/baidu/clientupdate/ClientUpdater;)Landroid/content/Context;
      //   654: invokestatic 185	com/baidu/clientupdate/utility/ClientUpdateUtility:getInstance	(Landroid/content/Context;)Lcom/baidu/clientupdate/utility/ClientUpdateUtility;
      //   657: invokevirtual 223	com/baidu/clientupdate/utility/ClientUpdateUtility:clearLastResult	()V
      //   660: goto -309 -> 351
      //   663: astore 4
      //   665: invokestatic 97	com/baidu/clientupdate/ClientUpdater:access$6	()Z
      //   668: ifeq +11 -> 679
      //   671: ldc 57
      //   673: ldc 191
      //   675: invokestatic 120	android/util/Log:d	(Ljava/lang/String;Ljava/lang/String;)I
      //   678: pop
      //   679: aload_2
      //   680: invokevirtual 194	com/baidu/android/common/net/ProxyHttpClient:close	()V
      //   683: aload_0
      //   684: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   687: aconst_null
      //   688: invokestatic 198	com/baidu/clientupdate/ClientUpdater:access$8	(Lcom/baidu/clientupdate/ClientUpdater;Lcom/baidu/clientupdate/IClientUpdaterCallback;)V
      //   691: aload 4
      //   693: athrow
      //   694: astore 16
      //   696: aload 16
      //   698: invokevirtual 236	org/json/JSONException:printStackTrace	()V
      //   701: goto -78 -> 623
      //   704: aload_0
      //   705: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   708: invokestatic 201	com/baidu/clientupdate/ClientUpdater:access$10	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   711: ifnull -64 -> 647
      //   714: aload_0
      //   715: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   718: invokestatic 201	com/baidu/clientupdate/ClientUpdater:access$10	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   721: aload 15
      //   723: invokeinterface 233 2 0
      //   728: goto -81 -> 647
      //   731: astore 8
      //   733: aload 8
      //   735: invokevirtual 236	org/json/JSONException:printStackTrace	()V
      //   738: goto -249 -> 489
      //   741: aload_0
      //   742: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   745: invokestatic 201	com/baidu/clientupdate/ClientUpdater:access$10	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   748: ifnull -235 -> 513
      //   751: aload_0
      //   752: getfield 10	com/baidu/clientupdate/ClientUpdater$ClientUpdaterWorker:this$0	Lcom/baidu/clientupdate/ClientUpdater;
      //   755: invokestatic 201	com/baidu/clientupdate/ClientUpdater:access$10	(Lcom/baidu/clientupdate/ClientUpdater;)Lcom/baidu/clientupdate/IClientUpdaterCallback;
      //   758: aload 7
      //   760: invokeinterface 220 2 0
      //   765: goto -252 -> 513
      //
      // Exception table:
      //   from	to	target	type
      //   167	246	441	java/lang/Exception
      //   246	294	441	java/lang/Exception
      //   294	351	441	java/lang/Exception
      //   392	438	441	java/lang/Exception
      //   553	594	441	java/lang/Exception
      //   594	603	441	java/lang/Exception
      //   603	623	441	java/lang/Exception
      //   623	647	441	java/lang/Exception
      //   647	660	441	java/lang/Exception
      //   696	701	441	java/lang/Exception
      //   704	728	441	java/lang/Exception
      //   167	246	663	finally
      //   246	294	663	finally
      //   294	351	663	finally
      //   392	438	663	finally
      //   443	457	663	finally
      //   457	466	663	finally
      //   466	489	663	finally
      //   489	513	663	finally
      //   513	526	663	finally
      //   553	594	663	finally
      //   594	603	663	finally
      //   603	623	663	finally
      //   623	647	663	finally
      //   647	660	663	finally
      //   696	701	663	finally
      //   704	728	663	finally
      //   733	738	663	finally
      //   741	765	663	finally
      //   603	623	694	org/json/JSONException
      //   466	489	731	org/json/JSONException
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.ClientUpdater
 * JD-Core Version:    0.6.2
 */