package com.baidu.clientupdate;

import com.baidu.clientupdate.appinfo.AppSearchInfo;
import com.baidu.clientupdate.appinfo.ClientUpdateInfo;
import com.baidu.clientupdate.appinfo.RecommandAppInfo;
import org.json.JSONObject;

public abstract interface IClientUpdaterCallback
{
  public abstract void onCompleted(ClientUpdateInfo paramClientUpdateInfo, RecommandAppInfo paramRecommandAppInfo, AppSearchInfo paramAppSearchInfo);

  public abstract void onError(JSONObject paramJSONObject);

  public abstract void onException(JSONObject paramJSONObject);

  public abstract void onFetched(JSONObject paramJSONObject);
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.clientupdate.IClientUpdaterCallback
 * JD-Core Version:    0.6.2
 */