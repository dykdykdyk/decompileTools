package com.baidu.mobstat;

import com.baidu.mobstat.a.c;

class w
  implements Runnable
{
  w(s params)
  {
  }

  public void run()
  {
    if (!k.a().c())
      synchronized (k.a())
      {
        try
        {
          k.a().wait();
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            c.a("stat", localInterruptedException);
        }
      }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.w
 * JD-Core Version:    0.6.2
 */