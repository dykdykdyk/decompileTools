package com.baidu.mobstat;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.support.v4.app.Fragment;
import com.baidu.mobstat.a.c;
import java.lang.ref.WeakReference;

class x
  implements Runnable
{
  private long b;
  private WeakReference<Context> c;
  private WeakReference<Fragment> d;
  private WeakReference<Object> e;
  private long f;
  private WeakReference<Context> g;
  private WeakReference<Fragment> h;
  private WeakReference<Object> i;
  private int j;
  private String k = null;

  public x(s params, long paramLong1, Context paramContext1, Fragment paramFragment1, long paramLong2, Context paramContext2, Fragment paramFragment2, int paramInt, String paramString, Object paramObject1, Object paramObject2)
  {
    this.b = paramLong1;
    if (paramContext1 != null)
      this.c = new WeakReference(paramContext1);
    this.f = paramLong2;
    if (paramContext2 != null)
      this.g = new WeakReference(paramContext2);
    if (paramFragment1 != null)
      this.d = new WeakReference(paramFragment1);
    if (paramFragment2 != null)
      this.h = new WeakReference(paramFragment2);
    if (paramObject1 != null)
      this.i = new WeakReference(paramObject1);
    if (paramObject2 != null)
      this.e = new WeakReference(paramObject2);
    this.j = paramInt;
    this.k = paramString;
  }

  public void run()
  {
    if (this.j == 1)
      if (this.c.get() != this.g.get())
        if (this.k != null)
          c.c(new Object[] { "stat", "onPageStart() 或 onPageEnd()安放错误  || onPageStart() or onPageEnd() install error." });
    do
    {
      return;
      c.c(new Object[] { "stat", "onPause() 或 onResume()安放错误  ||  onPause() or onResume() install error." });
      return;
      long l3 = this.b - this.f;
      Activity localActivity = (Activity)this.c.get();
      if (localActivity == null)
      {
        c.c(new Object[] { "stat", "onPause,WeakReference is already been released" });
        return;
      }
      StringBuilder localStringBuilder = new StringBuilder();
      if (this.k != null)
        localStringBuilder.append(this.k);
      while (true)
      {
        c.a("stat", "new page view, page name = " + localStringBuilder.toString() + ",stay time = " + l3 + "(ms)");
        s.a(this.a).a(localStringBuilder.toString(), l3, this.f);
        s.a(this.a, (Context)this.c.get(), this.b);
        return;
        localStringBuilder.append(localActivity.getComponentName().getShortClassName());
        if (localStringBuilder.charAt(0) == '.')
          localStringBuilder.deleteCharAt(0);
      }
      if (this.j == 2)
      {
        if (this.d.get() != this.h.get())
        {
          c.c(new Object[] { "stat", " Fragment onPause() 或 onResume()安放错误||onPause() or onResume() install error." });
          return;
        }
        long l2 = this.b - this.f;
        Fragment localFragment = (Fragment)this.d.get();
        if (localFragment == null)
        {
          c.c(new Object[] { "stat", "onPause,WeakReference is already been released" });
          return;
        }
        String str3 = localFragment.getClass().getName().toString();
        String str4 = str3.substring(1 + str3.lastIndexOf("."));
        c.a("stat", "Fragment new page view, page name = " + str3.toString() + ",stay time = " + l2 + "(ms)");
        s.a(this.a).a(str4, l2, this.f);
        s.a(this.a, ((Fragment)this.d.get()).getActivity(), this.b);
        return;
      }
    }
    while (this.j != 3);
    if (this.e.get() != this.i.get())
    {
      c.c(new Object[] { "stat", " Fragment onPause() 或 onResume()安放错误||onPause() or onResume() install error." });
      return;
    }
    long l1 = this.b - this.f;
    Object localObject = this.e.get();
    if (localObject == null)
    {
      c.c(new Object[] { "stat", "onPause,WeakReference is already been released" });
      return;
    }
    Context localContext = s.a(localObject);
    String str1 = localObject.getClass().getName().toString();
    String str2 = str1.substring(1 + str1.lastIndexOf("."));
    c.a("stat", "android.app.Fragment new page view, page name = " + str1.toString() + ",stay time = " + l1 + "(ms)");
    s.a(this.a).a(str2, l1, this.f);
    s.a(this.a, localContext, this.b);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.x
 * JD-Core Version:    0.6.2
 */