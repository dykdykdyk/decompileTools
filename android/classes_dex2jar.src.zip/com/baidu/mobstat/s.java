package com.baidu.mobstat;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.Fragment;
import com.baidu.mobstat.a.b;
import com.baidu.mobstat.a.c;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import org.json.JSONException;
import org.json.JSONObject;

class s
{
  private static HandlerThread a = new HandlerThread("SessionAnalysisThread");
  private static Handler b;
  private static s k = new s();
  private long c = 0L;
  private long d = 0L;
  private long e = 0L;
  private long f = 0L;
  private WeakReference<Context> g;
  private WeakReference<Fragment> h;
  private WeakReference<Object> i;
  private q j = new q();
  private int l = -1;
  private boolean m = true;
  private boolean n = false;
  private boolean o = false;
  private boolean p = false;
  private boolean q = false;
  private String r = null;

  private s()
  {
    a.start();
    a.setPriority(10);
    b = new Handler(a.getLooper());
  }

  static Context a(Object paramObject)
  {
    try
    {
      Class localClass = paramObject.getClass();
      Class[] arrayOfClass = new Class[0];
      Object[] arrayOfObject = new Object[0];
      Context localContext = (Context)localClass.getMethod("getActivity", arrayOfClass).invoke(paramObject, arrayOfObject);
      return localContext;
    }
    catch (Throwable localThrowable)
    {
      c.a(localThrowable.getMessage());
    }
    return null;
  }

  private void a(Context paramContext)
  {
    if (paramContext == null)
    {
      c.a("stat", "clearLastSession(Context context):context=null");
      return;
    }
    b.a(false, paramContext, "__local_last_session.json", "{}", false);
  }

  private void a(boolean paramBoolean)
  {
    this.m = paramBoolean;
  }

  public static s b()
  {
    return k;
  }

  private void c(Context paramContext, long paramLong)
  {
    c.a("stat", "flush current session to last_session.json");
    new JSONObject();
    JSONObject localJSONObject = this.j.c();
    try
    {
      localJSONObject.put("e", paramLong);
      String str = localJSONObject.toString();
      c.a("stat", "cacheString=" + str);
      b.a(false, paramContext, "__local_last_session.json", str, false);
      return;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        c.a("stat", "StatSession.flushSession() failed");
    }
  }

  private boolean e()
  {
    return this.m;
  }

  public int a()
  {
    if (this.l == -1)
      this.l = 30000;
    return this.l;
  }

  public void a(int paramInt)
  {
    this.l = (paramInt * 1000);
  }

  public void a(Context paramContext, long paramLong)
  {
    c.a("stat", "AnalysisResume job");
    if (this.n)
      c.c(new Object[] { "stat", "遗漏StatService.onPause() || missing StatService.onPause()" });
    this.n = true;
    if (e())
    {
      c.a("is_first_resume=true");
      a(false);
      b.post(new t(this));
    }
    while (true)
    {
      y localy = new y(this, this.c, paramLong, paramContext, null, null, 1);
      b.post(localy);
      this.g = new WeakReference(paramContext);
      this.d = paramLong;
      return;
      c.a("stat", " is_first_resume=false");
    }
  }

  public void a(Context paramContext, long paramLong, String paramString)
  {
    c.a("stat", "AnalysisPageStart");
    if (this.q)
      c.c(new Object[] { "stat", "遗漏StatService.onPageEnd() || missing StatService.onPageEnd()" });
    this.q = true;
    if (e())
    {
      c.b("PPPPPPPPPPPPP is_first_resume=true");
      a(false);
      b.post(new u(this));
    }
    while (true)
    {
      y localy = new y(this, this.c, paramLong, paramContext, null, null, 1);
      b.post(localy);
      this.r = paramString;
      this.g = new WeakReference(paramContext);
      this.d = paramLong;
      return;
      c.a("stat", " is_first_resume=false");
    }
  }

  public void a(Fragment paramFragment, long paramLong)
  {
    c.a("stat", "post resume job");
    if (this.o)
      c.c(new Object[] { "stat", "遗漏StatService.onPause() || missing StatService.onPause()" });
    this.o = true;
    if (e())
    {
      c.a("stat", "is_first_resume=true");
      a(false);
      b.post(new v(this));
    }
    while (true)
    {
      y localy = new y(this, this.c, paramLong, null, paramFragment, null, 2);
      b.post(localy);
      this.h = new WeakReference(paramFragment);
      this.e = paramLong;
      return;
      c.a("stat", "is_first_resume=false");
    }
  }

  public void a(Object paramObject, long paramLong)
  {
    c.a("stat", "post resume job");
    if (this.p)
      c.c(new Object[] { "stat", "遗漏StatService.onPause() || missing StatService.onPause()" });
    this.p = true;
    if (e())
    {
      c.a("stat", "is_first_resume=true");
      a(false);
      b.post(new w(this));
    }
    while (true)
    {
      y localy = new y(this, this.c, paramLong, null, null, paramObject, 3);
      b.post(localy);
      this.i = new WeakReference(paramObject);
      this.f = paramLong;
      return;
      c.a("stat", "is_first_resume=false");
    }
  }

  public void b(Context paramContext, long paramLong)
  {
    c.a("stat", "post pause job");
    if (!this.n)
    {
      c.c(new Object[] { "stat", "遗漏StatService.onResume() || missing StatService.onResume()" });
      return;
    }
    this.n = false;
    x localx = new x(this, paramLong, paramContext, null, this.d, (Context)this.g.get(), null, 1, null, null, null);
    b.post(localx);
    this.c = paramLong;
  }

  public void b(Context paramContext, long paramLong, String paramString)
  {
    c.a("stat", "post pause job");
    if (!this.q)
    {
      c.c(new Object[] { "stat", "Please check (1)遗漏StatService.onPageStart() || missing StatService.onPageStart()" });
      return;
    }
    this.q = false;
    if ((this.r == null) || (!this.r.equals(paramString)))
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = "stat";
      arrayOfObject[1] = ("Please check the reason : (1)遗漏StatService.onPageStart() || missing StatService.onPageStart() || (2)页面的起始和结束不是同一页面 || The page " + paramString + " name is not equal to the page end " + this.r + "");
      c.c(arrayOfObject);
      return;
    }
    x localx = new x(this, paramLong, paramContext, null, this.d, (Context)this.g.get(), null, 1, paramString, null, null);
    b.post(localx);
    this.c = paramLong;
  }

  public void b(Fragment paramFragment, long paramLong)
  {
    c.a("stat", "post pause job");
    if (!this.o)
    {
      c.c(new Object[] { "stat", "遗漏android.support.v4.app.Fragment StatService.onResume() || android.support.v4.app.Fragment missing StatService.onResume()" });
      return;
    }
    this.o = false;
    x localx = new x(this, paramLong, null, paramFragment, this.e, null, (Fragment)this.h.get(), 2, null, null, null);
    b.post(localx);
    this.c = paramLong;
  }

  public void b(Object paramObject, long paramLong)
  {
    c.a("stat", "post pause job");
    if (!this.p)
    {
      c.c(new Object[] { "stat", "遗漏android.app.Fragment StatService.onResume() || android.app.Fragment missing StatService.onResume()" });
      return;
    }
    this.p = false;
    x localx = new x(this, paramLong, null, null, this.f, null, null, 3, null, this.i.get(), paramObject);
    b.post(localx);
    this.c = paramLong;
  }

  public void c()
  {
    this.j.a(1 + this.j.d());
  }

  public long d()
  {
    return this.j.a();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.s
 * JD-Core Version:    0.6.2
 */