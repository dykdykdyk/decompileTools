package com.baidu.mobstat;

import android.app.Activity;
import com.baidu.mobstat.a.c;

public class StatActivity extends Activity
{
  public void onPause()
  {
    super.onPause();
    c.a("stat", "StatActivity.OnResume()");
    StatService.onPause(this);
  }

  public void onResume()
  {
    super.onResume();
    c.a("stat", "StatActivity.OnResume()");
    StatService.onResume(this);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.StatActivity
 * JD-Core Version:    0.6.2
 */