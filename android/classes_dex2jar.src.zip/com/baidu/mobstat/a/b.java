package com.baidu.mobstat.a;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URL;

public final class b
{
  private static final Proxy a = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.0.0.172", 80));
  private static final Proxy b = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.0.0.200", 80));

  public static String a(Context paramContext, String paramString)
  {
    c.a("MoUtil.read", paramString);
    try
    {
      byte[] arrayOfByte = b(paramContext, paramString);
      if (arrayOfByte != null)
      {
        String str = new String(arrayOfByte, "utf-8");
        return str;
      }
    }
    catch (Exception localException)
    {
      Log.w("stat", "MoUtil.read", localException);
    }
    return "";
  }

  public static String a(boolean paramBoolean, Context paramContext, String paramString)
  {
    if (paramBoolean)
      return b(paramString);
    return a(paramContext, paramString);
  }

  public static HttpURLConnection a(Context paramContext, String paramString, int paramInt1, int paramInt2)
  {
    URL localURL = new URL(paramString);
    ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    NetworkInfo localNetworkInfo1 = localConnectivityManager.getNetworkInfo(0);
    NetworkInfo localNetworkInfo2 = localConnectivityManager.getNetworkInfo(1);
    HttpURLConnection localHttpURLConnection;
    if ((localNetworkInfo2 != null) && (localNetworkInfo2.isAvailable()))
    {
      c.a("", "WIFI is available");
      localHttpURLConnection = (HttpURLConnection)localURL.openConnection();
    }
    while (true)
    {
      localHttpURLConnection.setConnectTimeout(paramInt1);
      localHttpURLConnection.setReadTimeout(paramInt2);
      return localHttpURLConnection;
      if ((localNetworkInfo1 != null) && (localNetworkInfo1.isAvailable()))
      {
        String str1 = localNetworkInfo1.getExtraInfo();
        if (str1 != null);
        for (String str2 = str1.toLowerCase(); ; str2 = "")
        {
          c.a("current APN", str2);
          if ((!str2.startsWith("cmwap")) && (!str2.startsWith("uniwap")) && (!str2.startsWith("3gwap")))
            break label176;
          localHttpURLConnection = (HttpURLConnection)localURL.openConnection(a);
          break;
        }
        label176: if (str2.startsWith("ctwap"))
          localHttpURLConnection = (HttpURLConnection)localURL.openConnection(b);
        else
          localHttpURLConnection = (HttpURLConnection)localURL.openConnection();
      }
      else
      {
        c.a("", "getConnection:not wifi and mobile");
        localHttpURLConnection = (HttpURLConnection)localURL.openConnection();
      }
    }
  }

  public static void a(Context paramContext, String paramString1, String paramString2, boolean paramBoolean)
  {
    FileOutputStream localFileOutputStream = null;
    int i;
    if (paramBoolean)
      i = 32768;
    try
    {
      localFileOutputStream = paramContext.openFileOutput(paramString1, i);
      if (localFileOutputStream != null)
        localFileOutputStream.write(paramString2.getBytes("utf-8"));
    }
    catch (Exception localException2)
    {
    }
    finally
    {
      StringBuilder localStringBuilder;
      boolean bool;
      if (localFileOutputStream == null);
    }
    try
    {
      localFileOutputStream.close();
      throw localObject;
    }
    catch (Exception localException1)
    {
      while (true)
        Log.w("stat", "MoUtil.write", localException1);
    }
  }

  // ERROR //
  public static void a(String paramString1, String paramString2, boolean paramBoolean)
  {
    // Byte code:
    //   0: ldc 183
    //   2: invokestatic 188	android/os/Environment:getExternalStorageState	()Ljava/lang/String;
    //   5: invokevirtual 192	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   8: ifne +4 -> 12
    //   11: return
    //   12: aconst_null
    //   13: astore_3
    //   14: invokestatic 196	android/os/Environment:getExternalStorageDirectory	()Ljava/io/File;
    //   17: astore 15
    //   19: new 198	java/io/File
    //   22: dup
    //   23: new 158	java/lang/StringBuilder
    //   26: dup
    //   27: invokespecial 160	java/lang/StringBuilder:<init>	()V
    //   30: aload 15
    //   32: invokevirtual 201	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   35: getstatic 205	java/io/File:separator	Ljava/lang/String;
    //   38: invokevirtual 166	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: aload_0
    //   42: invokevirtual 166	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: invokevirtual 172	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   48: invokespecial 206	java/io/File:<init>	(Ljava/lang/String;)V
    //   51: astore 16
    //   53: aload 16
    //   55: invokevirtual 209	java/io/File:exists	()Z
    //   58: istore 17
    //   60: aconst_null
    //   61: astore_3
    //   62: iload 17
    //   64: ifne +18 -> 82
    //   67: aload 16
    //   69: invokevirtual 212	java/io/File:getParentFile	()Ljava/io/File;
    //   72: invokevirtual 215	java/io/File:mkdirs	()Z
    //   75: pop
    //   76: aload 16
    //   78: invokevirtual 218	java/io/File:createNewFile	()Z
    //   81: pop
    //   82: new 149	java/io/FileOutputStream
    //   85: dup
    //   86: aload 16
    //   88: iload_2
    //   89: invokespecial 221	java/io/FileOutputStream:<init>	(Ljava/io/File;Z)V
    //   92: astore 20
    //   94: aload 20
    //   96: aload_1
    //   97: ldc 51
    //   99: invokevirtual 147	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   102: invokevirtual 153	java/io/FileOutputStream:write	([B)V
    //   105: aload 20
    //   107: ifnull -96 -> 11
    //   110: aload 20
    //   112: invokevirtual 156	java/io/FileOutputStream:close	()V
    //   115: return
    //   116: astore 21
    //   118: ldc 56
    //   120: ldc 223
    //   122: aload 21
    //   124: invokestatic 62	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   127: pop
    //   128: return
    //   129: astore 11
    //   131: ldc 56
    //   133: ldc 223
    //   135: aload 11
    //   137: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   140: pop
    //   141: aload_3
    //   142: ifnull -131 -> 11
    //   145: aload_3
    //   146: invokevirtual 156	java/io/FileOutputStream:close	()V
    //   149: return
    //   150: astore 13
    //   152: ldc 56
    //   154: ldc 223
    //   156: aload 13
    //   158: invokestatic 62	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   161: pop
    //   162: return
    //   163: astore 7
    //   165: ldc 56
    //   167: ldc 223
    //   169: aload 7
    //   171: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   174: pop
    //   175: aload_3
    //   176: ifnull -165 -> 11
    //   179: aload_3
    //   180: invokevirtual 156	java/io/FileOutputStream:close	()V
    //   183: return
    //   184: astore 9
    //   186: ldc 56
    //   188: ldc 223
    //   190: aload 9
    //   192: invokestatic 62	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   195: pop
    //   196: return
    //   197: astore 4
    //   199: aload_3
    //   200: ifnull +7 -> 207
    //   203: aload_3
    //   204: invokevirtual 156	java/io/FileOutputStream:close	()V
    //   207: aload 4
    //   209: athrow
    //   210: astore 5
    //   212: ldc 56
    //   214: ldc 223
    //   216: aload 5
    //   218: invokestatic 62	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   221: pop
    //   222: goto -15 -> 207
    //   225: astore 4
    //   227: aload 20
    //   229: astore_3
    //   230: goto -31 -> 199
    //   233: astore 7
    //   235: aload 20
    //   237: astore_3
    //   238: goto -73 -> 165
    //   241: astore 11
    //   243: aload 20
    //   245: astore_3
    //   246: goto -115 -> 131
    //
    // Exception table:
    //   from	to	target	type
    //   110	115	116	java/io/IOException
    //   14	60	129	java/io/FileNotFoundException
    //   67	82	129	java/io/FileNotFoundException
    //   82	94	129	java/io/FileNotFoundException
    //   145	149	150	java/io/IOException
    //   14	60	163	java/io/IOException
    //   67	82	163	java/io/IOException
    //   82	94	163	java/io/IOException
    //   179	183	184	java/io/IOException
    //   14	60	197	finally
    //   67	82	197	finally
    //   82	94	197	finally
    //   131	141	197	finally
    //   165	175	197	finally
    //   203	207	210	java/io/IOException
    //   94	105	225	finally
    //   94	105	233	java/io/IOException
    //   94	105	241	java/io/FileNotFoundException
  }

  public static void a(boolean paramBoolean1, Context paramContext, String paramString1, String paramString2, boolean paramBoolean2)
  {
    if (paramBoolean1)
    {
      a(paramString1, paramString2, paramBoolean2);
      return;
    }
    a(paramContext, paramString1, paramString2, paramBoolean2);
  }

  public static boolean a(String paramString)
  {
    c.a("MoUtil.deleteExt", paramString);
    if (!"mounted".equals(Environment.getExternalStorageState()));
    File localFile2;
    do
    {
      return false;
      File localFile1 = Environment.getExternalStorageDirectory();
      localFile2 = new File(localFile1 + File.separator + paramString);
    }
    while (!localFile2.exists());
    return localFile2.delete();
  }

  // ERROR //
  public static String b(String paramString)
  {
    // Byte code:
    //   0: ldc 238
    //   2: aload_0
    //   3: invokestatic 44	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   6: pop
    //   7: invokestatic 188	android/os/Environment:getExternalStorageState	()Ljava/lang/String;
    //   10: astore_2
    //   11: ldc 183
    //   13: aload_2
    //   14: invokevirtual 192	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   17: ifne +19 -> 36
    //   20: ldc 240
    //   22: aload_2
    //   23: invokevirtual 192	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   26: ifne +10 -> 36
    //   29: ldc 64
    //   31: astore 5
    //   33: aload 5
    //   35: areturn
    //   36: invokestatic 196	android/os/Environment:getExternalStorageDirectory	()Ljava/io/File;
    //   39: astore_3
    //   40: new 198	java/io/File
    //   43: dup
    //   44: new 158	java/lang/StringBuilder
    //   47: dup
    //   48: invokespecial 160	java/lang/StringBuilder:<init>	()V
    //   51: aload_3
    //   52: invokevirtual 201	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   55: getstatic 205	java/io/File:separator	Ljava/lang/String;
    //   58: invokevirtual 166	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: aload_0
    //   62: invokevirtual 166	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: invokevirtual 172	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   68: invokespecial 206	java/io/File:<init>	(Ljava/lang/String;)V
    //   71: astore 4
    //   73: ldc 64
    //   75: astore 5
    //   77: aload 4
    //   79: invokevirtual 209	java/io/File:exists	()Z
    //   82: ifeq -49 -> 33
    //   85: new 242	java/io/FileInputStream
    //   88: dup
    //   89: aload 4
    //   91: invokespecial 245	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   94: astore 6
    //   96: aload 6
    //   98: invokevirtual 249	java/io/FileInputStream:available	()I
    //   101: newarray byte
    //   103: astore 19
    //   105: aload 6
    //   107: aload 19
    //   109: invokevirtual 253	java/io/FileInputStream:read	([B)I
    //   112: pop
    //   113: new 49	java/lang/String
    //   116: dup
    //   117: aload 19
    //   119: ldc 51
    //   121: invokespecial 54	java/lang/String:<init>	([BLjava/lang/String;)V
    //   124: astore 12
    //   126: aload 6
    //   128: ifnull +8 -> 136
    //   131: aload 6
    //   133: invokevirtual 254	java/io/FileInputStream:close	()V
    //   136: aload 12
    //   138: areturn
    //   139: astore 21
    //   141: ldc 56
    //   143: ldc 238
    //   145: aload 21
    //   147: invokestatic 62	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   150: pop
    //   151: goto -15 -> 136
    //   154: astore 7
    //   156: aconst_null
    //   157: astore 6
    //   159: ldc 56
    //   161: ldc 238
    //   163: aload 7
    //   165: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   168: pop
    //   169: aload 6
    //   171: ifnull +8 -> 179
    //   174: aload 6
    //   176: invokevirtual 254	java/io/FileInputStream:close	()V
    //   179: aload 5
    //   181: astore 12
    //   183: goto -47 -> 136
    //   186: astore 13
    //   188: ldc 56
    //   190: ldc 238
    //   192: aload 13
    //   194: invokestatic 62	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   197: pop
    //   198: aload 5
    //   200: astore 12
    //   202: goto -66 -> 136
    //   205: astore 15
    //   207: aconst_null
    //   208: astore 6
    //   210: ldc 56
    //   212: ldc 238
    //   214: aload 15
    //   216: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   219: pop
    //   220: aload 6
    //   222: ifnull +8 -> 230
    //   225: aload 6
    //   227: invokevirtual 254	java/io/FileInputStream:close	()V
    //   230: aload 5
    //   232: astore 12
    //   234: goto -98 -> 136
    //   237: astore 17
    //   239: ldc 56
    //   241: ldc 238
    //   243: aload 17
    //   245: invokestatic 62	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   248: pop
    //   249: aload 5
    //   251: astore 12
    //   253: goto -117 -> 136
    //   256: astore 8
    //   258: aconst_null
    //   259: astore 6
    //   261: aload 6
    //   263: ifnull +8 -> 271
    //   266: aload 6
    //   268: invokevirtual 254	java/io/FileInputStream:close	()V
    //   271: aload 8
    //   273: athrow
    //   274: astore 9
    //   276: ldc 56
    //   278: ldc 238
    //   280: aload 9
    //   282: invokestatic 62	android/util/Log:w	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   285: pop
    //   286: goto -15 -> 271
    //   289: astore 8
    //   291: goto -30 -> 261
    //   294: astore 15
    //   296: goto -86 -> 210
    //   299: astore 7
    //   301: goto -142 -> 159
    //
    // Exception table:
    //   from	to	target	type
    //   131	136	139	java/io/IOException
    //   85	96	154	java/io/FileNotFoundException
    //   174	179	186	java/io/IOException
    //   85	96	205	java/io/IOException
    //   225	230	237	java/io/IOException
    //   85	96	256	finally
    //   266	271	274	java/io/IOException
    //   96	126	289	finally
    //   159	169	289	finally
    //   210	220	289	finally
    //   96	126	294	java/io/IOException
    //   96	126	299	java/io/FileNotFoundException
  }

  // ERROR //
  static byte[] b(Context paramContext, String paramString)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual 258	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   7: astore 17
    //   9: aload 17
    //   11: ifnull +243 -> 254
    //   14: aload 17
    //   16: invokevirtual 249	java/io/FileInputStream:available	()I
    //   19: newarray byte
    //   21: astore 22
    //   23: aload 17
    //   25: aload 22
    //   27: invokevirtual 253	java/io/FileInputStream:read	([B)I
    //   30: pop
    //   31: aload 22
    //   33: astore 8
    //   35: aload 17
    //   37: ifnull +8 -> 45
    //   40: aload 17
    //   42: invokevirtual 254	java/io/FileInputStream:close	()V
    //   45: aload 8
    //   47: areturn
    //   48: astore 18
    //   50: ldc 56
    //   52: ldc_w 260
    //   55: aload 18
    //   57: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   60: pop
    //   61: aload 8
    //   63: areturn
    //   64: astore 12
    //   66: aload 12
    //   68: astore 13
    //   70: aconst_null
    //   71: astore 8
    //   73: ldc 56
    //   75: ldc_w 260
    //   78: aload 13
    //   80: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   83: pop
    //   84: aload_2
    //   85: ifnull -40 -> 45
    //   88: aload_2
    //   89: invokevirtual 254	java/io/FileInputStream:close	()V
    //   92: aload 8
    //   94: areturn
    //   95: astore 15
    //   97: ldc 56
    //   99: ldc_w 260
    //   102: aload 15
    //   104: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   107: pop
    //   108: aload 8
    //   110: areturn
    //   111: astore 6
    //   113: aload 6
    //   115: astore 7
    //   117: aconst_null
    //   118: astore 8
    //   120: ldc 56
    //   122: ldc_w 260
    //   125: aload 7
    //   127: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   130: pop
    //   131: aload_2
    //   132: ifnull -87 -> 45
    //   135: aload_2
    //   136: invokevirtual 254	java/io/FileInputStream:close	()V
    //   139: aload 8
    //   141: areturn
    //   142: astore 10
    //   144: ldc 56
    //   146: ldc_w 260
    //   149: aload 10
    //   151: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   154: pop
    //   155: aload 8
    //   157: areturn
    //   158: astore_3
    //   159: aload_2
    //   160: ifnull +7 -> 167
    //   163: aload_2
    //   164: invokevirtual 254	java/io/FileInputStream:close	()V
    //   167: aload_3
    //   168: athrow
    //   169: astore 4
    //   171: ldc 56
    //   173: ldc_w 260
    //   176: aload 4
    //   178: invokestatic 226	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   181: pop
    //   182: goto -15 -> 167
    //   185: astore_3
    //   186: aload 17
    //   188: astore_2
    //   189: goto -30 -> 159
    //   192: astore 21
    //   194: aload 17
    //   196: astore_2
    //   197: aload 21
    //   199: astore 7
    //   201: aconst_null
    //   202: astore 8
    //   204: goto -84 -> 120
    //   207: astore 24
    //   209: aload 22
    //   211: astore 8
    //   213: aload 17
    //   215: astore_2
    //   216: aload 24
    //   218: astore 7
    //   220: goto -100 -> 120
    //   223: astore 20
    //   225: aload 17
    //   227: astore_2
    //   228: aload 20
    //   230: astore 13
    //   232: aconst_null
    //   233: astore 8
    //   235: goto -162 -> 73
    //   238: astore 23
    //   240: aload 22
    //   242: astore 8
    //   244: aload 17
    //   246: astore_2
    //   247: aload 23
    //   249: astore 13
    //   251: goto -178 -> 73
    //   254: aconst_null
    //   255: astore 8
    //   257: goto -222 -> 35
    //
    // Exception table:
    //   from	to	target	type
    //   40	45	48	java/io/IOException
    //   2	9	64	java/io/FileNotFoundException
    //   88	92	95	java/io/IOException
    //   2	9	111	java/io/IOException
    //   135	139	142	java/io/IOException
    //   2	9	158	finally
    //   73	84	158	finally
    //   120	131	158	finally
    //   163	167	169	java/io/IOException
    //   14	23	185	finally
    //   23	31	185	finally
    //   14	23	192	java/io/IOException
    //   23	31	207	java/io/IOException
    //   14	23	223	java/io/FileNotFoundException
    //   23	31	238	java/io/FileNotFoundException
  }

  public static void c(String paramString)
  {
    c.c(new Object[] { "stat", paramString });
    Log.e("stat", "SDK install error:" + paramString);
  }

  public static boolean c(Context paramContext, String paramString)
  {
    boolean bool = paramContext.getFileStreamPath(paramString).exists();
    c.a("MoUtil.exists", bool + " " + paramString);
    return bool;
  }

  public static void d(Context paramContext, String paramString)
  {
    if (!e(paramContext, paramString))
      c("You need the " + paramString + " permission. Open AndroidManifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"" + paramString + "\" />");
  }

  public static boolean e(Context paramContext, String paramString)
  {
    if (paramContext.checkCallingOrSelfPermission(paramString) != -1);
    for (boolean bool = true; ; bool = false)
    {
      c.a("hasPermission ", bool + " | " + paramString);
      return bool;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.a.b
 * JD-Core Version:    0.6.2
 */