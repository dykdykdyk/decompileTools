package com.baidu.mobstat.a;

public final class a
{
  public static int a = 4;
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.a.a
 * JD-Core Version:    0.6.2
 */