package com.baidu.mobstat.a;

import android.text.format.DateFormat;
import android.util.Log;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

public final class c
{
  private static DateFormat a = new DateFormat();

  static
  {
    a();
  }

  public static int a(String paramString)
  {
    return a("stat", paramString);
  }

  public static int a(String paramString1, String paramString2)
  {
    if (!a(3))
      return -1;
    b(paramString1, paramString2);
    return Log.d(paramString1, paramString2);
  }

  public static int a(String paramString, Throwable paramThrowable)
  {
    if (!a(3))
      return -1;
    a("stat", paramString, paramThrowable);
    return Log.d("stat", paramString, paramThrowable);
  }

  public static int a(Throwable paramThrowable)
  {
    return a("", paramThrowable);
  }

  public static int a(Object[] paramArrayOfObject)
  {
    if (!a(3))
      return -1;
    return a(d(paramArrayOfObject));
  }

  public static void a()
  {
    b.a("_b_sdk.log");
  }

  private static void a(String paramString1, String paramString2, Throwable paramThrowable)
  {
    StringWriter localStringWriter = new StringWriter();
    PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
    paramThrowable.printStackTrace(localPrintWriter);
    b(paramString1, paramString2 + "\n" + localStringWriter.toString());
    localPrintWriter.close();
    try
    {
      localStringWriter.close();
      return;
    }
    catch (IOException localIOException)
    {
      Log.w("Log.debug", "", localIOException);
    }
  }

  public static boolean a(int paramInt)
  {
    return a("stat", paramInt);
  }

  public static boolean a(String paramString, int paramInt)
  {
    return paramInt >= a.a;
  }

  public static int b(String paramString)
  {
    if (!a(5))
      return -1;
    b("stat", paramString);
    return Log.w("stat", paramString);
  }

  public static int b(String paramString, Throwable paramThrowable)
  {
    if (!a(6))
      return -1;
    a("stat", paramString, paramThrowable);
    return Log.e("stat", paramString, paramThrowable);
  }

  public static int b(Throwable paramThrowable)
  {
    return b("", paramThrowable);
  }

  public static int b(Object[] paramArrayOfObject)
  {
    if (!a(5))
      return -1;
    return b(d(paramArrayOfObject));
  }

  private static void b(String paramString1, String paramString2)
  {
  }

  public static int c(String paramString)
  {
    if (!a(6))
      return -1;
    b("stat", paramString);
    return Log.e("stat", paramString);
  }

  public static int c(Object[] paramArrayOfObject)
  {
    if (!a(6))
      return -1;
    return c(d(paramArrayOfObject));
  }

  private static String d(Object[] paramArrayOfObject)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    int i = paramArrayOfObject.length;
    for (int j = 0; j < i; j++)
      localStringBuilder.append(paramArrayOfObject[j]).append(' ');
    return localStringBuilder.toString();
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.a.c
 * JD-Core Version:    0.6.2
 */