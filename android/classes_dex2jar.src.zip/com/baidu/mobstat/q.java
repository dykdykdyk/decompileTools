package com.baidu.mobstat;

import com.baidu.mobstat.a.c;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class q
{
  List<r> a = new ArrayList();
  private long b = 0L;
  private long c = 0L;
  private int d = 0;

  public q()
  {
    a(System.currentTimeMillis());
  }

  public long a()
  {
    return this.b;
  }

  public void a(int paramInt)
  {
    this.d = paramInt;
  }

  public void a(long paramLong)
  {
    this.b = paramLong;
  }

  public void a(String paramString, long paramLong1, long paramLong2)
  {
    r localr = new r(this, paramString, paramLong1, paramLong2);
    this.a.add(localr);
  }

  public void b()
  {
    this.b = 0L;
    this.c = 0L;
    this.d = 0;
    this.a.clear();
    a(System.currentTimeMillis());
  }

  public void b(long paramLong)
  {
    this.c = paramLong;
  }

  public JSONObject c()
  {
    JSONObject localJSONObject1 = new JSONObject();
    try
    {
      localJSONObject1.put("s", this.b);
      localJSONObject1.put("e", this.c);
      localJSONObject1.put("i", System.currentTimeMillis());
      localJSONObject1.put("c", this.d);
      JSONArray localJSONArray = new JSONArray();
      for (int i = 0; i < this.a.size(); i++)
      {
        JSONObject localJSONObject2 = new JSONObject();
        localJSONObject2.put("n", ((r)this.a.get(i)).a());
        localJSONObject2.put("d", ((r)this.a.get(i)).b());
        long l = ((r)this.a.get(i)).c() - this.b;
        if (l < 0L)
          l = 0L;
        localJSONObject2.put("ps", l);
        localJSONArray.put(localJSONObject2);
      }
      localJSONObject1.put("p", localJSONArray);
      return localJSONObject1;
    }
    catch (JSONException localJSONException)
    {
      c.a("stat", "StatSession.constructJSONObject() failed");
    }
    return localJSONObject1;
  }

  public int d()
  {
    return this.d;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.q
 * JD-Core Version:    0.6.2
 */