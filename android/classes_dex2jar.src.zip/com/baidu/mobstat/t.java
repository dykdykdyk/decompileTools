package com.baidu.mobstat;

import com.baidu.mobstat.a.c;

class t
  implements Runnable
{
  t(s params)
  {
  }

  public void run()
  {
    if (!k.a().c())
      synchronized (k.a())
      {
        try
        {
          k.a().wait();
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          while (true)
            c.a("stat", localInterruptedException);
        }
      }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.t
 * JD-Core Version:    0.6.2
 */