package com.baidu.mobstat;

import android.content.Context;
import com.baidu.mobstat.a.c;
import java.util.TimerTask;

class o extends TimerTask
{
  o(l paraml, Context paramContext)
  {
  }

  public void run()
  {
    c.a("welcome timer log");
    if (!b.a().b())
    {
      c.a("welcome timer log start");
      this.b.a(this.a, l.d(this.b));
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.o
 * JD-Core Version:    0.6.2
 */