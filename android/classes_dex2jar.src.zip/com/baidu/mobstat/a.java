package com.baidu.mobstat;

import android.content.Context;
import com.baidu.mobstat.a.c;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.json.JSONArray;
import org.json.JSONObject;

class a
  implements Thread.UncaughtExceptionHandler
{
  private static a a = new a();
  private Thread.UncaughtExceptionHandler b = null;
  private Context c = null;

  public static a a()
  {
    return a;
  }

  private void a(long paramLong, String paramString1, String paramString2)
  {
    if ((this.c == null) || (paramString1 == null) || (paramString1.trim().equals("")))
      return;
    try
    {
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put("t", paramLong);
      localJSONObject.put("c", paramString1);
      localJSONObject.put("y", paramString2);
      JSONArray localJSONArray = b(this.c);
      if (localJSONArray == null)
        localJSONArray = new JSONArray();
      localJSONArray.put(localJSONObject);
      FileOutputStream localFileOutputStream = this.c.openFileOutput("__local_except_cache.json", 0);
      localFileOutputStream.write(localJSONArray.toString().getBytes());
      localFileOutputStream.flush();
      localFileOutputStream.close();
      c.a("SDKCrashHandler", "Save Exception String Successlly");
      return;
    }
    catch (Exception localException)
    {
      c.a("SDKCrashHandler", localException);
    }
  }

  public void a(Context paramContext)
  {
    if (this.b == null)
    {
      this.b = Thread.getDefaultUncaughtExceptionHandler();
      Thread.setDefaultUncaughtExceptionHandler(this);
    }
    if (this.c == null)
      this.c = paramContext.getApplicationContext();
  }

  protected JSONArray b(Context paramContext)
  {
    Object localObject = null;
    if (paramContext == null);
    File localFile;
    FileInputStream localFileInputStream;
    StringBuffer localStringBuffer;
    while (true)
    {
      return null;
      localFile = new File(paramContext.getFilesDir(), "__local_except_cache.json");
      try
      {
        if (localFile.exists())
        {
          localFileInputStream = paramContext.openFileInput("__local_except_cache.json");
          localStringBuffer = new StringBuffer();
          byte[] arrayOfByte = new byte[1024];
          while (true)
          {
            int i = localFileInputStream.read(arrayOfByte);
            if (i == -1)
              break;
            localStringBuffer.append(new String(arrayOfByte, 0, i));
          }
        }
      }
      catch (Exception localException1)
      {
        c.a("SDKCrashHandler", localException1);
      }
    }
    try
    {
      localFile.delete();
      return localObject;
    }
    catch (Exception localException2)
    {
      c.a("SDKCrashHandler", localException2);
      return localObject;
    }
    localFileInputStream.close();
    if (localStringBuffer.length() != 0);
    for (JSONArray localJSONArray = new JSONArray(localStringBuffer.toString()); ; localJSONArray = null)
    {
      localObject = localJSONArray;
      break;
    }
  }

  public void uncaughtException(Thread paramThread, Throwable paramThrowable)
  {
    Object localObject1 = paramThrowable.toString();
    Object localObject2 = "";
    if ((localObject1 != null) && (!((String)localObject1).equals("")));
    try
    {
      String[] arrayOfString = ((String)localObject1).split(":");
      if (((String)localObject1).length() > 1);
      for (localObject2 = arrayOfString[0]; (localObject2 == null) || (((String)localObject2).equals("")); localObject2 = localObject1)
      {
        StringWriter localStringWriter = new StringWriter();
        PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
        paramThrowable.printStackTrace(localPrintWriter);
        localPrintWriter.close();
        String str = localStringWriter.toString();
        c.a("SDKCrashHandler", str);
        a(System.currentTimeMillis(), str, (String)localObject1);
        if (!this.b.equals(this))
          this.b.uncaughtException(paramThread, paramThrowable);
        throw new RuntimeException(paramThrowable);
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        c.b(localException);
        localObject2 = "";
        continue;
        localObject1 = localObject2;
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.a
 * JD-Core Version:    0.6.2
 */