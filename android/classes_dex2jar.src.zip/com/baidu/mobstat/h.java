package com.baidu.mobstat;

import android.content.Context;
import com.baidu.mobstat.a.c;

class h
  implements Runnable
{
  h(d paramd, long paramLong, String paramString1, String paramString2, Context paramContext)
  {
  }

  public void run()
  {
    if (!k.a().c());
    synchronized (k.a())
    {
      try
      {
        k.a().wait();
        if (this.a <= 0L)
        {
          c.a("stat", "EventStat: Wrong Case, Duration must be positive");
          return;
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          c.a("stat", localInterruptedException);
      }
    }
    b.a().a(this.b, this.c, 1, System.currentTimeMillis(), this.a);
    b.a().b(this.d);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.h
 * JD-Core Version:    0.6.2
 */