package com.baidu.mobstat;

import android.content.Context;
import org.json.JSONException;
import org.json.JSONObject;

class c
{
  private static String a = "Android";
  private String b;
  private String c = null;
  private String d = null;
  private int e = -1;
  private String f;
  private String g;
  private int h;
  private int i;
  private String j = null;
  private String k;
  private String l;
  private String m;
  private String n;
  private String o;
  private String p;

  // ERROR //
  public void a(Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 37	com/baidu/mobstat/c:e	I
    //   6: istore_3
    //   7: iload_3
    //   8: iconst_m1
    //   9: if_icmpeq +6 -> 15
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: aload_1
    //   16: ldc 46
    //   18: invokestatic 51	com/baidu/mobstat/a/b:d	(Landroid/content/Context;Ljava/lang/String;)V
    //   21: aload_1
    //   22: ldc 53
    //   24: invokestatic 51	com/baidu/mobstat/a/b:d	(Landroid/content/Context;Ljava/lang/String;)V
    //   27: aload_1
    //   28: ldc 55
    //   30: invokestatic 51	com/baidu/mobstat/a/b:d	(Landroid/content/Context;Ljava/lang/String;)V
    //   33: aload_1
    //   34: ldc 57
    //   36: invokestatic 51	com/baidu/mobstat/a/b:d	(Landroid/content/Context;Ljava/lang/String;)V
    //   39: aload_1
    //   40: ldc 59
    //   42: invokevirtual 65	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   45: checkcast 67	android/telephony/TelephonyManager
    //   48: astore 4
    //   50: aload_0
    //   51: getstatic 72	android/os/Build$VERSION:SDK	Ljava/lang/String;
    //   54: putfield 74	com/baidu/mobstat/c:b	Ljava/lang/String;
    //   57: aload_0
    //   58: getstatic 79	android/os/Build:MODEL	Ljava/lang/String;
    //   61: putfield 81	com/baidu/mobstat/c:l	Ljava/lang/String;
    //   64: aload_0
    //   65: aload 4
    //   67: invokevirtual 85	android/telephony/TelephonyManager:getDeviceId	()Ljava/lang/String;
    //   70: putfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   73: aload_0
    //   74: aload_0
    //   75: getfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   78: aload_1
    //   79: invokestatic 92	com/baidu/mobstat/b:a	(Ljava/lang/String;Landroid/content/Context;)Ljava/lang/String;
    //   82: putfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   85: aload_0
    //   86: getfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   89: ifnonnull +11 -> 100
    //   92: aload_0
    //   93: aload_1
    //   94: invokestatic 95	com/baidu/mobstat/b:g	(Landroid/content/Context;)Ljava/lang/String;
    //   97: putfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   100: aload_0
    //   101: getfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   104: ifnull +15 -> 119
    //   107: aload_0
    //   108: getfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   111: ldc 97
    //   113: invokevirtual 103	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   116: ifeq +14 -> 130
    //   119: aload_0
    //   120: invokestatic 109	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   123: aload_1
    //   124: invokevirtual 112	com/baidu/mobstat/BasicStoreTools:loadGenerateDeviceId	(Landroid/content/Context;)Ljava/lang/String;
    //   127: putfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   130: aload_0
    //   131: getfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   134: ifnull +15 -> 149
    //   137: aload_0
    //   138: getfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   141: ldc 97
    //   143: invokevirtual 103	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   146: ifeq +104 -> 250
    //   149: new 114	java/lang/StringBuilder
    //   152: dup
    //   153: invokespecial 115	java/lang/StringBuilder:<init>	()V
    //   156: new 117	java/util/Date
    //   159: dup
    //   160: invokespecial 118	java/util/Date:<init>	()V
    //   163: invokevirtual 122	java/util/Date:getTime	()J
    //   166: invokevirtual 126	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   169: ldc 128
    //   171: invokevirtual 131	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   174: invokevirtual 134	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   177: astore 7
    //   179: aload_0
    //   180: new 114	java/lang/StringBuilder
    //   183: dup
    //   184: invokespecial 115	java/lang/StringBuilder:<init>	()V
    //   187: ldc 136
    //   189: invokevirtual 131	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: aload 7
    //   194: invokevirtual 140	java/lang/String:hashCode	()I
    //   197: invokevirtual 143	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   200: ldc 145
    //   202: invokevirtual 131	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   205: invokevirtual 134	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   208: putfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   211: invokestatic 109	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   214: aload_1
    //   215: aload_0
    //   216: getfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   219: invokevirtual 148	com/baidu/mobstat/BasicStoreTools:setGenerateDeviceId	(Landroid/content/Context;Ljava/lang/String;)V
    //   222: ldc 150
    //   224: new 114	java/lang/StringBuilder
    //   227: dup
    //   228: invokespecial 115	java/lang/StringBuilder:<init>	()V
    //   231: ldc 152
    //   233: invokevirtual 131	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: aload_0
    //   237: getfield 87	com/baidu/mobstat/c:g	Ljava/lang/String;
    //   240: invokevirtual 131	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: invokevirtual 134	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   246: invokestatic 157	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   249: pop
    //   250: aload_0
    //   251: getfield 35	com/baidu/mobstat/c:d	Ljava/lang/String;
    //   254: ifnonnull +11 -> 265
    //   257: aload_0
    //   258: aload_1
    //   259: invokestatic 159	com/baidu/mobstat/b:f	(Landroid/content/Context;)Ljava/lang/String;
    //   262: putfield 35	com/baidu/mobstat/c:d	Ljava/lang/String;
    //   265: aload_0
    //   266: aload 4
    //   268: invokevirtual 162	android/telephony/TelephonyManager:getNetworkOperator	()Ljava/lang/String;
    //   271: putfield 164	com/baidu/mobstat/c:k	Ljava/lang/String;
    //   274: aload_0
    //   275: aload_1
    //   276: invokestatic 169	com/baidu/mobstat/z:a	(Landroid/content/Context;)I
    //   279: putfield 171	com/baidu/mobstat/c:h	I
    //   282: aload_0
    //   283: aload_1
    //   284: invokestatic 173	com/baidu/mobstat/z:b	(Landroid/content/Context;)I
    //   287: putfield 175	com/baidu/mobstat/c:i	I
    //   290: aload_1
    //   291: invokevirtual 179	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   294: invokevirtual 185	android/content/res/Resources:getConfiguration	()Landroid/content/res/Configuration;
    //   297: getfield 190	android/content/res/Configuration:orientation	I
    //   300: iconst_2
    //   301: if_icmpne +50 -> 351
    //   304: ldc 150
    //   306: ldc 192
    //   308: invokestatic 157	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   311: pop
    //   312: aload_0
    //   313: aload_0
    //   314: getfield 171	com/baidu/mobstat/c:h	I
    //   317: aload_0
    //   318: getfield 175	com/baidu/mobstat/c:i	I
    //   321: ixor
    //   322: putfield 171	com/baidu/mobstat/c:h	I
    //   325: aload_0
    //   326: aload_0
    //   327: getfield 171	com/baidu/mobstat/c:h	I
    //   330: aload_0
    //   331: getfield 175	com/baidu/mobstat/c:i	I
    //   334: ixor
    //   335: putfield 175	com/baidu/mobstat/c:i	I
    //   338: aload_0
    //   339: aload_0
    //   340: getfield 171	com/baidu/mobstat/c:h	I
    //   343: aload_0
    //   344: getfield 175	com/baidu/mobstat/c:i	I
    //   347: ixor
    //   348: putfield 171	com/baidu/mobstat/c:h	I
    //   351: aload_0
    //   352: getfield 39	com/baidu/mobstat/c:j	Ljava/lang/String;
    //   355: ifnull +15 -> 370
    //   358: aload_0
    //   359: getfield 39	com/baidu/mobstat/c:j	Ljava/lang/String;
    //   362: ldc 128
    //   364: invokevirtual 103	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   367: ifeq +62 -> 429
    //   370: invokestatic 109	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   373: aload_1
    //   374: invokevirtual 196	com/baidu/mobstat/BasicStoreTools:loadAppChannelWithCode	(Landroid/content/Context;)Z
    //   377: istore 28
    //   379: iload 28
    //   381: ifeq +14 -> 395
    //   384: aload_0
    //   385: invokestatic 109	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   388: aload_1
    //   389: invokevirtual 199	com/baidu/mobstat/BasicStoreTools:loadAppChannelWithPreference	(Landroid/content/Context;)Ljava/lang/String;
    //   392: putfield 39	com/baidu/mobstat/c:j	Ljava/lang/String;
    //   395: iload 28
    //   397: ifeq +22 -> 419
    //   400: aload_0
    //   401: getfield 39	com/baidu/mobstat/c:j	Ljava/lang/String;
    //   404: ifnull +15 -> 419
    //   407: aload_0
    //   408: getfield 39	com/baidu/mobstat/c:j	Ljava/lang/String;
    //   411: ldc 128
    //   413: invokevirtual 103	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   416: ifeq +13 -> 429
    //   419: aload_0
    //   420: aload_1
    //   421: ldc 201
    //   423: invokestatic 204	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   426: putfield 39	com/baidu/mobstat/c:j	Ljava/lang/String;
    //   429: aload_0
    //   430: getfield 33	com/baidu/mobstat/c:c	Ljava/lang/String;
    //   433: ifnonnull +13 -> 446
    //   436: aload_0
    //   437: aload_1
    //   438: ldc 206
    //   440: invokestatic 204	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   443: putfield 33	com/baidu/mobstat/c:c	Ljava/lang/String;
    //   446: aload_0
    //   447: aload_1
    //   448: invokestatic 208	com/baidu/mobstat/z:c	(Landroid/content/Context;)I
    //   451: putfield 37	com/baidu/mobstat/c:e	I
    //   454: aload_0
    //   455: aload_1
    //   456: invokestatic 210	com/baidu/mobstat/z:d	(Landroid/content/Context;)Ljava/lang/String;
    //   459: putfield 212	com/baidu/mobstat/c:f	Ljava/lang/String;
    //   462: aload_1
    //   463: ldc 214
    //   465: invokestatic 204	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   468: astore 27
    //   470: aload 27
    //   472: ifnull +168 -> 640
    //   475: aload 27
    //   477: invokevirtual 217	java/lang/String:toLowerCase	()Ljava/lang/String;
    //   480: ldc 219
    //   482: invokevirtual 103	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   485: ifeq +155 -> 640
    //   488: aload_0
    //   489: ldc 221
    //   491: putfield 223	com/baidu/mobstat/c:m	Ljava/lang/String;
    //   494: aload_1
    //   495: ldc 225
    //   497: invokestatic 204	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   500: astore 26
    //   502: aload 26
    //   504: ifnull +158 -> 662
    //   507: aload 26
    //   509: invokevirtual 217	java/lang/String:toLowerCase	()Ljava/lang/String;
    //   512: ldc 219
    //   514: invokevirtual 103	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   517: ifeq +145 -> 662
    //   520: aload_0
    //   521: ldc 128
    //   523: putfield 227	com/baidu/mobstat/c:n	Ljava/lang/String;
    //   526: aload_1
    //   527: ldc 229
    //   529: invokestatic 204	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   532: astore 25
    //   534: aload 25
    //   536: ifnull +148 -> 684
    //   539: aload 25
    //   541: invokevirtual 217	java/lang/String:toLowerCase	()Ljava/lang/String;
    //   544: ldc 219
    //   546: invokevirtual 103	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   549: ifeq +135 -> 684
    //   552: aload_0
    //   553: ldc 128
    //   555: putfield 231	com/baidu/mobstat/c:o	Ljava/lang/String;
    //   558: aload_0
    //   559: aload_1
    //   560: invokestatic 233	com/baidu/mobstat/z:i	(Landroid/content/Context;)Ljava/lang/String;
    //   563: putfield 235	com/baidu/mobstat/c:p	Ljava/lang/String;
    //   566: goto -554 -> 12
    //   569: astore 23
    //   571: aload 23
    //   573: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   576: pop
    //   577: goto -565 -> 12
    //   580: astore_2
    //   581: aload_0
    //   582: monitorexit
    //   583: aload_2
    //   584: athrow
    //   585: astore 5
    //   587: aload 5
    //   589: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   592: pop
    //   593: goto -508 -> 85
    //   596: astore 9
    //   598: aload 9
    //   600: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   603: pop
    //   604: goto -330 -> 274
    //   607: astore 11
    //   609: aload 11
    //   611: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   614: pop
    //   615: goto -264 -> 351
    //   618: astore 13
    //   620: aload 13
    //   622: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   625: pop
    //   626: goto -197 -> 429
    //   629: astore 15
    //   631: aload 15
    //   633: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   636: pop
    //   637: goto -175 -> 462
    //   640: aload_0
    //   641: aload_1
    //   642: invokestatic 240	com/baidu/mobstat/z:e	(Landroid/content/Context;)Ljava/lang/String;
    //   645: putfield 223	com/baidu/mobstat/c:m	Ljava/lang/String;
    //   648: goto -154 -> 494
    //   651: astore 17
    //   653: aload 17
    //   655: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   658: pop
    //   659: goto -165 -> 494
    //   662: aload_0
    //   663: aload_1
    //   664: invokestatic 241	com/baidu/mobstat/z:f	(Landroid/content/Context;)Ljava/lang/String;
    //   667: putfield 227	com/baidu/mobstat/c:n	Ljava/lang/String;
    //   670: goto -144 -> 526
    //   673: astore 19
    //   675: aload 19
    //   677: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   680: pop
    //   681: goto -155 -> 526
    //   684: aload_0
    //   685: aload_1
    //   686: invokestatic 243	com/baidu/mobstat/z:h	(Landroid/content/Context;)Ljava/lang/String;
    //   689: putfield 231	com/baidu/mobstat/c:o	Ljava/lang/String;
    //   692: goto -134 -> 558
    //   695: astore 21
    //   697: aload 21
    //   699: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   702: pop
    //   703: goto -145 -> 558
    //
    // Exception table:
    //   from	to	target	type
    //   558	566	569	java/lang/Exception
    //   2	7	580	finally
    //   15	64	580	finally
    //   64	85	580	finally
    //   85	100	580	finally
    //   100	119	580	finally
    //   119	130	580	finally
    //   130	149	580	finally
    //   149	250	580	finally
    //   250	265	580	finally
    //   265	274	580	finally
    //   274	351	580	finally
    //   351	370	580	finally
    //   370	379	580	finally
    //   384	395	580	finally
    //   400	419	580	finally
    //   419	429	580	finally
    //   429	446	580	finally
    //   446	462	580	finally
    //   462	470	580	finally
    //   475	494	580	finally
    //   494	502	580	finally
    //   507	526	580	finally
    //   526	534	580	finally
    //   539	558	580	finally
    //   558	566	580	finally
    //   571	577	580	finally
    //   587	593	580	finally
    //   598	604	580	finally
    //   609	615	580	finally
    //   620	626	580	finally
    //   631	637	580	finally
    //   640	648	580	finally
    //   653	659	580	finally
    //   662	670	580	finally
    //   675	681	580	finally
    //   684	692	580	finally
    //   697	703	580	finally
    //   64	85	585	java/lang/Exception
    //   265	274	596	java/lang/Exception
    //   274	351	607	java/lang/Exception
    //   351	370	618	java/lang/Exception
    //   370	379	618	java/lang/Exception
    //   384	395	618	java/lang/Exception
    //   400	419	618	java/lang/Exception
    //   419	429	618	java/lang/Exception
    //   446	462	629	java/lang/Exception
    //   462	470	651	java/lang/Exception
    //   475	494	651	java/lang/Exception
    //   640	648	651	java/lang/Exception
    //   494	502	673	java/lang/Exception
    //   507	526	673	java/lang/Exception
    //   662	670	673	java/lang/Exception
    //   526	534	695	java/lang/Exception
    //   539	558	695	java/lang/Exception
    //   684	692	695	java/lang/Exception
  }

  public void b(Context paramContext)
  {
    while (true)
    {
      try
      {
        int i1 = b.c().length();
        if (i1 > 0)
          return;
        a(paramContext);
        try
        {
          JSONObject localJSONObject1 = b.c();
          if (a == null)
          {
            str1 = "";
            localJSONObject1.put("o", str1);
            JSONObject localJSONObject2 = b.c();
            if (this.b != null)
              break label487;
            str2 = "";
            localJSONObject2.put("s", str2);
            JSONObject localJSONObject3 = b.c();
            if (this.c != null)
              break label496;
            str3 = "";
            localJSONObject3.put("k", str3);
            JSONObject localJSONObject4 = b.c();
            if (this.d != null)
              break label505;
            str4 = "";
            localJSONObject4.put("i", str4);
            b.c().put("v", "3.3");
            b.c().put("a", this.e);
            JSONObject localJSONObject5 = b.c();
            if (this.f != null)
              break label514;
            str5 = "";
            localJSONObject5.put("n", str5);
            JSONObject localJSONObject6 = b.c();
            if (this.g != null)
              break label523;
            str6 = "";
            localJSONObject6.put("d", str6);
            b.c().put("w", this.h);
            b.c().put("h", this.i);
            JSONObject localJSONObject7 = b.c();
            if (this.j != null)
              break label532;
            str7 = "";
            localJSONObject7.put("c", str7);
            JSONObject localJSONObject8 = b.c();
            if (this.k != null)
              break label541;
            str8 = "";
            localJSONObject8.put("op", str8);
            JSONObject localJSONObject9 = b.c();
            if (this.l != null)
              break label550;
            str9 = "";
            localJSONObject9.put("m", str9);
            b.c().put("cl", this.m);
            JSONObject localJSONObject10 = b.c();
            if (this.n != null)
              break label559;
            str10 = "";
            localJSONObject10.put("gl", str10);
            JSONObject localJSONObject11 = b.c();
            if (this.o != null)
              break label568;
            str11 = "";
            localJSONObject11.put("wl", str11);
            JSONObject localJSONObject12 = b.c();
            if (this.p != null)
              break label577;
            str12 = "";
            localJSONObject12.put("l", str12);
            b.c().put("t", System.currentTimeMillis());
            b.c().put("sq", 0);
            com.baidu.mobstat.a.c.a("stat", b.c().toString());
          }
        }
        catch (JSONException localJSONException)
        {
          com.baidu.mobstat.a.c.a("stat", "header ini error");
          throw new RuntimeException("header ini error");
        }
      }
      finally
      {
      }
      String str1 = a;
      continue;
      label487: String str2 = this.b;
      continue;
      label496: String str3 = this.c;
      continue;
      label505: String str4 = this.d;
      continue;
      label514: String str5 = this.f;
      continue;
      label523: String str6 = this.g;
      continue;
      label532: String str7 = this.j;
      continue;
      label541: String str8 = this.k;
      continue;
      label550: String str9 = this.l;
      continue;
      label559: String str10 = this.n;
      continue;
      label568: String str11 = this.o;
      continue;
      label577: String str12 = this.p;
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.c
 * JD-Core Version:    0.6.2
 */