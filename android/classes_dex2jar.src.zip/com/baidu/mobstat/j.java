package com.baidu.mobstat;

import android.content.Context;
import com.baidu.mobstat.a.c;
import org.json.JSONArray;
import org.json.JSONObject;

class j
{
  private static j a = new j();
  private boolean b = false;

  public static j a()
  {
    return a;
  }

  public void a(Context paramContext)
  {
    c.a("stat", "openExceptonAnalysis");
    if (!this.b)
    {
      this.b = true;
      a.a().a(paramContext);
    }
  }

  public void b(Context paramContext)
  {
    if (paramContext == null)
      c.a("stat", "exceptonAnalysis, context=null");
    while (true)
    {
      return;
      JSONArray localJSONArray = a.a().b(paramContext);
      if (localJSONArray == null)
      {
        c.a("stat", "no exception str");
        return;
      }
      c.a("stat", "move exception cache to stat cache");
      int i = 0;
      try
      {
        while (i < localJSONArray.length())
        {
          JSONObject localJSONObject = (JSONObject)localJSONArray.get(i);
          b.a().a(localJSONObject.getLong("t"), localJSONObject.getString("c"), localJSONObject.getString("y"));
          b.a().b(paramContext);
          i++;
        }
      }
      catch (Exception localException)
      {
        c.a("stat", localException);
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.j
 * JD-Core Version:    0.6.2
 */