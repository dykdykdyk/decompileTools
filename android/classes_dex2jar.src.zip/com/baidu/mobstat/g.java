package com.baidu.mobstat;

import android.content.Context;
import com.baidu.mobstat.a.c;
import java.util.HashMap;

class g
  implements Runnable
{
  g(d paramd, String paramString1, String paramString2, long paramLong, Context paramContext)
  {
  }

  public void run()
  {
    if (!k.a().c());
    String str;
    i locali;
    synchronized (k.a())
    {
      try
      {
        k.a().wait();
        str = this.e.a(this.a, this.b);
        locali = (i)this.e.a.get(str);
        if (locali == null)
        {
          Object[] arrayOfObject = new Object[2];
          arrayOfObject[0] = "stat";
          arrayOfObject[1] = ("EventStat: event_id[" + this.a + "] with label[" + this.b + "] is not started or alread done.");
          c.b(arrayOfObject);
          return;
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          c.a("stat", localInterruptedException);
      }
    }
    if ((!this.a.equals(locali.a)) || (!this.b.equals(locali.b)))
    {
      c.a("stat", "EventStat: Wrong Case, eventId/label pair not match");
      return;
    }
    this.e.a.remove(str);
    long l = this.c - locali.c;
    if (l <= 0L)
    {
      c.a("stat", "EventStat: Wrong Case, Duration must be positive");
      return;
    }
    b.a().a(this.a, this.b, 1, locali.c, l);
    b.a().b(this.d);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.g
 * JD-Core Version:    0.6.2
 */