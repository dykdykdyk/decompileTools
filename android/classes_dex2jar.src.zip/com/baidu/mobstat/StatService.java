package com.baidu.mobstat;

import android.app.Activity;
import android.content.Context;
import android.support.v4.app.Fragment;
import com.baidu.mobstat.a.c;

public class StatService
{
  public static final int EXCEPTION_LOG = 1;
  private static boolean a = false;

  private static void a(Context paramContext)
  {
    if (!a(paramContext, "onError(...)"))
      return;
    j.a().a(paramContext.getApplicationContext());
    l.a().a(true, paramContext.getApplicationContext());
  }

  private static boolean a()
  {
    return a;
  }

  private static boolean a(Context paramContext, String paramString)
  {
    if (paramContext == null)
    {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = "stat";
      arrayOfObject[1] = (paramString + ":context=null");
      c.c(arrayOfObject);
      return false;
    }
    return true;
  }

  private static boolean a(Class<?> paramClass, String paramString)
  {
    int i = 2;
    StackTraceElement[] arrayOfStackTraceElement = new Throwable().getStackTrace();
    Object[] arrayOfObject = new Object[4];
    arrayOfObject[0] = "isCalledBy";
    arrayOfObject[1] = Integer.valueOf(arrayOfStackTraceElement.length);
    arrayOfObject[i] = paramClass;
    arrayOfObject[3] = paramString;
    c.a(arrayOfObject);
    int j = arrayOfStackTraceElement.length;
    boolean bool = false;
    if (j >= i)
      if (i < arrayOfStackTraceElement.length)
      {
        StackTraceElement localStackTraceElement = arrayOfStackTraceElement[i];
        if (localStackTraceElement.getMethodName().equals(paramString))
          try
          {
            Class localClass = Class.forName(localStackTraceElement.getClassName());
            c.a(new Object[] { "isCalledBy", localClass });
            while ((localClass.getSuperclass() != null) && (localClass.getSuperclass() != paramClass))
            {
              localClass = localClass.getSuperclass();
              c.a(new Object[] { "isCalledBy", localClass });
            }
          }
          catch (Exception localException)
          {
            c.a(localException);
          }
        while (true)
        {
          i++;
          break;
          bool = true;
        }
      }
    return bool;
  }

  private static void b()
  {
    a = true;
  }

  private static void b(Context paramContext)
  {
    if (!k.a().b())
      k.a().a(paramContext.getApplicationContext());
  }

  public static void onEvent(Context paramContext, String paramString1, String paramString2)
  {
    onEvent(paramContext, paramString1, paramString2, 1);
  }

  public static void onEvent(Context paramContext, String paramString1, String paramString2, int paramInt)
  {
    if (!a(paramContext, "onEvent(...)"));
    while ((paramString1 == null) || (paramString1.equals("")))
      return;
    b(paramContext);
    d.a().a(paramContext.getApplicationContext(), paramString1, paramString2, paramInt, System.currentTimeMillis());
  }

  public static void onEventDuration(Context paramContext, String paramString1, String paramString2, long paramLong)
  {
    if (!a(paramContext, "onEventDuration(...)"));
    while ((paramString1 == null) || (paramString1.equals("")))
      return;
    if (paramLong <= 0L)
    {
      c.b(new Object[] { "stat", "onEventDuration: duration must be greater than zero" });
      return;
    }
    b(paramContext);
    d.a().c(paramContext.getApplicationContext(), paramString1, paramString2, paramLong);
  }

  public static void onEventEnd(Context paramContext, String paramString1, String paramString2)
  {
    if (!a(paramContext, "onEventEnd(...)"));
    while ((paramString1 == null) || (paramString1.equals("")))
      return;
    b(paramContext);
    d.a().b(paramContext.getApplicationContext(), paramString1, paramString2, System.currentTimeMillis());
  }

  public static void onEventStart(Context paramContext, String paramString1, String paramString2)
  {
    if (!a(paramContext, "onEventStart(...)"));
    while ((paramString1 == null) || (paramString1.equals("")))
      return;
    b(paramContext);
    d.a().a(paramContext.getApplicationContext(), paramString1, paramString2, System.currentTimeMillis());
  }

  public static void onPageEnd(Context paramContext, String paramString)
  {
    if ((paramContext != null) && (paramString != null));
    try
    {
      if (paramString.equals(""))
        c.c(new Object[] { "stat", "onPageEnd :parame=null || empty" });
      while (true)
      {
        return;
        s.b().b(paramContext, System.currentTimeMillis(), paramString);
      }
    }
    finally
    {
    }
  }

  public static void onPageStart(Context paramContext, String paramString)
  {
    if ((paramContext != null) && (paramString != null));
    try
    {
      if (paramString.equals(""))
        c.c(new Object[] { "stat", "onPageStart :parame=null || empty" });
      while (true)
      {
        return;
        b(paramContext);
        s.b().a(paramContext, System.currentTimeMillis(), paramString);
      }
    }
    finally
    {
    }
  }

  public static void onPause(Context paramContext)
  {
    while (true)
    {
      try
      {
        boolean bool = a(paramContext, "onPause(...)");
        if (!bool)
          return;
        if (!a(Activity.class, "onPause"))
          throw new SecurityException("onPause(Context context)不在Activity.onPause()中被调用||onPause(Context context)is not called in Activity.onPause().");
      }
      finally
      {
      }
      s.b().b(paramContext, System.currentTimeMillis());
    }
  }

  public static void onPause(Fragment paramFragment)
  {
    if (paramFragment == null);
    while (true)
    {
      try
      {
        c.c(new Object[] { "stat", "onResume :parame=null" });
        return;
        if (!a(Fragment.class, "onPause"))
          throw new SecurityException("Fragment onPause(Context context)不在Fragment.onPause()中被调用||onPause(Context context)is not called in Fragment.onPause().");
      }
      finally
      {
      }
      s.b().b(paramFragment, System.currentTimeMillis());
    }
  }

  public static void onPause(Object paramObject)
  {
    if (paramObject == null);
    while (true)
    {
      try
      {
        c.c(new Object[] { "stat", "android.app.Fragment onResume :parame=null" });
        return;
        if (!a(paramObject.getClass(), "onPause"))
          throw new SecurityException("android.app.Fragment onPause(Context context)不在android.app.Fragment.onPause()中被调用||onPause(Context context)is not called in android.app.Fragment.onPause().");
      }
      finally
      {
      }
      s.b().b(paramObject, System.currentTimeMillis());
    }
  }

  public static void onResume(Context paramContext)
  {
    while (true)
    {
      try
      {
        boolean bool = a(paramContext, "onResume(...)");
        if (!bool)
          return;
        if (!a(Activity.class, "onResume"))
          throw new SecurityException("onResume(Context context)不在Activity.onResume()中被调用||onResume(Context context)is not called in Activity.onResume().");
      }
      finally
      {
      }
      b(paramContext);
      s.b().a(paramContext, System.currentTimeMillis());
    }
  }

  public static void onResume(Fragment paramFragment)
  {
    if (paramFragment == null);
    while (true)
    {
      try
      {
        c.c(new Object[] { "stat", "onResume :parame=null" });
        return;
        if (!a(Fragment.class, "onResume"))
          throw new SecurityException("onResume(Context context)不在Activity.onResume()中被调用||onResume(Context context)is not called in Activity.onResume().");
      }
      finally
      {
      }
      b(paramFragment.getActivity());
      s.b().a(paramFragment, System.currentTimeMillis());
    }
  }

  public static void onResume(Object paramObject)
  {
    if (paramObject == null);
    while (true)
    {
      try
      {
        c.c(new Object[] { "stat", "onResume :parame=null" });
        return;
        if (!a(paramObject.getClass(), "onResume"))
          throw new SecurityException("onResume(Context context)不在Activity.onResume()中被调用||onResume(Context context)is not called in Activity.onResume().");
      }
      finally
      {
      }
      b(s.a(paramObject));
      s.b().a(paramObject, System.currentTimeMillis());
    }
  }

  public static void setAppChannel(Context paramContext, String paramString, boolean paramBoolean)
  {
    b.a().a(paramContext, paramString, paramBoolean);
  }

  public static void setAppChannel(String paramString)
  {
    b.a().b(paramString);
  }

  public static void setAppKey(String paramString)
  {
    b.a().a(paramString);
  }

  public static void setDebugOn(boolean paramBoolean)
  {
    if (paramBoolean)
    {
      com.baidu.mobstat.a.a.a = 2;
      return;
    }
    com.baidu.mobstat.a.a.a = 7;
  }

  public static void setLogSenderDelayed(int paramInt)
  {
    l.a().a(paramInt);
  }

  public static void setOn(Context paramContext, int paramInt)
  {
    if (!a(paramContext, "setOn(...)"));
    do
    {
      do
      {
        return;
        if (!a(Activity.class, "onCreate"))
          throw new SecurityException("setOn()没有在Activity.onCreate()内被调用||setOn()is not called in Activity.onCreate().");
      }
      while (a());
      b();
    }
    while ((paramInt & 0x1) == 0);
    a(paramContext);
  }

  public static void setSendLogStrategy(Context paramContext, SendStrategyEnum paramSendStrategyEnum, int paramInt)
  {
    setSendLogStrategy(paramContext, paramSendStrategyEnum, paramInt, false);
  }

  public static void setSendLogStrategy(Context paramContext, SendStrategyEnum paramSendStrategyEnum, int paramInt, boolean paramBoolean)
  {
    if (!a(paramContext, "setSendLogStrategy(...)"))
      return;
    b(paramContext);
    l.a().a(paramContext.getApplicationContext(), paramSendStrategyEnum, paramInt, paramBoolean);
  }

  public static void setSessionTimeOut(int paramInt)
  {
    if (paramInt <= 0)
    {
      c.b("SessionTimeOut is between 1 and 600. Default value[30] is used");
      return;
    }
    if (paramInt <= 600)
    {
      s.b().a(paramInt);
      return;
    }
    c.b("SessionTimeOut is between 1 and 600. Value[600] is used");
    s.b().a(paramInt);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.StatService
 * JD-Core Version:    0.6.2
 */