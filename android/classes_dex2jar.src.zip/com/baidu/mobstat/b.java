package com.baidu.mobstat;

import android.content.Context;
import com.baidu.a.a.a.b.a;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

class b
{
  static c a = new c();
  private static JSONObject c = new JSONObject();
  private static b i = new b();
  private int b = 0;
  private JSONArray d = new JSONArray();
  private JSONArray e = new JSONArray();
  private JSONArray f = new JSONArray();
  private JSONArray g = new JSONArray();
  private boolean h = false;

  public static b a()
  {
    return i;
  }

  private void a(boolean paramBoolean)
  {
    this.h = paramBoolean;
  }

  private static String b(String paramString, Context paramContext)
  {
    if (paramString == null)
      paramString = null;
    while (!paramString.equals("000000000000000"))
      return paramString;
    String str = h(paramContext);
    com.baidu.mobstat.a.c.a("stat", "imei=null,mac=" + str);
    return str;
  }

  private boolean d()
  {
    return this.h;
  }

  static String f(Context paramContext)
  {
    if (c.b(a) == null)
    {
      c.c(a, BasicStoreTools.getInstance().loadGenerateDeviceCUID(paramContext));
      if ((c.b(a) != null) && (!"".equalsIgnoreCase(c.b(a))));
    }
    try
    {
      c.c(a, a.a(paramContext));
      BasicStoreTools.getInstance().setGenerateDeviceCUID(paramContext, c.b(a));
      return c.b(a);
    }
    catch (Exception localException)
    {
      while (true)
      {
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = "stat";
        arrayOfObject[1] = localException.getMessage();
        com.baidu.mobstat.a.c.c(arrayOfObject);
      }
    }
  }

  private static String h(Context paramContext)
  {
    String str = z.g(paramContext);
    if (str != null)
      return str.replaceAll(":", "");
    return null;
  }

  public void a(long paramLong, String paramString1, String paramString2)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("t", paramLong);
      localJSONObject.put("y", paramString2);
      if (paramString1.getBytes().length > 5120)
      {
        byte[] arrayOfByte = new byte[5120];
        paramString1.getBytes(0, 5120, arrayOfByte, 0);
        int j = arrayOfByte.length;
        com.baidu.mobstat.a.c.a("exception bytes=" + j);
        localJSONObject.put("c", new String(arrayOfByte));
      }
      while (true)
      {
        c(localJSONObject, false);
        return;
        localJSONObject.put("c", paramString1);
      }
    }
    catch (JSONException localJSONException)
    {
      while (true)
        com.baidu.mobstat.a.c.a("stat", localJSONException);
    }
  }

  public void a(Context paramContext)
  {
    try
    {
      a.b(paramContext);
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void a(Context paramContext, String paramString, boolean paramBoolean)
  {
    if ((paramString == null) || (paramString.equals("")))
      com.baidu.mobstat.a.c.c(new Object[] { "stat", "设置的渠道不能为空或者为null || The channel that you have been set is null or empty, please check it." });
    c.b(a, paramString);
    if ((paramBoolean) && (paramString != null) && (!paramString.equals("")))
    {
      BasicStoreTools.getInstance().setAppChannelWithPreference(paramContext, paramString);
      BasicStoreTools.getInstance().setAppChannelWithCode(paramContext, true);
    }
    if (!paramBoolean)
    {
      BasicStoreTools.getInstance().setAppChannelWithPreference(paramContext, "");
      BasicStoreTools.getInstance().setAppChannelWithCode(paramContext, false);
    }
  }

  public void a(String paramString)
  {
    c.a(a, paramString);
  }

  public void a(String paramString1, String paramString2, int paramInt, long paramLong1, long paramLong2)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("i", paramString1);
      localJSONObject.put("l", paramString2);
      localJSONObject.put("c", paramInt);
      localJSONObject.put("t", paramLong1);
      localJSONObject.put("d", paramLong2);
      b(localJSONObject, false);
      com.baidu.mobstat.a.c.a("stat", "put event:" + localJSONObject.toString());
      return;
    }
    catch (JSONException localJSONException)
    {
      com.baidu.mobstat.a.c.a("stat", localJSONException);
    }
  }

  public void a(JSONObject paramJSONObject, boolean paramBoolean)
  {
    if ((paramJSONObject != null) && (!paramBoolean))
    {
      int k = paramJSONObject.toString().getBytes().length;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = "stat";
      arrayOfObject[1] = "putSession:addSize is:";
      arrayOfObject[2] = Integer.valueOf(k);
      com.baidu.mobstat.a.c.a(arrayOfObject);
      if (k + this.b > 204800)
      {
        com.baidu.mobstat.a.c.a("stat", "putSession: size is full!");
        return;
      }
    }
    int j;
    synchronized (this.d)
    {
      j = this.d.length();
    }
    try
    {
      this.d.put(j, paramJSONObject);
      return;
      localObject = finally;
      throw localObject;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        com.baidu.mobstat.a.c.a("stat", localJSONException);
    }
  }

  // ERROR //
  public void b(Context paramContext)
  {
    // Byte code:
    //   0: ldc 70
    //   2: ldc 229
    //   4: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   7: pop
    //   8: new 30	org/json/JSONObject
    //   11: dup
    //   12: invokespecial 31	org/json/JSONObject:<init>	()V
    //   15: astore_3
    //   16: aload_0
    //   17: getfield 44	com/baidu/mobstat/b:d	Lorg/json/JSONArray;
    //   20: astore 10
    //   22: aload 10
    //   24: monitorenter
    //   25: aload_3
    //   26: ldc 231
    //   28: new 41	org/json/JSONArray
    //   31: dup
    //   32: aload_0
    //   33: getfield 44	com/baidu/mobstat/b:d	Lorg/json/JSONArray;
    //   36: invokevirtual 232	org/json/JSONArray:toString	()Ljava/lang/String;
    //   39: invokespecial 234	org/json/JSONArray:<init>	(Ljava/lang/String;)V
    //   42: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   45: pop
    //   46: aload 10
    //   48: monitorexit
    //   49: aload_0
    //   50: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   53: astore 13
    //   55: aload 13
    //   57: monitorenter
    //   58: aload_3
    //   59: ldc 236
    //   61: new 41	org/json/JSONArray
    //   64: dup
    //   65: aload_0
    //   66: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   69: invokevirtual 232	org/json/JSONArray:toString	()Ljava/lang/String;
    //   72: invokespecial 234	org/json/JSONArray:<init>	(Ljava/lang/String;)V
    //   75: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   78: pop
    //   79: aload 13
    //   81: monitorexit
    //   82: aload_0
    //   83: getfield 50	com/baidu/mobstat/b:g	Lorg/json/JSONArray;
    //   86: astore 16
    //   88: aload 16
    //   90: monitorenter
    //   91: aload_3
    //   92: ldc 238
    //   94: new 41	org/json/JSONArray
    //   97: dup
    //   98: aload_0
    //   99: getfield 50	com/baidu/mobstat/b:g	Lorg/json/JSONArray;
    //   102: invokevirtual 232	org/json/JSONArray:toString	()Ljava/lang/String;
    //   105: invokespecial 234	org/json/JSONArray:<init>	(Ljava/lang/String;)V
    //   108: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   111: pop
    //   112: aload 16
    //   114: monitorexit
    //   115: aload_3
    //   116: invokevirtual 207	org/json/JSONObject:toString	()Ljava/lang/String;
    //   119: astore 6
    //   121: aload_0
    //   122: invokespecial 240	com/baidu/mobstat/b:d	()Z
    //   125: ifeq +49 -> 174
    //   128: ldc 70
    //   130: ldc 242
    //   132: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   135: pop
    //   136: return
    //   137: astore 11
    //   139: aload 10
    //   141: monitorexit
    //   142: aload 11
    //   144: athrow
    //   145: astore 4
    //   147: ldc 70
    //   149: ldc 244
    //   151: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   154: pop
    //   155: goto -40 -> 115
    //   158: astore 14
    //   160: aload 13
    //   162: monitorexit
    //   163: aload 14
    //   165: athrow
    //   166: astore 17
    //   168: aload 16
    //   170: monitorexit
    //   171: aload 17
    //   173: athrow
    //   174: aload 6
    //   176: invokevirtual 155	java/lang/String:getBytes	()[B
    //   179: arraylength
    //   180: istore 7
    //   182: iload 7
    //   184: ldc 218
    //   186: if_icmplt +9 -> 195
    //   189: aload_0
    //   190: iconst_1
    //   191: invokespecial 246	com/baidu/mobstat/b:a	(Z)V
    //   194: return
    //   195: aload_0
    //   196: iload 7
    //   198: putfield 39	com/baidu/mobstat/b:b	I
    //   201: ldc 70
    //   203: new 72	java/lang/StringBuilder
    //   206: dup
    //   207: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   210: ldc 248
    //   212: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: aload_0
    //   216: getfield 39	com/baidu/mobstat/b:b	I
    //   219: invokevirtual 163	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   222: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   225: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   228: pop
    //   229: iconst_0
    //   230: aload_1
    //   231: ldc 250
    //   233: aload 6
    //   235: iconst_0
    //   236: invokestatic 255	com/baidu/mobstat/a/b:a	(ZLandroid/content/Context;Ljava/lang/String;Ljava/lang/String;Z)V
    //   239: return
    //
    // Exception table:
    //   from	to	target	type
    //   25	49	137	finally
    //   139	142	137	finally
    //   16	25	145	org/json/JSONException
    //   49	58	145	org/json/JSONException
    //   82	91	145	org/json/JSONException
    //   142	145	145	org/json/JSONException
    //   163	166	145	org/json/JSONException
    //   171	174	145	org/json/JSONException
    //   58	82	158	finally
    //   160	163	158	finally
    //   91	115	166	finally
    //   168	171	166	finally
  }

  public void b(String paramString)
  {
    if ((paramString == null) || (paramString.equals("")))
      com.baidu.mobstat.a.c.c(new Object[] { "stat", "设置的渠道不能为空或者为null || The channel that you have been set is null or empty, please check it." });
    c.b(a, paramString);
  }

  // ERROR //
  public void b(JSONObject paramJSONObject, boolean paramBoolean)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +73 -> 74
    //   4: iload_2
    //   5: ifne +69 -> 74
    //   8: aload_1
    //   9: invokevirtual 207	org/json/JSONObject:toString	()Ljava/lang/String;
    //   12: invokevirtual 155	java/lang/String:getBytes	()[B
    //   15: arraylength
    //   16: istore 54
    //   18: iconst_3
    //   19: anewarray 4	java/lang/Object
    //   22: astore 55
    //   24: aload 55
    //   26: iconst_0
    //   27: ldc 70
    //   29: aastore
    //   30: aload 55
    //   32: iconst_1
    //   33: ldc_w 257
    //   36: aastore
    //   37: aload 55
    //   39: iconst_2
    //   40: iload 54
    //   42: invokestatic 215	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   45: aastore
    //   46: aload 55
    //   48: invokestatic 217	com/baidu/mobstat/a/c:a	([Ljava/lang/Object;)I
    //   51: pop
    //   52: iload 54
    //   54: aload_0
    //   55: getfield 39	com/baidu/mobstat/b:b	I
    //   58: iadd
    //   59: ldc 218
    //   61: if_icmple +13 -> 74
    //   64: ldc 70
    //   66: ldc_w 259
    //   69: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   72: pop
    //   73: return
    //   74: aload_1
    //   75: ldc 196
    //   77: invokevirtual 263	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   80: astore 5
    //   82: aload_1
    //   83: ldc 198
    //   85: invokevirtual 263	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   88: astore 6
    //   90: aload_1
    //   91: ldc 142
    //   93: invokevirtual 267	org/json/JSONObject:getLong	(Ljava/lang/String;)J
    //   96: ldc2_w 268
    //   99: ldiv
    //   100: lstore 7
    //   102: aload_1
    //   103: ldc_w 271
    //   106: invokevirtual 274	org/json/JSONObject:optString	(Ljava/lang/String;)Ljava/lang/String;
    //   109: astore 9
    //   111: aload_1
    //   112: ldc 202
    //   114: invokevirtual 277	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   117: istore 53
    //   119: iload 53
    //   121: istore 12
    //   123: iload 12
    //   125: ifne +449 -> 574
    //   128: aload_0
    //   129: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   132: astore 20
    //   134: aload 20
    //   136: monitorenter
    //   137: aload_0
    //   138: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   141: invokevirtual 224	org/json/JSONArray:length	()I
    //   144: istore 22
    //   146: aload 9
    //   148: ifnull +13 -> 161
    //   151: aload 9
    //   153: ldc 109
    //   155: invokevirtual 65	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   158: ifeq +14 -> 172
    //   161: aload_1
    //   162: ldc_w 271
    //   165: ldc_w 279
    //   168: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   171: pop
    //   172: iconst_0
    //   173: istore 25
    //   175: iload 22
    //   177: istore 26
    //   179: iload 25
    //   181: iload 22
    //   183: if_icmpge +469 -> 652
    //   186: aload_0
    //   187: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   190: iload 25
    //   192: invokevirtual 283	org/json/JSONArray:getJSONObject	(I)Lorg/json/JSONObject;
    //   195: astore 32
    //   197: ldc 70
    //   199: new 72	java/lang/StringBuilder
    //   202: dup
    //   203: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   206: ldc_w 285
    //   209: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   212: aload 32
    //   214: invokevirtual 207	org/json/JSONObject:toString	()Ljava/lang/String;
    //   217: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   223: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   226: pop
    //   227: aload 32
    //   229: ldc 196
    //   231: invokevirtual 263	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   234: astore 34
    //   236: aload 32
    //   238: ldc 198
    //   240: invokevirtual 263	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   243: astore 35
    //   245: aload 32
    //   247: ldc 142
    //   249: invokevirtual 267	org/json/JSONObject:getLong	(Ljava/lang/String;)J
    //   252: ldc2_w 268
    //   255: ldiv
    //   256: lstore 36
    //   258: aload 32
    //   260: ldc 202
    //   262: invokevirtual 277	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   265: istore 51
    //   267: iload 51
    //   269: istore 40
    //   271: lload 36
    //   273: lload 7
    //   275: lcmp
    //   276: ifne +8 -> 284
    //   279: iload 40
    //   281: ifeq +87 -> 368
    //   284: iinc 25 1
    //   287: goto -108 -> 179
    //   290: astore_3
    //   291: ldc 70
    //   293: aload_3
    //   294: invokestatic 176	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   297: pop
    //   298: return
    //   299: astore 10
    //   301: ldc 70
    //   303: ldc_w 287
    //   306: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   309: pop
    //   310: iconst_0
    //   311: istore 12
    //   313: goto -190 -> 123
    //   316: astore 23
    //   318: ldc 70
    //   320: ldc_w 289
    //   323: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   326: pop
    //   327: goto -155 -> 172
    //   330: astore 21
    //   332: aload 20
    //   334: monitorexit
    //   335: aload 21
    //   337: athrow
    //   338: astore 38
    //   340: ldc 70
    //   342: ldc_w 287
    //   345: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   348: pop
    //   349: iconst_0
    //   350: istore 40
    //   352: goto -81 -> 271
    //   355: astore 30
    //   357: ldc 70
    //   359: aload 30
    //   361: invokestatic 176	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   364: pop
    //   365: goto -81 -> 284
    //   368: ldc 70
    //   370: new 72	java/lang/StringBuilder
    //   373: dup
    //   374: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   377: ldc_w 285
    //   380: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   383: aload 32
    //   385: invokevirtual 207	org/json/JSONObject:toString	()Ljava/lang/String;
    //   388: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   391: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   394: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   397: pop
    //   398: aload 34
    //   400: aload 5
    //   402: invokevirtual 65	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   405: ifeq -121 -> 284
    //   408: aload 35
    //   410: aload 6
    //   412: invokevirtual 65	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   415: ifeq -131 -> 284
    //   418: aload_1
    //   419: ldc 167
    //   421: invokevirtual 277	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   424: aload 32
    //   426: ldc 167
    //   428: invokevirtual 277	org/json/JSONObject:getInt	(Ljava/lang/String;)I
    //   431: iadd
    //   432: istore 42
    //   434: aload 32
    //   436: ldc_w 271
    //   439: invokevirtual 274	org/json/JSONObject:optString	(Ljava/lang/String;)Ljava/lang/String;
    //   442: astore 43
    //   444: aload 43
    //   446: ifnull +213 -> 659
    //   449: aload 43
    //   451: ldc 109
    //   453: invokevirtual 113	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   456: ifeq +6 -> 462
    //   459: goto +200 -> 659
    //   462: aload_1
    //   463: ldc 142
    //   465: invokevirtual 267	org/json/JSONObject:getLong	(Ljava/lang/String;)J
    //   468: aload 32
    //   470: ldc 142
    //   472: invokevirtual 267	org/json/JSONObject:getLong	(Ljava/lang/String;)J
    //   475: lsub
    //   476: lstore 44
    //   478: new 72	java/lang/StringBuilder
    //   481: dup
    //   482: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   485: aload 43
    //   487: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   490: lload 44
    //   492: invokevirtual 292	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   495: ldc_w 294
    //   498: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   501: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   504: astore 46
    //   506: aload 32
    //   508: ldc 167
    //   510: invokevirtual 298	org/json/JSONObject:remove	(Ljava/lang/String;)Ljava/lang/Object;
    //   513: pop
    //   514: aload 32
    //   516: ldc 167
    //   518: iload 42
    //   520: invokevirtual 201	org/json/JSONObject:put	(Ljava/lang/String;I)Lorg/json/JSONObject;
    //   523: pop
    //   524: aload 32
    //   526: ldc_w 271
    //   529: aload 46
    //   531: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   534: pop
    //   535: iload 25
    //   537: iload 22
    //   539: if_icmpge +7 -> 546
    //   542: aload 20
    //   544: monitorexit
    //   545: return
    //   546: aload_0
    //   547: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   550: iload 22
    //   552: aload_1
    //   553: invokevirtual 227	org/json/JSONArray:put	(ILjava/lang/Object;)Lorg/json/JSONArray;
    //   556: pop
    //   557: aload 20
    //   559: monitorexit
    //   560: return
    //   561: astore 27
    //   563: ldc 70
    //   565: aload 27
    //   567: invokestatic 176	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   570: pop
    //   571: goto -14 -> 557
    //   574: aload_0
    //   575: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   578: astore 13
    //   580: aload 13
    //   582: monitorenter
    //   583: aload_0
    //   584: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   587: invokevirtual 224	org/json/JSONArray:length	()I
    //   590: istore 15
    //   592: aload_1
    //   593: ldc_w 271
    //   596: ldc_w 300
    //   599: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   602: pop
    //   603: aload_0
    //   604: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   607: iload 15
    //   609: aload_1
    //   610: invokevirtual 227	org/json/JSONArray:put	(ILjava/lang/Object;)Lorg/json/JSONArray;
    //   613: pop
    //   614: aload 13
    //   616: monitorexit
    //   617: return
    //   618: astore 14
    //   620: aload 13
    //   622: monitorexit
    //   623: aload 14
    //   625: athrow
    //   626: astore 16
    //   628: ldc 70
    //   630: aload 16
    //   632: invokestatic 176	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   635: pop
    //   636: goto -22 -> 614
    //   639: astore 47
    //   641: aload 47
    //   643: astore 30
    //   645: iload 25
    //   647: istore 26
    //   649: goto -292 -> 357
    //   652: iload 26
    //   654: istore 25
    //   656: goto -121 -> 535
    //   659: ldc_w 279
    //   662: astore 43
    //   664: goto -202 -> 462
    //
    // Exception table:
    //   from	to	target	type
    //   74	111	290	org/json/JSONException
    //   111	119	299	org/json/JSONException
    //   151	161	316	org/json/JSONException
    //   161	172	316	org/json/JSONException
    //   137	146	330	finally
    //   151	161	330	finally
    //   161	172	330	finally
    //   186	258	330	finally
    //   258	267	330	finally
    //   318	327	330	finally
    //   332	335	330	finally
    //   340	349	330	finally
    //   357	365	330	finally
    //   368	444	330	finally
    //   449	459	330	finally
    //   462	506	330	finally
    //   506	535	330	finally
    //   542	545	330	finally
    //   546	557	330	finally
    //   557	560	330	finally
    //   563	571	330	finally
    //   258	267	338	org/json/JSONException
    //   186	258	355	org/json/JSONException
    //   340	349	355	org/json/JSONException
    //   368	444	355	org/json/JSONException
    //   449	459	355	org/json/JSONException
    //   462	506	355	org/json/JSONException
    //   546	557	561	org/json/JSONException
    //   583	592	618	finally
    //   592	614	618	finally
    //   614	617	618	finally
    //   620	623	618	finally
    //   628	636	618	finally
    //   592	614	626	org/json/JSONException
    //   506	535	639	org/json/JSONException
  }

  public boolean b()
  {
    return (this.d.length() == 0) && (this.e.length() == 0) && (this.g.length() == 0);
  }

  public void c(Context paramContext)
  {
    com.baidu.mobstat.a.c.a("stat", "LoadLastSession()");
    if (paramContext == null);
    while (!com.baidu.mobstat.a.b.c(paramContext, "__local_last_session.json"))
      return;
    String str = com.baidu.mobstat.a.b.a(false, paramContext, "__local_last_session.json");
    if (str.equals(""))
    {
      com.baidu.mobstat.a.c.a("stat", "loadLastSession(): last_session.json file not found.");
      return;
    }
    com.baidu.mobstat.a.b.a(false, paramContext, "__local_last_session.json", new JSONObject().toString(), false);
    c(str);
    b(paramContext);
  }

  public void c(String paramString)
  {
    if ((paramString.equals("{}")) || (paramString.equals("")))
      return;
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      a(localJSONObject, false);
      com.baidu.mobstat.a.c.a("stat", "Load last session:" + localJSONObject);
      return;
    }
    catch (JSONException localJSONException)
    {
      com.baidu.mobstat.a.c.a("stat", "putSession()" + localJSONException);
    }
  }

  public void c(JSONObject paramJSONObject, boolean paramBoolean)
  {
    if ((paramJSONObject != null) && (!paramBoolean))
    {
      int k = paramJSONObject.toString().getBytes().length;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = "stat";
      arrayOfObject[1] = "putException:addSize is:";
      arrayOfObject[2] = Integer.valueOf(k);
      com.baidu.mobstat.a.c.a(arrayOfObject);
      if (k + this.b > 204800)
      {
        com.baidu.mobstat.a.c.a("stat", "putException: size is full!");
        return;
      }
    }
    int j;
    synchronized (this.g)
    {
      j = this.g.length();
    }
    try
    {
      this.g.put(j, paramJSONObject);
      return;
      localObject = finally;
      throw localObject;
    }
    catch (JSONException localJSONException)
    {
      while (true)
        com.baidu.mobstat.a.c.a("stat", localJSONException);
    }
  }

  public void d(Context paramContext)
  {
    int j = 0;
    if (paramContext == null);
    label340: label352: label356: 
    while (true)
    {
      return;
      if (com.baidu.mobstat.a.b.c(paramContext, "__local_stat_cache.json"))
      {
        String str = com.baidu.mobstat.a.b.a(false, paramContext, "__local_stat_cache.json");
        if (str.equals(""))
        {
          com.baidu.mobstat.a.c.a("stat", "stat_cache file not found.");
          return;
        }
        com.baidu.mobstat.a.c.a("stat", "loadStatData, ");
        JSONObject localJSONObject1;
        long l;
        int k;
        try
        {
          this.b = str.getBytes().length;
          com.baidu.mobstat.a.c.a("stat", "load Stat Data:cacheFileSize is:" + this.b);
          localJSONObject1 = new JSONObject(str);
          com.baidu.mobstat.a.c.a("stat", "Load cache:" + str);
          l = System.currentTimeMillis();
          JSONArray localJSONArray1 = localJSONObject1.getJSONArray("pr");
          k = 0;
          if (k < localJSONArray1.length())
          {
            JSONObject localJSONObject4 = localJSONArray1.getJSONObject(k);
            if (l - localJSONObject4.getLong("s") > 604800000L)
              break label340;
            a(localJSONObject4, true);
          }
        }
        catch (JSONException localJSONException)
        {
          com.baidu.mobstat.a.c.a("stat", "Load stat data error:" + localJSONException);
          return;
        }
        JSONArray localJSONArray2 = localJSONObject1.getJSONArray("ev");
        int m = 0;
        label235: JSONArray localJSONArray3;
        if (m < localJSONArray2.length())
        {
          JSONObject localJSONObject3 = localJSONArray2.getJSONObject(m);
          if (l - localJSONObject3.getLong("t") <= 604800000L)
            b(localJSONObject3, true);
        }
        else
        {
          localJSONArray3 = localJSONObject1.getJSONArray("ex");
        }
        while (true)
        {
          if (j >= localJSONArray3.length())
            break label356;
          JSONObject localJSONObject2 = localJSONArray3.getJSONObject(j);
          if (l - localJSONObject2.getLong("t") <= 604800000L)
          {
            c(localJSONObject2, true);
            break label352;
            k++;
            break;
            m++;
            break label235;
          }
          j++;
        }
      }
    }
  }

  // ERROR //
  public boolean e(Context paramContext)
  {
    // Byte code:
    //   0: ldc 70
    //   2: ldc_w 356
    //   5: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   8: pop
    //   9: getstatic 28	com/baidu/mobstat/b:a	Lcom/baidu/mobstat/c;
    //   12: ifnull +65 -> 77
    //   15: getstatic 28	com/baidu/mobstat/b:a	Lcom/baidu/mobstat/c;
    //   18: invokestatic 358	com/baidu/mobstat/c:a	(Lcom/baidu/mobstat/c;)Ljava/lang/String;
    //   21: ifnull +17 -> 38
    //   24: ldc 109
    //   26: getstatic 28	com/baidu/mobstat/b:a	Lcom/baidu/mobstat/c;
    //   29: invokestatic 358	com/baidu/mobstat/c:a	(Lcom/baidu/mobstat/c;)Ljava/lang/String;
    //   32: invokevirtual 113	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   35: ifeq +42 -> 77
    //   38: getstatic 28	com/baidu/mobstat/b:a	Lcom/baidu/mobstat/c;
    //   41: aload_1
    //   42: invokevirtual 360	com/baidu/mobstat/c:a	(Landroid/content/Context;)V
    //   45: getstatic 28	com/baidu/mobstat/b:a	Lcom/baidu/mobstat/c;
    //   48: invokestatic 358	com/baidu/mobstat/c:a	(Lcom/baidu/mobstat/c;)Ljava/lang/String;
    //   51: ifnull +17 -> 68
    //   54: ldc 109
    //   56: getstatic 28	com/baidu/mobstat/b:a	Lcom/baidu/mobstat/c;
    //   59: invokestatic 358	com/baidu/mobstat/c:a	(Lcom/baidu/mobstat/c;)Ljava/lang/String;
    //   62: invokevirtual 113	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   65: ifeq +12 -> 77
    //   68: ldc_w 362
    //   71: invokestatic 364	com/baidu/mobstat/a/c:c	(Ljava/lang/String;)I
    //   74: pop
    //   75: iconst_0
    //   76: ireturn
    //   77: new 30	org/json/JSONObject
    //   80: dup
    //   81: invokespecial 31	org/json/JSONObject:<init>	()V
    //   84: astore_3
    //   85: getstatic 33	com/baidu/mobstat/b:c	Lorg/json/JSONObject;
    //   88: astore 4
    //   90: aload 4
    //   92: monitorenter
    //   93: getstatic 33	com/baidu/mobstat/b:c	Lorg/json/JSONObject;
    //   96: ldc 142
    //   98: invokestatic 345	java/lang/System:currentTimeMillis	()J
    //   101: invokevirtual 146	org/json/JSONObject:put	(Ljava/lang/String;J)Lorg/json/JSONObject;
    //   104: pop
    //   105: getstatic 33	com/baidu/mobstat/b:c	Lorg/json/JSONObject;
    //   108: ldc_w 366
    //   111: invokestatic 371	com/baidu/mobstat/s:b	()Lcom/baidu/mobstat/s;
    //   114: invokevirtual 373	com/baidu/mobstat/s:d	()J
    //   117: invokevirtual 146	org/json/JSONObject:put	(Ljava/lang/String;J)Lorg/json/JSONObject;
    //   120: pop
    //   121: aload_3
    //   122: ldc_w 375
    //   125: getstatic 33	com/baidu/mobstat/b:c	Lorg/json/JSONObject;
    //   128: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   131: pop
    //   132: aload_0
    //   133: getfield 44	com/baidu/mobstat/b:d	Lorg/json/JSONArray;
    //   136: astore 11
    //   138: aload 11
    //   140: monitorenter
    //   141: aload_3
    //   142: ldc 231
    //   144: aload_0
    //   145: getfield 44	com/baidu/mobstat/b:d	Lorg/json/JSONArray;
    //   148: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   151: pop
    //   152: aload_0
    //   153: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   156: astore 16
    //   158: aload 16
    //   160: monitorenter
    //   161: aload_3
    //   162: ldc 236
    //   164: aload_0
    //   165: getfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   168: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   171: pop
    //   172: aload_0
    //   173: getfield 48	com/baidu/mobstat/b:f	Lorg/json/JSONArray;
    //   176: astore 21
    //   178: aload 21
    //   180: monitorenter
    //   181: aload_0
    //   182: getfield 50	com/baidu/mobstat/b:g	Lorg/json/JSONArray;
    //   185: astore 23
    //   187: aload 23
    //   189: monitorenter
    //   190: aload_3
    //   191: ldc 238
    //   193: aload_0
    //   194: getfield 50	com/baidu/mobstat/b:g	Lorg/json/JSONArray;
    //   197: invokevirtual 151	org/json/JSONObject:put	(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    //   200: pop
    //   201: aload_3
    //   202: invokevirtual 207	org/json/JSONObject:toString	()Ljava/lang/String;
    //   205: astore 28
    //   207: ldc 70
    //   209: new 72	java/lang/StringBuilder
    //   212: dup
    //   213: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   216: ldc_w 377
    //   219: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   222: aload 28
    //   224: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   227: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   230: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   233: pop
    //   234: aload_1
    //   235: ldc_w 379
    //   238: aload 28
    //   240: ldc_w 380
    //   243: ldc_w 380
    //   246: invokestatic 383	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;
    //   249: pop
    //   250: ldc 70
    //   252: new 72	java/lang/StringBuilder
    //   255: dup
    //   256: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   259: ldc_w 385
    //   262: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   265: aload 28
    //   267: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   273: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   276: pop
    //   277: iconst_1
    //   278: istore 32
    //   280: iconst_2
    //   281: anewarray 4	java/lang/Object
    //   284: astore 33
    //   286: aload 33
    //   288: iconst_0
    //   289: ldc 70
    //   291: aastore
    //   292: aload 33
    //   294: iconst_1
    //   295: new 72	java/lang/StringBuilder
    //   298: dup
    //   299: invokespecial 73	java/lang/StringBuilder:<init>	()V
    //   302: ldc_w 387
    //   305: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   308: iload 32
    //   310: invokevirtual 390	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   313: invokevirtual 83	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   316: aastore
    //   317: aload 33
    //   319: invokestatic 392	com/baidu/mobstat/a/c:b	([Ljava/lang/Object;)I
    //   322: pop
    //   323: iload 32
    //   325: ifeq +59 -> 384
    //   328: aload_0
    //   329: iconst_0
    //   330: invokespecial 246	com/baidu/mobstat/b:a	(Z)V
    //   333: aload_0
    //   334: new 41	org/json/JSONArray
    //   337: dup
    //   338: invokespecial 42	org/json/JSONArray:<init>	()V
    //   341: putfield 50	com/baidu/mobstat/b:g	Lorg/json/JSONArray;
    //   344: aload_0
    //   345: new 41	org/json/JSONArray
    //   348: dup
    //   349: invokespecial 42	org/json/JSONArray:<init>	()V
    //   352: putfield 46	com/baidu/mobstat/b:e	Lorg/json/JSONArray;
    //   355: aload_0
    //   356: new 41	org/json/JSONArray
    //   359: dup
    //   360: invokespecial 42	org/json/JSONArray:<init>	()V
    //   363: putfield 44	com/baidu/mobstat/b:d	Lorg/json/JSONArray;
    //   366: aload_0
    //   367: aload_1
    //   368: invokevirtual 315	com/baidu/mobstat/b:b	(Landroid/content/Context;)V
    //   371: invokestatic 371	com/baidu/mobstat/s:b	()Lcom/baidu/mobstat/s;
    //   374: invokevirtual 394	com/baidu/mobstat/s:c	()V
    //   377: invokestatic 399	com/baidu/mobstat/l:a	()Lcom/baidu/mobstat/l;
    //   380: aload_1
    //   381: invokevirtual 401	com/baidu/mobstat/l:c	(Landroid/content/Context;)V
    //   384: aload 23
    //   386: monitorexit
    //   387: aload 21
    //   389: monitorexit
    //   390: aload 16
    //   392: monitorexit
    //   393: aload 11
    //   395: monitorexit
    //   396: aload 4
    //   398: monitorexit
    //   399: ldc 70
    //   401: ldc_w 403
    //   404: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   407: pop
    //   408: iload 32
    //   410: ireturn
    //   411: astore 6
    //   413: ldc 70
    //   415: aload 6
    //   417: invokestatic 176	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   420: pop
    //   421: aload 4
    //   423: monitorexit
    //   424: iconst_0
    //   425: ireturn
    //   426: astore 5
    //   428: aload 4
    //   430: monitorexit
    //   431: aload 5
    //   433: athrow
    //   434: astore 13
    //   436: ldc 70
    //   438: aload 13
    //   440: invokevirtual 404	org/json/JSONException:toString	()Ljava/lang/String;
    //   443: invokestatic 88	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   446: pop
    //   447: aload 11
    //   449: monitorexit
    //   450: aload 4
    //   452: monitorexit
    //   453: iconst_0
    //   454: ireturn
    //   455: astore 18
    //   457: ldc 70
    //   459: aload 18
    //   461: invokestatic 176	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   464: pop
    //   465: aload 16
    //   467: monitorexit
    //   468: aload 11
    //   470: monitorexit
    //   471: aload 4
    //   473: monitorexit
    //   474: iconst_0
    //   475: ireturn
    //   476: astore 25
    //   478: ldc 70
    //   480: aload 25
    //   482: invokestatic 176	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   485: pop
    //   486: aload 23
    //   488: monitorexit
    //   489: aload 21
    //   491: monitorexit
    //   492: aload 16
    //   494: monitorexit
    //   495: aload 11
    //   497: monitorexit
    //   498: aload 4
    //   500: monitorexit
    //   501: iconst_0
    //   502: ireturn
    //   503: astore 30
    //   505: ldc 70
    //   507: aload 30
    //   509: invokestatic 406	com/baidu/mobstat/a/c:b	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   512: pop
    //   513: iconst_0
    //   514: istore 32
    //   516: goto -236 -> 280
    //   519: astore 24
    //   521: aload 23
    //   523: monitorexit
    //   524: aload 24
    //   526: athrow
    //   527: astore 22
    //   529: aload 21
    //   531: monitorexit
    //   532: aload 22
    //   534: athrow
    //   535: astore 17
    //   537: aload 16
    //   539: monitorexit
    //   540: aload 17
    //   542: athrow
    //   543: astore 12
    //   545: aload 11
    //   547: monitorexit
    //   548: aload 12
    //   550: athrow
    //
    // Exception table:
    //   from	to	target	type
    //   93	132	411	org/json/JSONException
    //   93	132	426	finally
    //   132	141	426	finally
    //   396	399	426	finally
    //   413	424	426	finally
    //   428	431	426	finally
    //   450	453	426	finally
    //   471	474	426	finally
    //   498	501	426	finally
    //   548	551	426	finally
    //   141	152	434	org/json/JSONException
    //   161	172	455	org/json/JSONException
    //   190	201	476	org/json/JSONException
    //   234	277	503	java/lang/Exception
    //   190	201	519	finally
    //   201	234	519	finally
    //   234	277	519	finally
    //   280	323	519	finally
    //   328	384	519	finally
    //   384	387	519	finally
    //   478	489	519	finally
    //   505	513	519	finally
    //   521	524	519	finally
    //   181	190	527	finally
    //   387	390	527	finally
    //   489	492	527	finally
    //   524	527	527	finally
    //   529	532	527	finally
    //   161	172	535	finally
    //   172	181	535	finally
    //   390	393	535	finally
    //   457	468	535	finally
    //   492	495	535	finally
    //   532	535	535	finally
    //   537	540	535	finally
    //   141	152	543	finally
    //   152	161	543	finally
    //   393	396	543	finally
    //   436	450	543	finally
    //   468	471	543	finally
    //   495	498	543	finally
    //   540	543	543	finally
    //   545	548	543	finally
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.b
 * JD-Core Version:    0.6.2
 */