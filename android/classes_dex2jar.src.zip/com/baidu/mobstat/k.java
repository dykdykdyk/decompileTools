package com.baidu.mobstat;

import android.content.Context;
import android.os.Process;
import com.baidu.mobstat.a.c;

class k extends Thread
{
  private static k a = new k();
  private Context b;
  private boolean c = false;
  private boolean d = false;

  public static k a()
  {
    return a;
  }

  private void d()
  {
    this.c = true;
  }

  private void e()
  {
    try
    {
      this.d = true;
      return;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void a(Context paramContext)
  {
    if ((paramContext == null) || (b()))
      return;
    this.b = paramContext;
    d();
    start();
    c.a("**************load caceh**start********");
  }

  public boolean b()
  {
    return this.c;
  }

  public boolean c()
  {
    try
    {
      boolean bool = this.d;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw localObject;
    }
  }

  public void run()
  {
    Process.setThreadPriority(19);
    while (!this.d)
    {
      l.a().a(this.b);
      b.a().d(this.b);
      b.a().c(this.b);
      e();
      synchronized (a)
      {
        try
        {
          notifyAll();
          b.a().a(this.b);
          l.a().b(this.b);
          c.a("**************load caceh**end********");
        }
        catch (IllegalMonitorStateException localIllegalMonitorStateException)
        {
          while (true)
            c.a("stat", localIllegalMonitorStateException);
        }
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.k
 * JD-Core Version:    0.6.2
 */