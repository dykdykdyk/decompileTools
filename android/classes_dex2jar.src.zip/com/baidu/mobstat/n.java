package com.baidu.mobstat;

class n
  implements Runnable
{
  n(m paramm)
  {
  }

  public void run()
  {
    this.a.b.a(this.a.a, l.d(this.a.b));
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.n
 * JD-Core Version:    0.6.2
 */