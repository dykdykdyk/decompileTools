package com.baidu.mobstat;

import android.content.Context;

class p
  implements Runnable
{
  p(l paraml, Context paramContext)
  {
  }

  public void run()
  {
    this.b.a = b.a().e(this.a);
    if (!this.b.a)
      l.a(this.b, this.a);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.p
 * JD-Core Version:    0.6.2
 */