package com.baidu.mobstat;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import java.util.HashMap;

class d
{
  private static HandlerThread c = new HandlerThread("EventHandleThread");
  private static Handler d;
  private static d e = new d();
  HashMap<String, i> a = new HashMap();
  public final String b = "$|$";

  private d()
  {
    c.start();
    c.setPriority(10);
    d = new Handler(c.getLooper());
  }

  public static d a()
  {
    return e;
  }

  public String a(String paramString1, String paramString2)
  {
    return "__sdk_" + paramString1 + "$|$" + paramString2;
  }

  public void a(Context paramContext, String paramString1, String paramString2, int paramInt, long paramLong)
  {
    d.post(new e(this, paramString1, paramString2, paramInt, paramLong, paramContext));
  }

  public void a(Context paramContext, String paramString1, String paramString2, long paramLong)
  {
    d.post(new f(this, paramLong, paramString1, paramString2));
  }

  public void b(Context paramContext, String paramString1, String paramString2, long paramLong)
  {
    d.post(new g(this, paramString1, paramString2, paramLong, paramContext));
  }

  public void c(Context paramContext, String paramString1, String paramString2, long paramLong)
  {
    d.post(new h(this, paramLong, paramString1, paramString2, paramContext));
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.d
 * JD-Core Version:    0.6.2
 */