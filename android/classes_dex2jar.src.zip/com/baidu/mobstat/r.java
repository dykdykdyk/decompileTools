package com.baidu.mobstat;

class r
{
  private String b;
  private long c;
  private long d;

  public r(q paramq, String paramString, long paramLong1, long paramLong2)
  {
    this.b = paramString;
    this.c = paramLong1;
    this.d = paramLong2;
  }

  public String a()
  {
    return this.b;
  }

  public long b()
  {
    return this.c;
  }

  public long c()
  {
    return this.d;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.r
 * JD-Core Version:    0.6.2
 */