package com.baidu.mobstat;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.telephony.CellLocation;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import com.baidu.mobstat.a.b;
import com.baidu.mobstat.a.c;

final class z
{
  public static int a(Context paramContext)
  {
    Object localObject = new DisplayMetrics();
    try
    {
      DisplayMetrics localDisplayMetrics = j(paramContext);
      localObject = localDisplayMetrics;
      return ((DisplayMetrics)localObject).widthPixels;
    }
    catch (Exception localException)
    {
      while (true)
        c.a("createAdReqURL", localException);
    }
  }

  public static String a(Context paramContext, String paramString)
  {
    String str = "";
    PackageManager localPackageManager = paramContext.getPackageManager();
    label112: 
    do
    {
      Object localObject;
      try
      {
        ApplicationInfo localApplicationInfo = localPackageManager.getApplicationInfo(paramContext.getPackageName(), 128);
        if (localApplicationInfo != null)
        {
          Bundle localBundle = localApplicationInfo.metaData;
          localObject = null;
          if (localBundle != null)
            localObject = localApplicationInfo.metaData.get(paramString);
          if (localObject != null)
            break label112;
          c.a("StatSDK", "null,can't find information for key:" + paramString);
          if (paramString == "BaiduMobAd_STAT_ID")
            c.c("不能在manifest.xml中找到APP Key||can't find app key in manifest.xml.");
        }
        return str;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        while (paramString != "BaiduMobAd_STAT_ID");
        c.c("不能在manifest.xml中找到APP Key||can't find app key in manifest.xml.");
        return str;
      }
      str = localObject.toString();
    }
    while ((!str.trim().equals("")) || (paramString != "BaiduMobAd_STAT_ID"));
    c.c("APP Key值为空||The value of APP Key is empty.");
    return str;
  }

  // ERROR //
  public static String a(Context paramContext, String paramString1, String paramString2, int paramInt1, int paramInt2)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 5
    //   3: aload_0
    //   4: aload_1
    //   5: iload_3
    //   6: iload 4
    //   8: invokestatic 107	com/baidu/mobstat/a/b:a	(Landroid/content/Context;Ljava/lang/String;II)Ljava/net/HttpURLConnection;
    //   11: astore 6
    //   13: aload 6
    //   15: iconst_1
    //   16: invokevirtual 113	java/net/HttpURLConnection:setDoOutput	(Z)V
    //   19: aload 6
    //   21: iconst_0
    //   22: invokevirtual 116	java/net/HttpURLConnection:setInstanceFollowRedirects	(Z)V
    //   25: aload 6
    //   27: iconst_0
    //   28: invokevirtual 119	java/net/HttpURLConnection:setUseCaches	(Z)V
    //   31: aload 6
    //   33: ldc 121
    //   35: ldc 123
    //   37: invokevirtual 127	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   40: aload 6
    //   42: invokevirtual 130	java/net/HttpURLConnection:connect	()V
    //   45: ldc 132
    //   47: invokestatic 134	com/baidu/mobstat/a/c:a	(Ljava/lang/String;)I
    //   50: pop
    //   51: new 66	java/lang/StringBuilder
    //   54: dup
    //   55: invokespecial 67	java/lang/StringBuilder:<init>	()V
    //   58: astore 8
    //   60: new 136	java/io/BufferedWriter
    //   63: dup
    //   64: new 138	java/io/OutputStreamWriter
    //   67: dup
    //   68: new 140	java/util/zip/GZIPOutputStream
    //   71: dup
    //   72: aload 6
    //   74: invokevirtual 144	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
    //   77: invokespecial 147	java/util/zip/GZIPOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   80: invokespecial 148	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   83: invokespecial 151	java/io/BufferedWriter:<init>	(Ljava/io/Writer;)V
    //   86: astore 9
    //   88: aload 9
    //   90: aload_2
    //   91: invokevirtual 155	java/io/BufferedWriter:write	(Ljava/lang/String;)V
    //   94: aload 9
    //   96: invokevirtual 158	java/io/BufferedWriter:close	()V
    //   99: new 160	java/io/BufferedReader
    //   102: dup
    //   103: new 162	java/io/InputStreamReader
    //   106: dup
    //   107: aload 6
    //   109: invokevirtual 166	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   112: invokespecial 169	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
    //   115: invokespecial 172	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   118: astore 11
    //   120: aload 11
    //   122: invokevirtual 175	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   125: astore 12
    //   127: aload 12
    //   129: ifnull +44 -> 173
    //   132: aload 8
    //   134: aload 12
    //   136: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: pop
    //   140: goto -20 -> 120
    //   143: astore 10
    //   145: aload 11
    //   147: ifnull +8 -> 155
    //   150: aload 11
    //   152: invokevirtual 176	java/io/BufferedReader:close	()V
    //   155: aload 5
    //   157: ifnull +8 -> 165
    //   160: aload 5
    //   162: invokevirtual 158	java/io/BufferedWriter:close	()V
    //   165: aload 6
    //   167: invokevirtual 179	java/net/HttpURLConnection:disconnect	()V
    //   170: aload 10
    //   172: athrow
    //   173: aload 11
    //   175: invokevirtual 176	java/io/BufferedReader:close	()V
    //   178: aload 6
    //   180: invokevirtual 179	java/net/HttpURLConnection:disconnect	()V
    //   183: aload 6
    //   185: invokevirtual 183	java/net/HttpURLConnection:getContentLength	()I
    //   188: istore 14
    //   190: aload 6
    //   192: invokevirtual 186	java/net/HttpURLConnection:getResponseCode	()I
    //   195: sipush 200
    //   198: if_icmpne +8 -> 206
    //   201: iload 14
    //   203: ifeq +55 -> 258
    //   206: new 102	java/io/IOException
    //   209: dup
    //   210: new 66	java/lang/StringBuilder
    //   213: dup
    //   214: invokespecial 67	java/lang/StringBuilder:<init>	()V
    //   217: ldc 188
    //   219: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   222: aload 6
    //   224: invokevirtual 186	java/net/HttpURLConnection:getResponseCode	()I
    //   227: invokevirtual 191	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   230: ldc 193
    //   232: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   235: aload 8
    //   237: invokevirtual 196	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   240: invokevirtual 76	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   243: invokespecial 198	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   246: athrow
    //   247: astore 10
    //   249: aconst_null
    //   250: astore 11
    //   252: aconst_null
    //   253: astore 5
    //   255: goto -110 -> 145
    //   258: aload 8
    //   260: invokevirtual 76	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   263: areturn
    //   264: astore 10
    //   266: aload 9
    //   268: astore 5
    //   270: aconst_null
    //   271: astore 11
    //   273: goto -128 -> 145
    //
    // Exception table:
    //   from	to	target	type
    //   120	127	143	java/io/IOException
    //   132	140	143	java/io/IOException
    //   173	178	143	java/io/IOException
    //   60	88	247	java/io/IOException
    //   99	120	247	java/io/IOException
    //   178	201	247	java/io/IOException
    //   206	247	247	java/io/IOException
    //   88	99	264	java/io/IOException
  }

  public static int b(Context paramContext)
  {
    Object localObject = new DisplayMetrics();
    try
    {
      DisplayMetrics localDisplayMetrics = j(paramContext);
      localObject = localDisplayMetrics;
      return ((DisplayMetrics)localObject).heightPixels;
    }
    catch (Exception localException)
    {
      while (true)
        c.a("createAdReqURL", localException);
    }
  }

  public static int c(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    String str = paramContext.getPackageName();
    try
    {
      int i = localPackageManager.getPackageInfo(str, 0).versionCode;
      return i;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      c.c(new Object[] { "stat", "get app version code exception" });
    }
    return 1;
  }

  public static String d(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    String str1 = paramContext.getPackageName();
    try
    {
      String str2 = localPackageManager.getPackageInfo(str1, 0).versionName;
      return str2;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      c.c(new Object[] { "stat", "get app version name exception" });
    }
    return "";
  }

  public static String e(Context paramContext)
  {
    Object[] arrayOfObject1 = new Object[3];
    arrayOfObject1[0] = Integer.valueOf(0);
    arrayOfObject1[1] = Integer.valueOf(0);
    arrayOfObject1[2] = Integer.valueOf(0);
    String str1 = String.format("%s_%s_%s", arrayOfObject1);
    try
    {
      if ((b.e(paramContext, "android.permission.ACCESS_FINE_LOCATION")) || (b.e(paramContext, "android.permission.ACCESS_COARSE_LOCATION")))
      {
        CellLocation localCellLocation = ((TelephonyManager)paramContext.getSystemService("phone")).getCellLocation();
        c.a("getLocation cell:", localCellLocation + "");
        if (localCellLocation == null)
          return str1;
        if ((localCellLocation instanceof GsmCellLocation))
        {
          GsmCellLocation localGsmCellLocation = (GsmCellLocation)localCellLocation;
          Object[] arrayOfObject3 = new Object[3];
          Object[] arrayOfObject4 = new Object[1];
          arrayOfObject4[0] = Integer.valueOf(localGsmCellLocation.getCid());
          arrayOfObject3[0] = String.format("%d", arrayOfObject4);
          Object[] arrayOfObject5 = new Object[1];
          arrayOfObject5[0] = Integer.valueOf(localGsmCellLocation.getLac());
          arrayOfObject3[1] = String.format("%d", arrayOfObject5);
          arrayOfObject3[2] = Integer.valueOf(0);
          return String.format("%s_%s_%s", arrayOfObject3);
        }
        String[] arrayOfString = localCellLocation.toString().replace("[", "").replace("]", "").split(",");
        Object[] arrayOfObject2 = new Object[3];
        arrayOfObject2[0] = arrayOfString[0];
        arrayOfObject2[1] = arrayOfString[3];
        arrayOfObject2[2] = arrayOfString[4];
        String str2 = String.format("%s_%s_%s", arrayOfObject2);
        return str2;
      }
    }
    catch (Exception localException)
    {
      c.a("getLocation", localException);
    }
    return str1;
  }

  public static String f(Context paramContext)
  {
    try
    {
      if (b.e(paramContext, "android.permission.ACCESS_FINE_LOCATION"))
      {
        Location localLocation = ((LocationManager)paramContext.getSystemService("location")).getLastKnownLocation("gps");
        c.a("stat", "location: " + localLocation);
        if (localLocation != null)
        {
          Object[] arrayOfObject = new Object[3];
          arrayOfObject[0] = Long.valueOf(localLocation.getTime());
          arrayOfObject[1] = Double.valueOf(localLocation.getLongitude());
          arrayOfObject[2] = Double.valueOf(localLocation.getLatitude());
          String str = String.format("%s_%s_%s", arrayOfObject);
          return str;
        }
      }
    }
    catch (Exception localException)
    {
      c.a("stat", localException);
    }
    return "";
  }

  // ERROR //
  public static String g(Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 324
    //   4: invokestatic 244	com/baidu/mobstat/a/b:e	(Landroid/content/Context;Ljava/lang/String;)Z
    //   7: ifeq +66 -> 73
    //   10: aload_0
    //   11: ldc_w 326
    //   14: invokevirtual 251	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   17: checkcast 328	android/net/wifi/WifiManager
    //   20: invokevirtual 332	android/net/wifi/WifiManager:getConnectionInfo	()Landroid/net/wifi/WifiInfo;
    //   23: astore 6
    //   25: aload 6
    //   27: invokevirtual 337	android/net/wifi/WifiInfo:getMacAddress	()Ljava/lang/String;
    //   30: astore 7
    //   32: aload 7
    //   34: astore_2
    //   35: iconst_2
    //   36: anewarray 4	java/lang/Object
    //   39: astore 8
    //   41: aload 8
    //   43: iconst_0
    //   44: aload 6
    //   46: invokevirtual 340	android/net/wifi/WifiInfo:getSSID	()Ljava/lang/String;
    //   49: aastore
    //   50: aload 8
    //   52: iconst_1
    //   53: aload 6
    //   55: invokevirtual 337	android/net/wifi/WifiInfo:getMacAddress	()Ljava/lang/String;
    //   58: aastore
    //   59: ldc_w 342
    //   62: aload 8
    //   64: invokestatic 239	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   67: invokestatic 134	com/baidu/mobstat/a/c:a	(Ljava/lang/String;)I
    //   70: pop
    //   71: aload_2
    //   72: areturn
    //   73: ldc_w 344
    //   76: invokestatic 87	com/baidu/mobstat/a/c:c	(Ljava/lang/String;)I
    //   79: pop
    //   80: ldc 34
    //   82: areturn
    //   83: astore_1
    //   84: ldc 34
    //   86: astore_2
    //   87: aload_1
    //   88: astore_3
    //   89: ldc 213
    //   91: aload_3
    //   92: invokestatic 29	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   95: pop
    //   96: aload_2
    //   97: areturn
    //   98: astore_3
    //   99: goto -10 -> 89
    //
    // Exception table:
    //   from	to	target	type
    //   0	32	83	java/lang/Exception
    //   73	80	83	java/lang/Exception
    //   35	71	98	java/lang/Exception
  }

  // ERROR //
  public static String h(Context paramContext)
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: ldc_w 324
    //   6: invokestatic 244	com/baidu/mobstat/a/b:e	(Landroid/content/Context;Ljava/lang/String;)Z
    //   9: ifeq +353 -> 362
    //   12: aload_0
    //   13: ldc_w 326
    //   16: invokevirtual 251	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   19: checkcast 328	android/net/wifi/WifiManager
    //   22: astore 6
    //   24: aload 6
    //   26: invokevirtual 349	android/net/wifi/WifiManager:isWifiEnabled	()Z
    //   29: ifeq +333 -> 362
    //   32: ldc_w 351
    //   35: new 66	java/lang/StringBuilder
    //   38: dup
    //   39: invokespecial 67	java/lang/StringBuilder:<init>	()V
    //   42: aload 6
    //   44: invokevirtual 355	android/net/wifi/WifiManager:getScanResults	()Ljava/util/List;
    //   47: invokevirtual 196	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   50: ldc 34
    //   52: invokevirtual 73	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   55: invokevirtual 76	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   58: invokestatic 79	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/String;)I
    //   61: pop
    //   62: ldc_w 356
    //   65: istore 8
    //   67: iconst_m1
    //   68: istore 9
    //   70: iload_1
    //   71: aload 6
    //   73: invokevirtual 355	android/net/wifi/WifiManager:getScanResults	()Ljava/util/List;
    //   76: invokeinterface 361 1 0
    //   81: if_icmpge +91 -> 172
    //   84: aload 6
    //   86: invokevirtual 355	android/net/wifi/WifiManager:getScanResults	()Ljava/util/List;
    //   89: iload_1
    //   90: invokeinterface 364 2 0
    //   95: checkcast 366	android/net/wifi/ScanResult
    //   98: astore 19
    //   100: aload 19
    //   102: getfield 369	android/net/wifi/ScanResult:level	I
    //   105: invokestatic 375	java/lang/Math:abs	(I)I
    //   108: istore 20
    //   110: iconst_3
    //   111: anewarray 4	java/lang/Object
    //   114: astore 21
    //   116: aload 21
    //   118: iconst_0
    //   119: aload 19
    //   121: getfield 378	android/net/wifi/ScanResult:SSID	Ljava/lang/String;
    //   124: aastore
    //   125: aload 21
    //   127: iconst_1
    //   128: aload 19
    //   130: getfield 381	android/net/wifi/ScanResult:BSSID	Ljava/lang/String;
    //   133: aastore
    //   134: aload 21
    //   136: iconst_2
    //   137: iload 20
    //   139: invokestatic 233	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   142: aastore
    //   143: ldc_w 383
    //   146: aload 21
    //   148: invokestatic 239	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   151: invokestatic 134	com/baidu/mobstat/a/c:a	(Ljava/lang/String;)I
    //   154: pop
    //   155: iload 8
    //   157: iload 20
    //   159: if_icmple +192 -> 351
    //   162: iload_1
    //   163: istore 23
    //   165: iload 20
    //   167: istore 24
    //   169: goto +196 -> 365
    //   172: iload 9
    //   174: iflt +170 -> 344
    //   177: aload 6
    //   179: invokevirtual 355	android/net/wifi/WifiManager:getScanResults	()Ljava/util/List;
    //   182: iload 9
    //   184: invokeinterface 364 2 0
    //   189: checkcast 366	android/net/wifi/ScanResult
    //   192: astore 10
    //   194: aload 10
    //   196: getfield 381	android/net/wifi/ScanResult:BSSID	Ljava/lang/String;
    //   199: ldc_w 385
    //   202: ldc 34
    //   204: invokevirtual 275	java/lang/String:replace	(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   207: invokevirtual 388	java/lang/String:toLowerCase	()Ljava/lang/String;
    //   210: astore 11
    //   212: iconst_2
    //   213: anewarray 4	java/lang/Object
    //   216: astore 12
    //   218: aload 12
    //   220: iconst_0
    //   221: aload 11
    //   223: aastore
    //   224: aload 12
    //   226: iconst_1
    //   227: aload 10
    //   229: getfield 369	android/net/wifi/ScanResult:level	I
    //   232: invokestatic 375	java/lang/Math:abs	(I)I
    //   235: invokestatic 233	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   238: aastore
    //   239: ldc_w 390
    //   242: aload 12
    //   244: invokestatic 239	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   247: astore 13
    //   249: aload 13
    //   251: astore 14
    //   253: aload 6
    //   255: invokevirtual 332	android/net/wifi/WifiManager:getConnectionInfo	()Landroid/net/wifi/WifiInfo;
    //   258: astore 16
    //   260: iconst_3
    //   261: anewarray 4	java/lang/Object
    //   264: astore 17
    //   266: aload 17
    //   268: iconst_0
    //   269: aload 16
    //   271: invokevirtual 340	android/net/wifi/WifiInfo:getSSID	()Ljava/lang/String;
    //   274: aastore
    //   275: aload 17
    //   277: iconst_1
    //   278: aload 16
    //   280: invokevirtual 337	android/net/wifi/WifiInfo:getMacAddress	()Ljava/lang/String;
    //   283: aastore
    //   284: aload 17
    //   286: iconst_2
    //   287: aload 16
    //   289: invokevirtual 393	android/net/wifi/WifiInfo:getRssi	()I
    //   292: invokestatic 375	java/lang/Math:abs	(I)I
    //   295: invokestatic 233	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   298: aastore
    //   299: ldc_w 395
    //   302: aload 17
    //   304: invokestatic 239	java/lang/String:format	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   307: invokestatic 134	com/baidu/mobstat/a/c:a	(Ljava/lang/String;)I
    //   310: pop
    //   311: aload 14
    //   313: areturn
    //   314: astore_2
    //   315: aload_2
    //   316: astore_3
    //   317: ldc 34
    //   319: astore 4
    //   321: ldc_w 397
    //   324: aload_3
    //   325: invokestatic 29	com/baidu/mobstat/a/c:a	(Ljava/lang/String;Ljava/lang/Throwable;)I
    //   328: pop
    //   329: aload 4
    //   331: areturn
    //   332: astore 15
    //   334: aload 14
    //   336: astore 4
    //   338: aload 15
    //   340: astore_3
    //   341: goto -20 -> 321
    //   344: ldc 34
    //   346: astore 14
    //   348: goto -95 -> 253
    //   351: iload 9
    //   353: istore 23
    //   355: iload 8
    //   357: istore 24
    //   359: goto +6 -> 365
    //   362: ldc 34
    //   364: areturn
    //   365: iinc 1 1
    //   368: iload 24
    //   370: istore 8
    //   372: iload 23
    //   374: istore 9
    //   376: goto -306 -> 70
    //
    // Exception table:
    //   from	to	target	type
    //   2	62	314	java/lang/Exception
    //   70	155	314	java/lang/Exception
    //   177	249	314	java/lang/Exception
    //   253	311	332	java/lang/Exception
  }

  public static String i(Context paramContext)
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
    String str = localNetworkInfo.getTypeName();
    if ((!str.equals("WIFI")) && (localNetworkInfo.getSubtypeName() != null))
      str = localNetworkInfo.getSubtypeName();
    return str;
  }

  public static DisplayMetrics j(Context paramContext)
  {
    DisplayMetrics localDisplayMetrics = new DisplayMetrics();
    ((WindowManager)paramContext.getApplicationContext().getSystemService("window")).getDefaultDisplay().getMetrics(localDisplayMetrics);
    return localDisplayMetrics;
  }

  public static boolean k(Context paramContext)
  {
    if (paramContext != null)
    {
      NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getNetworkInfo(1);
      if (localNetworkInfo != null)
        return localNetworkInfo.isConnected();
    }
    return false;
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.z
 * JD-Core Version:    0.6.2
 */