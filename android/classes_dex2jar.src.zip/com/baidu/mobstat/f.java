package com.baidu.mobstat;

import com.baidu.mobstat.a.c;
import java.util.HashMap;

class f
  implements Runnable
{
  f(d paramd, long paramLong, String paramString1, String paramString2)
  {
  }

  public void run()
  {
    if (!k.a().c());
    synchronized (k.a())
    {
      try
      {
        k.a().wait();
        i locali = new i(this.d);
        locali.c = this.a;
        locali.a = this.b;
        locali.b = this.c;
        String str = this.d.a(this.b, this.c);
        if (this.d.a.get(str) != null)
        {
          Object[] arrayOfObject = new Object[2];
          arrayOfObject[0] = "stat";
          arrayOfObject[1] = ("EventStat: event_id[" + this.b + "] with label[" + this.c + "] is duplicated, older is removed");
          c.b(arrayOfObject);
        }
        this.d.a.put(str, locali);
        c.a("stat", "put a keyword[" + str + "] into durationlist");
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        while (true)
          c.a("stat", localInterruptedException);
      }
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.f
 * JD-Core Version:    0.6.2
 */