package com.baidu.mobstat;

import android.content.Context;
import android.support.v4.app.Fragment;
import com.baidu.mobstat.a.c;
import java.lang.ref.WeakReference;
import org.json.JSONObject;

class y
  implements Runnable
{
  private long b;
  private long c;
  private WeakReference<Context> d;
  private WeakReference<Fragment> e;
  private WeakReference<Object> f;
  private int g = 1;

  public y(s params, long paramLong1, long paramLong2, Context paramContext, Fragment paramFragment, Object paramObject, int paramInt)
  {
    this.b = paramLong1;
    this.c = paramLong2;
    this.d = new WeakReference(paramContext);
    this.e = new WeakReference(paramFragment);
    this.f = new WeakReference(paramObject);
    this.g = paramInt;
  }

  public void run()
  {
    Object localObject;
    if ((this.c - this.b >= this.a.a()) && (this.b > 0L) && ((this.d.get() != null) || (this.e.get() != null) || (this.f.get() != null)))
    {
      s.a(this.a).b(this.b);
      String str = s.a(this.a).c().toString();
      c.a("stat", "new session:" + str);
      b.a().c(str);
      if (this.g != 1)
        break label196;
      Context localContext2 = (Context)this.d.get();
      b.a().b(localContext2);
      localObject = localContext2;
      s.a(this.a).b();
      if (this.g != 1)
        break label269;
      s.a(this.a, (Context)this.d.get());
    }
    while (true)
    {
      l.a().b((Context)localObject);
      return;
      label196: if (this.g == 2)
      {
        b.a().b(((Fragment)this.e.get()).getActivity());
        localObject = null;
        break;
      }
      int i = this.g;
      localObject = null;
      if (i != 3)
        break;
      Context localContext1 = s.a(this.f.get());
      b.a().b(localContext1);
      localObject = localContext1;
      break;
      label269: if (this.g == 2)
        s.a(this.a, ((Fragment)this.e.get()).getActivity());
      else
        s.a(this.a, (Context)localObject);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.y
 * JD-Core Version:    0.6.2
 */