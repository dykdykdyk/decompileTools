package com.baidu.mobstat;

class i
{
  String a;
  String b;
  long c;

  i(d paramd)
  {
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.i
 * JD-Core Version:    0.6.2
 */