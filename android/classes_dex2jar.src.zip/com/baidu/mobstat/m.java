package com.baidu.mobstat;

import android.content.Context;
import android.os.Handler;
import java.util.Timer;

class m
  implements Runnable
{
  m(l paraml, Context paramContext)
  {
  }

  public void run()
  {
    l.a(this.b, BasicStoreTools.getInstance().loadExceptionTurn(this.a));
    if (l.a(this.b))
      j.a().b(this.a);
    if (l.b(this.b) != null)
    {
      l.b(this.b).cancel();
      l.a(this.b, null);
    }
    l.a(this.b, SendStrategyEnum.values()[BasicStoreTools.getInstance().loadSendStrategy(this.a)]);
    l.a(this.b, BasicStoreTools.getInstance().loadSendStrategyTime(this.a));
    l.b(this.b, BasicStoreTools.getInstance().loadOnlyWifiChannel(this.a));
    if (l.c(this.b).equals(SendStrategyEnum.SET_TIME_INTERVAL))
      this.b.d(this.a);
    while (true)
    {
      l.b().postDelayed(new n(this), 1000 * l.e(this.b));
      return;
      if (l.c(this.b).equals(SendStrategyEnum.ONCE_A_DAY))
        this.b.d(this.a);
    }
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.m
 * JD-Core Version:    0.6.2
 */