package com.baidu.mobstat;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import com.baidu.mobstat.a.c;
import java.lang.ref.WeakReference;
import java.util.Date;
import java.util.Timer;

class l
{
  private static HandlerThread c = new HandlerThread("LogSenderThread");
  private static Handler k;
  private static l l = new l();
  boolean a = false;
  int b = 0;
  private boolean d = false;
  private SendStrategyEnum e = SendStrategyEnum.APP_START;
  private int f = 1;
  private Timer g;
  private int h = 0;
  private boolean i = false;
  private WeakReference<Context> j;

  private l()
  {
    c.start();
    k = new Handler(c.getLooper());
  }

  public static l a()
  {
    return l;
  }

  private Context c()
  {
    return (Context)this.j.get();
  }

  private void e(Context paramContext)
  {
    if (paramContext == null)
      c.a("stat", "initContext context=" + null);
    if ((this.j == null) && (paramContext != null))
      this.j = new WeakReference(paramContext);
  }

  private void f(Context paramContext)
  {
    if (paramContext == null)
      paramContext = c();
    this.b = (1 + this.b);
    c.a("Log sendtimes=" + this.b);
    if (this.b == 3)
    {
      a(paramContext, 3600000 * this.f, 900000);
      return;
    }
    if (this.b == 1)
      this.a = b.a().e(paramContext);
    if (!this.a)
    {
      k.postDelayed(new p(this, paramContext), 30000L);
      return;
    }
    c.a("Log send succ=" + this.b);
  }

  public void a(int paramInt)
  {
    if ((paramInt >= 0) && (paramInt <= 30))
      this.h = paramInt;
  }

  // ERROR //
  public void a(Context paramContext)
  {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial 168	com/baidu/mobstat/l:e	(Landroid/content/Context;)V
    //   5: getstatic 49	com/baidu/mobstat/SendStrategyEnum:APP_START	Lcom/baidu/mobstat/SendStrategyEnum;
    //   8: astore_2
    //   9: aload_1
    //   10: ldc 170
    //   12: invokestatic 175	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   15: astore 16
    //   17: aload 16
    //   19: ldc 177
    //   21: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   24: ifne +28 -> 52
    //   27: aload 16
    //   29: ldc 185
    //   31: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   34: ifeq +161 -> 195
    //   37: invokestatic 190	com/baidu/mobstat/j:a	()Lcom/baidu/mobstat/j;
    //   40: aload_1
    //   41: invokevirtual 192	com/baidu/mobstat/j:a	(Landroid/content/Context;)V
    //   44: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   47: aload_1
    //   48: iconst_1
    //   49: invokevirtual 202	com/baidu/mobstat/BasicStoreTools:setExceptionTurn	(Landroid/content/Context;Z)V
    //   52: aload_1
    //   53: ldc 204
    //   55: invokestatic 175	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   58: astore 15
    //   60: aload 15
    //   62: ldc 177
    //   64: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   67: ifne +32 -> 99
    //   70: aload 15
    //   72: getstatic 49	com/baidu/mobstat/SendStrategyEnum:APP_START	Lcom/baidu/mobstat/SendStrategyEnum;
    //   75: invokevirtual 207	com/baidu/mobstat/SendStrategyEnum:name	()Ljava/lang/String;
    //   78: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   81: ifeq +144 -> 225
    //   84: getstatic 49	com/baidu/mobstat/SendStrategyEnum:APP_START	Lcom/baidu/mobstat/SendStrategyEnum;
    //   87: astore_2
    //   88: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   91: aload_1
    //   92: aload_2
    //   93: invokevirtual 211	com/baidu/mobstat/SendStrategyEnum:ordinal	()I
    //   96: invokevirtual 215	com/baidu/mobstat/BasicStoreTools:setSendStrategy	(Landroid/content/Context;I)V
    //   99: aload_1
    //   100: ldc 217
    //   102: invokestatic 175	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   105: astore 13
    //   107: aload 13
    //   109: ldc 177
    //   111: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   114: ifne +44 -> 158
    //   117: aload 13
    //   119: invokestatic 222	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   122: istore 14
    //   124: aload_2
    //   125: invokevirtual 211	com/baidu/mobstat/SendStrategyEnum:ordinal	()I
    //   128: getstatic 225	com/baidu/mobstat/SendStrategyEnum:SET_TIME_INTERVAL	Lcom/baidu/mobstat/SendStrategyEnum;
    //   131: invokevirtual 211	com/baidu/mobstat/SendStrategyEnum:ordinal	()I
    //   134: if_icmpne +24 -> 158
    //   137: iload 14
    //   139: ifle +19 -> 158
    //   142: iload 14
    //   144: bipush 24
    //   146: if_icmpgt +12 -> 158
    //   149: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   152: aload_1
    //   153: iload 14
    //   155: invokevirtual 228	com/baidu/mobstat/BasicStoreTools:setSendStrategyTime	(Landroid/content/Context;I)V
    //   158: aload_1
    //   159: ldc 230
    //   161: invokestatic 175	com/baidu/mobstat/z:a	(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   164: astore 12
    //   166: aload 12
    //   168: ldc 177
    //   170: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   173: ifne +21 -> 194
    //   176: aload 12
    //   178: ldc 185
    //   180: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   183: ifeq +143 -> 326
    //   186: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   189: aload_1
    //   190: iconst_1
    //   191: invokevirtual 233	com/baidu/mobstat/BasicStoreTools:setOnlyWifi	(Landroid/content/Context;Z)V
    //   194: return
    //   195: aload 16
    //   197: ldc 235
    //   199: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   202: ifeq -150 -> 52
    //   205: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   208: aload_1
    //   209: iconst_0
    //   210: invokevirtual 202	com/baidu/mobstat/BasicStoreTools:setExceptionTurn	(Landroid/content/Context;Z)V
    //   213: goto -161 -> 52
    //   216: astore_3
    //   217: aload_3
    //   218: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   221: pop
    //   222: goto -170 -> 52
    //   225: aload 15
    //   227: getstatic 241	com/baidu/mobstat/SendStrategyEnum:ONCE_A_DAY	Lcom/baidu/mobstat/SendStrategyEnum;
    //   230: invokevirtual 207	com/baidu/mobstat/SendStrategyEnum:name	()Ljava/lang/String;
    //   233: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   236: ifeq +47 -> 283
    //   239: getstatic 241	com/baidu/mobstat/SendStrategyEnum:ONCE_A_DAY	Lcom/baidu/mobstat/SendStrategyEnum;
    //   242: astore_2
    //   243: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   246: aload_1
    //   247: aload_2
    //   248: invokevirtual 211	com/baidu/mobstat/SendStrategyEnum:ordinal	()I
    //   251: invokevirtual 215	com/baidu/mobstat/BasicStoreTools:setSendStrategy	(Landroid/content/Context;I)V
    //   254: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   257: aload_1
    //   258: bipush 24
    //   260: invokevirtual 228	com/baidu/mobstat/BasicStoreTools:setSendStrategyTime	(Landroid/content/Context;I)V
    //   263: goto -164 -> 99
    //   266: astore 5
    //   268: aload_2
    //   269: astore 6
    //   271: aload 5
    //   273: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   276: pop
    //   277: aload 6
    //   279: astore_2
    //   280: goto -181 -> 99
    //   283: aload 15
    //   285: getstatic 225	com/baidu/mobstat/SendStrategyEnum:SET_TIME_INTERVAL	Lcom/baidu/mobstat/SendStrategyEnum;
    //   288: invokevirtual 207	com/baidu/mobstat/SendStrategyEnum:name	()Ljava/lang/String;
    //   291: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   294: ifeq -195 -> 99
    //   297: getstatic 225	com/baidu/mobstat/SendStrategyEnum:SET_TIME_INTERVAL	Lcom/baidu/mobstat/SendStrategyEnum;
    //   300: astore_2
    //   301: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   304: aload_1
    //   305: aload_2
    //   306: invokevirtual 211	com/baidu/mobstat/SendStrategyEnum:ordinal	()I
    //   309: invokevirtual 215	com/baidu/mobstat/BasicStoreTools:setSendStrategy	(Landroid/content/Context;I)V
    //   312: goto -213 -> 99
    //   315: astore 8
    //   317: aload 8
    //   319: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   322: pop
    //   323: goto -165 -> 158
    //   326: aload 12
    //   328: ldc 235
    //   330: invokevirtual 183	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   333: ifeq -139 -> 194
    //   336: invokestatic 198	com/baidu/mobstat/BasicStoreTools:getInstance	()Lcom/baidu/mobstat/BasicStoreTools;
    //   339: aload_1
    //   340: iconst_0
    //   341: invokevirtual 233	com/baidu/mobstat/BasicStoreTools:setOnlyWifi	(Landroid/content/Context;Z)V
    //   344: return
    //   345: astore 10
    //   347: aload 10
    //   349: invokestatic 238	com/baidu/mobstat/a/c:a	(Ljava/lang/Throwable;)I
    //   352: pop
    //   353: return
    //
    // Exception table:
    //   from	to	target	type
    //   9	52	216	java/lang/Exception
    //   195	213	216	java/lang/Exception
    //   52	99	266	java/lang/Exception
    //   225	263	266	java/lang/Exception
    //   283	312	266	java/lang/Exception
    //   99	137	315	java/lang/Exception
    //   149	158	315	java/lang/Exception
    //   158	194	345	java/lang/Exception
    //   326	344	345	java/lang/Exception
  }

  public void a(Context paramContext, long paramLong, int paramInt)
  {
    this.g = new Timer();
    c.a("set timer log");
    this.g.schedule(new o(this, paramContext), 3600000 * this.f, 3600000 * this.f);
  }

  public void a(Context paramContext, SendStrategyEnum paramSendStrategyEnum, int paramInt, boolean paramBoolean)
  {
    if (paramSendStrategyEnum.equals(SendStrategyEnum.SET_TIME_INTERVAL))
      if ((paramInt > 0) && (paramInt <= 24))
      {
        this.f = paramInt;
        this.e = SendStrategyEnum.SET_TIME_INTERVAL;
        BasicStoreTools.getInstance().setSendStrategy(paramContext, this.e.ordinal());
        BasicStoreTools.getInstance().setSendStrategyTime(paramContext, this.f);
      }
    while (true)
    {
      this.d = paramBoolean;
      BasicStoreTools.getInstance().setOnlyWifi(paramContext, this.d);
      c.a("stat", "sstype is:" + this.e.name() + " And time_interval is:" + this.f + " And m_only_wifi:" + this.d);
      return;
      c.c(new Object[] { "setSendLogStrategy", "time_interval is invalid, new strategy does not work" });
      continue;
      this.e = paramSendStrategyEnum;
      BasicStoreTools.getInstance().setSendStrategy(paramContext, this.e.ordinal());
      if (paramSendStrategyEnum.equals(SendStrategyEnum.ONCE_A_DAY))
        BasicStoreTools.getInstance().setSendStrategyTime(paramContext, 24);
    }
  }

  protected void a(Context paramContext, boolean paramBoolean)
  {
    if (paramBoolean)
      try
      {
        if (!z.k(paramContext))
        {
          c.a("stat", "sendLogData() does not send because of only_wifi setting");
          return;
        }
      }
      catch (Exception localException)
      {
        c.a("stat", "sendLogData exception when get wifimanager");
        return;
      }
    this.b = 0;
    this.a = false;
    f(paramContext);
  }

  public void a(boolean paramBoolean, Context paramContext)
  {
    e(paramContext);
    this.i = paramBoolean;
    c.a("stat", "APP_ANALYSIS_EXCEPTION is:" + this.i);
    BasicStoreTools.getInstance().setExceptionTurn(paramContext, this.i);
  }

  public void b(Context paramContext)
  {
    e(paramContext);
    if ((paramContext == null) && (this.j.get() != null))
      paramContext = (Context)this.j.get();
    k.post(new m(this, paramContext));
  }

  public void c(Context paramContext)
  {
    BasicStoreTools.getInstance().setLastSendTime(paramContext, new Date().getTime());
  }

  public void d(Context paramContext)
  {
    a(paramContext, 3600000 * this.f, 3600000 * this.f);
  }
}

/* Location:           C:\Users\Administrator\Desktop\Wearable\classes_dex2jar.jar
 * Qualified Name:     com.baidu.mobstat.l
 * JD-Core Version:    0.6.2
 */