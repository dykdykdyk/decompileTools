package a;

import java.io.IOException;

public abstract interface i extends z
{
  public abstract long a(aa paramaa)
    throws IOException;

  public abstract f a();

  public abstract i b()
    throws IOException;

  public abstract i b(k paramk)
    throws IOException;

  public abstract i b(String paramString)
    throws IOException;

  public abstract i b(byte[] paramArrayOfByte)
    throws IOException;

  public abstract i c(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException;

  public abstract i f(int paramInt)
    throws IOException;

  public abstract i g(int paramInt)
    throws IOException;

  public abstract i h(int paramInt)
    throws IOException;

  public abstract i i(long paramLong)
    throws IOException;

  public abstract i j(long paramLong)
    throws IOException;

  public abstract i q()
    throws IOException;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     a.i
 * JD-Core Version:    0.6.2
 */