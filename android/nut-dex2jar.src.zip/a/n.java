package a;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public final class n extends ab
{
  public ab a;

  public n(ab paramab)
  {
    if (paramab == null)
      throw new IllegalArgumentException("delegate == null");
    this.a = paramab;
  }

  public final ab a(long paramLong)
  {
    return this.a.a(paramLong);
  }

  public final ab a(long paramLong, TimeUnit paramTimeUnit)
  {
    return this.a.a(paramLong, paramTimeUnit);
  }

  public final long c()
  {
    return this.a.c();
  }

  public final ab d()
  {
    return this.a.d();
  }

  public final void f()
    throws IOException
  {
    this.a.f();
  }

  public final long k_()
  {
    return this.a.k_();
  }

  public final boolean l_()
  {
    return this.a.l_();
  }

  public final ab m_()
  {
    return this.a.m_();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     a.n
 * JD-Core Version:    0.6.2
 */