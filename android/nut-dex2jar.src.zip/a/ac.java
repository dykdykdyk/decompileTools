package a;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

final class ac extends ab
{
  public final ab a(long paramLong)
  {
    return this;
  }

  public final ab a(long paramLong, TimeUnit paramTimeUnit)
  {
    return this;
  }

  public final void f()
    throws IOException
  {
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     a.ac
 * JD-Core Version:    0.6.2
 */