package a;

import java.io.IOException;
import java.io.InputStream;

public abstract interface j extends aa
{
  public abstract long a(byte paramByte)
    throws IOException;

  public abstract long a(z paramz)
    throws IOException;

  public abstract f a();

  public abstract void a(long paramLong)
    throws IOException;

  public abstract k c(long paramLong)
    throws IOException;

  public abstract boolean c()
    throws IOException;

  public abstract InputStream d();

  public abstract byte[] e(long paramLong)
    throws IOException;

  public abstract byte f()
    throws IOException;

  public abstract void f(long paramLong)
    throws IOException;

  public abstract short g()
    throws IOException;

  public abstract int h()
    throws IOException;

  public abstract short i()
    throws IOException;

  public abstract int j()
    throws IOException;

  public abstract long k()
    throws IOException;

  public abstract String n()
    throws IOException;

  public abstract byte[] o()
    throws IOException;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     a.j
 * JD-Core Version:    0.6.2
 */