package android.support.b;

final class f
{
  long a;
  long b;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.b.f
 * JD-Core Version:    0.6.2
 */