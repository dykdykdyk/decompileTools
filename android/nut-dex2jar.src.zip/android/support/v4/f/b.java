package android.support.v4.f;

import java.util.Map;

final class b extends h<K, V>
{
  b(a parama)
  {
  }

  protected final int a()
  {
    return this.a.h;
  }

  protected final int a(Object paramObject)
  {
    return this.a.a(paramObject);
  }

  protected final Object a(int paramInt1, int paramInt2)
  {
    return this.a.g[((paramInt1 << 1) + paramInt2)];
  }

  protected final V a(int paramInt, V paramV)
  {
    return this.a.a(paramInt, paramV);
  }

  protected final void a(int paramInt)
  {
    this.a.d(paramInt);
  }

  protected final void a(K paramK, V paramV)
  {
    this.a.put(paramK, paramV);
  }

  protected final int b(Object paramObject)
  {
    return this.a.b(paramObject);
  }

  protected final Map<K, V> b()
  {
    return this.a;
  }

  protected final void c()
  {
    this.a.clear();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.f.b
 * JD-Core Version:    0.6.2
 */