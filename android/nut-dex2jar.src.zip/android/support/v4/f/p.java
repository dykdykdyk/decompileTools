package android.support.v4.f;

public abstract interface p<T>
{
  public abstract T a();

  public abstract boolean a(T paramT);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.f.p
 * JD-Core Version:    0.6.2
 */