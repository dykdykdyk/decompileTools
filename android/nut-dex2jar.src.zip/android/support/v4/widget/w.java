package android.support.v4.widget;

public abstract interface w
{
  public abstract void a(NestedScrollView paramNestedScrollView);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.w
 * JD-Core Version:    0.6.2
 */