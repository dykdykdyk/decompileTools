package android.support.v4.widget;

import java.lang.reflect.Method;

final class ag
{
  static Method a;
  static boolean b;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.ag
 * JD-Core Version:    0.6.2
 */