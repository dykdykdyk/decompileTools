package android.support.v4.widget;

import android.content.Context;
import android.view.animation.Interpolator;

public abstract interface aj
{
  public abstract Object a(Context paramContext, Interpolator paramInterpolator);

  public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3);

  public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4);

  public abstract void a(Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);

  public abstract boolean a(Object paramObject);

  public abstract int b(Object paramObject);

  public abstract void b(Object paramObject, int paramInt1, int paramInt2, int paramInt3);

  public abstract int c(Object paramObject);

  public abstract boolean c(Object paramObject, int paramInt1, int paramInt2, int paramInt3);

  public abstract float d(Object paramObject);

  public abstract boolean e(Object paramObject);

  public abstract void f(Object paramObject);

  public abstract int g(Object paramObject);

  public abstract int h(Object paramObject);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.aj
 * JD-Core Version:    0.6.2
 */