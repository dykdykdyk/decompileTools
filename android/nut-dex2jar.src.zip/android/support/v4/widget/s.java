package android.support.v4.widget;

import android.widget.EdgeEffect;

final class s extends q
{
  public final boolean a(Object paramObject, float paramFloat1, float paramFloat2)
  {
    ((EdgeEffect)paramObject).onPull(paramFloat1, paramFloat2);
    return true;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.s
 * JD-Core Version:    0.6.2
 */