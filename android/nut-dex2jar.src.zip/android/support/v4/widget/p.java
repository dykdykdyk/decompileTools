package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;

final class p
  implements r
{
  public final Object a(Context paramContext)
  {
    return null;
  }

  public final void a(Object paramObject, int paramInt1, int paramInt2)
  {
  }

  public final boolean a(Object paramObject)
  {
    return true;
  }

  public final boolean a(Object paramObject, float paramFloat)
  {
    return false;
  }

  public final boolean a(Object paramObject, float paramFloat1, float paramFloat2)
  {
    return false;
  }

  public final boolean a(Object paramObject, int paramInt)
  {
    return false;
  }

  public final boolean a(Object paramObject, Canvas paramCanvas)
  {
    return false;
  }

  public final void b(Object paramObject)
  {
  }

  public final boolean c(Object paramObject)
  {
    return false;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.p
 * JD-Core Version:    0.6.2
 */