package android.support.v4.widget;

import android.view.View;
import android.widget.PopupWindow;

abstract interface ae
{
  public abstract void a(PopupWindow paramPopupWindow, int paramInt);

  public abstract void a(PopupWindow paramPopupWindow, View paramView, int paramInt1, int paramInt2, int paramInt3);

  public abstract void a(PopupWindow paramPopupWindow, boolean paramBoolean);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.ae
 * JD-Core Version:    0.6.2
 */