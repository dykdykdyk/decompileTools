package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;

abstract interface r
{
  public abstract Object a(Context paramContext);

  public abstract void a(Object paramObject, int paramInt1, int paramInt2);

  public abstract boolean a(Object paramObject);

  public abstract boolean a(Object paramObject, float paramFloat);

  public abstract boolean a(Object paramObject, float paramFloat1, float paramFloat2);

  public abstract boolean a(Object paramObject, int paramInt);

  public abstract boolean a(Object paramObject, Canvas paramCanvas);

  public abstract void b(Object paramObject);

  public abstract boolean c(Object paramObject);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.r
 * JD-Core Version:    0.6.2
 */