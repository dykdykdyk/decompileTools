package android.support.v4.widget;

import android.widget.OverScroller;

final class am extends al
{
  public final float d(Object paramObject)
  {
    return ((OverScroller)paramObject).getCurrVelocity();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.am
 * JD-Core Version:    0.6.2
 */