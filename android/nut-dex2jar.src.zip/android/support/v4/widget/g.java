package android.support.v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;

abstract interface g
{
  public abstract Drawable a(CompoundButton paramCompoundButton);

  public abstract void a(CompoundButton paramCompoundButton, ColorStateList paramColorStateList);

  public abstract void a(CompoundButton paramCompoundButton, PorterDuff.Mode paramMode);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.widget.g
 * JD-Core Version:    0.6.2
 */