package android.support.v4.app;

import android.app.PendingIntent;
import android.os.Bundle;

public final class bh extends cd
{
  public static final ce d = new bi();
  public int a;
  public CharSequence b;
  public PendingIntent c;
  private final Bundle e;
  private final cl[] f;

  public final int a()
  {
    return this.a;
  }

  public final CharSequence b()
  {
    return this.b;
  }

  public final PendingIntent c()
  {
    return this.c;
  }

  public final Bundle d()
  {
    return this.e;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.bh
 * JD-Core Version:    0.6.2
 */