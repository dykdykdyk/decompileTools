package android.support.v4.app;

abstract interface be
{
  public abstract void a(cd paramcd);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.be
 * JD-Core Version:    0.6.2
 */