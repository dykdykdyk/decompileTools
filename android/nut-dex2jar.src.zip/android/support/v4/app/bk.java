package android.support.v4.app;

public final class bk extends bx
{
  CharSequence a;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.bk
 * JD-Core Version:    0.6.2
 */