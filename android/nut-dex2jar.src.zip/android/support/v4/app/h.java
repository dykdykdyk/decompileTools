package android.support.v4.app;

import android.content.Context;

class h
{
  public int a(Context paramContext, String paramString1, String paramString2)
  {
    return 1;
  }

  public String a(String paramString)
  {
    return null;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.h
 * JD-Core Version:    0.6.2
 */