package android.support.v4.app;

import android.support.v4.b.g;

public abstract class av
{
  public abstract <D> g<D> a(aw<D> paramaw);

  public boolean a()
  {
    return false;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.av
 * JD-Core Version:    0.6.2
 */