package android.support.v4.app;

import android.util.AndroidRuntimeException;

final class cx extends AndroidRuntimeException
{
  public cx(String paramString)
  {
    super(paramString);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.cx
 * JD-Core Version:    0.6.2
 */