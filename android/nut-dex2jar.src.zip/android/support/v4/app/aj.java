package android.support.v4.app;

import android.support.v4.view.bl;

final class aj
  implements Runnable
{
  aj(ah paramah)
  {
  }

  public final void run()
  {
    bl.d(ah.a(this.a), 0);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.aj
 * JD-Core Version:    0.6.2
 */