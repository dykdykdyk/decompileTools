package android.support.v4.app;

import android.view.View;

final class j
  implements au
{
  j(i parami, Fragment paramFragment)
  {
  }

  public final View a()
  {
    return this.a.getView();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.j
 * JD-Core Version:    0.6.2
 */