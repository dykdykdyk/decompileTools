package android.support.v4.app;

import android.app.Notification;

class bw extends bv
{
  public Notification a(bl parambl)
  {
    ck localck = new ck(parambl.a, parambl.B, parambl.b, parambl.c, parambl.h, parambl.f, parambl.i, parambl.d, parambl.e, parambl.g, parambl.o, parambl.p, parambl.q, parambl.k, parambl.l, parambl.j, parambl.n, parambl.v, parambl.C, parambl.x, parambl.r, parambl.s, parambl.t);
    bg.a(localck, parambl.u);
    bg.a(localck, parambl.m);
    return localck.b();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.bw
 * JD-Core Version:    0.6.2
 */