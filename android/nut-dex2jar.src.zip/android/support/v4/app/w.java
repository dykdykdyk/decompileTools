package android.support.v4.app;

import android.os.Handler;
import android.os.Message;

final class w extends Handler
{
  w(v paramv)
  {
  }

  public final void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default:
      super.handleMessage(paramMessage);
    case 1:
      do
        return;
      while (!this.a.e);
      this.a.a(false);
      return;
    case 2:
    }
    this.a.b();
    this.a.b.b();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.w
 * JD-Core Version:    0.6.2
 */