package android.support.v4.app;

final class af
  implements Runnable
{
  af(ad paramad, int paramInt)
  {
  }

  public final void run()
  {
    ad localad = this.c;
    ab localab = this.c.o;
    localad.a(this.a, this.b);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.af
 * JD-Core Version:    0.6.2
 */