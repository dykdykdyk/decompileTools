package android.support.v4.app;

import android.os.Bundle;

public abstract class ct
{
  protected abstract String a();

  protected abstract CharSequence b();

  protected abstract CharSequence[] c();

  protected abstract boolean d();

  protected abstract Bundle e();
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ct
 * JD-Core Version:    0.6.2
 */