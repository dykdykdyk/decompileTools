package android.support.v4.app;

import android.app.Notification;

abstract interface bo
{
  public abstract Notification a(bl parambl);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.bo
 * JD-Core Version:    0.6.2
 */