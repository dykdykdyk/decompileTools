package android.support.v4.app;

import android.app.Notification;
import android.app.Notification.Builder;

public abstract interface bf
{
  public abstract Notification.Builder a();

  public abstract Notification b();
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.bf
 * JD-Core Version:    0.6.2
 */