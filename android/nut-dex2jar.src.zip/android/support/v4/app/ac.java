package android.support.v4.app;

import java.io.FileDescriptor;
import java.io.PrintWriter;

public abstract class ac
{
  public abstract Fragment a(String paramString);

  public abstract an a();

  public abstract void a(int paramInt);

  public abstract void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString);

  public abstract boolean b();
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ac
 * JD-Core Version:    0.6.2
 */