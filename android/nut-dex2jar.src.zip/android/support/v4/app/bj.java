package android.support.v4.app;

import android.graphics.Bitmap;

public final class bj extends bx
{
  Bitmap a;
  Bitmap b;
  boolean c;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.bj
 * JD-Core Version:    0.6.2
 */