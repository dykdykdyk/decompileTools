package android.support.v4.app;

import java.util.ArrayList;

final class m
{
  m a;
  m b;
  int c;
  Fragment d;
  int e;
  int f;
  int g;
  int h;
  ArrayList<Fragment> i;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.m
 * JD-Core Version:    0.6.2
 */