package android.support.v4.app;

import android.os.Bundle;
import android.support.v4.b.g;

public abstract interface aw<D>
{
  public abstract g<D> onCreateLoader(int paramInt, Bundle paramBundle);

  public abstract void onLoadFinished(g<D> paramg, D paramD);

  public abstract void onLoaderReset(g<D> paramg);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.aw
 * JD-Core Version:    0.6.2
 */