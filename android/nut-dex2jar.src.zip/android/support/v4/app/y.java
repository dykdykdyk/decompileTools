package android.support.v4.app;

import android.support.v4.f.r;
import java.util.List;

final class y
{
  Object a;
  List<Fragment> b;
  r<String, av> c;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.y
 * JD-Core Version:    0.6.2
 */