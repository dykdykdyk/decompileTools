package android.support.v4.app;

import android.support.v4.f.a;
import android.view.View;
import java.util.ArrayList;

public final class n
{
  public a<String, String> a = new a();
  public ArrayList<View> b = new ArrayList();
  public at c = new at();
  public View d;

  public n(i parami)
  {
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.n
 * JD-Core Version:    0.6.2
 */