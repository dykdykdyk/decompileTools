package android.support.v4.app;

public abstract class an
{
  public abstract int a();

  public abstract an a(Fragment paramFragment);

  public abstract an a(Fragment paramFragment, String paramString);

  public abstract int b();
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.an
 * JD-Core Version:    0.6.2
 */