package android.support.v4.app;

import android.app.Notification;

class bp extends bw
{
  public Notification a(bl parambl)
  {
    bz localbz = new bz(parambl.a, parambl.B, parambl.b, parambl.c, parambl.h, parambl.f, parambl.i, parambl.d, parambl.e, parambl.g, parambl.o, parambl.p, parambl.q, parambl.k, parambl.l, parambl.j, parambl.n, parambl.v, parambl.C, parambl.x, parambl.r, parambl.s, parambl.t);
    bg.a(localbz, parambl.u);
    bg.a(localbz, parambl.m);
    return localbz.b();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.bp
 * JD-Core Version:    0.6.2
 */