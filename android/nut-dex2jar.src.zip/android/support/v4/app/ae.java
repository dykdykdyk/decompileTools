package android.support.v4.app;

final class ae
  implements Runnable
{
  ae(ad paramad)
  {
  }

  public final void run()
  {
    this.a.d();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ae
 * JD-Core Version:    0.6.2
 */