package android.support.v4.app;

import android.support.v4.view.bl;

final class ai
  implements Runnable
{
  ai(ah paramah)
  {
  }

  public final void run()
  {
    bl.d(ah.a(this.a), 2);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ai
 * JD-Core Version:    0.6.2
 */