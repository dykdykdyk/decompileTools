package android.support.v4.app;

abstract class q extends p
{
  final void b_()
  {
    super.onBackPressed();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.q
 * JD-Core Version:    0.6.2
 */