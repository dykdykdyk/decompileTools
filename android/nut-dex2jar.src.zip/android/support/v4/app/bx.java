package android.support.v4.app;

public abstract class bx
{
  CharSequence d;
  CharSequence e;
  boolean f = false;
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.bx
 * JD-Core Version:    0.6.2
 */