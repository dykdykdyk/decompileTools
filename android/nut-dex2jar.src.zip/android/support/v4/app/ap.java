package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;

final class ap extends Transition.EpicenterCallback
{
  ap(Rect paramRect)
  {
  }

  public final Rect onGetEpicenter(Transition paramTransition)
  {
    return this.a;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.ap
 * JD-Core Version:    0.6.2
 */