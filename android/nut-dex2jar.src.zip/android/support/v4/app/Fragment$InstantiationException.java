package android.support.v4.app;

public class Fragment$InstantiationException extends RuntimeException
{
  public Fragment$InstantiationException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.Fragment.InstantiationException
 * JD-Core Version:    0.6.2
 */