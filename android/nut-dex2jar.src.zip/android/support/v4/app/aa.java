package android.support.v4.app;

public final class aa
{
  final ab<?> a;

  aa(ab<?> paramab)
  {
    this.a = paramab;
  }

  final Fragment a(String paramString)
  {
    return this.a.f.b(paramString);
  }

  public final void a()
  {
    this.a.f.t = false;
  }

  public final boolean b()
  {
    return this.a.f.d();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.app.aa
 * JD-Core Version:    0.6.2
 */