package android.support.v4.os;

import android.os.Parcel;

public abstract interface c<T>
{
  public abstract T a(Parcel paramParcel, ClassLoader paramClassLoader);

  public abstract T[] a(int paramInt);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.os.c
 * JD-Core Version:    0.6.2
 */