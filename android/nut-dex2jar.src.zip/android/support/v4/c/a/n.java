package android.support.v4.c.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

final class n extends m
{
  n(m paramm)
  {
    super(paramm);
  }

  public final Drawable newDrawable(Resources paramResources)
  {
    return new l(this, paramResources);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.c.a.n
 * JD-Core Version:    0.6.2
 */