package android.support.v4.c.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

final class r extends m
{
  r(m paramm)
  {
    super(paramm);
  }

  public final Drawable newDrawable(Resources paramResources)
  {
    return new q(this, paramResources);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.c.a.r
 * JD-Core Version:    0.6.2
 */