package android.support.v4.c.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

class s extends q
{
  s(Drawable paramDrawable)
  {
    super(paramDrawable);
  }

  s(m paramm, Resources paramResources)
  {
    super(paramm, paramResources);
  }

  m b()
  {
    return new t(this.b);
  }

  public boolean isAutoMirrored()
  {
    return this.c.isAutoMirrored();
  }

  public void setAutoMirrored(boolean paramBoolean)
  {
    this.c.setAutoMirrored(paramBoolean);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.c.a.s
 * JD-Core Version:    0.6.2
 */