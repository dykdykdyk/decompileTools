package android.support.v4.c.a;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

class q extends l
{
  q(Drawable paramDrawable)
  {
    super(paramDrawable);
  }

  q(m paramm, Resources paramResources)
  {
    super(paramm, paramResources);
  }

  m b()
  {
    return new r(this.b);
  }

  public void jumpToCurrentState()
  {
    this.c.jumpToCurrentState();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.c.a.q
 * JD-Core Version:    0.6.2
 */