package android.support.v4.c.a;

import android.graphics.drawable.Drawable;

final class i extends h
{
  public final Drawable c(Drawable paramDrawable)
  {
    return paramDrawable;
  }

  public final int d(Drawable paramDrawable)
  {
    return paramDrawable.getLayoutDirection();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.c.a.i
 * JD-Core Version:    0.6.2
 */