package android.support.v4.c.a;

import android.graphics.drawable.Drawable;

class d extends b
{
  public Drawable c(Drawable paramDrawable)
  {
    Object localObject = paramDrawable;
    if (!(paramDrawable instanceof w))
      localObject = new o(paramDrawable);
    return localObject;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.c.a.d
 * JD-Core Version:    0.6.2
 */