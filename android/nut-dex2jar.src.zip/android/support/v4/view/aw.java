package android.support.v4.view;

import android.view.MotionEvent;

class aw extends av
{
  public final int a(MotionEvent paramMotionEvent)
  {
    return paramMotionEvent.getSource();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.aw
 * JD-Core Version:    0.6.2
 */