package android.support.v4.view;

public abstract interface o
{
  public abstract void a(boolean paramBoolean);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.o
 * JD-Core Version:    0.6.2
 */