package android.support.v4.view;

import android.view.ViewConfiguration;

final class cg extends cf
{
  public final boolean b(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.hasPermanentMenuKey();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.cg
 * JD-Core Version:    0.6.2
 */