package android.support.v4.view;

class bn extends bm
{
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.bn
 * JD-Core Version:    0.6.2
 */