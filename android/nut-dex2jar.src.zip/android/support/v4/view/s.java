package android.support.v4.view;

final class s
  implements r
{
  public final int a(int paramInt1, int paramInt2)
  {
    return 0xFF7FFFFF & paramInt1;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.s
 * JD-Core Version:    0.6.2
 */