package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public abstract interface ai
{
  public abstract View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ai
 * JD-Core Version:    0.6.2
 */