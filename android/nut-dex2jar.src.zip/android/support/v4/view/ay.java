package android.support.v4.view;

import android.view.MotionEvent;

abstract interface ay
{
  public abstract int a(MotionEvent paramMotionEvent);

  public abstract int a(MotionEvent paramMotionEvent, int paramInt);

  public abstract int b(MotionEvent paramMotionEvent, int paramInt);

  public abstract float c(MotionEvent paramMotionEvent, int paramInt);

  public abstract float d(MotionEvent paramMotionEvent, int paramInt);

  public abstract float e(MotionEvent paramMotionEvent, int paramInt);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ay
 * JD-Core Version:    0.6.2
 */