package android.support.v4.view;

import android.view.MenuItem;

final class aq extends ap
{
  public final boolean b(MenuItem paramMenuItem)
  {
    return paramMenuItem.expandActionView();
  }

  public final boolean c(MenuItem paramMenuItem)
  {
    return paramMenuItem.isActionViewExpanded();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.aq
 * JD-Core Version:    0.6.2
 */