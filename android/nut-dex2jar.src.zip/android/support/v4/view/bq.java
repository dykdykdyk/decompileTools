package android.support.v4.view;

import android.view.View;

class bq extends br
{
  public final boolean z(View paramView)
  {
    return paramView.hasOnClickListeners();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.bq
 * JD-Core Version:    0.6.2
 */