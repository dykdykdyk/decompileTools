package android.support.v4.view;

import android.view.LayoutInflater;

abstract interface aa
{
  public abstract ai a(LayoutInflater paramLayoutInflater);

  public abstract void a(LayoutInflater paramLayoutInflater, ai paramai);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.aa
 * JD-Core Version:    0.6.2
 */