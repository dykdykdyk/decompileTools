package android.support.v4.view;

import android.view.Gravity;

final class t
  implements r
{
  public final int a(int paramInt1, int paramInt2)
  {
    return Gravity.getAbsoluteGravity(paramInt1, paramInt2);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.t
 * JD-Core Version:    0.6.2
 */