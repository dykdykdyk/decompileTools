package android.support.v4.view;

import android.view.View;

final class bx extends bw
{
  public final void e(View paramView, int paramInt)
  {
    paramView.setScrollIndicators(paramInt, 3);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.bx
 * JD-Core Version:    0.6.2
 */