package android.support.v4.view;

import android.view.View;
import android.view.animation.Interpolator;

public abstract interface dm
{
  public abstract long a(View paramView);

  public abstract void a(dd paramdd, View paramView);

  public abstract void a(dd paramdd, View paramView, float paramFloat);

  public abstract void a(dd paramdd, View paramView, dt paramdt);

  public abstract void a(View paramView, long paramLong);

  public abstract void a(View paramView, dv paramdv);

  public abstract void a(View paramView, Interpolator paramInterpolator);

  public abstract void b(dd paramdd, View paramView);

  public abstract void b(dd paramdd, View paramView, float paramFloat);

  public abstract void b(View paramView, long paramLong);

  public abstract void c(dd paramdd, View paramView, float paramFloat);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.dm
 * JD-Core Version:    0.6.2
 */