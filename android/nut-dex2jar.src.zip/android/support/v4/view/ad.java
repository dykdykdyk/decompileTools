package android.support.v4.view;

import android.view.LayoutInflater;

final class ad extends ac
{
  public final void a(LayoutInflater paramLayoutInflater, ai paramai)
  {
    if (paramai != null);
    for (paramai = new ah(paramai); ; paramai = null)
    {
      paramLayoutInflater.setFactory2(paramai);
      return;
    }
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ad
 * JD-Core Version:    0.6.2
 */