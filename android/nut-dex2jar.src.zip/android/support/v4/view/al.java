package android.support.v4.view;

import android.view.ViewGroup.MarginLayoutParams;

final class al
  implements ak
{
  public final int a(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    return paramMarginLayoutParams.leftMargin;
  }

  public final int b(ViewGroup.MarginLayoutParams paramMarginLayoutParams)
  {
    return paramMarginLayoutParams.rightMargin;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.al
 * JD-Core Version:    0.6.2
 */