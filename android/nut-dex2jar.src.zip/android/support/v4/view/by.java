package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.view.View;

abstract interface by
{
  public abstract int a(int paramInt1, int paramInt2, int paramInt3);

  public abstract int a(View paramView);

  public abstract dw a(View paramView, dw paramdw);

  public abstract void a(View paramView, float paramFloat);

  public abstract void a(View paramView, ColorStateList paramColorStateList);

  public abstract void a(View paramView, PorterDuff.Mode paramMode);

  public abstract void a(View paramView, a parama);

  public abstract void a(View paramView, bd parambd);

  public abstract void a(View paramView, Runnable paramRunnable);

  public abstract void a(View paramView, Runnable paramRunnable, long paramLong);

  public abstract void a(View paramView, boolean paramBoolean);

  public abstract boolean a(View paramView, int paramInt);

  public abstract dw b(View paramView, dw paramdw);

  public abstract void b(View paramView, float paramFloat);

  public abstract boolean b(View paramView);

  public abstract boolean b(View paramView, int paramInt);

  public abstract void c(View paramView, float paramFloat);

  public abstract void c(View paramView, int paramInt);

  public abstract boolean c(View paramView);

  public abstract void d(View paramView);

  public abstract void d(View paramView, float paramFloat);

  public abstract void d(View paramView, int paramInt);

  public abstract int e(View paramView);

  public abstract void e(View paramView, int paramInt);

  public abstract float f(View paramView);

  public abstract int g(View paramView);

  public abstract int h(View paramView);

  public abstract int i(View paramView);

  public abstract int j(View paramView);

  public abstract boolean k(View paramView);

  public abstract float l(View paramView);

  public abstract float m(View paramView);

  public abstract int n(View paramView);

  public abstract int o(View paramView);

  public abstract dd p(View paramView);

  public abstract int q(View paramView);

  public abstract void r(View paramView);

  public abstract void s(View paramView);

  public abstract void t(View paramView);

  public abstract ColorStateList u(View paramView);

  public abstract PorterDuff.Mode v(View paramView);

  public abstract void w(View paramView);

  public abstract boolean x(View paramView);

  public abstract boolean y(View paramView);

  public abstract boolean z(View paramView);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.by
 * JD-Core Version:    0.6.2
 */