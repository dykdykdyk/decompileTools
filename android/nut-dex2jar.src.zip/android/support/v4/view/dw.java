package android.support.v4.view;

public class dw
{
  public int a()
  {
    return 0;
  }

  public dw a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    return this;
  }

  public int b()
  {
    return 0;
  }

  public int c()
  {
    return 0;
  }

  public int d()
  {
    return 0;
  }

  public boolean e()
  {
    return false;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.dw
 * JD-Core Version:    0.6.2
 */