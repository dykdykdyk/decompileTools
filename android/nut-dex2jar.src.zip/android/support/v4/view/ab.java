package android.support.v4.view;

import android.view.LayoutInflater;

class ab
  implements aa
{
  public final ai a(LayoutInflater paramLayoutInflater)
  {
    paramLayoutInflater = paramLayoutInflater.getFactory();
    if ((paramLayoutInflater instanceof af))
      return ((af)paramLayoutInflater).a;
    return null;
  }

  public void a(LayoutInflater paramLayoutInflater, ai paramai)
  {
    if (paramai != null);
    for (paramai = new af(paramai); ; paramai = null)
    {
      paramLayoutInflater.setFactory(paramai);
      return;
    }
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.ab
 * JD-Core Version:    0.6.2
 */