package android.support.v4.view.a;

import java.util.List;

abstract interface ad
{
  public abstract boolean a();

  public abstract List<Object> b();

  public abstract Object c();

  public abstract Object d();
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.ad
 * JD-Core Version:    0.6.2
 */