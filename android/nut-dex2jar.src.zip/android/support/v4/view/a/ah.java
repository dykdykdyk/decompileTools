package android.support.v4.view.a;

public abstract interface ah
{
  public abstract void a(Object paramObject, int paramInt);

  public abstract void a(Object paramObject, boolean paramBoolean);

  public abstract void b(Object paramObject, int paramInt);

  public abstract void c(Object paramObject, int paramInt);

  public abstract void d(Object paramObject, int paramInt);

  public abstract void e(Object paramObject, int paramInt);

  public abstract void f(Object paramObject, int paramInt);

  public abstract void g(Object paramObject, int paramInt);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.ah
 * JD-Core Version:    0.6.2
 */