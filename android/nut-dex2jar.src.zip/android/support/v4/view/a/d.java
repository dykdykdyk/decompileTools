package android.support.v4.view.a;

import android.view.accessibility.AccessibilityEvent;

class d
  implements e
{
  public int a(AccessibilityEvent paramAccessibilityEvent)
  {
    return 0;
  }

  public void a(AccessibilityEvent paramAccessibilityEvent, int paramInt)
  {
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.d
 * JD-Core Version:    0.6.2
 */