package android.support.v4.view.a;

final class t extends x
{
  public final Object a(r paramr)
  {
    return new z(new u(this, paramr));
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.t
 * JD-Core Version:    0.6.2
 */