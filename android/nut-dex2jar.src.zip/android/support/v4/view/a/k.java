package android.support.v4.view.a;

class k extends i
{
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.k
 * JD-Core Version:    0.6.2
 */