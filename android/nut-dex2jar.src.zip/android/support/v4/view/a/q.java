package android.support.v4.view.a;

public final class q
{
  final Object a;

  private q(Object paramObject)
  {
    this.a = paramObject;
  }

  public static q a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    return new q(f.a().a(paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean));
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.q
 * JD-Core Version:    0.6.2
 */