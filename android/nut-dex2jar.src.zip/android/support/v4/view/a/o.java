package android.support.v4.view.a;

import android.graphics.Rect;

class o
  implements j
{
  public int a(Object paramObject)
  {
    return 0;
  }

  public Object a(int paramInt1, int paramInt2)
  {
    return null;
  }

  public Object a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean)
  {
    return null;
  }

  public void a(Object paramObject, int paramInt)
  {
  }

  public void a(Object paramObject, Rect paramRect)
  {
  }

  public void a(Object paramObject, CharSequence paramCharSequence)
  {
  }

  public void a(Object paramObject1, Object paramObject2)
  {
  }

  public void a(Object paramObject, boolean paramBoolean)
  {
  }

  public CharSequence b(Object paramObject)
  {
    return null;
  }

  public void b(Object paramObject, Rect paramRect)
  {
  }

  public void b(Object paramObject1, Object paramObject2)
  {
  }

  public CharSequence c(Object paramObject)
  {
    return null;
  }

  public CharSequence d(Object paramObject)
  {
    return null;
  }

  public CharSequence e(Object paramObject)
  {
    return null;
  }

  public boolean f(Object paramObject)
  {
    return false;
  }

  public boolean g(Object paramObject)
  {
    return false;
  }

  public boolean h(Object paramObject)
  {
    return false;
  }

  public boolean i(Object paramObject)
  {
    return false;
  }

  public boolean j(Object paramObject)
  {
    return false;
  }

  public boolean k(Object paramObject)
  {
    return false;
  }

  public boolean l(Object paramObject)
  {
    return false;
  }

  public boolean m(Object paramObject)
  {
    return false;
  }

  public boolean n(Object paramObject)
  {
    return false;
  }

  public boolean o(Object paramObject)
  {
    return false;
  }

  public String p(Object paramObject)
  {
    return null;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.o
 * JD-Core Version:    0.6.2
 */