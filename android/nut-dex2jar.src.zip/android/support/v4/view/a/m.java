package android.support.v4.view.a;

import android.view.accessibility.AccessibilityNodeInfo;

class m extends l
{
  public final String p(Object paramObject)
  {
    return ((AccessibilityNodeInfo)paramObject).getViewIdResourceName();
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.m
 * JD-Core Version:    0.6.2
 */