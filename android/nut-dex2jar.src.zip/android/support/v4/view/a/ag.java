package android.support.v4.view.a;

import android.view.accessibility.AccessibilityRecord;

class ag extends af
{
  public final void f(Object paramObject, int paramInt)
  {
    ((AccessibilityRecord)paramObject).setMaxScrollX(paramInt);
  }

  public final void g(Object paramObject, int paramInt)
  {
    ((AccessibilityRecord)paramObject).setMaxScrollY(paramInt);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.ag
 * JD-Core Version:    0.6.2
 */