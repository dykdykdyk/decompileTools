package android.support.v4.view.a;

import java.util.ArrayList;
import java.util.List;

final class w
  implements ad
{
  w(v paramv, r paramr)
  {
  }

  public final boolean a()
  {
    return r.b();
  }

  public final List<Object> b()
  {
    r.c();
    new ArrayList();
    throw new NullPointerException();
  }

  public final Object c()
  {
    r.a();
    return null;
  }

  public final Object d()
  {
    r.d();
    return null;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.w
 * JD-Core Version:    0.6.2
 */