package android.support.v4.view.a;

import android.graphics.Rect;

public abstract interface j
{
  public abstract int a(Object paramObject);

  public abstract Object a(int paramInt1, int paramInt2);

  public abstract Object a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean);

  public abstract void a(Object paramObject, int paramInt);

  public abstract void a(Object paramObject, Rect paramRect);

  public abstract void a(Object paramObject, CharSequence paramCharSequence);

  public abstract void a(Object paramObject1, Object paramObject2);

  public abstract void a(Object paramObject, boolean paramBoolean);

  public abstract CharSequence b(Object paramObject);

  public abstract void b(Object paramObject, Rect paramRect);

  public abstract void b(Object paramObject1, Object paramObject2);

  public abstract CharSequence c(Object paramObject);

  public abstract CharSequence d(Object paramObject);

  public abstract CharSequence e(Object paramObject);

  public abstract boolean f(Object paramObject);

  public abstract boolean g(Object paramObject);

  public abstract boolean h(Object paramObject);

  public abstract boolean i(Object paramObject);

  public abstract boolean j(Object paramObject);

  public abstract boolean k(Object paramObject);

  public abstract boolean l(Object paramObject);

  public abstract boolean m(Object paramObject);

  public abstract boolean n(Object paramObject);

  public abstract boolean o(Object paramObject);

  public abstract String p(Object paramObject);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.view.a.j
 * JD-Core Version:    0.6.2
 */