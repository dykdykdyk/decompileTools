package android.support.v4.a;

import android.view.View;

final class c
  implements b
{
  public final void a(View paramView)
  {
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.a.c
 * JD-Core Version:    0.6.2
 */