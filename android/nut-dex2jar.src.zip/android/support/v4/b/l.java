package android.support.v4.b;

import android.content.Intent;
import java.util.ArrayList;

final class l
{
  final Intent a;
  final ArrayList<m> b;

  l(Intent paramIntent, ArrayList<m> paramArrayList)
  {
    this.a = paramIntent;
    this.b = paramArrayList;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.b.l
 * JD-Core Version:    0.6.2
 */