package android.support.v4.b;

import android.content.ComponentName;
import android.content.Intent;

abstract interface c
{
  public abstract Intent a(ComponentName paramComponentName);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.b.c
 * JD-Core Version:    0.6.2
 */