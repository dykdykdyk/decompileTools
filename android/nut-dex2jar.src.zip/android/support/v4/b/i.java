package android.support.v4.b;

public abstract interface i<D>
{
  public abstract void a(g<D> paramg, D paramD);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.b.i
 * JD-Core Version:    0.6.2
 */