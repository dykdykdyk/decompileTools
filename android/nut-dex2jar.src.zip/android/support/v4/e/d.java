package android.support.v4.e;

import java.util.Locale;

final class d
  implements b
{
  public final String a(Locale paramLocale)
  {
    return g.a(paramLocale);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.e.d
 * JD-Core Version:    0.6.2
 */