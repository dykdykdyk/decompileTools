package android.support.v4.e;

import android.text.TextUtils;
import java.util.Locale;

final class j extends i
{
  private j()
  {
    super((byte)0);
  }

  public final int a(Locale paramLocale)
  {
    return TextUtils.getLayoutDirectionFromLocale(paramLocale);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v4.e.j
 * JD-Core Version:    0.6.2
 */