package android.support.v7.a;

import android.support.v4.view.bl;
import android.support.v4.view.dd;
import android.support.v4.view.du;
import android.support.v7.widget.ActionBarContextView;
import android.view.View;

final class ai extends du
{
  ai(ah paramah)
  {
  }

  public final void a(View paramView)
  {
    this.a.a.r.setVisibility(0);
  }

  public final void b(View paramView)
  {
    bl.c(this.a.a.r, 1.0F);
    this.a.a.u.a(null);
    this.a.a.u = null;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.a.ai
 * JD-Core Version:    0.6.2
 */