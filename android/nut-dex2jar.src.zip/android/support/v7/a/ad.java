package android.support.v7.a;

final class ad
  implements Runnable
{
  ad(ac paramac)
  {
  }

  public final void run()
  {
    if ((ac.a(this.a) & 0x1) != 0)
      ac.a(this.a, 0);
    if ((ac.a(this.a) & 0x1000) != 0)
      ac.a(this.a, 108);
    ac.b(this.a);
    ac.c(this.a);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.a.ad
 * JD-Core Version:    0.6.2
 */