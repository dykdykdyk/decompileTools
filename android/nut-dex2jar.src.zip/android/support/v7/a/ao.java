package android.support.v7.a;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.view.menu.g;
import android.support.v7.view.menu.i;
import android.view.View;
import android.view.ViewGroup;

final class ao
{
  int a;
  int b;
  int c;
  int d;
  int e;
  int f;
  ViewGroup g;
  View h;
  View i;
  i j;
  g k;
  Context l;
  boolean m;
  boolean n;
  boolean o;
  public boolean p;
  boolean q;
  boolean r;
  Bundle s;

  ao(int paramInt)
  {
    this.a = paramInt;
    this.q = false;
  }

  final void a(i parami)
  {
    if (parami == this.j);
    do
    {
      return;
      if (this.j != null)
        this.j.b(this.k);
      this.j = parami;
    }
    while ((parami == null) || (this.k == null));
    parami.a(this.k);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.a.ao
 * JD-Core Version:    0.6.2
 */