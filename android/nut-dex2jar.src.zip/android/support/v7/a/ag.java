package android.support.v7.a;

import android.support.v7.widget.bs;

final class ag
  implements bs
{
  ag(ac paramac)
  {
  }

  public final void a()
  {
    ac.d(this.a);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.a.ag
 * JD-Core Version:    0.6.2
 */