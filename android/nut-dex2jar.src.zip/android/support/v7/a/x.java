package android.support.v7.a;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.Window;

class x extends ac
{
  x(Context paramContext, Window paramWindow, t paramt)
  {
    super(paramContext, paramWindow, paramt);
  }

  final View a(String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    return null;
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.a.x
 * JD-Core Version:    0.6.2
 */