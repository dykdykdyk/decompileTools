package android.support.v7.a;

import android.support.v7.widget.fz;
import android.view.MenuItem;
import android.view.Window.Callback;

final class av
  implements fz
{
  av(at paramat)
  {
  }

  public final boolean a(MenuItem paramMenuItem)
  {
    return this.a.c.onMenuItemSelected(0, paramMenuItem);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.a.av
 * JD-Core Version:    0.6.2
 */