package android.support.v7.a;

import android.content.Context;
import android.content.res.Configuration;
import android.support.v7.view.c;
import android.view.KeyEvent;
import android.view.View;

public abstract class a
{
  public android.support.v7.view.b a(c paramc)
  {
    return null;
  }

  public abstract void a();

  public void a(Configuration paramConfiguration)
  {
  }

  public abstract void a(View paramView, b paramb);

  public void a(CharSequence paramCharSequence)
  {
  }

  public void a(boolean paramBoolean)
  {
  }

  public boolean a(int paramInt, KeyEvent paramKeyEvent)
  {
    return false;
  }

  public abstract void b();

  public void b(boolean paramBoolean)
  {
  }

  public abstract View c();

  public void c(boolean paramBoolean)
  {
  }

  public abstract int d();

  public abstract boolean e();

  public Context f()
  {
    return null;
  }

  public boolean g()
  {
    return false;
  }

  public boolean h()
  {
    return false;
  }

  boolean i()
  {
    return false;
  }

  void j()
  {
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.a.a
 * JD-Core Version:    0.6.2
 */