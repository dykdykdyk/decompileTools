package android.support.v7.a;

import android.graphics.Rect;
import android.support.v7.widget.cj;

final class af
  implements cj
{
  af(ac paramac)
  {
  }

  public final void a(Rect paramRect)
  {
    paramRect.top = ac.b(this.a, paramRect.top);
  }
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.a.af
 * JD-Core Version:    0.6.2
 */