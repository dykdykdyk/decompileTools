package android.support.v7.widget;

public abstract interface bs
{
  public abstract void a();
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.bs
 * JD-Core Version:    0.6.2
 */