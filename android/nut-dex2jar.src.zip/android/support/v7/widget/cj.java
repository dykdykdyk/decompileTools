package android.support.v7.widget;

import android.graphics.Rect;

public abstract interface cj
{
  public abstract void a(Rect paramRect);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.widget.cj
 * JD-Core Version:    0.6.2
 */