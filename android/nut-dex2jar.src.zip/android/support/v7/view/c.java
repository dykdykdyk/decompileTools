package android.support.v7.view;

import android.view.Menu;
import android.view.MenuItem;

public abstract interface c
{
  public abstract void a(b paramb);

  public abstract boolean a(b paramb, Menu paramMenu);

  public abstract boolean a(b paramb, MenuItem paramMenuItem);

  public abstract boolean b(b paramb, Menu paramMenu);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.view.c
 * JD-Core Version:    0.6.2
 */