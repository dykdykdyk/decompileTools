package android.support.v7.view.menu;

import android.view.MenuItem;

public abstract interface j
{
  public abstract void a(i parami);

  public abstract boolean a(i parami, MenuItem paramMenuItem);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.j
 * JD-Core Version:    0.6.2
 */