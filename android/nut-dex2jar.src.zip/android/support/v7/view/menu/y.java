package android.support.v7.view.menu;

public abstract interface y
{
  public abstract void a(i parami, boolean paramBoolean);

  public abstract boolean a(i parami);
}

/* Location:           C:\crazyd\work\ustone\odm2016031702\baidu\android\nut-dex2jar.jar
 * Qualified Name:     android.support.v7.view.menu.y
 * JD-Core Version:    0.6.2
 */