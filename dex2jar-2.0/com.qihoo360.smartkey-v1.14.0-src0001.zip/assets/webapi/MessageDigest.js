define(function(require, exports, module) {

    function MessageDigest() {
    }

    (function() {

        this.md5 = function(s, encoding) {
            return s;
        };

    }).call(MessageDigest.protype);

    module.exports = MessageDigest;

});

