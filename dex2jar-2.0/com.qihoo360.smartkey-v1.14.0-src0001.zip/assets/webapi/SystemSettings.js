define(function(require, exports, module) {

    function SystemSettings() {
    }

    (function() {

        this.getAndroidId = function() {
            return '0123456789';
        };

    }).call(SystemSettings.prototype);

    module.exports = SystemSettings;

});

