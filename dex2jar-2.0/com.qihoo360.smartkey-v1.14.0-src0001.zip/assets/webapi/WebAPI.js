define(function(require, exports, module) {

    var ConnectivityManager = require('./ConnectivityManager');
    var DownloadManager = require('./DownloadManager');
    var MessageDigest = require('./MessageDigest');
    var PackageManager = require('./PackageManager');
    var TelephonyManager = require('./TelephonyManager');
    var WifiManager = require('./WifiManager');
    var SystemSettings = require('./SystemSettings');
    var SystemProperties = require('./SystemProperties');

    function WebAPI = function() {
        this.$connectivityManager = new ConnectivityManager();
        this.$downloadManager = new DownloadManager();
        this.$messageDigest = new MessageDigest();
        this.$packageManager = new PackageManager();
        this.$telephonyManager = new TelephonyManager();
        this.$wifiManager = new WifiManager();
        this.$systemSettings = new SystemSettings();
        this.$systemProperties = new SystemProperties();
    }

    (function() {

        this.getConnectivityManager = function() {
            return this.$connectivityManager;
        };

        this.getDownloadManager = function() {
            return this.$downloadManager;
        };

        this.getMessageDigest = function() {
            return this.$messageDigest;
        };

        this.getPackageManager = function() {
            return this.$packageManager;
        };

        this.getTelephonyManager = function() {
            return this.$telephonyManager;
        };

        this.getWifiManager = function() {
            return this.$wifiManager;
        };

        this.getSystemSettings = function() {
            return this.$systemSettings;
        };

        this.getSystemProperties = function() {
            return this.$systemProperties;
        };

        this.getLauncher = function() {
            return 'com.smartkey.platform.MainActivity';
        };

        this.getHeadsetState = function() {
            return 0;
        };

        this.getHeadsetName = function() {
            return 'virtual-headset';
        };

        this.getHeadsetMicrophone = function() {
            return 1;
        };

        this.isSwitchOn = function() {
            return false;
        };

        this.setSwitchOn = function(state) {
            // TODO
        };

        this.isVibratorEnabled = function() {
            return true;
        };

        this.setVibratorEnabled = function(enabled) {
            // TODO
        };

        this.isNotificationEnabled = function() {
            return true;
        };

        this.setNotificationEnabled = function(enabled) {
            // TODO
        };

        this.isKeepAwakeEnabled = function() {
            return true;
        };

        this.setKeepAwakeEnabled = function(enabled) {
            // TODO
        };

        this.isPocketModeEnabled = function() {
            return true;
        };

        this.setPocketModeEnabled = function(enabled) {
            // TODO
        };

        this.isFileLogEnabled = function() {
            return false;
        };

        this.setFileLogEnabled = function(enabled) {
            // TODO
        };

        this.getRecognitionTimeout = function() {
            return 800;
        };

        this.setRecognitionTimeout = function(timeout) {
            // TODO
        };

        this.isScreenOn = function() {
            return true;
        };

        this.getChannelNumber = function() {
            return 0;
        };

        this.getPackageName = function() {
            return 'com.smartkey.platform';
        };

        this.getVersionCode = function() {
            return 0x0101;
        };

        this.getVersionName = function() {
            return '1.1';
        };

        this.getMetaData = function(name) {
            return null;
        };

        this.startActivity = function(json) {
            if ('object' === typeof json) {
                json = JSON.stringify(json);
            } else if ('string' === typeof json) {
                // TODO
            } else {
                return;
            }
        };

        this.startService = function(json) {
            if ('object' === typeof json) {
                json = JSON.stringify(json);
            } else if ('string' === typeof json) {
                // TODO
            } else {
                return;
            }
        };

        this.finish = function() {
        };

    }).call(WebAPI.prototype);

    module.exports = WebAPI;

});

