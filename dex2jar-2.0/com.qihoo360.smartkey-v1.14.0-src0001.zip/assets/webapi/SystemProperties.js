define(function(require, exports, module) {

    function SystemProperties() {
    }

    (function() {

        this.get = function(property) {
            return null;
        };

        this.getBuildProperties = function() {
            return JSON.stringify({
            });
        };

    }).call(SystemProperties.prototype);

});

