define(function(require, exports, module) {

    function ConnectivityManager() {
    }

    ConnectivityManager.TYPE_NONE           = -1;
    ConnectivityManager.TYPE_MOBILE         = 0;
    ConnectivityManager.TYPE_WIFI           = 1;
    ConnectivityManager.TYPE_MOBILE_MMS     = 2;
    ConnectivityManager.TYPE_MOBILE_SUPL    = 3;
    ConnectivityManager.TYPE_MOBILE_DUN     = 4;
    ConnectivityManager.TYPE_MOBILE_HIPRI   = 5;
    ConnectivityManager.TYPE_WIMAX          = 6;
    ConnectivityManager.TYPE_BLUETOOTH      = 7;
    ConnectivityManager.TYPE_DUMMY          = 8;
    ConnectivityManager.TYPE_ETHERNET       = 9;
    ConnectivityManager.TYPE_MOBILE_FOTA    = 10;
    ConnectivityManager.TYPE_MOBILE_IMS     = 11;
    ConnectivityManager.TYPE_MOBILE_CBS     = 12;
    ConnectivityManager.TYPE_WIFI_P2P       = 13;
    ConnectivityManager.TYPE_MOBILE_IA      = 14;

    ConnectivityManager.TYPE_NAMES = [
        /* 00 */ 'MOBILE',
        /* 01 */ 'WIFI',
        /* 02 */ 'MOBILE_MMS',
        /* 03 */ 'MOBILE_SUPL',
        /* 04 */ 'MOBILE_DUN',
        /* 05 */ 'MOBILE_HIPRI',
        /* 06 */ 'WIMAX',
        /* 07 */ 'BLUETOOTH',
        /* 08 */ 'DUMMY',
        /* 09 */ 'ETHERNET',
        /* 10 */ 'MOBILE_FOTA',
        /* 11 */ 'MOBILE_IMS',
        /* 12 */ 'MOBILE_CBS',
        /* 13 */ 'WIFI_P2P',
        /* 14 */ 'MOBILE_IA',
    ];

    (function() {

        this.getNetworkInfo = function(networkType) {
            return JSON.stringify({
                'type' : ConnectivityManager.TYPE_ETHERNET,
                'typeName' : ConnectivityManager.TYPE_NAMES[ConnectivityManager.TYPE_ETHERNET],
                'subtype' : -1,
                'subtypeName' : 'none',
                'extraInfo' : '',
                'available' : true,
                'connected' : true,
                'failover' : false,
                'roaming' : false,
            }); 
        };

        this.getActiveNetworkInfo = function() {
            return JSON.stringify({
                'type' : ConnectivityManager.TYPE_ETHERNET,
                'typeName' : ConnectivityManager.TYPE_NAMES[ConnectivityManager.TYPE_ETHERNET],
                'subtype' : -1,
                'subtypeName' : 'none',
                'extraInfo' : '',
                'available' : true,
                'connected' : true,
                'failover' : false,
                'roaming' : false,
            });
        };

    }).call(ConnectivityManager.prototype);

    module.exports = ConnectivityManager;

});

