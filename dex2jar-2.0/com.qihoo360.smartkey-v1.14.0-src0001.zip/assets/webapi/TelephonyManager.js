define(function(require, exports, module) {

    function TelephonyManager() {
    }

    (function() {

        this.getDeviceId = function() {
            return '0123456789';
        };

        this.hasIccCard = function() {
            return false;
        };

        this.getSimSerialNumber = function() {
            return "9876543210";
        };

    }).call(TelephonyManager.protype);

    module.exports = TelephonyManager;

});

