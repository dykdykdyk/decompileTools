define(function(require, module, exports) {

    function WifiManager() {
    }

    (function() {

        this.getIpAddress = function() {
            return '00000000';
        };

        this.getMacAddress = function() {
            return 'FFFFFFFF';
        };

    }).call(WifiManager.protype);

    module.exports = WifiManager;

});

