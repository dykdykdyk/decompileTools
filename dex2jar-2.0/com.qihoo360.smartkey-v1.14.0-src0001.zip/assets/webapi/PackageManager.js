define(function(require, exports, module) {

    function PackageManager() {
    }

    PackageManager.FLAG_SYSTEM                    = 1 << 0;
    PackageManager.FLAG_DEBUGGABLE                = 1 << 1;
    PackageManager.FLAG_HAS_CODE                  = 1 << 2;
    PackageManager.FLAG_PERSISTENT                = 1 << 3;
    PackageManager.FLAG_FACTORY_TEST              = 1 << 4;
    PackageManager.FLAG_ALLOW_TASK_REPARENTING    = 1 << 5;
    PackageManager.FLAG_ALLOW_CLEAR_USER_DATA     = 1 << 6;
    PackageManager.FLAG_UPDATED_SYSTEM_APP        = 1 << 7;
    PackageManager.FLAG_TEST_ONLY                 = 1 << 8;
    PackageManager.FLAG_SUPPORTS_SMALL_SCREENS    = 1 << 9;
    PackageManager.FLAG_SUPPORTS_NORMAL_SCREENS   = 1 << 10;
    PackageManager.FLAG_SUPPORTS_LARGE_SCREENS    = 1 << 11;
    PackageManager.FLAG_RESIZEABLE_FOR_SCREENS    = 1 << 12;
    PackageManager.FLAG_SUPPORTS_SCREEN_DENSITIES = 1 << 13;
    PackageManager.FLAG_VM_SAFE_MODE              = 1 << 14;
    PackageManager.FLAG_ALLOW_BACKUP              = 1 << 15;
    PackageManager.FLAG_KILL_AFTER_RESTORE        = 1 << 16;
    PackageManager.FLAG_RESTORE_ANY_VERSION       = 1 << 17;
    PackageManager.FLAG_EXTERNAL_STORAGE          = 1 << 18;
    PackageManager.FLAG_SUPPORTS_XLARGE_SCREENS   = 1 << 19;
    PackageManager.FLAG_LARGE_HEAP                = 1 << 20;
    PackageManager.FLAG_STOPPED                   = 1 << 21;
    PackageManager.FLAG_SUPPORTS_RTL              = 1 << 22;
    PackageManager.FLAG_INSTALLED                 = 1 << 23;
    PackageManager.FLAG_IS_DATA_ONLY              = 1 << 24;
    PackageManager.FLAG_BLOCKED                   = 1 << 27;
    PackageManager.FLAG_CANT_SAVE_STATE           = 1 << 28;
    PackageManager.FLAG_FORWARD_LOCK              = 1 << 29;
    PackageManager.FLAG_PRIVILEGED                = 1 << 30;

    (function() {

        this.getVersionCode = function(packageName) {
            return 0;
        };

        this.getVersionName = function(packageName) {
            return '1.0.0';
        };

        this.hasInstalled = function(packageName) {
            return false;
        };

        this.getInstalledApplications = function(flags, matches) {
            return '[]';
        };

        this.launch = function(packageName) {
        };

        this.install = function(uri) {
        };

    }).call(PackageManager.protype);

    module.exports = PackageManager;

});

