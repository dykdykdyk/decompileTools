define(function(require, exports, module) {

    function DownloadManager() {
    }

    DownloadManager.STATUS_PENDING    = 1 << 0;
    DownloadManager.STATUS_RUNNING    = 1 << 1;
    DownloadManager.STATUS_PAUSED     = 1 << 2;
    DownloadManager.STATUS_SUCCESSFUL = 1 << 3;
    DownloadManager.STATUS_FAILED     = 1 << 4;

    (function() {

        var $id = 0;

        this.enqueue = function(uri, sjson) {
            return ++($id);
        };

        this.getLocalUriForDownloadedFile = function(id) {
            return 'file:///fakedrive/downloadfile-' + id;
        };

        this.getUriForDownloadedFile = function(id) {
            return 'file:///fakedrive/downloadfile-' + id;
        };

        this.getMimeTypeForDownloadedFile = function(id) {
            return '*/*';
        };

        this.getStatusForDownloadedFile = function(id) {
            return -1;
        };

        this.getTotalSizeForDownloadedFile = function(id) {
            return -1;
        };

        this.getBytesDownloadedSoFarForDownloadedFile = function(id) {
            return -1;
        };

        this.remove = function(ids) {
            return 0;
        };

        this.queryByIds = function(ids, foreach) {
        };

        this.queryByStatus = function(status, foreach) {
        };

    }).call(DownloadManager.protype);

    module.exports = DownloadManager;

});

